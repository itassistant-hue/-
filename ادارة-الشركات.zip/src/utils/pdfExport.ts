import jsPDF from 'jspdf';
import html2canvas from 'html2canvas-pro';
import autoTable from 'jspdf-autotable';
import { REPORT_EXPORT_FIELDS, ReportExportFieldKey, ReportQueryResult } from '../types/reports';

export async function generateReportPdf(
  reportData: ReportQueryResult,
  selectedFields: ReportExportFieldKey[],
  isArabic: boolean = false
): Promise<void> {
  const activeFields = REPORT_EXPORT_FIELDS.filter((f) => selectedFields.includes(f.key));
  const tableData: any[] = reportData.data || reportData.tasks || [];
  const totalCount = reportData.filteredCount ?? tableData.length;

  const title = isArabic
    ? 'تقرير المهام والمؤشرات التشغيلية للمجموعة'
    : 'Enterprise Operations & Tasks Governance Report';
  const systemName = isArabic
    ? 'المنظومة المركزية لإدارة حوكمة الشركات والمهام'
    : 'Central Enterprise Holding Governance Platform';
  const genDate = new Date().toLocaleString(isArabic ? 'ar-SA' : 'en-US');
  const genBy = reportData.generatedBy?.fullName || 'Administrator';
  const compScope = reportData.appliedFilters?.companyName || (isArabic ? 'كافة الشركات التابعة' : 'All Authorized Companies');

  // Summary counts
  const completedCount = reportData.summary?.completedTasks ?? tableData.filter((t: any) => t.status === 'completed').length;
  const inProgressCount = reportData.summary?.inProgressTasks ?? tableData.filter((t: any) => t.status === 'in_progress').length;
  const delayedCount = reportData.summary?.delayedTasks ?? tableData.filter((t: any) => t.status === 'delayed').length;
  const overdueCount = reportData.summary?.overdueTasks ?? tableData.filter((t: any) => t.isOverdue || (t.dueDate && t.status !== 'completed' && new Date(t.dueDate) < new Date())).length;
  const completionRate = reportData.summary?.completionRate ?? (totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0);

  // Status and Priority helper labels
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'completed':
        return `<span style="display: inline-block; padding: 3px 8px; border-radius: 6px; background-color: #d1fae5; color: #065f46; font-weight: bold; font-size: 11px;">${isArabic ? 'مكتملة' : 'Completed'}</span>`;
      case 'in_progress':
        return `<span style="display: inline-block; padding: 3px 8px; border-radius: 6px; background-color: #dbeafe; color: #1e40af; font-weight: bold; font-size: 11px;">${isArabic ? 'قيد التنفيذ' : 'In Progress'}</span>`;
      case 'delayed':
        return `<span style="display: inline-block; padding: 3px 8px; border-radius: 6px; background-color: #ffe4e6; color: #9f1239; font-weight: bold; font-size: 11px;">${isArabic ? 'متأخرة' : 'Delayed'}</span>`;
      case 'paused':
        return `<span style="display: inline-block; padding: 3px 8px; border-radius: 6px; background-color: #fef3c7; color: #92400e; font-weight: bold; font-size: 11px;">${isArabic ? 'متوقفة' : 'Paused'}</span>`;
      case 'cancelled':
        return `<span style="display: inline-block; padding: 3px 8px; border-radius: 6px; background-color: #f1f5f9; color: #475569; font-weight: bold; font-size: 11px;">${isArabic ? 'ملغاة' : 'Cancelled'}</span>`;
      default:
        return `<span style="display: inline-block; padding: 3px 8px; border-radius: 6px; background-color: #f8fafc; color: #334155; font-weight: bold; font-size: 11px; border: 1px solid #cbd5e1;">${isArabic ? 'قيد الانتظار' : 'Pending'}</span>`;
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'vip':
        return `<span style="display: inline-block; padding: 3px 8px; border-radius: 6px; background-color: #ffe4e6; color: #be123c; font-weight: 800; font-size: 11px;">VIP</span>`;
      case 'high':
        return `<span style="display: inline-block; padding: 3px 8px; border-radius: 6px; background-color: #ffedd5; color: #c2410c; font-weight: bold; font-size: 11px;">${isArabic ? 'عالية' : 'High'}</span>`;
      case 'medium':
        return `<span style="display: inline-block; padding: 3px 8px; border-radius: 6px; background-color: #dbeafe; color: #1d4ed8; font-weight: bold; font-size: 11px;">${isArabic ? 'متوسطة' : 'Medium'}</span>`;
      default:
        return `<span style="display: inline-block; padding: 3px 8px; border-radius: 6px; background-color: #f1f5f9; color: #475569; font-weight: normal; font-size: 11px;">${isArabic ? 'منخفضة' : 'Low'}</span>`;
    }
  };

  // Helper for cell content
  const formatCellValue = (row: any, key: ReportExportFieldKey): string => {
    switch (key) {
      case 'taskCode':
        return `<span style="font-family: monospace; font-weight: bold; color: #1d4ed8;">${row.taskCode || row.id || '-'}</span>`;
      case 'title':
        return `<span style="font-weight: 600; color: #0f172a;">${row.title || '-'}</span>`;
      case 'company':
      case 'companyName': {
        const comp = isArabic ? (row.companyNameAr || row.company?.nameAr || row.companyName || row.company?.nameEn) : (row.companyNameEn || row.company?.nameEn || row.companyName);
        return `<span style="font-weight: 600; color: #1e293b;">${comp || '-'}</span>`;
      }
      case 'status':
        return getStatusBadge(row.status);
      case 'priority':
        return getPriorityBadge(row.priority);
      case 'assignedTo':
      case 'assigneeName': {
        const user = isArabic ? (row.assignedToNameAr || row.assignedTo?.fullNameAr || row.assignedToName || row.assignedTo?.fullName) : (row.assignedToName || row.assignedTo?.fullName);
        return `<span style="color: #334155;">${user || (isArabic ? 'غير محدد' : 'Unassigned')}</span>`;
      }
      case 'creator':
      case 'creatorName': {
        const c = isArabic ? (row.creatorNameAr || row.creator?.fullNameAr || row.creatorName || row.creator?.fullName) : (row.creatorName || row.creator?.fullName);
        return `<span style="color: #475569;">${c || 'System'}</span>`;
      }
      case 'completionRate': {
        const prog = row.progress ?? row.completionRate ?? (row.status === 'completed' ? 100 : 0);
        return `<div style="display: flex; align-items: center; gap: 6px;">
          <div style="flex: 1; height: 7px; background: #e2e8f0; border-radius: 4px; overflow: hidden; min-width: 50px;">
            <div style="width: ${prog}%; height: 100%; background: #2563eb;"></div>
          </div>
          <span style="font-size: 11px; font-weight: bold; font-family: monospace;">${prog}%</span>
        </div>`;
      }
      case 'dueDate': {
        const isOver = row.daysOverdue > 0 || (row.dueDate && row.status !== 'completed' && new Date(row.dueDate) < new Date());
        return `<span style="font-family: monospace; ${isOver ? 'color: #e11d48; font-weight: bold;' : 'color: #334155;'}">${row.dueDate || '-'}</span>`;
      }
      case 'startDate':
        return `<span style="font-family: monospace; color: #475569;">${row.startDate || '-'}</span>`;
      case 'completionDate':
        return `<span style="font-family: monospace; color: #475569;">${row.completionDate || '-'}</span>`;
      case 'estimatedHours':
        return row.estimatedHours ? `${row.estimatedHours}h` : '-';
      case 'actualHours':
        return row.actualHours ? `${row.actualHours}h` : '-';
      case 'statusReason':
        return row.statusReason ? `<span style="font-size: 11px; color: #64748b;">${row.statusReason}</span>` : '-';
      case 'description':
        return row.description ? `<span style="font-size: 11px; color: #475569;">${row.description}</span>` : '-';
      case 'createdAt':
        return row.createdAt ? new Date(row.createdAt).toLocaleDateString() : '-';
      case 'updatedAt':
        return row.updatedAt ? new Date(row.updatedAt).toLocaleDateString() : '-';
      default: {
        const val = row[key];
        if (val === null || val === undefined) return '-';
        if (typeof val === 'object') return JSON.stringify(val);
        return String(val);
      }
    }
  };

  // Create an off-screen yet DOM-measurable container
  const container = document.createElement('div');
  container.id = 'pdf-render-export-container';
  container.style.position = 'fixed';
  container.style.top = '0';
  container.style.left = '0';
  container.style.zIndex = '-999999';
  container.style.width = '1180px';
  container.style.backgroundColor = '#ffffff';
  container.style.padding = '36px 40px';
  container.style.fontFamily = "'Segoe UI', Tahoma, Arial, 'Noto Sans Arabic', sans-serif";
  container.style.color = '#0f172a';
  container.style.boxSizing = 'border-box';
  container.style.opacity = '1';
  container.style.pointerEvents = 'none';
  container.dir = isArabic ? 'rtl' : 'ltr';

  container.innerHTML = `
    <!-- Header Section -->
    <div style="border-bottom: 2px solid #0f172a; padding-bottom: 18px; margin-bottom: 20px;">
      <div style="display: flex; justify-content: space-between; align-items: flex-start;">
        <div>
          <div style="font-size: 12px; font-weight: bold; color: #2563eb; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 4px;">
            ${systemName}
          </div>
          <h1 style="font-size: 22px; font-weight: 900; color: #0f172a; margin: 0 0 6px 0;">
            ${title}
          </h1>
          <div style="font-size: 12px; color: #64748b;">
            ${isArabic ? 'نطاق الشركات:' : 'Scope:'} <strong style="color: #1e293b;">${compScope}</strong> | 
            ${isArabic ? 'المسؤول:' : 'Author:'} <strong style="color: #1e293b;">${genBy}</strong>
          </div>
        </div>
        <div style="text-align: ${isArabic ? 'left' : 'right'}; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 10px 14px;">
          <div style="font-size: 11px; color: #64748b;">${isArabic ? 'تاريخ ووقت الإصدار' : 'Issue Date & Time'}</div>
          <div style="font-size: 13px; font-weight: bold; color: #0f172a; font-family: monospace; margin-top: 2px;">${genDate}</div>
          <div style="font-size: 11px; color: #2563eb; font-weight: bold; margin-top: 4px;">${isArabic ? 'إجمالي السجلات:' : 'Total Records:'} ${totalCount}</div>
        </div>
      </div>
    </div>

    <!-- Summary KPI Cards -->
    <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; margin-bottom: 24px;">
      <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 10px; padding: 12px; text-align: center;">
        <div style="font-size: 11px; color: #64748b; font-weight: 600;">${isArabic ? 'إجمالي المهام' : 'Total Tasks'}</div>
        <div style="font-size: 20px; font-weight: 900; color: #0f172a; margin-top: 2px;">${totalCount}</div>
      </div>
      <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 10px; padding: 12px; text-align: center;">
        <div style="font-size: 11px; color: #166534; font-weight: 600;">${isArabic ? 'مكتملة' : 'Completed'}</div>
        <div style="font-size: 20px; font-weight: 900; color: #15803d; margin-top: 2px;">${completedCount}</div>
      </div>
      <div style="background: #eff6ff; border: 1px solid #bfdbfe; border-radius: 10px; padding: 12px; text-align: center;">
        <div style="font-size: 11px; color: #1e40af; font-weight: 600;">${isArabic ? 'قيد التنفيذ' : 'In Progress'}</div>
        <div style="font-size: 20px; font-weight: 900; color: #2563eb; margin-top: 2px;">${inProgressCount}</div>
      </div>
      <div style="background: #fff1f2; border: 1px solid #fecdd3; border-radius: 10px; padding: 12px; text-align: center;">
        <div style="font-size: 11px; color: #9f1239; font-weight: 600;">${isArabic ? 'متأخرة / حرجة' : 'Delayed'}</div>
        <div style="font-size: 20px; font-weight: 900; color: #e11d48; margin-top: 2px;">${delayedCount || overdueCount}</div>
      </div>
      <div style="background: #faf5ff; border: 1px solid #e9d5ff; border-radius: 10px; padding: 12px; text-align: center;">
        <div style="font-size: 11px; color: #6b21a8; font-weight: 600;">${isArabic ? 'معدل الإنجاز العام' : 'Completion Rate'}</div>
        <div style="font-size: 20px; font-weight: 900; color: #7e22ce; margin-top: 2px;">${completionRate}%</div>
      </div>
    </div>

    <!-- Records Table -->
    <table style="width: 100%; border-collapse: collapse; font-size: 12px; text-align: ${isArabic ? 'right' : 'left'};">
      <thead>
        <tr style="background-color: #1e293b; color: #ffffff;">
          ${activeFields
            .map(
              (f) =>
                `<th style="padding: 10px 12px; border: 1px solid #334155; font-size: 11px; font-weight: 700; white-space: nowrap;">${
                  isArabic ? f.labelAr : f.labelEn
                }</th>`
            )
            .join('')}
        </tr>
      </thead>
      <tbody>
        ${tableData
          .map((row: any, i: number) => {
            const bg = i % 2 === 0 ? '#ffffff' : '#f8fafc';
            return `<tr style="background-color: ${bg}; border-bottom: 1px solid #e2e8f0;">
            ${activeFields
              .map(
                (f) =>
                  `<td style="padding: 10px 12px; border: 1px solid #e2e8f0; vertical-align: middle;">
                    ${formatCellValue(row, f.key)}
                  </td>`
              )
              .join('')}
          </tr>`;
          })
          .join('')}
      </tbody>
    </table>

    <!-- Document Stamp & Footer -->
    <div style="margin-top: 28px; padding-top: 14px; border-top: 1px solid #cbd5e1; display: flex; justify-content: space-between; align-items: center; font-size: 11px; color: #64748b;">
      <div>${isArabic ? 'وثيقة رسمية معتمدة ومسجلة بسجل التدقيق الرقمي للنظام' : 'Official Certified Governance Document with Audit Verification'}</div>
      <div style="font-family: monospace;">${isArabic ? 'ختم رقمي معتمد' : 'Digital Verification Seal: VERIFIED'}</div>
    </div>
  `;

  document.body.appendChild(container);

  try {
    // Wait slightly to ensure any fonts / layout settle
    await new Promise((resolve) => setTimeout(resolve, 80));

    const canvas = await html2canvas(container, {
      scale: 2, // 2x sharp Retina quality
      useCORS: true,
      logging: false,
      backgroundColor: '#ffffff',
      windowWidth: 1200,
    });

    const imgData = canvas.toDataURL('image/jpeg', 0.95);
    const pdf = new jsPDF({
      orientation: 'landscape',
      unit: 'pt',
      format: 'a4',
    });

    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const imgWidth = pageWidth;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;

    let heightLeft = imgHeight;
    let position = 0;

    // First Page
    pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight, undefined, 'FAST');
    heightLeft -= pageHeight;

    // Subsequent Pages if long table
    while (heightLeft > 5) {
      position -= pageHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight, undefined, 'FAST');
      heightLeft -= pageHeight;
    }

    const timestamp = new Date().toISOString().slice(0, 10);
    pdf.save(`Operations_Report_${timestamp}.pdf`);
  } catch (err) {
    console.warn('html2canvas-pro rendering issue, falling back to direct table PDF generation:', err);
    fallbackAutoTablePdf(reportData, selectedFields, isArabic);
  } finally {
    if (document.body.contains(container)) {
      document.body.removeChild(container);
    }
  }
}

function fallbackAutoTablePdf(
  reportData: ReportQueryResult,
  selectedFields: ReportExportFieldKey[],
  isArabic: boolean = false
) {
  const activeFields = REPORT_EXPORT_FIELDS.filter((f) => selectedFields.includes(f.key));
  const tableData: any[] = reportData.data || reportData.tasks || [];
  const pdf = new jsPDF({
    orientation: 'landscape',
    unit: 'pt',
    format: 'a4',
  });

  const title = isArabic
    ? 'تقرير المهام والمؤشرات التشغيلية للمجموعة'
    : 'Enterprise Operations & Tasks Governance Report';
  const genDate = new Date().toLocaleString(isArabic ? 'ar-SA' : 'en-US');
  const genBy = reportData.generatedBy?.fullName || 'Administrator';

  pdf.setFontSize(14);
  pdf.text(title, 40, 36);
  pdf.setFontSize(9);
  pdf.text(`${isArabic ? 'التاريخ:' : 'Date:'} ${genDate} | ${isArabic ? 'المسؤول:' : 'Author:'} ${genBy} | ${isArabic ? 'الإجمالي:' : 'Total:'} ${tableData.length}`, 40, 52);

  const head = [activeFields.map((f) => (isArabic ? f.labelAr : f.labelEn))];
  const body = tableData.map((row: any) =>
    activeFields.map((f) => {
      if (f.key === 'company' || f.key === 'companyName') {
        return isArabic
          ? row.companyNameAr || row.company?.nameAr || row.companyName || row.company?.nameEn || '-'
          : row.companyNameEn || row.company?.nameEn || row.companyName || '-';
      }
      if (f.key === 'assignedTo' || f.key === 'assigneeName') {
        return isArabic
          ? row.assignedToNameAr || row.assignedTo?.fullNameAr || row.assignedToName || row.assignedTo?.fullName || (isArabic ? 'غير محدد' : 'Unassigned')
          : row.assignedToName || row.assignedTo?.fullName || 'Unassigned';
      }
      if (f.key === 'status') {
        const s = row.status;
        if (s === 'completed') return isArabic ? 'مكتملة' : 'Completed';
        if (s === 'in_progress') return isArabic ? 'قيد التنفيذ' : 'In Progress';
        if (s === 'delayed') return isArabic ? 'متأخرة' : 'Delayed';
        if (s === 'paused') return isArabic ? 'متوقفة' : 'Paused';
        if (s === 'cancelled') return isArabic ? 'ملغاة' : 'Cancelled';
        return isArabic ? 'قيد الانتظار' : 'Pending';
      }
      if (f.key === 'priority') {
        const p = row.priority;
        if (p === 'vip') return 'VIP';
        if (p === 'high') return isArabic ? 'عالية' : 'High';
        if (p === 'medium') return isArabic ? 'متوسطة' : 'Medium';
        return isArabic ? 'منخفضة' : 'Low';
      }
      if (f.key === 'completionRate') {
        const prog = row.progress ?? row.completionRate ?? (row.status === 'completed' ? 100 : 0);
        return `${prog}%`;
      }
      const val = row[f.key];
      if (val === null || val === undefined) return '-';
      if (typeof val === 'object') return JSON.stringify(val);
      return String(val);
    })
  );

  autoTable(pdf, {
    head,
    body,
    startY: 65,
    styles: {
      fontSize: 8,
      cellPadding: 4,
    },
    headStyles: {
      fillColor: [30, 41, 59],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
    },
    alternateRowStyles: {
      fillColor: [248, 250, 252],
    },
  });

  const timestamp = new Date().toISOString().slice(0, 10);
  pdf.save(`Operations_Report_${timestamp}.pdf`);
}



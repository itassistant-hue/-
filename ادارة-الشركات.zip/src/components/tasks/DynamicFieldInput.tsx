import React, { useState } from 'react';
import { CustomField } from '../../types/database';
import { User, Company } from '../../types/database';
import { useI18n } from '../../i18n/I18nContext';
import { Upload, Edit3, ListFilter, Plus } from 'lucide-react';

interface DynamicFieldInputProps {
  field: CustomField;
  value: any;
  onChange: (value: any) => void;
  users?: User[];
  companies?: Company[];
}

export const DynamicFieldInput: React.FC<DynamicFieldInputProps> = ({
  field,
  value,
  onChange,
  users = [],
  companies = [],
}) => {
  const { language } = useI18n();
  const isAr = language === 'ar';
  const label = isAr ? field.nameAr : field.nameEn;
  const inputId = `custom-field-${field.fieldKey}`;

  const getOptVal = (opt: any): string => (typeof opt === 'object' && opt !== null ? opt.value : String(opt));
  const getOptLabel = (opt: any): string => {
    if (typeof opt === 'object' && opt !== null) {
      return isAr ? (opt.labelAr || opt.labelEn || opt.value) : (opt.labelEn || opt.labelAr || opt.value);
    }
    return String(opt);
  };

  // State to track manual write-in custom mode for dropdowns & radios
  const [isCustomMode, setIsCustomMode] = useState(() => {
    if ((field.type === 'dropdown' || field.type === 'radio') && value) {
      const known = (field.options || []).map((o) => getOptVal(o));
      return !known.includes(String(value));
    }
    return false;
  });

  const [customInputValue, setCustomInputValue] = useState(value || '');
  const [multiCustomInput, setMultiCustomInput] = useState('');
  const [isAddingMultiCustom, setIsAddingMultiCustom] = useState(false);

  const renderControl = () => {
    switch (field.type) {
      case 'text':
        return (
          <input
            type="text"
            id={inputId}
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            required={field.required}
            className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-hidden bg-white"
            placeholder={isAr ? `أدخل ${label}...` : `Enter ${label}...`}
          />
        );

      case 'long_text':
        return (
          <textarea
            id={inputId}
            rows={3}
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            required={field.required}
            className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-hidden bg-white"
            placeholder={isAr ? `أدخل ${label}...` : `Enter ${label}...`}
          />
        );

      case 'number':
        return (
          <input
            type="number"
            id={inputId}
            value={value !== undefined && value !== null ? value : ''}
            onChange={(e) => onChange(e.target.value === '' ? '' : Number(e.target.value))}
            required={field.required}
            className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-hidden bg-white"
          />
        );

      case 'date':
        return (
          <input
            type="date"
            id={inputId}
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            required={field.required}
            className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-hidden bg-white"
          />
        );

      case 'date_time':
        return (
          <input
            type="datetime-local"
            id={inputId}
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            required={field.required}
            className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-hidden bg-white"
          />
        );

      case 'dropdown':
        if (isCustomMode) {
          return (
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  id={inputId}
                  autoFocus
                  value={customInputValue || ''}
                  onChange={(e) => {
                    setCustomInputValue(e.target.value);
                    onChange(e.target.value);
                  }}
                  required={field.required}
                  placeholder={isAr ? '✍️ اكتب القيمة المخصصة هنا...' : '✍️ Write custom value here...'}
                  className="flex-1 px-3.5 py-2 text-sm border-2 border-blue-500 rounded-lg focus:ring-2 focus:ring-blue-500 outline-hidden bg-white shadow-2xs font-medium"
                />
                <button
                  type="button"
                  onClick={() => {
                    setIsCustomMode(false);
                    onChange('');
                  }}
                  className="px-3 py-2 text-xs font-semibold rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-300 flex items-center gap-1 shrink-0"
                  title={isAr ? 'العودة للاختيار من القائمة' : 'Back to dropdown list'}
                >
                  <ListFilter className="w-3.5 h-3.5 text-blue-600" />
                  <span>{isAr ? 'القائمة' : 'List'}</span>
                </button>
              </div>
              <span className="text-[11px] text-blue-600 font-medium block">
                {isAr ? 'نمط الكتابة اليدوية المخصصة مفعل' : 'Custom manual write-in mode active'}
              </span>
            </div>
          );
        }

        return (
          <div className="flex items-center gap-2">
            <select
              id={inputId}
              value={value || ''}
              onChange={(e) => {
                if (e.target.value === '__CUSTOM__') {
                  setIsCustomMode(true);
                  setCustomInputValue('');
                  onChange('');
                } else {
                  onChange(e.target.value);
                }
              }}
              required={field.required}
              className="flex-1 px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-hidden bg-white"
            >
              <option value="">{isAr ? '-- اختر --' : '-- Select --'}</option>
              {(field.options || []).map((opt) => {
                const val = getOptVal(opt);
                const lbl = getOptLabel(opt);
                return (
                  <option key={val} value={val}>
                    {lbl}
                  </option>
                );
              })}
              <option value="__CUSTOM__" className="font-bold text-blue-600">
                {isAr ? '✍️ + إضافة مخصص (كتابة يدوية)...' : '✍️ + Add custom (write manually)...'}
              </option>
            </select>

            <button
              type="button"
              onClick={() => {
                setIsCustomMode(true);
                setCustomInputValue(value || '');
              }}
              className="px-2.5 py-2 text-xs font-semibold rounded-lg bg-slate-100 text-slate-700 hover:bg-blue-50 hover:text-blue-700 border border-slate-300 flex items-center gap-1 shrink-0"
              title={isAr ? 'كتابة خيار مخصص يدوي' : 'Write custom option'}
            >
              <Edit3 className="w-3.5 h-3.5 text-blue-600" />
              <span>{isAr ? 'مخصص' : 'Custom'}</span>
            </button>
          </div>
        );

      case 'multi_select': {
        const selectedValues: string[] = Array.isArray(value) ? value : [];
        const toggleOption = (optVal: string) => {
          if (selectedValues.includes(optVal)) {
            onChange(selectedValues.filter((v) => v !== optVal));
          } else {
            onChange([...selectedValues, optVal]);
          }
        };

        const handleAddCustomMulti = () => {
          if (!multiCustomInput.trim()) return;
          const trimmed = multiCustomInput.trim();
          if (!selectedValues.includes(trimmed)) {
            onChange([...selectedValues, trimmed]);
          }
          setMultiCustomInput('');
          setIsAddingMultiCustom(false);
        };

        return (
          <div className="space-y-2 p-2.5 border border-slate-200 rounded-lg bg-slate-50/50">
            <div className="flex flex-wrap gap-2">
              {(field.options || []).map((opt) => {
                const optVal = getOptVal(opt);
                const optLbl = getOptLabel(opt);
                const isChecked = selectedValues.includes(optVal);
                return (
                  <button
                    key={optVal}
                    type="button"
                    id={`${inputId}-${optVal}`}
                    onClick={() => toggleOption(optVal)}
                    className={`px-3 py-1 text-xs rounded-md font-medium border transition-all ${
                      isChecked
                        ? 'bg-blue-600 border-blue-600 text-white shadow-xs'
                        : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    {optLbl}
                  </button>
                );
              })}

              {/* Display custom selected values that are not in predefined options */}
              {selectedValues
                .filter((v) => !(field.options || []).some((opt) => getOptVal(opt) === v))
                .map((custVal) => (
                  <button
                    key={custVal}
                    type="button"
                    onClick={() => toggleOption(custVal)}
                    className="px-3 py-1 text-xs rounded-md font-medium border bg-indigo-600 border-indigo-600 text-white shadow-xs flex items-center gap-1"
                  >
                    <span>✍️ {custVal}</span>
                    <span className="text-white/80 font-bold ms-1">×</span>
                  </button>
                ))}
            </div>

            {/* Custom Add Trigger */}
            <div className="pt-1.5 border-t border-slate-200 flex items-center gap-2">
              {isAddingMultiCustom ? (
                <div className="flex items-center gap-2 w-full">
                  <input
                    type="text"
                    value={multiCustomInput || ''}
                    onChange={(e) => setMultiCustomInput(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddCustomMulti();
                      }
                    }}
                    placeholder={isAr ? 'اكتب الخيار المخصص...' : 'Write custom item...'}
                    className="px-2.5 py-1 text-xs border border-blue-500 rounded-md focus:ring-1 focus:ring-blue-500 outline-hidden bg-white flex-1"
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={handleAddCustomMulti}
                    className="px-2.5 py-1 text-xs font-bold rounded-md bg-blue-600 text-white hover:bg-blue-700"
                  >
                    {isAr ? 'إضافة' : 'Add'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setIsAddingMultiCustom(false)}
                    className="px-2 py-1 text-xs text-slate-600 hover:bg-slate-200 rounded-md"
                  >
                    {isAr ? 'إلغاء' : 'Cancel'}
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => setIsAddingMultiCustom(true)}
                  className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue-600 hover:text-blue-800"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{isAr ? '+ إضافة مخصص (كتابة يدوية)' : '+ Add custom (write manually)'}</span>
                </button>
              )}
            </div>
          </div>
        );
      }

      case 'checkbox':
        return (
          <label className="flex items-center gap-3 cursor-pointer py-1">
            <input
              type="checkbox"
              id={inputId}
              checked={!!value}
              onChange={(e) => onChange(e.target.checked)}
              className="w-4 h-4 text-blue-600 border-slate-300 rounded-sm focus:ring-blue-500"
            />
            <span className="text-sm font-medium text-slate-700">
              {value ? (isAr ? 'نعم / مفعل' : 'Yes / Active') : (isAr ? 'لا / غير مفعل' : 'No / Inactive')}
            </span>
          </label>
        );

      case 'radio': {
        const isCustomSelected = isCustomMode || (value && !(field.options || []).some((opt) => getOptVal(opt) === value));
        return (
          <div className="space-y-2 py-1">
            <div className="flex flex-wrap gap-4">
              {(field.options || []).map((opt) => {
                const optVal = getOptVal(opt);
                const optLbl = getOptLabel(opt);
                return (
                  <label key={optVal} className="flex items-center gap-2 cursor-pointer text-sm text-slate-700">
                    <input
                      type="radio"
                      name={field.fieldKey}
                      value={optVal || ''}
                      checked={value === optVal && !isCustomMode}
                      onChange={() => {
                        setIsCustomMode(false);
                        onChange(optVal);
                      }}
                      className="w-4 h-4 text-blue-600 border-slate-300 focus:ring-blue-500"
                    />
                    <span>{optLbl}</span>
                  </label>
                );
              })}

              <label className="flex items-center gap-2 cursor-pointer text-sm text-blue-700 font-semibold">
                <input
                  type="radio"
                  name={field.fieldKey}
                  value="__CUSTOM__"
                  checked={isCustomSelected}
                  onChange={() => {
                    setIsCustomMode(true);
                    onChange(customInputValue || '');
                  }}
                  className="w-4 h-4 text-blue-600 border-slate-300 focus:ring-blue-500"
                />
                <span>{isAr ? '✍️ مخصص (كتابة يدوية)' : '✍️ Custom (write manually)'}</span>
              </label>
            </div>

            {isCustomSelected && (
              <div className="pt-1">
                <input
                  type="text"
                  value={customInputValue || ''}
                  onChange={(e) => {
                    setCustomInputValue(e.target.value);
                    onChange(e.target.value);
                  }}
                  placeholder={isAr ? '✍️ اكتب القيمة المخصصة هنا...' : '✍️ Enter custom value...'}
                  className="w-full max-w-sm px-3.5 py-1.5 text-xs border-2 border-blue-500 rounded-lg focus:ring-2 focus:ring-blue-500 outline-hidden bg-white shadow-2xs font-medium"
                  autoFocus
                />
              </div>
            )}
          </div>
        );
      }

      case 'user_selector':
        return (
          <select
            id={inputId}
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            required={field.required}
            className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-hidden bg-white"
          >
            <option value="">{isAr ? '-- حدد المستخدم --' : '-- Select User --'}</option>
            {users.map((u) => (
              <option key={u.id} value={u.id}>
                {isAr && u.fullNameAr ? u.fullNameAr : u.fullName} ({u.email})
              </option>
            ))}
          </select>
        );

      case 'company_selector':
        return (
          <select
            id={inputId}
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            required={field.required}
            className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-hidden bg-white"
          >
            <option value="">{isAr ? '-- حدد الشركة --' : '-- Select Company --'}</option>
            {companies.map((c) => (
              <option key={c.id} value={c.id}>
                {isAr && c.nameAr ? c.nameAr : c.nameEn} ({c.code})
              </option>
            ))}
          </select>
        );

      case 'file_upload':
        return (
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <label
                htmlFor={inputId}
                className="cursor-pointer inline-flex items-center gap-2 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 transition-colors"
              >
                <Upload className="w-3.5 h-3.5 text-slate-500" />
                <span>{isAr ? 'اختيار ملف مرفق' : 'Browse File'}</span>
              </label>
              <input
                type="file"
                id={inputId}
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    onChange(file.name);
                  }
                }}
              />
              <span className="text-xs text-slate-600 truncate max-w-xs">
                {value ? String(value) : (isAr ? 'لم يتم اختيار ملف' : 'No file selected')}
              </span>
            </div>
          </div>
        );

      default:
        return (
          <input
            type="text"
            id={inputId}
            value={value || ''}
            onChange={(e) => onChange(e.target.value)}
            className="w-full px-3.5 py-2 text-sm border border-slate-300 rounded-lg bg-white"
          />
        );
    }
  };

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between">
        <label htmlFor={inputId} className="block text-xs font-semibold text-slate-700">
          {label}
          {field.required && <span className="text-red-500 ms-1">*</span>}
        </label>
        <span className="text-[10px] font-mono text-slate-600 uppercase">
          {field.type}
        </span>
      </div>
      {renderControl()}
    </div>
  );
};

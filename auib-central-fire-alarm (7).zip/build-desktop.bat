@echo off
title BWE Communication Monitor - Windows Desktop Builder
cls

echo ====================================================================
echo   BWE Communication Monitor - Windows Desktop Application Builder
echo ====================================================================
echo.

:: Check if Node.js is installed
where node >nul 2>nul
if errorlevel 1 goto NO_NODE

echo [✓] Node.js is installed.
echo.
echo [1/3] Installing project dependencies (this may take a minute)...
echo --------------------------------------------------------------------
call npm install
if errorlevel 1 goto FAIL_INSTALL

echo.
echo [2/3] Compiling and building web assets...
echo --------------------------------------------------------------------
call npm run build
if errorlevel 1 goto FAIL_BUILD

echo.
echo [3/3] Packing and generating Installable Windows Setup (.exe)...
echo --------------------------------------------------------------------
call npm run electron:build
if errorlevel 1 goto FAIL_PACK

echo.
echo ====================================================================
echo   [SUCCESS] BUILD COMPLETED SUCCESSFULLY!
echo.
echo   Please open the 'dist-desktop' folder to find your compiled 
echo   Installable Windows Setup application (.exe).
echo ====================================================================
echo.
pause
exit /b

:NO_NODE
echo [ERROR] Node.js is not installed on your system!
echo Please download and install Node.js from: https://nodejs.org
echo After installing, please restart this build file.
echo.
pause
exit /b

:FAIL_INSTALL
echo [ERROR] Failed to install dependencies. Please check your internet connection.
echo.
pause
exit /b

:FAIL_BUILD
echo [ERROR] Failed to build the web assets.
echo.
pause
exit /b

:FAIL_PACK
echo [ERROR] Failed to pack into installable setup executable.
echo.
pause
exit /b

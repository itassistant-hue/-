const { app, BrowserWindow, dialog } = require('electron');
const path = require('path');
const http = require('http');

let mainWindow;

// Determine environment
const isDev = process.env.NODE_ENV === 'development' || !app.isPackaged;

function startExpressServer() {
  if (!isDev) {
    // In production, we start the bundled server in production mode
    try {
      process.env.NODE_ENV = 'production';
      process.env.ELECTRON_APP_PATH = app.getAppPath();
      process.env.ELECTRON_USER_DATA_PATH = app.getPath('userData');
      
      const serverPath = path.join(app.getAppPath(), 'dist', 'server.cjs');
      console.log('Spawning BWE local background system service at:', serverPath);
      require(serverPath);
    } catch (e) {
      console.error('Failed to spawn integrated backend server:', e);
      dialog.showErrorBox(
        'خطأ في تشغيل خادم النظام الخلفي / Backend Server Launch Failure',
        `فشل بدء تشغيل الخادم الخلفي المدمج للتطبيق. يرجى محاولة تشغيل البرنامج كمسؤول.\n\nالتفاصيل (Error details):\n${e.stack || e.message || e}`
      );
    }
  }
}

function checkServerReady(url, callback) {
  const req = http.get(url, (res) => {
    // Both 200 OK and 404/others from a running express count as server active
    if (res.statusCode) {
      callback(true);
    } else {
      callback(false);
    }
  });
  req.on('error', () => {
    callback(false);
  });
  req.end();
}

function waitForServerAndLoad() {
  const serverUrl = 'http://localhost:3000';
  let checks = 0;
  
  const checkInterval = setInterval(() => {
    checks++;
    checkServerReady(serverUrl, (isReady) => {
      if (isReady) {
        clearInterval(checkInterval);
        mainWindow.loadURL(serverUrl);
      }
      // Fail-safe timeout to show fallback if server takes > 10s
      if (checks > 50) {
        clearInterval(checkInterval);
        mainWindow.loadURL(serverUrl);
      }
    });
  }, 200);
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 720,
    title: "نظام البنك المركزي العراقي للمراقبة والإنذار المركزي",
    autoHideMenuBar: true,
    backgroundColor: '#020617', // Match slate-950 dark background instantly
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true
    }
  });

  // Turn off window top standard menus for a native software look/feel
  mainWindow.setMenuBarVisibility(false);

  // Enable F12 and Ctrl+Shift+I shortcuts to toggle Developer Tools
  mainWindow.webContents.on('before-input-event', (event, input) => {
    if (input.key === 'F12' || (input.control && input.shift && input.key.toLowerCase() === 'i')) {
      mainWindow.webContents.toggleDevTools();
      event.preventDefault();
    }
  });

  if (isDev) {
    mainWindow.webContents.openDevTools();
  }

  // Show a blank loading state while waiting for the express port to open
  waitForServerAndLoad();

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// Start backend Express service
startExpressServer();

app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

package com.restaurant.signage

import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * مسؤول عن بناء اتصال Retrofit بالسيرفر المحلي.
 *
 * !! هام جدًا !!
 * يجب تغيير SERVER_IP ليطابق عنوان الـ IP الثابت لحاسوب السيرفر داخل شبكة المطعم.
 * راجع تعليمات ضبط IP ثابت في نهاية هذا الدليل.
 */
object ApiClient {

    // 👇 عدّل هذا العنوان ليطابق IP السيرفر الثابت في شبكتك المحلية
    private const val SERVER_IP = "192.168.1.100"
    private const val SERVER_PORT = "3000"

    const val BASE_URL = "http://$SERVER_IP:$SERVER_PORT/"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    val service: ApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }
}

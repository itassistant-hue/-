package com.restaurant.signage

import com.google.gson.annotations.SerializedName

/**
 * يمثل عنصرًا واحدًا في قائمة التشغيل القادمة من السيرفر
 */
data class PlaylistItem(
    @SerializedName("id") val id: Int,
    @SerializedName("name") val name: String,
    @SerializedName("type") val type: String,           // "image" أو "video"
    @SerializedName("durationSeconds") val durationSeconds: Int,
    @SerializedName("url") val url: String               // رابط التحميل الكامل من السيرفر
) {
    fun isVideo() = type == "video"
    fun isImage() = type == "image"

    /** اسم ملف فريد يُستخدم للتخزين المؤقت المحلي، مبني على الرابط لتفادي التعارض */
    fun localFileName(): String {
        val ext = url.substringAfterLast('.', if (isVideo()) "mp4" else "jpg")
        return "media_${id}.${ext}"
    }
}

/** الاستجابة الكاملة القادمة من GET /api/playlist */
data class PlaylistResponse(
    @SerializedName("count") val count: Int,
    @SerializedName("playlist") val playlist: List<PlaylistItem>
)

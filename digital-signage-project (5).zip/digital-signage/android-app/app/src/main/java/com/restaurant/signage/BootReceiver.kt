package com.restaurant.signage

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * يستقبل إشارة BOOT_COMPLETED من النظام فور انتهاء إقلاع جهاز Android TV Box
 * ويقوم بتشغيل MainActivity تلقائيًا دون تدخل بشري.
 *
 * ملاحظة مهمة: على بعض أجهزة TV Box الصينية (مثل تلك المبنية على أنظمة مخصصة)،
 * قد يحتاج المستخدم لتفعيل خيار "Auto-start / التشغيل التلقائي" يدويًا من إعدادات
 * النظام الخاصة بالجهاز (Settings > Apps > Auto-start Manager) لأن بعض الشركات
 * المصنعة تقيّد BOOT_COMPLETED لأسباب تتعلق باستهلاك البطارية (غير منطبق هنا لأنها TV).
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Log.d("BootReceiver", "تم استقبال إشارة الإقلاع - جاري تشغيل تطبيق العرض")

            val launchIntent = Intent(context, MainActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
                )
            }
            context.startActivity(launchIntent)
        }
    }
}

package com.restaurant.signage

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream

/**
 * مسؤول عن تنزيل ملفات الوسائط من السيرفر وحفظها في التخزين الداخلي للجهاز
 * (التخزين الداخلي وليس Cache العادي، لضمان عدم مسحها تلقائيًا من قبل النظام).
 *
 * الهدف: استمرار عرض الإعلانات حتى لو:
 *   - تم إطفاء السيرفر
 *   - انقطعت الشبكة المحلية بالكامل
 *
 * آلية العمل:
 *   1. عند وصول قائمة تشغيل جديدة، نتحقق من كل عنصر: هل هو موجود محليًا مسبقًا؟
 *   2. إن لم يكن موجودًا، يُنزَّل في الخلفية دون إيقاف تشغيل الإعلانات الحالية.
 *   3. نحتفظ دائمًا بآخر قائمة تشغيل صالحة في ملف محلي (playlist_cache.json) لاستخدامها
 *      عند فقدان الاتصال بالسيرفر بالكامل عند إعادة تشغيل الجهاز.
 */
class CacheManager(private val context: Context) {

    private val mediaDir: File by lazy {
        File(context.filesDir, "signage_media").apply { if (!exists()) mkdirs() }
    }

    private val playlistCacheFile: File by lazy {
        File(context.filesDir, "playlist_cache.json")
    }

    private val httpClient = OkHttpClient()

    /** يتحقق مما إذا كان الملف محملاً بالفعل محليًا */
    fun isCached(item: PlaylistItem): Boolean {
        val file = File(mediaDir, item.localFileName())
        return file.exists() && file.length() > 0
    }

    /** يرجع المسار المحلي الكامل للملف المخزن */
    fun getLocalPath(item: PlaylistItem): String {
        return File(mediaDir, item.localFileName()).absolutePath
    }

    /**
     * يقوم بتنزيل ملف وسائط واحد من السيرفر وحفظه محليًا.
     * يعمل على Dispatchers.IO حتى لا يعطّل واجهة العرض.
     */
    suspend fun downloadMedia(item: PlaylistItem): Boolean = withContext(Dispatchers.IO) {
        if (isCached(item)) return@withContext true

        return@withContext try {
            val request = Request.Builder().url(item.url).build()
            val response = httpClient.newCall(request).execute()

            if (!response.isSuccessful) {
                Log.e("CacheManager", "فشل تنزيل ${item.name}: ${response.code}")
                return@withContext false
            }

            val targetFile = File(mediaDir, item.localFileName())
            val tempFile = File(mediaDir, "${item.localFileName()}.tmp")

            response.body?.byteStream()?.use { input ->
                FileOutputStream(tempFile).use { output ->
                    input.copyTo(output)
                }
            }

            // إعادة تسمية بعد اكتمال التنزيل بالكامل لتفادي استخدام ملف ناقص
            tempFile.renameTo(targetFile)
            Log.d("CacheManager", "✅ تم تنزيل وتخزين: ${item.name}")
            true
        } catch (e: Exception) {
            Log.e("CacheManager", "خطأ أثناء تنزيل ${item.name}: ${e.message}")
            false
        }
    }

    /** يحمّل كل عناصر القائمة الجديدة التي لم تُخزَّن بعد، ويحذف الملفات القديمة غير المستخدمة */
    suspend fun syncPlaylist(playlist: List<PlaylistItem>) {
        // تنزيل أي عناصر جديدة
        for (item in playlist) {
            if (!isCached(item)) downloadMedia(item)
        }
        cleanupUnusedFiles(playlist)
        savePlaylistToDisk(playlist)
    }

    /** يحذف الملفات المخزنة التي لم تعد موجودة في قائمة التشغيل الحالية (توفير مساحة) */
    private fun cleanupUnusedFiles(currentPlaylist: List<PlaylistItem>) {
        val validNames = currentPlaylist.map { it.localFileName() }.toSet()
        mediaDir.listFiles()?.forEach { file ->
            if (file.name !in validNames && !file.name.endsWith(".tmp")) {
                file.delete()
                Log.d("CacheManager", "🗑️ حذف ملف غير مستخدم: ${file.name}")
            }
        }
    }

    /** يحفظ نسخة من قائمة التشغيل الحالية بصيغة JSON للاستخدام عند فقدان الاتصال بالكامل */
    private fun savePlaylistToDisk(playlist: List<PlaylistItem>) {
        try {
            val gson = com.google.gson.Gson()
            playlistCacheFile.writeText(gson.toJson(playlist))
        } catch (e: Exception) {
            Log.e("CacheManager", "فشل حفظ نسخة القائمة المحلية: ${e.message}")
        }
    }

    /** يقرأ آخر قائمة تشغيل محفوظة محليًا - تُستخدم عند تعذر الوصول للسيرفر إطلاقًا */
    fun loadPlaylistFromDisk(): List<PlaylistItem> {
        return try {
            if (!playlistCacheFile.exists()) return emptyList()
            val gson = com.google.gson.Gson()
            val json = playlistCacheFile.readText()
            val type = object : com.google.gson.reflect.TypeToken<List<PlaylistItem>>() {}.type
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: Exception) {
            Log.e("CacheManager", "فشل قراءة القائمة المحلية: ${e.message}")
            emptyList()
        }
    }
}

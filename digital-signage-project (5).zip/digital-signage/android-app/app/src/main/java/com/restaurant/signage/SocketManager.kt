package com.restaurant.signage

import android.util.Log
import io.socket.client.IO
import io.socket.client.Socket
import java.net.URISyntaxException

/**
 * يستمع لحدث "playlist-updated" القادم من السيرفر عبر WebSocket (Socket.IO)
 * ليقوم التطبيق بجلب قائمة تشغيل جديدة فورًا دون الحاجة للانتظار حتى دورة الـ Polling التالية.
 */
class SocketManager(
    private val serverUrl: String,
    private val onPlaylistUpdated: () -> Unit
) {
    private var socket: Socket? = null

    fun connect() {
        try {
            socket = IO.socket(serverUrl)
            socket?.on(Socket.EVENT_CONNECT) {
                Log.d("SocketManager", "✅ تم الاتصال بالسيرفر عبر WebSocket")
            }
            socket?.on("playlist-updated") {
                Log.d("SocketManager", "📥 وصل إشعار تحديث قائمة التشغيل")
                onPlaylistUpdated()
            }
            socket?.on(Socket.EVENT_DISCONNECT) {
                Log.d("SocketManager", "⚠️ انقطع اتصال WebSocket - سيتم الاعتماد على Polling")
            }
            socket?.connect()
        } catch (e: URISyntaxException) {
            Log.e("SocketManager", "خطأ في عنوان السيرفر: ${e.message}")
        }
    }

    fun disconnect() {
        socket?.disconnect()
        socket?.off()
    }
}

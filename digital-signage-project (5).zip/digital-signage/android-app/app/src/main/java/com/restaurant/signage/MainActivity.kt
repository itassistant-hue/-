package com.restaurant.signage

import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.ui.PlayerView
import kotlinx.coroutines.*

/**
 * الشاشة الرئيسية والوحيدة في التطبيق: تعرض قائمة التشغيل بحلقة لا نهائية
 * وتدعم الصور والفيديوهات، مع تخزين مؤقت محلي وتحديث تلقائي من السيرفر.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var playerView: PlayerView
    private lateinit var imageView: ImageView
    private lateinit var loadingView: View
    private lateinit var loadingText: TextView
    private lateinit var exoPlayer: ExoPlayer
    private lateinit var cacheManager: CacheManager
    private var socketManager: SocketManager? = null

    private val mainScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val pollingHandler = Handler(Looper.getMainLooper())
    private val imageHandler = Handler(Looper.getMainLooper())

    private var currentPlaylist: List<PlaylistItem> = emptyList()
    private var currentIndex = 0
    private var imageAdvanceRunnable: Runnable? = null

    // فترة الاستعلام الدوري (Polling) عن السيرفر لضمان الحصول على أي تحديث حتى لو انقطع WebSocket
    private val POLLING_INTERVAL_MS = 60_000L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        enableKioskMode()

        playerView = findViewById(R.id.player_view)
        imageView = findViewById(R.id.image_view)
        loadingView = findViewById(R.id.loading_view)
        loadingText = findViewById(R.id.loading_text)

        cacheManager = CacheManager(applicationContext)
        setupExoPlayer()
        setupSocket()

        loadInitialContent()
        startPolling()
    }

    // ---------------------------------------------------------------
    // وضع الشاشة الكاملة (Kiosk Mode): إخفاء شريط الحالة وأزرار التنقل
    // ---------------------------------------------------------------
    private fun enableKioskMode() {
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
        )
        hideSystemUI()
    }

    private fun hideSystemUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.insetsController?.let {
                it.hide(android.view.WindowInsets.Type.statusBars() or android.view.WindowInsets.Type.navigationBars())
                it.systemBarsBehavior = android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_FULLSCREEN
            )
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // إعادة تفعيل الوضع الكامل في كل مرة يستعيد فيها التطبيق التركيز
        // (يحمي من ظهور الأشرطة مؤقتًا عند أي تفاعل غير متوقع)
        if (hasFocus) hideSystemUI()
    }

    // منع الخروج من التطبيق بالخطأ عبر زر الرجوع (وضع Kiosk)
    override fun onBackPressed() {
        // لا شيء - نتجاهل الضغط على زر الرجوع عمدًا
    }

    // ---------------------------------------------------------------
    // إعداد ExoPlayer
    // ---------------------------------------------------------------
    private fun setupExoPlayer() {
        exoPlayer = ExoPlayer.Builder(this).build()
        playerView.player = exoPlayer

        exoPlayer.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(state: Int) {
                // عند انتهاء تشغيل الفيديو الحالي بالكامل، ننتقل للعنصر التالي في القائمة
                if (state == Player.STATE_ENDED) {
                    advanceToNext()
                }
            }
        })
    }

    private fun setupSocket() {
        // نبني عنوان WebSocket من نفس عنوان الـ API الأساسي
        val socketUrl = ApiClient.BASE_URL.trimEnd('/')
        socketManager = SocketManager(socketUrl) {
            // عند وصول إشعار تحديث، نجلب القائمة الجديدة فورًا
            mainScope.launch { fetchAndSyncPlaylist(showLoadingIfEmpty = false) }
        }
        socketManager?.connect()
    }

    // ---------------------------------------------------------------
    // تحميل المحتوى الأولي عند فتح التطبيق
    // ---------------------------------------------------------------
    private fun loadInitialContent() {
        mainScope.launch {
            // أولًا: نحاول عرض أي محتوى محفوظ محليًا فورًا (حتى لو السيرفر غير متاح الآن)
            val cachedPlaylist = cacheManager.loadPlaylistFromDisk()
            if (cachedPlaylist.isNotEmpty()) {
                currentPlaylist = cachedPlaylist.filter { cacheManager.isCached(it) }
                if (currentPlaylist.isNotEmpty()) {
                    loadingView.visibility = View.GONE
                    playCurrentItem()
                }
            }
            // ثم نحاول جلب أحدث نسخة من السيرفر ومزامنتها في الخلفية
            fetchAndSyncPlaylist(showLoadingIfEmpty = currentPlaylist.isEmpty())
        }
    }

    /** يجلب قائمة التشغيل من السيرفر، يزامن التخزين المؤقت، ثم يحدّث العرض الحالي إن لزم */
    private suspend fun fetchAndSyncPlaylist(showLoadingIfEmpty: Boolean) {
        try {
            val response = withContext(Dispatchers.IO) { ApiClient.service.getPlaylist() }
            if (response.isSuccessful) {
                val newPlaylist = response.body()?.playlist ?: emptyList()
                if (newPlaylist.isEmpty()) {
                    Log.w("MainActivity", "قائمة التشغيل من السيرفر فارغة")
                    return
                }

                // مزامنة الملفات (تنزيل الجديد، حذف القديم غير المستخدم) بالخلفية
                cacheManager.syncPlaylist(newPlaylist)

                val isPlaylistChanged = newPlaylist.map { it.id } != currentPlaylist.map { it.id }
                currentPlaylist = newPlaylist

                if (currentPlaylist.isNotEmpty() && (isPlaylistChanged || loadingView.visibility == View.VISIBLE)) {
                    currentIndex = 0
                    loadingView.visibility = View.GONE
                    playCurrentItem()
                }
            }
        } catch (e: Exception) {
            Log.e("MainActivity", "تعذر الاتصال بالسيرفر: ${e.message}")
            if (showLoadingIfEmpty && currentPlaylist.isEmpty()) {
                loadingText.text = "تعذر الاتصال بالسيرفر - جاري إعادة المحاولة..."
            }
            // لا نوقف العرض - إن كانت هناك قائمة محفوظة محليًا ستستمر بالعمل بشكل طبيعي
        }
    }

    // ---------------------------------------------------------------
    // الاستعلام الدوري (Polling) كخطة احتياطية بجانب WebSocket
    // ---------------------------------------------------------------
    private fun startPolling() {
        pollingHandler.postDelayed(object : Runnable {
            override fun run() {
                mainScope.launch { fetchAndSyncPlaylist(showLoadingIfEmpty = false) }
                pollingHandler.postDelayed(this, POLLING_INTERVAL_MS)
            }
        }, POLLING_INTERVAL_MS)
    }

    // ---------------------------------------------------------------
    // منطق التشغيل: عرض العنصر الحالي (صورة أو فيديو) والانتقال التلقائي للتالي
    // ---------------------------------------------------------------
    private fun playCurrentItem() {
        if (currentPlaylist.isEmpty()) return
        val item = currentPlaylist[currentIndex]

        // إلغاء أي مؤقت صورة سابق معلّق
        imageAdvanceRunnable?.let { imageHandler.removeCallbacks(it) }

        if (!cacheManager.isCached(item)) {
            // إن لم يكن الملف جاهزًا محليًا بعد (نادر الحدوث)، ننزّله أولًا دون توقف طويل
            mainScope.launch {
                cacheManager.downloadMedia(item)
                playCurrentItem()
            }
            return
        }

        val localPath = cacheManager.getLocalPath(item)

        if (item.isVideo()) {
            imageView.visibility = View.GONE
            playerView.visibility = View.VISIBLE
            val mediaItem = MediaItem.fromUri(Uri.fromFile(java.io.File(localPath)))
            exoPlayer.setMediaItem(mediaItem)
            exoPlayer.prepare()
            exoPlayer.playWhenReady = true
        } else {
            playerView.visibility = View.GONE
            imageView.visibility = View.VISIBLE
            Glide.with(this).load(java.io.File(localPath)).into(imageView)

            // جدولة الانتقال التلقائي للعنصر التالي بعد مدة العرض المحددة للصورة
            imageAdvanceRunnable = Runnable { advanceToNext() }
            imageHandler.postDelayed(imageAdvanceRunnable!!, item.durationSeconds * 1000L)
        }

        // تحميل العنصر التالي مسبقًا بالخلفية لضمان انتقال سلس بلا فراغ
        preloadNextItem()
    }

    private fun advanceToNext() {
        if (currentPlaylist.isEmpty()) return
        currentIndex = (currentIndex + 1) % currentPlaylist.size
        playCurrentItem()
    }

    private fun preloadNextItem() {
        if (currentPlaylist.size < 2) return
        val nextIndex = (currentIndex + 1) % currentPlaylist.size
        val nextItem = currentPlaylist[nextIndex]
        if (!cacheManager.isCached(nextItem)) {
            mainScope.launch { cacheManager.downloadMedia(nextItem) }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        pollingHandler.removeCallbacksAndMessages(null)
        imageHandler.removeCallbacksAndMessages(null)
        mainScope.cancel()
        socketManager?.disconnect()
        exoPlayer.release()
    }
}

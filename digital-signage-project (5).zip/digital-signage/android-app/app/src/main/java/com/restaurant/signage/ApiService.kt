package com.restaurant.signage

import retrofit2.Response
import retrofit2.http.GET

/**
 * واجهة نداءات الشبكة نحو سيرفر اللافتات الرقمية المحلي
 */
interface ApiService {
    @GET("api/playlist")
    suspend fun getPlaylist(): Response<PlaylistResponse>
}

// app.js - منطق لوحة التحكم (رفع، عرض، إعادة ترتيب، تفعيل/تعطيل، حذف)

const uploadForm = document.getElementById('upload-form');
const fileInput = document.getElementById('file-input');
const durationInput = document.getElementById('duration-input');
const uploadBtn = document.getElementById('upload-btn');
const progressBar = document.getElementById('upload-progress');
const progressFill = document.getElementById('progress-fill');
const uploadMessage = document.getElementById('upload-message');
const playlistContainer = document.getElementById('playlist-container');
const statusBadge = document.getElementById('server-status');

// ---------- فحص حالة السيرفر ----------
async function checkStatus() {
  try {
    const res = await fetch('/health');
    if (res.ok) {
      statusBadge.textContent = '🟢 متصل';
      statusBadge.className = 'status-badge online';
    }
  } catch {
    statusBadge.textContent = '🔴 غير متصل';
    statusBadge.className = 'status-badge offline';
  }
}

// ---------- رفع ملف جديد ----------
uploadForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const file = fileInput.files[0];
  if (!file) return;

  const formData = new FormData();
  formData.append('media', file);
  formData.append('duration', durationInput.value);

  progressBar.style.display = 'block';
  uploadBtn.disabled = true;
  uploadMessage.textContent = '';

  const xhr = new XMLHttpRequest();
  xhr.open('POST', '/api/upload');

  xhr.upload.onprogress = (evt) => {
    if (evt.lengthComputable) {
      const percent = (evt.loaded / evt.total) * 100;
      progressFill.style.width = percent + '%';
    }
  };

  xhr.onload = () => {
    uploadBtn.disabled = false;
    progressBar.style.display = 'none';
    progressFill.style.width = '0%';
    if (xhr.status === 200) {
      uploadMessage.textContent = '✅ تم رفع الملف بنجاح';
      uploadMessage.style.color = '#16a34a';
      uploadForm.reset();
      loadPlaylist();
    } else {
      const err = JSON.parse(xhr.responseText);
      uploadMessage.textContent = '❌ ' + (err.error || 'فشل الرفع');
      uploadMessage.style.color = '#dc2626';
    }
  };

  xhr.send(formData);
});

// ---------- تحميل وعرض قائمة التشغيل ----------
async function loadPlaylist() {
  const res = await fetch('/api/media');
  const items = await res.json();
  playlistContainer.innerHTML = '';

  items.forEach(item => {
    const li = document.createElement('li');
    li.className = 'playlist-item' + (item.is_active ? '' : ' inactive');
    li.draggable = true;
    li.dataset.playlistId = item.playlist_id;

    li.innerHTML = `
      <div class="info">
        <span class="drag-handle">☰</span>
        <span>${item.original_name}</span>
        <span class="badge">${item.type === 'video' ? '🎬 فيديو' : '🖼️ صورة'}</span>
        ${item.type === 'image' ? `<span class="badge">${item.duration_seconds} ثانية</span>` : ''}
      </div>
      <div class="actions">
        <button class="${item.is_active ? '' : 'toggle-off'}" onclick="toggleItem(${item.playlist_id})">
          ${item.is_active ? 'تعطيل' : 'تفعيل'}
        </button>
        <button class="danger" onclick="deleteItem(${item.id})">حذف</button>
      </div>
    `;
    playlistContainer.appendChild(li);
  });

  enableDragAndDrop();
}

// ---------- تفعيل / تعطيل عنصر ----------
async function toggleItem(playlistId) {
  await fetch(`/api/playlist/${playlistId}/toggle`, { method: 'PUT' });
  loadPlaylist();
}

// ---------- حذف عنصر ----------
async function deleteItem(mediaId) {
  if (!confirm('هل أنت متأكد من حذف هذا الملف نهائيًا؟')) return;
  await fetch(`/api/media/${mediaId}`, { method: 'DELETE' });
  loadPlaylist();
}

// ---------- السحب والإفلات لإعادة الترتيب ----------
function enableDragAndDrop() {
  let draggedEl = null;

  playlistContainer.querySelectorAll('.playlist-item').forEach(item => {
    item.addEventListener('dragstart', () => { draggedEl = item; item.style.opacity = '0.4'; });
    item.addEventListener('dragend', () => { item.style.opacity = '1'; saveOrder(); });
    item.addEventListener('dragover', (e) => {
      e.preventDefault();
      const afterElement = getDragAfterElement(playlistContainer, e.clientY);
      if (afterElement == null) {
        playlistContainer.appendChild(draggedEl);
      } else {
        playlistContainer.insertBefore(draggedEl, afterElement);
      }
    });
  });
}

function getDragAfterElement(container, y) {
  const items = [...container.querySelectorAll('.playlist-item:not([style*="opacity: 0.4"])')];
  return items.reduce((closest, child) => {
    const box = child.getBoundingClientRect();
    const offset = y - box.top - box.height / 2;
    if (offset < 0 && offset > closest.offset) {
      return { offset, element: child };
    }
    return closest;
  }, { offset: Number.NEGATIVE_INFINITY }).element;
}

async function saveOrder() {
  const items = [...playlistContainer.querySelectorAll('.playlist-item')];
  const order = items.map((item, index) => ({
    playlistId: parseInt(item.dataset.playlistId),
    sortOrder: index + 1
  }));
  await fetch('/api/playlist/reorder', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ order })
  });
}

// ---------- التشغيل الأولي ----------
checkStatus();
loadPlaylist();
setInterval(checkStatus, 10000);

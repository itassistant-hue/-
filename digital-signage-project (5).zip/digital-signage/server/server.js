// server.js
// نقطة الدخول الرئيسية للسيرفر - يجمع كل الأجزاء معًا
const express = require('express');
const path = require('path');
const cors = require('cors');
const http = require('http');
const { Server } = require('socket.io');

const apiRoutes = require('./routes/api');
const uploadRoutes = require('./routes/upload');

const app = express();
const server = http.createServer(app);

// إعداد WebSocket لإرسال إشعار "تحديث" فوري لكل شاشات Android TV
const io = new Server(server, { cors: { origin: '*' } });
app.set('io', io);

io.on('connection', (socket) => {
  console.log(`🔌 جهاز عرض متصل: ${socket.id}`);
  socket.on('disconnect', () => console.log(`❌ جهاز عرض قُطع الاتصال: ${socket.id}`));
});

// ------------------- الإعدادات الوسيطة (Middlewares) -------------------
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// تقديم لوحة التحكم (الملفات الثابتة: HTML/CSS/JS)
app.use(express.static(path.join(__dirname, 'public')));

// تقديم ملفات الوسائط المرفوعة كملفات ثابتة يمكن لأجهزة Android الوصول إليها عبر IP السيرفر
// مثال: http://192.168.1.100:3000/media/xxxx.mp4
app.use('/media', express.static(path.join(__dirname, 'media')));

// ------------------- المسارات (Routes) -------------------
app.use('/api', apiRoutes);
app.use('/api', uploadRoutes);

// فحص سريع لحالة السيرفر
app.get('/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

// ------------------- تشغيل السيرفر -------------------
const PORT = process.env.PORT || 3000;
// الاستماع على 0.0.0.0 مهم جدًا للسماح لأجهزة Android TV بالوصول عبر الشبكة المحلية
server.listen(PORT, '0.0.0.0', () => {
  console.log('====================================================');
  console.log(`✅ سيرفر نظام اللافتات الرقمية يعمل على المنفذ ${PORT}`);
  console.log(`🖥️  لوحة التحكم: http://<IP-السيرفر>:${PORT}`);
  console.log(`📺 API للشاشات: http://<IP-السيرفر>:${PORT}/api/playlist`);
  console.log('====================================================');
});

// routes/api.js
// المسارات التي يستخدمها كل من: لوحة التحكم (لإدارة القائمة) وتطبيق Android TV (لجلب البيانات)
const express = require('express');
const db = require('../db');
const router = express.Router();

// دالة مساعدة: تبني رابط التحميل الكامل بناءً على IP السيرفر
function buildMediaUrl(req, filename) {
  return `${req.protocol}://${req.get('host')}/media/${filename}`;
}

/**
 * GET /api/playlist
 * يستخدمه تطبيق Android TV لجلب قائمة التشغيل الحالية النشطة فقط، مرتبة حسب sort_order
 * الاستجابة تحتوي رابط تحميل مباشر لكل ملف
 */
router.get('/playlist', (req, res) => {
  const rows = db.prepare(`
    SELECT m.id, m.filename, m.original_name, m.type, m.duration_seconds, p.sort_order
    FROM playlist p
    JOIN media m ON m.id = p.media_id
    WHERE p.is_active = 1
    ORDER BY p.sort_order ASC
  `).all();

  const playlist = rows.map(row => ({
    id: row.id,
    name: row.original_name,
    type: row.type,
    durationSeconds: row.duration_seconds,
    url: buildMediaUrl(req, row.filename)
  }));

  res.json({ count: playlist.length, playlist });
});

/**
 * GET /api/media
 * يستخدمه لوحة التحكم لعرض كل الوسائط المرفوعة (نشطة وغير نشطة) مع ترتيبها
 */
router.get('/media', (req, res) => {
  const rows = db.prepare(`
    SELECT m.id, m.filename, m.original_name, m.type, m.duration_seconds,
           p.id as playlist_id, p.sort_order, p.is_active
    FROM media m
    LEFT JOIN playlist p ON p.media_id = m.id
    ORDER BY p.sort_order ASC
  `).all();

  const result = rows.map(row => ({
    ...row,
    url: buildMediaUrl(req, row.filename)
  }));

  res.json(result);
});

/**
 * PUT /api/playlist/reorder
 * body: { order: [ {playlistId, sortOrder}, ... ] }
 * تُستخدم من لوحة التحكم عند سحب وإفلات العناصر لإعادة الترتيب
 */
router.put('/playlist/reorder', (req, res) => {
  const { order } = req.body;
  if (!Array.isArray(order)) return res.status(400).json({ error: 'صيغة بيانات غير صحيحة' });

  const stmt = db.prepare('UPDATE playlist SET sort_order = ? WHERE id = ?');
  const transaction = db.transaction((items) => {
    for (const item of items) stmt.run(item.sortOrder, item.playlistId);
  });
  transaction(order);

  req.app.get('io')?.emit('playlist-updated');
  res.json({ success: true });
});

/**
 * PUT /api/playlist/:id/toggle
 * تفعيل/تعطيل عنصر معين في قائمة التشغيل دون حذفه
 */
router.put('/playlist/:id/toggle', (req, res) => {
  const item = db.prepare('SELECT * FROM playlist WHERE id = ?').get(req.params.id);
  if (!item) return res.status(404).json({ error: 'العنصر غير موجود' });

  const newState = item.is_active ? 0 : 1;
  db.prepare('UPDATE playlist SET is_active = ? WHERE id = ?').run(newState, req.params.id);

  req.app.get('io')?.emit('playlist-updated');
  res.json({ success: true, is_active: newState });
});

/**
 * PUT /api/media/:id/duration
 * body: { duration: number }
 * تحديد مدة عرض صورة معينة على الشاشة (بالثواني)
 */
router.put('/media/:id/duration', (req, res) => {
  const { duration } = req.body;
  if (!duration || duration <= 0) return res.status(400).json({ error: 'مدة غير صالحة' });

  db.prepare('UPDATE media SET duration_seconds = ? WHERE id = ?').run(duration, req.params.id);
  req.app.get('io')?.emit('playlist-updated');
  res.json({ success: true });
});

module.exports = router;

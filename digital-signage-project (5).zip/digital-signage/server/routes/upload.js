// routes/upload.js
// مسؤول عن استقبال ملفات الصور والفيديو وتخزينها في مجلد media
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const db = require('../db');

const router = express.Router();

const MEDIA_DIR = path.join(__dirname, '..', 'media');
if (!fs.existsSync(MEDIA_DIR)) fs.mkdirSync(MEDIA_DIR, { recursive: true });

// إعداد التخزين: نحافظ على الامتداد الأصلي ونولّد اسم فريد لتفادي التعارض
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, MEDIA_DIR),
  filename: (req, file, cb) => {
    const uniqueName = `${Date.now()}-${Math.round(Math.random() * 1e9)}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  }
});

// حد أقصى لحجم الملف: 500MB (يدعم فيديوهات عالية الدقة)
const upload = multer({
  storage,
  limits: { fileSize: 500 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = /jpeg|jpg|png|webp|mp4|mkv|mov|avi/;
    const ext = path.extname(file.originalname).toLowerCase().replace('.', '');
    if (allowed.test(ext)) return cb(null, true);
    cb(new Error('نوع الملف غير مدعوم. المسموح: صور (jpg,png,webp) أو فيديو (mp4,mov,mkv)'));
  }
});

// POST /api/upload  -> رفع ملف وسائط جديد
router.post('/upload', upload.single('media'), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'لم يتم إرفاق أي ملف' });

    const ext = path.extname(req.file.originalname).toLowerCase();
    const isVideo = ['.mp4', '.mkv', '.mov', '.avi'].includes(ext);
    const type = isVideo ? 'video' : 'image';

    // مدة العرض الافتراضية: للفيديو تُحسب تلقائيًا من قبل المشغل، للصورة من المستخدم (افتراضي 10 ثواني)
    const durationSeconds = parseInt(req.body.duration) || 10;

    const stmt = db.prepare(`
      INSERT INTO media (filename, original_name, type, duration_seconds)
      VALUES (?, ?, ?, ?)
    `);
    const info = stmt.run(req.file.filename, req.file.originalname, type, durationSeconds);

    // إضافة العنصر تلقائيًا لنهاية قائمة التشغيل
    const maxOrder = db.prepare('SELECT MAX(sort_order) as m FROM playlist').get().m || 0;
    db.prepare('INSERT INTO playlist (media_id, sort_order, is_active) VALUES (?, ?, 1)')
      .run(info.lastInsertRowid, maxOrder + 1);

    // إشعار كل الشاشات بوجود تحديث عبر WebSocket
    req.app.get('io')?.emit('playlist-updated');

    res.json({ success: true, id: info.lastInsertRowid, filename: req.file.filename, type });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /api/media/:id  -> حذف ملف وسائط وإزالته من القائمة
router.delete('/media/:id', (req, res) => {
  const media = db.prepare('SELECT * FROM media WHERE id = ?').get(req.params.id);
  if (!media) return res.status(404).json({ error: 'الملف غير موجود' });

  const filePath = path.join(MEDIA_DIR, media.filename);
  if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

  db.prepare('DELETE FROM media WHERE id = ?').run(req.params.id);
  db.prepare('DELETE FROM playlist WHERE media_id = ?').run(req.params.id);

  req.app.get('io')?.emit('playlist-updated');
  res.json({ success: true });
});

module.exports = router;

// db.js
// إعداد وتهيئة قاعدة بيانات SQLite لتخزين الوسائط وقائمة التشغيل
const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const DB_DIR = path.join(__dirname, 'db');
if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });

const db = new Database(path.join(DB_DIR, 'signage.db'));

// تفعيل خيارات الأداء
db.pragma('journal_mode = WAL');

// جدول الوسائط (كل الملفات المرفوعة)
db.exec(`
CREATE TABLE IF NOT EXISTS media (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  filename TEXT NOT NULL,
  original_name TEXT NOT NULL,
  type TEXT NOT NULL,          -- 'image' or 'video'
  duration_seconds INTEGER DEFAULT 10,  -- مدة العرض بالثواني (للصور فقط)
  uploaded_at TEXT DEFAULT (datetime('now'))
);
`);

// جدول قائمة التشغيل (يحدد الترتيب والحالة "مفعّل/معطّل")
db.exec(`
CREATE TABLE IF NOT EXISTS playlist (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  media_id INTEGER NOT NULL,
  sort_order INTEGER NOT NULL DEFAULT 0,
  is_active INTEGER NOT NULL DEFAULT 1,
  FOREIGN KEY (media_id) REFERENCES media(id) ON DELETE CASCADE
);
`);

module.exports = db;

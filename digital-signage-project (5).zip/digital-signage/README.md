# نظام اللافتات الرقمية المحلية للمطعم — دليل التشغيل الكامل

## 1) تشغيل السيرفر

```bash
cd server
npm install
npm start
```

سترى في الطرفية رسالة تؤكد تشغيل السيرفر على المنفذ 3000، ويمكنك فتح لوحة التحكم من متصفح الحاسوب عبر:
```
http://localhost:3000
```

أو من أي جهاز آخر بالشبكة عبر IP الحاسوب:
```
http://<IP-الحاسوب>:3000
```

---

## 2) تثبيت IP ثابت (Static IP) لحاسوب السيرفر — **خطوة ضرورية جدًا**

بما أن تطبيق Android مبرمج للاتصال بعنوان IP محدد (`ApiClient.kt`)، يجب أن لا يتغير IP حاسوب السيرفر أبدًا. إليك طريقتين:

### الطريقة الموصى بها: حجز IP من الراوتر (DHCP Reservation)
أسهل وأكثر أمانًا لأنك لا تلمس إعدادات الحاسوب:
1. ادخل إلى صفحة إدارة الراوتر (عادة `192.168.1.1` أو `192.168.0.1`) من المتصفح.
2. اذهب إلى قسم **DHCP Settings / Address Reservation / Static Leases**.
3. ابحث عن حاسوب السيرفر في قائمة الأجهزة المتصلة، وثبّت له IP ثابت (مثال: `192.168.1.100`) بناءً على عنوان MAC الخاص به.
4. أعد تشغيل الحاسوب للتأكد من حصوله على نفس العنوان دائمًا.

### الطريقة البديلة: تعيين IP ثابت يدويًا على نظام التشغيل

**على ويندوز:**
1. Control Panel → Network and Sharing Center → Change adapter settings.
2. كليك يمين على كرت الشبكة (Ethernet/Wi-Fi) → Properties.
3. اختر **Internet Protocol Version 4 (TCP/IPv4)** → Properties.
4. اختر "Use the following IP address" وأدخل:
   - IP address: `192.168.1.100`
   - Subnet mask: `255.255.255.0`
   - Default gateway: `192.168.1.1` (عنوان الراوتر)
   - DNS: `8.8.8.8`

**على لينكس (Ubuntu):**
```bash
sudo nano /etc/netplan/01-netcfg.yaml
```
```yaml
network:
  version: 2
  ethernets:
    eth0:
      dhcp4: no
      addresses: [192.168.1.100/24]
      gateway4: 192.168.1.1
      nameservers:
        addresses: [8.8.8.8]
```
```bash
sudo netplan apply
```

> بعد تثبيت IP الثابت، حدّث القيمة في ملف `android-app/.../ApiClient.kt`:
> ```kotlin
> private const val SERVER_IP = "192.168.1.100"
> ```

---

## 3) بناء وتثبيت تطبيق Android TV

1. افتح مجلد `android-app` في Android Studio.
2. عدّل `SERVER_IP` في `ApiClient.kt` ليطابق IP السيرفر الثابت.
3. وصّل جهاز Android TV Box بنفس الشبكة، وفعّل خاصية **تصحيح USB / ADB عبر الشبكة** من إعدادات الجهاز (Developer Options).
4. من Android Studio: Build → Generate Signed Bundle / APK → اختر APK.
5. ثبّت الـ APK على كل جهاز من أجهزة الـ TV Box الثمانية (يمكن استخدام أداة مثل `adb install app-release.apk`، أو نسخ الملف على USB وتثبيته يدويًا).

### تفعيل التشغيل التلقائي فعليًا على أجهزة TV Box
بعض أجهزة Android TV Box (خصوصًا الصينية العامة) تحتوي على مدير "Auto-start" خاص بها يمنع أي تطبيق من العمل عند الإقلاع ما لم يُفعَّل يدويًا. تحقق من:
```
Settings → Apps → Auto-start Manager → فعّل تطبيق "لافتات المطعم الرقمية"
```
وأيضًا تأكد من ضبط التطبيق كتطبيق الإقلاع الافتراضي (Launcher) إذا رغبت أن يظهر مباشرة بدل واجهة أندرويد التلفزيون العادية:
```
Settings → Apps → Default Apps → Home App → اختر التطبيق
```

---

## 4) اختبار سيناريو انقطاع الشبكة / إطفاء السيرفر
1. شغّل التطبيق على جهاز TV Box وتأكد من ظهور الإعلانات (سيقوم بتنزيلها وتخزينها محليًا تلقائيًا).
2. أطفئ حاسوب السيرفر أو افصل كابل الشبكة.
3. يجب أن يستمر التطبيق بعرض نفس الإعلانات المخزنة محليًا في حلقة لا نهائية دون توقف.
4. عند إعادة تشغيل السيرفر، سيكتشف التطبيق التحديث تلقائيًا (WebSocket أو Polling كل 60 ثانية) ويزامن أي محتوى جديد بالخلفية.

---

## ملخص التقنيات المستخدمة

| الجزء | التقنية |
|---|---|
| السيرفر | Node.js + Express + better-sqlite3 + Multer + Socket.IO |
| لوحة التحكم | HTML/CSS/JS خفيف بدون إطار عمل (Vanilla JS) |
| تطبيق Android | Kotlin + ExoPlayer + Retrofit + Socket.IO Client + Glide + Coroutines |

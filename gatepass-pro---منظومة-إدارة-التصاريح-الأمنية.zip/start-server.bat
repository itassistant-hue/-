@echo off
title GatePass Pro - Central Host Server
color 0A
echo ========================================================
echo   GatePass Pro - منظومة إدارة التصاريح الأمنية
echo   Central Host Server for Local Network (LAN)
echo   برمجة وتطوير: المهندس علي أحمد عنيد
echo ========================================================
echo.
echo [1/3] Checking Node.js installation...
node -v >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed on this PC!
    echo Please install Node.js from https://nodejs.org/ and try again.
    pause
    exit /b
)

echo [2/3] Checking dependencies...
if not exist "node_modules\" (
    echo Installing required packages...
    npm install
)

echo.
echo [3/3] Starting GatePass Pro Host Server on Port 3000...
echo.
echo --------------------------------------------------------
echo Access URL for this computer: http://localhost:3000
echo Access URL for other PCs:    http://YOUR-PC-IP:3000
echo (Check the Admin Settings tab inside the app to see your exact IP!)
echo --------------------------------------------------------
echo.

npm run dev

pause

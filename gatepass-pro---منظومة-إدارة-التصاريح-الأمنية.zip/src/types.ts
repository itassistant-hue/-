export type UserRole = 'admin' | 'security_ops' | 'gate_1' | 'gate_2' | 'company_user';

export type PassType = 'guest' | 'employee' | 'vip' | 'contractor' | 'materials';

export type PassDirection = 'entry_exit' | 'entry_only' | 'exit_only';

export type PassStatus = 
  | 'pending_security' // بانتظار موافقة السيطرة الأمنية
  | 'approved'         // مصرح وساري المفعول
  | 'rejected'         // مرفوض أمنياً
  | 'inside'           // داخل الموقع حالياً
  | 'completed'        // اكتملت الزيارة وغادر
  | 'cancelled'        // ملغي
  | 'expired';         // منتهي الصلاحية

export interface User {
  id: string;
  username: string;
  fullName: string;
  role: UserRole;
  password?: string;
  phone?: string;
  companyId?: string;
  companyName?: string;
  gateId?: string;
  avatar?: string;
  active: boolean;
  createdAt: string;
  lastLogin?: string;
}

export interface Company {
  id: string;
  name: string;
  code: string;
  contactPerson: string;
  phone: string;
  email: string;
  sector: string;
  locationInsideSite: string;
  activePassesCount?: number;
  active: boolean;
  logo?: string;
  createdAt: string;
}

export interface PassLogEntry {
  id: string;
  timestamp: string;
  action: 'requested' | 'approved' | 'rejected' | 'check_in' | 'check_out' | 'cancelled' | 'renewed';
  actionArabic: string;
  gate?: string;
  gateArabic?: string;
  operatorName: string;
  operatorRole: string;
  notes?: string;
}

export interface PassRequest {
  id: string;
  passNumber: string; // e.g. GP-2026-1048
  qrCodeData: string;
  companyId: string;
  companyName: string;
  requesterName: string;
  requesterPhone: string;
  
  // Visitor details
  visitorName: string;
  nationalIdOrPassport: string;
  nationality: string;
  visitorPhone: string;
  visitorType: PassType;
  escortPerson?: string; // الشخص المستضيف داخل الشركة
  photoUrl?: string; // صورة الزائر / الهوية / المستمسك / الشحنة
  
  // Logistics
  vehiclePlate?: string;
  vehicleModel?: string;
  destinationGate: string; // 'gate_1' | 'gate_2' | 'both' | 'all' | any custom gate id
  purpose: string;
  materialsList?: string; // تفاصيل المواد / المعدات إن وجدت
  
  // Custom Dynamic Fields (added by admin)
  customFieldValues?: Record<string, string>;
  
  // Validity
  validFrom: string; // ISO string
  validTo: string;   // ISO string
  durationHours: number;
  durationLabel: string;
  
  // Status & Decision
  status: PassStatus;
  rejectionReason?: string;
  securityNotes?: string;
  approvedBy?: string;
  approvedAt?: string;
  
  // Entry/Exit tracking
  entryTime?: string;
  entryGate?: string;
  entryOperator?: string;
  exitTime?: string;
  exitGate?: string;
  exitOperator?: string;
  
  logs: PassLogEntry[];
  createdAt: string;
}

export interface GateMovement {
  id: string;
  passId: string;
  passNumber: string;
  visitorName: string;
  visitorType: PassType;
  companyName: string;
  gateId: string;
  gateName: string;
  movementType: 'check_in' | 'check_out';
  operatorName: string;
  timestamp: string;
  vehiclePlate?: string;
  notes?: string;
}

export interface SystemLicense {
  licenseKey: string;
  clientName: string;
  facilityName: string;
  appNameAr?: string;
  appNameEn?: string;
  facilityNameAr?: string;
  facilityNameEn?: string;
  issuedDate: string;
  expiryDate: string;
  status: 'active' | 'expired' | 'suspended' | 'trial';
  maxAllowedGates: number;
  maxCompanies: number;
  hardwareFingerprint: string;
  secretGatewayCode: string; // '7941631'
  encryptedSignature: string;
  maintenanceMode: boolean;
  developerNameAr: string; // 'المهندس علي أحمد عنيد'
  developerNameEn: string; // 'Eng. Ali Ahmed Aneed'
  developerTitleAr: string; // 'المطور والمصمم البرمجي للمنظومة'
  developerTitleEn: string; // 'Software Architect & System Engineer'
  copyrightAr: string; // 'برمجة وتطوير: المهندس علي أحمد عنيد • جميع الحقوق محفوظة'
  copyrightEn: string; // 'Engineered & Developed by Eng. Ali Ahmed Aneed • All Rights Reserved'
  loginBgUrl?: string; // صورة خلفية شاشة تسجيل الدخول
  loginHeroImageUrl?: string; // صورة أو بانر شاشة تسجيل الدخول
  systemBgUrl?: string; // صورة أو نمط خلفية لوحات التحكم والواجهات الداخلية
  loginCardSubtitleAr?: string;
  loginCardSubtitleEn?: string;
  features: {
    vipFastTrack: boolean;
    smsNotifications: boolean;
    barcodeScanning: boolean;
    unlimitedArchive: boolean;
    multiGateSync: boolean;
  };
}

export type Language = 'ar' | 'en';

export interface EmergencyBroadcast {
  id: string;
  title: string;
  message: string;
  severity: 'critical' | 'warning' | 'drill' | 'lockdown';
  targets: string[]; // ['gate_1', 'gate_2', 'security_ops', 'all_guards', 'medical', 'fire', 'companies']
  sender: string;
  senderRole: string;
  timestamp: string;
  active: boolean;
  soundAlert: boolean;
  acknowledgedBy?: string[];
}

export interface CustomNomenclature {
  appNameAr: string;
  appNameEn: string;
  facilityNameAr: string;
  facilityNameEn: string;
  appLogoUrl?: string; // شعار أو صورة البرنامج المخصصة
  loginBgUrl?: string; // صورة خلفية شاشة تسجيل الدخول
  loginHeroImageUrl?: string; // صورة أو بانر شاشة تسجيل الدخول
  systemBgUrl?: string; // صورة أو نمط خلفية لوحات التحكم والواجهات الداخلية
  loginCardSubtitleAr?: string;
  loginCardSubtitleEn?: string;
  gate1NameAr: string;
  gate1NameEn: string;
  gate2NameAr: string;
  gate2NameEn: string;
  socNameAr: string;
  socNameEn: string;
  adminNameAr: string;
  adminNameEn: string;
  companyPortalNameAr: string;
  companyPortalNameEn: string;
  
  // Custom KPI & Header overrides for Admin
  kpiTotalPassesAr?: string;
  kpiTotalPassesEn?: string;
  kpiOnSiteAr?: string;
  kpiOnSiteEn?: string;
  kpiPendingAr?: string;
  kpiPendingEn?: string;
  kpiExpiredAr?: string;
  kpiExpiredEn?: string;
  kpiGate1Ar?: string;
  kpiGate1En?: string;
  kpiGate2Ar?: string;
  kpiGate2En?: string;
  maxSiteCapacity?: number;
}

export interface GateDefinition {
  id: string; // 'gate_1', 'gate_2', 'gate_3', etc.
  nameAr: string;
  nameEn: string;
  location?: string;
  type?: 'entry_exit' | 'entry_only' | 'exit_only' | 'cargo' | 'vip';
  enabled: boolean;
  isSystemDefault?: boolean;
  color?: string; // 'blue' | 'indigo' | 'emerald' | 'amber' | 'purple' | 'rose' | 'teal'
}

export interface CustomFieldDefinition {
  id: string; // e.g. 'escortPerson', 'vehiclePlate', 'vehicleModel', 'materialsList', 'photoUrl', or 'cf_1700...'
  key: string;
  labelAr: string;
  labelEn: string;
  type: 'text' | 'number' | 'select' | 'textarea' | 'date';
  options?: string[]; // for select
  category: 'visitor' | 'vehicle' | 'materials' | 'security' | 'custom';
  required: boolean;
  enabled: boolean;
  isSystemDefault?: boolean; // system fields can be toggled/renamed, custom fields can be deleted
  placeholderAr?: string;
  placeholderEn?: string;
  helpTextAr?: string;
}

export interface SystemViewDefinition {
  id: string; // 'admin', 'soc', 'gate_1', 'gate_2', 'company', or 'view_custom_...'
  nameAr: string;
  nameEn: string;
  icon?: string;
  enabled: boolean;
  isSystemDefault?: boolean;
  roleRequired?: string;
  gateId?: string;
}

export interface AutoBackupSettings {
  enabled: boolean;
  intervalMinutes: number; // 60, 360, 720, 1440
  autoDownload: boolean;
  lastBackupTime?: string;
  serverDestinationName: string;
}

export interface SystemNotification {
  id: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'emergency';
  timestamp: string;
  read: boolean;
  passId?: string;
}

import React, { useState } from 'react';
import { Company } from '../types';
import { storageService } from '../services/storage';
import { soundService } from '../services/audio';
import { Building2, Plus, X, Trash2, CheckCircle, MapPin, Phone, Mail } from 'lucide-react';

interface CompanyManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const CompanyManagerModal: React.FC<CompanyManagerModalProps> = ({ isOpen, onClose }) => {
  const [companies, setCompanies] = useState<Company[]>(() => storageService.getCompanies());
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [sector, setSector] = useState('النفط والغاز والطاقة');
  const [locationInsideSite, setLocationInsideSite] = useState('');
  const [statusMsg, setStatusMsg] = useState('');

  if (!isOpen) return null;

  const handleSaveCompany = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !contactPerson.trim()) {
      alert('يرجى ملء اسم الشركة والممثل المعتمد');
      return;
    }

    const newComp: Company = {
      id: 'comp_' + Date.now(),
      name: name.trim(),
      code: code.trim() || `COMP-${companies.length + 1}`,
      contactPerson: contactPerson.trim(),
      phone: phone.trim() || '07800000000',
      email: email.trim() || 'info@company.iq',
      sector,
      locationInsideSite: locationInsideSite.trim() || 'المجمع الرئيسي',
      active: true,
      createdAt: new Date().toISOString()
    };

    storageService.saveCompany(newComp);
    setCompanies(storageService.getCompanies());
    setIsAddingNew(false);
    setName('');
    setCode('');
    setContactPerson('');
    setPhone('');
    setLocationInsideSite('');
    setStatusMsg('تمت إضافة الشركة المستضافة بنجاح!');
    soundService.playSuccessSound();
    setTimeout(() => setStatusMsg(''), 3000);
  };

  const handleDeleteCompany = (id: string, name: string) => {
    if (window.confirm(`هل أنت متأكد من حذف الشركة (${name})؟`)) {
      storageService.deleteCompany(id);
      setCompanies(storageService.getCompanies());
      soundService.playAccessDenied();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md font-['Tajawal',sans-serif]">
      <div className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl text-slate-100">
        
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <Building2 className="w-5 h-5 text-amber-400" />
            <h3 className="text-base font-bold text-white">إدارة الشركات المستضافة في الموقع (أكثر من 10 شركات)</h3>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-5">
          
          {statusMsg && (
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center gap-2">
              <CheckCircle className="w-4 h-4" />
              {statusMsg}
            </div>
          )}

          {/* Add Company Toggle */}
          <div className="flex items-center justify-between">
            <p className="text-xs text-slate-400">إجمالي الشركات المسجلة: <span className="text-amber-400 font-bold font-mono">{companies.length} شركة</span></p>
            <button
              onClick={() => setIsAddingNew(!isAddingNew)}
              className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md"
            >
              <Plus className="w-4 h-4" />
              <span>{isAddingNew ? 'إلغاء' : 'إضافة شركة جديدة للموقع'}</span>
            </button>
          </div>

          {/* New Company Form */}
          {isAddingNew && (
            <form onSubmit={handleSaveCompany} className="p-5 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
              <h4 className="text-xs font-bold text-amber-400">بيانات الشركة الجديدة</h4>
              
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                <div className="sm:col-span-2">
                  <label className="block text-slate-400 mb-1">اسم الشركة الكامل: *</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: شركة الرافدين للاتصالات والتقنية"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">رمز الشركة (Code):</label>
                  <input
                    type="text"
                    placeholder="مثال: RIC-02"
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white outline-none focus:border-amber-400 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">الممثل المعتمد / ضابط الاتصال: *</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: م. علي حسين"
                    value={contactPerson}
                    onChange={(e) => setContactPerson(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">رقم الهاتف للتواصل:</label>
                  <input
                    type="tel"
                    placeholder="0780XXXXXXX"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">القطاع والنشاط:</label>
                  <select
                    value={sector}
                    onChange={(e) => setSector(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white outline-none focus:border-amber-400"
                  >
                    <option value="النفط والغاز والطاقة">النفط والغاز والطاقة</option>
                    <option value="الاتصالات والشبكات">الاتصالات والشبكات</option>
                    <option value="المقاولات والإنشاءات">المقاولات والإنشاءات</option>
                    <option value="النقل والشحن واللوجستيات">النقل والشحن واللوجستيات</option>
                    <option value="السلامة والصحة المهنية (HSE)">السلامة والصحة المهنية (HSE)</option>
                    <option value="الخدمات الطبية">الخدمات الطبية</option>
                    <option value="التموين والإعاشة">التموين والإعاشة</option>
                  </select>
                </div>
                <div className="sm:col-span-3">
                  <label className="block text-slate-400 mb-1">موقع المقر أو الورشة داخل المنشأة:</label>
                  <input
                    type="text"
                    placeholder="مثال: المجمع الجنوبي - مبنى B2 - الطابق الأول"
                    value={locationInsideSite}
                    onChange={(e) => setLocationInsideSite(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end">
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md"
                >
                  حفظ الشركة
                </button>
              </div>
            </form>
          )}

          {/* Companies Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {companies.map((c) => (
              <div key={c.id} className="p-4 rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition-colors flex items-start justify-between gap-3">
                <div className="space-y-1.5 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded-md bg-blue-500/20 text-blue-300 font-mono font-bold text-[10px] border border-blue-500/30">{c.code}</span>
                    <h4 className="text-xs font-bold text-white">{c.name}</h4>
                  </div>
                  <div className="text-[11px] text-slate-400 flex items-center gap-1">
                    <MapPin className="w-3 h-3 text-amber-400 shrink-0" />
                    <span>{c.locationInsideSite}</span>
                  </div>
                  <div className="text-[11px] text-slate-400 flex items-center gap-3">
                    <span>الممثل: <span className="text-slate-200">{c.contactPerson}</span></span>
                    <span>هاتف: <span className="text-slate-200">{c.phone}</span></span>
                  </div>
                  <div className="text-[10px] text-slate-500">{c.sector}</div>
                </div>

                <button
                  onClick={() => handleDeleteCompany(c.id, c.name)}
                  className="p-1.5 rounded-lg bg-slate-900 hover:bg-red-600 text-slate-400 hover:text-white transition-colors"
                  title="حذف الشركة"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>

        </div>

      </div>
    </div>
  );
};

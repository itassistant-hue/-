import React, { useState, useEffect } from 'react';
import { PassRequest, User, Company, GateMovement, PassType, Language } from '../types';
import { storageService } from '../services/storage';
import { soundService } from '../services/audio';
import { translations } from '../services/i18n';
import { AdminAnalyticsTab } from './AdminAnalyticsTab';
import { AdminSettingsTab } from './AdminSettingsTab';
import { 
  ShieldCheck, 
  Users, 
  Building2, 
  Key, 
  Plus, 
  Search, 
  Filter, 
  Eye, 
  Printer, 
  Trash2, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  Ban, 
  Crown, 
  Car, 
  RefreshCw,
  Sliders,
  TrendingUp,
  FileSpreadsheet,
  ArrowRightLeft,
  CalendarPlus,
  DoorOpen,
  Settings,
  ListFilter
} from 'lucide-react';

interface AdminDashboardProps {
  currentUser: User;
  lang?: Language;
  onOpenPassDetails: (pass: PassRequest) => void;
  onOpenNewPassModal: () => void;
  onOpenUserManager: () => void;
  onOpenCompanyManager: () => void;
  onOpenSecretGateway: () => void;
  onOpenCustomizeModal?: (tab?: 'branding' | 'views' | 'kpis') => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  currentUser,
  lang = 'ar',
  onOpenPassDetails,
  onOpenNewPassModal,
  onOpenUserManager,
  onOpenCompanyManager,
  onOpenSecretGateway,
  onOpenCustomizeModal
}) => {
  const t = translations[lang] || translations.ar;

  const [passes, setPasses] = useState<PassRequest[]>(() => storageService.getPasses());
  const [companies, setCompanies] = useState<Company[]>(() => storageService.getCompanies());
  const [movements, setMovements] = useState<GateMovement[]>(() => storageService.getMovements());
  const [nomenclature, setNomenclature] = useState(() => storageService.getNomenclature());
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCompanyFilter, setSelectedCompanyFilter] = useState('all');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState('all');
  const [selectedTypeFilter, setSelectedTypeFilter] = useState('all');
  const [activeTab, setActiveTab] = useState<'passes' | 'movements' | 'analytics' | 'settings'>('passes');

  useEffect(() => {
    const handleStorageChange = () => {
      setPasses(storageService.getPasses());
      setCompanies(storageService.getCompanies());
      setMovements(storageService.getMovements());
      setNomenclature(storageService.getNomenclature());
    };
    window.addEventListener('gatepass_storage_event', handleStorageChange);
    return () => window.removeEventListener('gatepass_storage_event', handleStorageChange);
  }, []);

  const handleExtendValidity = (pass: PassRequest, hours: number) => {
    storageService.extendPass(pass.id, hours, currentUser);
    soundService.playSuccess();
  };

  const handleDeletePass = (pass: PassRequest) => {
    const confirmPrompt = lang === 'ar'
      ? `هل أنت متأكد من حذف التصريح (${pass.passNumber} - ${pass.visitorName}) نهائياً من السجلات؟`
      : `Are you sure you want to delete pass (${pass.passNumber} - ${pass.visitorName})?`;
    
    if (window.confirm(confirmPrompt)) {
      storageService.deletePass(pass.id);
      soundService.playAccessDenied();
    }
  };

  const effectivePasses = passes.map(p => ({
    ...p,
    effectiveStatus: storageService.getEffectiveStatus(p)
  }));

  const insideCount = effectivePasses.filter(p => p.effectiveStatus === 'inside').length;
  const pendingCount = effectivePasses.filter(p => p.status === 'pending_security').length;
  const expiredCount = effectivePasses.filter(p => p.effectiveStatus === 'expired').length;
  const approvedCount = effectivePasses.filter(p => p.effectiveStatus === 'approved').length;

  const gate1Movements = movements.filter(m => m.gateId === 'gate_1').length;
  const gate2Movements = movements.filter(m => m.gateId === 'gate_2').length;

  const filteredPasses = effectivePasses.filter(p => {
    const matchesSearch = 
      p.visitorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.passNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.companyName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.nationalIdOrPassport.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.vehiclePlate && p.vehiclePlate.toLowerCase().includes(searchQuery.toLowerCase()));

    if (!matchesSearch) return false;

    if (selectedCompanyFilter !== 'all' && p.companyId !== selectedCompanyFilter) return false;
    if (selectedStatusFilter !== 'all' && p.effectiveStatus !== selectedStatusFilter) return false;
    if (selectedTypeFilter !== 'all' && p.visitorType !== selectedTypeFilter) return false;

    return true;
  });

  const displayAdminTitle = lang === 'ar' 
    ? (nomenclature.adminNameAr || t.admin_dashboard) 
    : (nomenclature.adminNameEn || t.admin_dashboard);

  const kpiTotalTitle = lang === 'ar'
    ? (nomenclature.kpiTotalPassesAr || t.total_passes)
    : (nomenclature.kpiTotalPassesEn || t.total_passes);

  const kpiOnSiteTitle = lang === 'ar'
    ? (nomenclature.kpiOnSiteAr || t.on_site)
    : (nomenclature.kpiOnSiteEn || t.on_site);

  const kpiPendingTitle = lang === 'ar'
    ? (nomenclature.kpiPendingAr || t.pending_soc_review)
    : (nomenclature.kpiPendingEn || t.pending_soc_review);

  const kpiExpiredTitle = lang === 'ar'
    ? (nomenclature.kpiExpiredAr || t.status_expired)
    : (nomenclature.kpiExpiredEn || t.status_expired);

  const kpiGate1Title = lang === 'ar'
    ? (nomenclature.kpiGate1Ar || (nomenclature.gate1NameAr ? `حركات ${nomenclature.gate1NameAr}` : 'حركات بوابة 1'))
    : (nomenclature.kpiGate1En || (nomenclature.gate1NameEn ? `${nomenclature.gate1NameEn} Logs` : 'Gate 1 Movements'));

  const kpiGate2Title = lang === 'ar'
    ? (nomenclature.kpiGate2Ar || (nomenclature.gate2NameAr ? `حركات ${nomenclature.gate2NameAr}` : 'حركات بوابة 2'))
    : (nomenclature.kpiGate2En || (nomenclature.gate2NameEn ? `${nomenclature.gate2NameEn} Logs` : 'Gate 2 Movements'));

  return (
    <div className="space-y-6 font-['Tajawal',sans-serif]">
      
      {/* Master Admin Header */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl flex flex-col md:flex-row items-center justify-between gap-5">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-amber-500/20 shrink-0">
            <Sliders className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg sm:text-xl font-black text-white">{displayAdminTitle}</h2>
              <span className="px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-xs font-mono font-bold border border-amber-500/30">
                FULL CONTROL
              </span>
              {onOpenCustomizeModal && (
                <button
                  onClick={() => onOpenCustomizeModal('branding')}
                  className="p-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 transition-colors"
                  title={lang === 'ar' ? 'تعديل مسميات المنظومة واللوحة' : 'Edit System Names'}
                >
                  <Sliders className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
            <p className="text-xs text-slate-400 mt-1">
              {lang === 'ar' ? 'المسؤول الحالي:' : 'Logged in as:'} <span className="text-white font-bold">{currentUser.fullName}</span> • {lang === 'ar' ? 'إشراف كامل على البوابات، السيطرة، التصاريح والتقارير' : 'Full access to gates, SOC review, passes & analytics'}
            </p>
          </div>
        </div>

        {/* Action Toolbar */}
        <div className="flex flex-wrap items-center gap-2.5">
          {onOpenCustomizeModal && (
            <button
              onClick={() => onOpenCustomizeModal('kpis')}
              className="px-3.5 py-2 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 text-xs font-bold flex items-center gap-1.5 border border-amber-500/30 transition-colors"
              title={lang === 'ar' ? 'تعديل خانات الإحصائيات والمتواجدين والواجهات' : 'Customize KPI & View Labels'}
            >
              <Sliders className="w-3.5 h-3.5 text-amber-400" />
              <span>{lang === 'ar' ? 'تعديل الخانات' : 'Edit Labels'}</span>
            </button>
          )}

          <button
            onClick={onOpenUserManager}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 border border-slate-700 transition-colors"
          >
            <Users className="w-3.5 h-3.5 text-blue-400" />
            <span>{t.user_mgmt}</span>
          </button>

          <button
            onClick={onOpenCompanyManager}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 border border-slate-700 transition-colors"
          >
            <Building2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>{t.company_mgmt} ({companies.length})</span>
          </button>

          <button
            onClick={onOpenNewPassModal}
            className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black shadow-md flex items-center gap-1.5 transition-transform active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>{t.issue_pass}</span>
          </button>
        </div>
      </div>

      {/* Interactive KPI Quick-Filter Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        
        <div 
          onClick={() => { setActiveTab('passes'); setSelectedStatusFilter('all'); setSelectedCompanyFilter('all'); }}
          className={`p-4 rounded-3xl border cursor-pointer transition-all hover:scale-[1.02] active:scale-95 ${
            activeTab === 'passes' && selectedStatusFilter === 'all'
              ? 'bg-blue-950/50 border-blue-500 ring-1 ring-blue-500/50'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <div className="text-[11px] text-slate-400 font-bold truncate">{kpiTotalTitle}</div>
            {onOpenCustomizeModal && (
              <button 
                type="button" 
                onClick={(e) => { e.stopPropagation(); onOpenCustomizeModal('kpis'); }}
                className="text-slate-500 hover:text-amber-400 p-0.5"
                title={lang === 'ar' ? 'تعديل تسمية الخانة' : 'Edit label'}
              >
                <Sliders className="w-3 h-3" />
              </button>
            )}
          </div>
          <div className="text-2xl font-black text-white font-mono">{passes.length}</div>
          <div className="text-[10px] text-blue-400 mt-1 font-bold flex items-center gap-1">
            <span>{lang === 'ar' ? 'عرض السجلات' : 'View records'}</span> ↗
          </div>
        </div>

        <div 
          onClick={() => { setActiveTab('passes'); setSelectedStatusFilter('inside'); }}
          className={`p-4 rounded-3xl border cursor-pointer transition-all hover:scale-[1.02] active:scale-95 ${
            activeTab === 'passes' && selectedStatusFilter === 'inside'
              ? 'bg-emerald-950/50 border-emerald-500 ring-1 ring-emerald-500/50'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <div className="text-[11px] text-slate-400 font-bold truncate">{kpiOnSiteTitle}</div>
            {onOpenCustomizeModal && (
              <button 
                type="button" 
                onClick={(e) => { e.stopPropagation(); onOpenCustomizeModal('kpis'); }}
                className="text-slate-500 hover:text-amber-400 p-0.5"
                title={lang === 'ar' ? 'تعديل تسمية الخانة' : 'Edit label'}
              >
                <Sliders className="w-3 h-3" />
              </button>
            )}
          </div>
          <div className="text-2xl font-black text-emerald-400 font-mono">{insideCount}</div>
          <div className="text-[10px] text-emerald-400 mt-1 font-bold flex items-center gap-1">
            <span>{lang === 'ar' ? 'المتواجدون الآن' : 'Currently inside'}</span> ↗
          </div>
        </div>

        <div 
          onClick={() => { setActiveTab('passes'); setSelectedStatusFilter('pending_security'); }}
          className={`p-4 rounded-3xl border cursor-pointer transition-all hover:scale-[1.02] active:scale-95 ${
            activeTab === 'passes' && selectedStatusFilter === 'pending_security'
              ? 'bg-amber-950/50 border-amber-500 ring-1 ring-amber-500/50'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <div className="text-[11px] text-slate-400 font-bold truncate">{kpiPendingTitle}</div>
            {onOpenCustomizeModal && (
              <button 
                type="button" 
                onClick={(e) => { e.stopPropagation(); onOpenCustomizeModal('kpis'); }}
                className="text-slate-500 hover:text-amber-400 p-0.5"
                title={lang === 'ar' ? 'تعديل تسمية الخانة' : 'Edit label'}
              >
                <Sliders className="w-3 h-3" />
              </button>
            )}
          </div>
          <div className="text-2xl font-black text-amber-400 font-mono">{pendingCount}</div>
          <div className="text-[10px] text-amber-400 mt-1 font-bold flex items-center gap-1">
            <span>{lang === 'ar' ? 'النداءات المعلقة' : 'Pending calls'}</span> ↗
          </div>
        </div>

        <div 
          onClick={() => { setActiveTab('passes'); setSelectedStatusFilter('expired'); }}
          className={`p-4 rounded-3xl border cursor-pointer transition-all hover:scale-[1.02] active:scale-95 ${
            activeTab === 'passes' && selectedStatusFilter === 'expired'
              ? 'bg-red-950/50 border-red-500 ring-1 ring-red-500/50'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <div className="text-[11px] text-slate-400 font-bold truncate">{kpiExpiredTitle}</div>
            {onOpenCustomizeModal && (
              <button 
                type="button" 
                onClick={(e) => { e.stopPropagation(); onOpenCustomizeModal('kpis'); }}
                className="text-slate-500 hover:text-amber-400 p-0.5"
                title={lang === 'ar' ? 'تعديل تسمية الخانة' : 'Edit label'}
              >
                <Sliders className="w-3 h-3" />
              </button>
            )}
          </div>
          <div className="text-2xl font-black text-red-400 font-mono">{expiredCount}</div>
          <div className="text-[10px] text-red-400 mt-1 font-bold flex items-center gap-1">
            <span>{lang === 'ar' ? 'المنتهية' : 'Expired passes'}</span> ↗
          </div>
        </div>

        <div 
          onClick={() => { setActiveTab('movements'); }}
          className={`p-4 rounded-3xl border cursor-pointer transition-all hover:scale-[1.02] active:scale-95 ${
            activeTab === 'movements'
              ? 'bg-blue-950/50 border-blue-500 ring-1 ring-blue-500/50'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <div className="text-[11px] text-slate-400 font-bold truncate">{kpiGate1Title}</div>
            {onOpenCustomizeModal && (
              <button 
                type="button" 
                onClick={(e) => { e.stopPropagation(); onOpenCustomizeModal('views'); }}
                className="text-slate-500 hover:text-amber-400 p-0.5"
                title={lang === 'ar' ? 'تعديل تسمية الخانة' : 'Edit label'}
              >
                <Sliders className="w-3 h-3" />
              </button>
            )}
          </div>
          <div className="text-2xl font-black text-blue-400 font-mono">{gate1Movements}</div>
          <div className="text-[10px] text-blue-400 mt-1 font-bold flex items-center gap-1">
            <span>{lang === 'ar' ? 'سجل البوابة 1' : 'Gate 1 log'}</span> ↗
          </div>
        </div>

        <div 
          onClick={() => { setActiveTab('movements'); }}
          className={`p-4 rounded-3xl border cursor-pointer transition-all hover:scale-[1.02] active:scale-95 ${
            activeTab === 'movements'
              ? 'bg-indigo-950/50 border-indigo-500 ring-1 ring-indigo-500/50'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <div className="text-[11px] text-slate-400 font-bold truncate">{kpiGate2Title}</div>
            {onOpenCustomizeModal && (
              <button 
                type="button" 
                onClick={(e) => { e.stopPropagation(); onOpenCustomizeModal('views'); }}
                className="text-slate-500 hover:text-amber-400 p-0.5"
                title={lang === 'ar' ? 'تعديل تسمية الخانة' : 'Edit label'}
              >
                <Sliders className="w-3 h-3" />
              </button>
            )}
          </div>
          <div className="text-2xl font-black text-indigo-400 font-mono">{gate2Movements}</div>
          <div className="text-[10px] text-indigo-400 mt-1 font-bold flex items-center gap-1">
            <span>{lang === 'ar' ? 'سجل البوابة 2' : 'Gate 2 log'}</span> ↗
          </div>
        </div>

      </div>

      {/* Main Tab Navigation Buttons */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveTab('passes')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-black transition-all ${
            activeTab === 'passes'
              ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
          }`}
        >
          <ListFilter className="w-4 h-4" />
          <span>{lang === 'ar' ? 'سجل التصاريح والطلبات' : 'Passes & Requests Log'}</span>
          <span className="px-2 py-0.5 rounded-full bg-slate-950/50 text-[10px] font-mono">
            {passes.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('analytics')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-black transition-all ${
            activeTab === 'analytics'
              ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
          }`}
        >
          <TrendingUp className="w-4 h-4 text-emerald-400" />
          <span>{t.tab_analytics}</span>
        </button>

        <button
          onClick={() => setActiveTab('movements')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-black transition-all ${
            activeTab === 'movements'
              ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
          }`}
        >
          <DoorOpen className="w-4 h-4 text-blue-400" />
          <span>{lang === 'ar' ? 'سجل حركات البوابات' : 'Gate Movements Log'}</span>
          <span className="px-2 py-0.5 rounded-full bg-slate-950/50 text-[10px] font-mono">
            {movements.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab('settings')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-black transition-all ${
            activeTab === 'settings'
              ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20'
              : 'bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800'
          }`}
        >
          <Settings className="w-4 h-4 text-purple-400" />
          <span>{t.tab_settings}</span>
        </button>
      </div>

      {/* Tab 1: Passes Table View */}
      {activeTab === 'passes' && (
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
          
          {/* Top Filters Bar */}
          <div className="flex flex-col lg:flex-row items-center justify-between gap-3">
            
            <div className="flex flex-wrap items-center gap-2 w-full lg:w-auto">
              {/* Search Box */}
              <div className="relative flex-1 sm:w-64">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={lang === 'ar' ? 'بحث بالاسم، الهوية، التصريح، اللوحة...' : 'Search by name, ID, pass #, plate...'}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 pl-9 text-xs text-white placeholder:text-slate-500 focus:border-amber-400 outline-none"
                />
                <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
              </div>

              {/* Company Filter */}
              <select
                value={selectedCompanyFilter}
                onChange={(e) => setSelectedCompanyFilter(e.target.value)}
                className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-amber-400"
              >
                <option value="all">{lang === 'ar' ? `كافة الشركات (${companies.length})` : `All Companies (${companies.length})`}</option>
                {companies.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>

              {/* Status Filter */}
              <select
                value={selectedStatusFilter}
                onChange={(e) => setSelectedStatusFilter(e.target.value)}
                className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-amber-400"
              >
                <option value="all">{lang === 'ar' ? 'كافة الحالات' : 'All Statuses'}</option>
                <option value="pending_security">{t.status_pending}</option>
                <option value="approved">{t.status_approved}</option>
                <option value="inside">{t.status_inside}</option>
                <option value="expired">{t.status_expired}</option>
                <option value="rejected">{t.status_rejected}</option>
                <option value="completed">{t.status_completed}</option>
              </select>

              {/* Type Filter */}
              <select
                value={selectedTypeFilter}
                onChange={(e) => setSelectedTypeFilter(e.target.value)}
                className="bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-amber-400"
              >
                <option value="all">{lang === 'ar' ? 'كافة الفئات' : 'All Types'}</option>
                <option value="vip">{t.type_vip}</option>
                <option value="guest">{t.type_guest}</option>
                <option value="employee">{t.type_employee}</option>
                <option value="contractor">{t.type_contractor}</option>
                <option value="materials">{t.type_materials}</option>
              </select>
            </div>

            <div className="text-xs text-slate-400 font-mono">
              {lang === 'ar' ? `عرض ${filteredPasses.length} من أصل ${passes.length} تصريح` : `Showing ${filteredPasses.length} of ${passes.length} passes`}
            </div>
          </div>

          {/* Passes Table */}
          <div className="rounded-2xl border border-slate-800 overflow-x-auto">
            <table className="w-full text-right text-xs whitespace-nowrap">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="p-3.5">{t.pass_number}</th>
                  <th className="p-3.5">{t.visitor_name}</th>
                  <th className="p-3.5">{t.company_name}</th>
                  <th className="p-3.5">{t.national_id}</th>
                  <th className="p-3.5">{t.vehicle_plate}</th>
                  <th className="p-3.5">{t.gate}</th>
                  <th className="p-3.5">{t.validity}</th>
                  <th className="p-3.5">{t.status}</th>
                  <th className="p-3.5 text-left">{t.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 bg-slate-900/60">
                {filteredPasses.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="p-8 text-center text-slate-400 text-xs">
                      {lang === 'ar' ? 'لا توجد تصاريح تطابق معايير البحث والفلترة' : 'No passes match the current filter criteria.'}
                    </td>
                  </tr>
                ) : (
                  filteredPasses.map((p) => {
                    const effStatus = p.effectiveStatus;
                    const isVip = p.visitorType === 'vip';

                    return (
                      <tr key={p.id} className="hover:bg-slate-800/40 transition-colors">
                        <td className="p-3.5 font-mono font-bold text-amber-400">{p.passNumber}</td>
                        <td className="p-3.5">
                          <div className="font-bold text-white flex items-center gap-1.5">
                            {p.visitorName}
                            {isVip && <Crown className="w-3.5 h-3.5 text-amber-400" />}
                          </div>
                          <div className="text-[10px] text-slate-400 font-mono">{p.visitorPhone}</div>
                        </td>
                        <td className="p-3.5 text-slate-300 max-w-[160px] truncate">{p.companyName}</td>
                        <td className="p-3.5 font-mono text-slate-300">{p.nationalIdOrPassport}</td>
                        <td className="p-3.5 text-slate-300">{p.vehiclePlate || '—'}</td>
                        <td className="p-3.5 text-amber-300">
                          {p.destinationGate === 'both' ? (lang === 'ar' ? 'بوابة 1 + 2' : 'Gate 1 & 2') : p.destinationGate === 'gate_1' ? (lang === 'ar' ? 'بوابة 1' : 'Gate 1') : (lang === 'ar' ? 'بوابة 2' : 'Gate 2')}
                        </td>
                        <td className="p-3.5">
                          <div className="font-bold text-slate-200">{p.durationLabel}</div>
                          <div className="text-[10px] text-slate-400">
                            {lang === 'ar' ? 'حتى:' : 'Until:'} {new Date(p.validTo).toLocaleTimeString(lang === 'ar' ? 'ar-IQ' : 'en-US', { hour: '2-digit', minute: '2-digit' })}
                          </div>
                        </td>
                        <td className="p-3.5">
                          {effStatus === 'inside' && <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">{t.status_inside}</span>}
                          {effStatus === 'approved' && <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/40">{t.status_approved}</span>}
                          {effStatus === 'pending_security' && <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">{t.status_pending}</span>}
                          {effStatus === 'expired' && <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-red-500/20 text-red-300 border border-red-500/40">{t.status_expired}</span>}
                          {effStatus === 'rejected' && <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40">{t.status_rejected}</span>}
                          {effStatus === 'completed' && <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-slate-800 text-slate-400">{t.status_completed}</span>}
                        </td>
                        <td className="p-3.5 text-left">
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              onClick={() => onOpenPassDetails(p)}
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200"
                              title={t.view_details}
                            >
                              <Eye className="w-3.5 h-3.5" />
                            </button>
                            
                            {/* Quick Extend Validity Button */}
                            <button
                              onClick={() => handleExtendValidity(p, 4)}
                              className="px-2 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 text-[10px] font-bold"
                              title={lang === 'ar' ? 'تمديد الصلاحية 4 ساعات إضافية' : 'Extend +4 hours'}
                            >
                              {lang === 'ar' ? '+4 ساعات' : '+4h'}
                            </button>

                            {/* Delete Pass Button */}
                            <button
                              onClick={() => handleDeletePass(p)}
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-red-600 text-slate-400 hover:text-white transition-colors"
                              title={lang === 'ar' ? 'حذف التصريح نهائياً' : 'Delete pass'}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>

        </div>
      )}

      {/* Tab 2: Visual Analytics Tab */}
      {activeTab === 'analytics' && (
        <AdminAnalyticsTab
          passes={passes}
          movements={movements}
          companies={companies}
          lang={lang}
        />
      )}

      {/* Tab 3: Gate Movements Tab */}
      {activeTab === 'movements' && (
        <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <DoorOpen className="w-5 h-5 text-blue-400" />
              <h3 className="font-bold text-white text-sm">{lang === 'ar' ? 'سجل حركات الدخول والخروج لكافة البوابات' : 'All Gates Traffic Log'}</h3>
            </div>
            <span className="text-xs text-slate-400 font-mono">
              {lang === 'ar' ? `إجمالي الحركات: ${movements.length}` : `Total Logged: ${movements.length}`}
            </span>
          </div>

          <div className="rounded-2xl border border-slate-800 overflow-x-auto">
            <table className="w-full text-right text-xs whitespace-nowrap">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="p-3.5">{lang === 'ar' ? 'الوقت والتاريخ' : 'Date & Time'}</th>
                  <th className="p-3.5">{lang === 'ar' ? 'نوع الحركة' : 'Movement Type'}</th>
                  <th className="p-3.5">{t.gate}</th>
                  <th className="p-3.5">{t.visitor_name}</th>
                  <th className="p-3.5">{t.company_name}</th>
                  <th className="p-3.5">{t.pass_number}</th>
                  <th className="p-3.5">{lang === 'ar' ? 'الحارس المناوب' : 'Gate Guard'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 bg-slate-900/60">
                {movements.map((m) => (
                  <tr key={m.id} className="hover:bg-slate-800/40">
                    <td className="p-3.5 font-mono text-slate-300">
                      {new Date(m.timestamp).toLocaleString(lang === 'ar' ? 'ar-IQ' : 'en-US')}
                    </td>
                    <td className="p-3.5">
                      {m.movementType === 'check_in' ? (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                          {t.movement_checkin}
                        </span>
                      ) : (
                        <span className="px-2.5 py-1 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/30">
                          {t.movement_checkout}
                        </span>
                      )}
                    </td>
                    <td className="p-3.5 text-amber-300 font-bold">
                      {m.gateId === 'gate_1' ? (lang === 'ar' ? 'بوابة 1 (الشمالية)' : 'Gate 1 (North)') : (lang === 'ar' ? 'بوابة 2 (الجنوبية)' : 'Gate 2 (South)')}
                    </td>
                    <td className="p-3.5 font-bold text-white">{m.visitorName}</td>
                    <td className="p-3.5 text-slate-300">{m.companyName}</td>
                    <td className="p-3.5 font-mono text-amber-400">{m.passNumber}</td>
                    <td className="p-3.5 text-slate-400">{m.operatorName}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 4: Nomenclature, Backups, and Reset Settings */}
      {activeTab === 'settings' && (
        <AdminSettingsTab
          currentUser={currentUser}
          lang={lang}
          onDataReset={() => {
            setPasses(storageService.getPasses());
            setMovements(storageService.getMovements());
            setCompanies(storageService.getCompanies());
          }}
        />
      )}

    </div>
  );
};

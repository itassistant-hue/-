import React, { useState } from 'react';
import { User, SystemLicense } from '../types';
import { storageService } from '../services/storage';
import { soundService } from '../services/audio';
import { 
  Lock, 
  User as UserIcon, 
  Key, 
  X, 
  ShieldCheck, 
  AlertCircle, 
  Building2, 
  DoorOpen, 
  Radio, 
  Sliders,
  Award,
  ChevronRight,
  LogIn
} from 'lucide-react';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: User) => void;
  isStandalone?: boolean;
}

export const LoginModal: React.FC<LoginModalProps> = ({ 
  isOpen, 
  onClose, 
  onLoginSuccess,
  isStandalone = false 
}) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [license, setLicense] = useState<SystemLicense>(() => storageService.getLicense());
  const users = storageService.getUsers();

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const found = users.find(
      u => u.username.toLowerCase() === username.trim().toLowerCase() && u.password === password.trim()
    );

    if (found) {
      if (!found.active) {
        setErrorMsg('هذا الحساب معطل حالياً من قبل إدارة المنظومة الأمنية');
        soundService.playAccessDenied();
        return;
      }
      storageService.setCurrentUser(found);
      onLoginSuccess(found);
      soundService.playAccessGranted();
      onClose();
    } else {
      setErrorMsg('اسم المستخدم أو كلمة المرور غير صحيحة! يرجى التحقق وإعادة المحاولة.');
      soundService.playAccessDenied();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-lg font-['Tajawal',sans-serif]">
      <div className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden text-slate-100 flex flex-col">
        
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-slate-950 font-black shadow-md shadow-amber-500/20">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">بوابة تسجيل الدخول الموحدة</h3>
              <p className="text-[11px] text-slate-400">{license.facilityName}</p>
            </div>
          </div>
          {!isStandalone && (
            <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors">
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {/* Body */}
        <div className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
          
          {errorMsg && (
            <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs font-bold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              {errorMsg}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">اسم المستخدم (Username):</label>
              <div className="relative">
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="أدخل اسم المستخدم..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 pl-9 text-xs text-white focus:border-amber-400 outline-none"
                />
                <UserIcon className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">كلمة المرور (Password):</label>
              <div className="relative">
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 pl-9 text-xs text-white focus:border-amber-400 outline-none font-mono"
                />
                <Key className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center gap-2 active:scale-95"
            >
              <LogIn className="w-4 h-4" />
              <span>دخول النظام الأمني</span>
            </button>
          </form>

          {/* Developer Copyright Branding Box (Requested by User) */}
          <div className="mt-4 pt-4 border-t border-slate-800/80 text-center space-y-1 bg-slate-950/50 p-3 rounded-2xl">
            <div className="flex items-center justify-center gap-1.5 text-amber-400 text-xs font-bold">
              <Award className="w-4 h-4" />
              <span>{license.developerNameAr || 'المهندس علي أحمد عنيد'}</span>
            </div>
            <p className="text-[11px] text-slate-400">{license.copyrightAr || 'برمجة وتطوير: المهندس علي أحمد عنيد • جميع الحقوق محفوظة'}</p>
            <p className="text-[10px] text-slate-500 font-sans tracking-wide">{license.copyrightEn || 'Engineered & Developed by Eng. Ali Ahmed Aneed • All Rights Reserved'}</p>
          </div>

        </div>

      </div>
    </div>
  );
};


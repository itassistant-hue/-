import React, { useState } from 'react';
import { User, Language } from '../types';
import { storageService } from '../services/storage';
import { soundService } from '../services/audio';
import { translations } from '../services/i18n';
import { 
  AlertTriangle, 
  Radio, 
  X, 
  Volume2, 
  DoorOpen, 
  ShieldAlert, 
  Flame, 
  Cross, 
  Building2, 
  Send, 
  CheckCircle2, 
  Zap,
  ShieldCheck
} from 'lucide-react';

interface EmergencyModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  lang?: Language;
}

const PRESET_MESSAGES = {
  ar: [
    { title: 'إغلاق فوري للبوابات (Lockdown)', msg: 'إغلاق شامل للبوابات فوراً - اشتباه أمني يمنع الدخول والخروج حتى إشعار آخر.' },
    { title: 'استنفار وتفتيش مشدد', msg: 'استنفار وتدقيق أمني مضاعف على كافة الهويات وبطاقات التصاريح ومركبات الشحن.' },
    { title: 'طوارئ حريق وإخلاء', msg: 'إنذار حريق - فتح مسار الطوارئ لمرور سيارات الدفاع المدني فوراً.' },
    { title: 'استغاثة طبية وإسعاف', msg: 'حالة طبية طارئة - تأمين دخول سيارة الإسعاف ونقل المصاب دون تأخير.' },
    { title: 'تمرين واختبار جاهزية (Drill)', msg: 'تمرين أمني واختبار سرعة استجابة البوابات وغرفة السيطرة - يرجى تأكيد الاستلام.' }
  ],
  en: [
    { title: 'Full Gate Lockdown', msg: 'Immediate total lockdown of all gates. Halt entry/exit pending security clearance.' },
    { title: 'Heightened Inspection', msg: 'Strict screening active for all visitors, cargo trucks, and personnel IDs.' },
    { title: 'Fire Alert & Evacuation', msg: 'Fire incident reported. Clear priority emergency lane for fire department.' },
    { title: 'Medical Emergency', msg: 'Medical team incoming. Expedite immediate access through Gate 1.' },
    { title: 'Readiness Drill', msg: 'Operational readiness drill in progress. All guards must acknowledge receipt.' }
  ]
};

export const EmergencyModal: React.FC<EmergencyModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  lang = 'ar'
}) => {
  const t = translations[lang] || translations.ar;

  const [title, setTitle] = useState('');
  const [message, setMessage] = useState('');
  const [severity, setSeverity] = useState<'critical' | 'warning' | 'drill' | 'lockdown'>('critical');
  const [targets, setTargets] = useState<string[]>(['gate_1', 'gate_2', 'security_ops', 'all_guards']);
  const [soundAlert, setSoundAlert] = useState(true);
  const [broadcastSent, setBroadcastSent] = useState(false);

  if (!isOpen) return null;

  const handleToggleTarget = (id: string) => {
    if (targets.includes(id)) {
      setTargets(targets.filter(t => t !== id));
    } else {
      setTargets([...targets, id]);
    }
  };

  const handleSelectPreset = (p: { title: string; msg: string }) => {
    setTitle(p.title);
    setMessage(p.msg);
  };

  const handleSendBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    const customTitle = title.trim() || (lang === 'ar' ? 'نداء استغاثة وطوارئ أمنية عاجلة' : 'Urgent Security SOS Alert');

    storageService.sendEmergencyBroadcast({
      title: customTitle,
      message: message.trim(),
      severity,
      targets,
      sender: currentUser.fullName,
      senderRole: currentUser.role,
      soundAlert
    });

    if (soundAlert) {
      soundService.playEmergencyAlert();
    }

    setBroadcastSent(true);
    setTimeout(() => {
      setBroadcastSent(false);
      onClose();
    }, 1300);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md font-['Tajawal',sans-serif] animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-950 border border-red-500/40 rounded-3xl shadow-[0_0_50px_rgba(239,68,68,0.25)] overflow-hidden text-slate-100 flex flex-col max-h-[92vh]">
        
        {/* Sleek Compact Tactical Header */}
        <div className="flex items-center justify-between px-5 py-3.5 bg-gradient-to-r from-red-950/80 via-slate-950 to-red-950/80 border-b border-red-900/40">
          <div className="flex items-center gap-2.5">
            <div className="relative flex items-center justify-center w-8 h-8 rounded-xl bg-red-600 text-white font-black shadow-md shadow-red-600/40 animate-pulse">
              <AlertTriangle className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-black text-white tracking-wide">
                  {lang === 'ar' ? 'مركز البث والنداء الطارئ (SOS)' : 'Tactical SOS Command'}
                </h3>
                <span className="px-1.5 py-0.2 rounded-md bg-red-500/20 text-red-300 text-[9px] font-mono font-bold border border-red-500/30">
                  LIVE
                </span>
              </div>
              <p className="text-[10px] text-red-300/80 leading-tight">
                {lang === 'ar' ? 'توجيه فوري لصافرات الإنذار والتعليمات الميدانية' : 'Instant alarm & tactical broadcast to terminals'}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-900 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body Content */}
        <div className="p-4 space-y-3.5 overflow-y-auto">
          
          {broadcastSent ? (
            <div className="py-8 text-center space-y-2">
              <div className="w-12 h-12 mx-auto rounded-2xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 animate-pulse">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <h4 className="text-sm font-black text-white">
                {lang === 'ar' ? 'تم إطلاق البث وصافرة الإنذار بنجاح!' : 'Emergency Siren & Alert Broadcasted!'}
              </h4>
              <p className="text-[11px] text-slate-400">
                {lang === 'ar' ? 'تم تعميم البلاغ على كافة المحطات المختارة.' : 'All targeted terminals have received the alarm.'}
              </p>
            </div>
          ) : (
            <form onSubmit={handleSendBroadcast} className="space-y-3">
              
              {/* 1. Compact Target Selection Grid */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-[11px] font-bold text-slate-300 flex items-center gap-1">
                    <Radio className="w-3 h-3 text-red-400" />
                    <span>{t.emergency_target_recipients}:</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => setTargets(['gate_1', 'gate_2', 'security_ops', 'all_guards', 'fire', 'medical', 'companies'])}
                    className="text-[10px] text-amber-400 hover:text-amber-300 font-bold flex items-center gap-0.5"
                  >
                    <Zap className="w-2.5 h-2.5" />
                    <span>{lang === 'ar' ? 'تحديد الكل' : 'Select All'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                  
                  <button
                    type="button"
                    onClick={() => handleToggleTarget('gate_1')}
                    className={`px-2 py-1.5 rounded-xl border text-[11px] font-bold transition-all flex items-center gap-1.5 ${
                      targets.includes('gate_1')
                        ? 'bg-blue-600/30 border-blue-500 text-blue-200'
                        : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <DoorOpen className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                    <span className="truncate">{lang === 'ar' ? 'بوابة 1' : 'Gate 1'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleToggleTarget('gate_2')}
                    className={`px-2 py-1.5 rounded-xl border text-[11px] font-bold transition-all flex items-center gap-1.5 ${
                      targets.includes('gate_2')
                        ? 'bg-indigo-600/30 border-indigo-500 text-indigo-200'
                        : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <DoorOpen className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                    <span className="truncate">{lang === 'ar' ? 'بوابة 2' : 'Gate 2'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleToggleTarget('security_ops')}
                    className={`px-2 py-1.5 rounded-xl border text-[11px] font-bold transition-all flex items-center gap-1.5 ${
                      targets.includes('security_ops')
                        ? 'bg-amber-600/30 border-amber-500 text-amber-200'
                        : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <ShieldAlert className="w-3.5 h-3.5 text-amber-400 shrink-0" />
                    <span className="truncate">{lang === 'ar' ? 'السيطرة SOC' : 'SOC Center'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleToggleTarget('all_guards')}
                    className={`px-2 py-1.5 rounded-xl border text-[11px] font-bold transition-all flex items-center gap-1.5 ${
                      targets.includes('all_guards')
                        ? 'bg-red-600/30 border-red-500 text-red-200'
                        : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <Radio className="w-3.5 h-3.5 text-red-400 shrink-0" />
                    <span className="truncate">{lang === 'ar' ? 'كافة الحراس' : 'All Guards'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleToggleTarget('fire')}
                    className={`px-2 py-1.5 rounded-xl border text-[11px] font-bold transition-all flex items-center gap-1.5 ${
                      targets.includes('fire')
                        ? 'bg-orange-600/30 border-orange-500 text-orange-200'
                        : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <Flame className="w-3.5 h-3.5 text-orange-400 shrink-0" />
                    <span className="truncate">{lang === 'ar' ? 'الإطفاء' : 'Fire'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleToggleTarget('medical')}
                    className={`px-2 py-1.5 rounded-xl border text-[11px] font-bold transition-all flex items-center gap-1.5 ${
                      targets.includes('medical')
                        ? 'bg-emerald-600/30 border-emerald-500 text-emerald-200'
                        : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <Cross className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span className="truncate">{lang === 'ar' ? 'الإسعاف' : 'Medical'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleToggleTarget('companies')}
                    className={`px-2 py-1.5 rounded-xl border text-[11px] font-bold transition-all flex items-center gap-1.5 ${
                      targets.includes('companies')
                        ? 'bg-purple-600/30 border-purple-500 text-purple-200'
                        : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <Building2 className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                    <span className="truncate">{lang === 'ar' ? 'الشركات' : 'Companies'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setTargets(['gate_1', 'gate_2', 'security_ops'])}
                    className="px-2 py-1.5 rounded-xl border border-slate-700 bg-slate-900 text-slate-300 text-[10px] font-bold hover:bg-slate-800 flex items-center justify-center gap-1"
                  >
                    <ShieldCheck className="w-3 h-3 text-amber-400" />
                    <span>{lang === 'ar' ? 'البوابات فقط' : 'Gates Only'}</span>
                  </button>

                </div>
              </div>

              {/* 2. Quick Preset Chips */}
              <div>
                <label className="block text-[10px] font-bold text-slate-400 mb-1">
                  {lang === 'ar' ? 'نماذج جاهزة سريعة:' : 'Quick Presets:'}
                </label>
                <div className="flex flex-wrap gap-1">
                  {(lang === 'ar' ? PRESET_MESSAGES.ar : PRESET_MESSAGES.en).map((p, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => handleSelectPreset(p)}
                      className="px-2 py-0.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-[10px] text-slate-300 border border-slate-800 hover:border-red-500/40 transition-colors"
                    >
                      {p.title}
                    </button>
                  ))}
                </div>
              </div>

              {/* 3. Severity & Title */}
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-bold text-slate-300 mb-1">{t.emergency_severity}:</label>
                  <select
                    value={severity}
                    onChange={(e) => setSeverity(e.target.value as any)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-white outline-none focus:border-red-400"
                  >
                    <option value="critical">{lang === 'ar' ? '🔴 طوارئ قصوى' : '🔴 Critical Alert'}</option>
                    <option value="lockdown">{lang === 'ar' ? '⛔ إغلاق أمني (Lockdown)' : '⛔ Gate Lockdown'}</option>
                    <option value="warning">{lang === 'ar' ? '🟡 تنبيه وتفتيش' : '🟡 Security Warning'}</option>
                    <option value="drill">{lang === 'ar' ? '🔵 تمرين وتدريب' : '🔵 Security Drill'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-300 mb-1">
                    {lang === 'ar' ? 'عنوان البلاغ:' : 'Alert Title:'}
                  </label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder={lang === 'ar' ? 'إغلاق فوري...' : 'Lockdown...'}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-2.5 py-1.5 text-xs text-white outline-none focus:border-red-400"
                  />
                </div>
              </div>

              {/* 4. Message Content */}
              <div>
                <label className="block text-[11px] font-bold text-slate-300 mb-1">{t.emergency_custom_msg}:</label>
                <textarea
                  required
                  rows={2}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder={lang === 'ar' ? 'اكتب التعليمات الأمنية الميدانية هنا...' : 'Type tactical instructions here...'}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-xs text-white outline-none focus:border-red-400 resize-none leading-relaxed"
                />
              </div>

              {/* 5. Siren Switch */}
              <div className="flex items-center justify-between p-2.5 rounded-xl bg-slate-900/90 border border-slate-800">
                <div className="flex items-center gap-2">
                  <Volume2 className="w-3.5 h-3.5 text-red-400" />
                  <span className="text-[11px] text-slate-300 font-bold">
                    {lang === 'ar' ? 'تشغيل صافرة الإنذار الصوتي' : 'Trigger Audio Siren'}
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={soundAlert}
                  onChange={(e) => setSoundAlert(e.target.checked)}
                  className="w-4 h-4 accent-red-600 rounded cursor-pointer"
                />
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-900">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-white text-xs font-bold transition-colors"
                >
                  {t.cancel}
                </button>

                <button
                  type="submit"
                  disabled={!message.trim() || targets.length === 0}
                  className="px-5 py-2 rounded-xl bg-gradient-to-r from-red-600 via-red-500 to-red-600 hover:from-red-500 hover:to-red-500 text-white font-black text-xs flex items-center gap-1.5 shadow-lg shadow-red-600/40 active:scale-95 disabled:opacity-50 transition-all"
                >
                  <Send className="w-3.5 h-3.5" />
                  <span>{t.emergency_send_broadcast}</span>
                </button>
              </div>

            </form>
          )}

        </div>

      </div>
    </div>
  );
};

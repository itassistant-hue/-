import React, { useState, useEffect } from 'react';
import { GateMovement, PassRequest, PassType, User, GateDefinition } from '../types';
import { storageService } from '../services/storage';
import { soundService } from '../services/audio';
import { 
  Search, 
  QrCode, 
  ShieldCheck, 
  LogIn, 
  LogOut, 
  AlertTriangle, 
  Crown, 
  Car, 
  Building2, 
  UserCheck, 
  Clock, 
  FileText, 
  CheckCircle2, 
  Ban, 
  Eye, 
  RefreshCw,
  Truck,
  Sparkles,
  Layers,
  ArrowRightLeft
} from 'lucide-react';

interface GateGuardTerminalProps {
  currentUser: User;
  onOpenPassDetails: (pass: PassRequest) => void;
  onOpenNewPassModal: () => void;
}

export const GateGuardTerminal: React.FC<GateGuardTerminalProps> = ({
  currentUser,
  onOpenPassDetails,
  onOpenNewPassModal
}) => {
  const [gates, setGates] = useState<GateDefinition[]>(() => storageService.getGates().filter(g => g.enabled));
  const initialGateId = currentUser.gateId || (gates.length > 0 ? gates[0].id : 'gate_1');
  const [selectedGate, setSelectedGate] = useState<string>(initialGateId);
  const [searchQuery, setSearchQuery] = useState('');
  const [passes, setPasses] = useState<PassRequest[]>(() => storageService.getPasses());
  const [movements, setMovements] = useState<GateMovement[]>(() => storageService.getMovements());
  const [activeTab, setActiveTab] = useState<'scan' | 'inside' | 'approved' | 'history'>('scan');
  const [lastScannedPass, setLastScannedPass] = useState<PassRequest | null>(null);
  const [notesInput, setNotesInput] = useState('');
  const [materialsChecked, setMaterialsChecked] = useState(false);

  useEffect(() => {
    const handleStorageChange = () => {
      setPasses(storageService.getPasses());
      setMovements(storageService.getMovements());
      setGates(storageService.getGates().filter(g => g.enabled));
    };
    window.addEventListener('gatepass_storage_event', handleStorageChange);
    return () => window.removeEventListener('gatepass_storage_event', handleStorageChange);
  }, []);

  // Update selected gate if user switches persona
  useEffect(() => {
    if (currentUser.gateId) {
      setSelectedGate(currentUser.gateId);
    }
  }, [currentUser]);

  // Search logic
  const normalizedQuery = searchQuery.trim().toLowerCase();
  const searchResults = normalizedQuery
    ? passes.filter(p => 
        p.passNumber.toLowerCase().includes(normalizedQuery) ||
        p.visitorName.toLowerCase().includes(normalizedQuery) ||
        p.nationalIdOrPassport.toLowerCase().includes(normalizedQuery) ||
        (p.vehiclePlate && p.vehiclePlate.toLowerCase().includes(normalizedQuery)) ||
        p.companyName.toLowerCase().includes(normalizedQuery)
      )
    : [];

  const handleSelectPassToVerify = (pass: PassRequest) => {
    setLastScannedPass(pass);
    setNotesInput('');
    setMaterialsChecked(false);
    const effStatus = storageService.getEffectiveStatus(pass);
    
    if (effStatus === 'expired') {
      soundService.playAccessDenied();
    } else if (pass.visitorType === 'vip') {
      soundService.playVipFanfare();
    } else if (effStatus === 'approved' || effStatus === 'inside') {
      soundService.playScanBeep();
    } else {
      soundService.playAccessDenied();
    }
  };

  const handleQuickCheckIn = (pass: PassRequest) => {
    const updated = storageService.checkIn(pass.id, selectedGate, currentUser, notesInput || undefined);
    if (updated) {
      setLastScannedPass(updated);
      soundService.playAccessGranted();
    }
  };

  const handleQuickCheckOut = (pass: PassRequest) => {
    const updated = storageService.checkOut(pass.id, selectedGate, currentUser, notesInput || undefined);
    if (updated) {
      setLastScannedPass(updated);
      soundService.playAccessGranted();
    }
  };

  // Filtered lists for this gate
  const effectivePasses = passes.map(p => ({
    ...p,
    effectiveStatus: storageService.getEffectiveStatus(p)
  }));

  const insideCurrentGatePasses = effectivePasses.filter(p => 
    p.effectiveStatus === 'inside' && (p.entryGate === selectedGate || !p.entryGate)
  );

  const approvedReadyPasses = effectivePasses.filter(p => 
    p.effectiveStatus === 'approved' && (p.destinationGate === 'both' || p.destinationGate === selectedGate)
  );

  const gateMovements = movements.filter(m => m.gateId === selectedGate);

  const isCurrentGateMatched = (pass: PassRequest) => {
    return pass.destinationGate === 'both' || pass.destinationGate === selectedGate;
  };

  const getVisitorTypeBadge = (type: PassType) => {
    switch (type) {
      case 'vip':
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-500/20 text-amber-300 border border-amber-500/40">VIP شخصية هامة</span>;
      case 'materials':
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-orange-500/20 text-orange-300 border border-orange-500/40">شحنة / مواد</span>;
      case 'contractor':
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40">مقاول / صيانة</span>;
      case 'employee':
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 text-blue-300 border border-blue-500/40">موظف موقع</span>;
      default:
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-500/20 text-slate-300 border border-slate-500/40">ضيف / زائر</span>;
    }
  };

  return (
    <div className="space-y-6 font-['Tajawal',sans-serif]">
      
      {/* Top Gate Station Header */}
      <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-white shadow-lg shadow-blue-500/20">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-white">
                محطة حرس {(() => {
                  const g = gates.find(gate => gate.id === selectedGate);
                  return g ? g.nameAr : (selectedGate === 'gate_1' ? 'بوابة 1 (الشمالية)' : selectedGate === 'gate_2' ? 'بوابة 2 (الجنوبية)' : selectedGate);
                })()}
              </h2>
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              مشغل الكابينة: <span className="text-amber-400 font-bold">{currentUser.fullName}</span> • نظام التحقق والمسح الفوري
            </p>
          </div>
        </div>

        {/* Gate Switcher (if admin or not locked) */}
        <div className="flex items-center gap-2">
          {!currentUser.gateId && gates.length > 1 && (
            <div className="flex items-center bg-slate-950 p-1.5 rounded-2xl border border-slate-800 flex-wrap gap-1">
              {gates.map((g) => (
                <button
                  key={g.id}
                  onClick={() => {
                    setSelectedGate(g.id);
                    soundService.playScanBeep();
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    selectedGate === g.id
                      ? 'bg-blue-600 text-white shadow-md'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {g.nameAr}
                </button>
              ))}
            </div>
          )}

          <button
            onClick={onOpenNewPassModal}
            className="px-4 py-2 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition-colors flex items-center gap-1.5"
          >
            <FileText className="w-4 h-4" />
            <span>تصريح طارئ</span>
          </button>
        </div>
      </div>

      {/* Main Terminal Grid: Left Scanner & Verification, Right Lists */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Search & Verification Card (Span 7) */}
        <div className="lg:col-span-7 space-y-5">
          
          {/* Fast Search / Scanner Input Bar */}
          <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-3">
            <label className="block text-xs font-bold text-slate-300">
              مسح الباركود أو البحث الفوري (رقم التصريح، اسم الشخص، رقم الهوية، أو رقم اللوحة):
            </label>
            
            <div className="relative">
              <input
                type="text"
                autoFocus
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  if (e.target.value.length > 2) {
                    const firstMatch = passes.find(p => 
                      p.passNumber.toLowerCase().includes(e.target.value.toLowerCase()) ||
                      p.visitorName.toLowerCase().includes(e.target.value.toLowerCase()) ||
                      p.nationalIdOrPassport.toLowerCase().includes(e.target.value.toLowerCase()) ||
                      (p.vehiclePlate && p.vehiclePlate.toLowerCase().includes(e.target.value.toLowerCase()))
                    );
                    if (firstMatch) {
                      handleSelectPassToVerify(firstMatch);
                    }
                  }
                }}
                placeholder="اكتب اسم الزائر، رقم الهوية، لوحة السيارة، أو امسح الباركود..."
                className="w-full bg-slate-950 border-2 border-amber-500/40 rounded-2xl px-4 py-3.5 pl-24 text-sm text-white font-bold placeholder:text-slate-500 focus:border-amber-400 outline-none shadow-inner"
              />
              <div className="absolute left-3 top-2.5 flex items-center gap-1">
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="p-1 text-slate-400 hover:text-white rounded-lg bg-slate-800 text-xs px-2 font-bold"
                  >
                    مسح
                  </button>
                )}
                <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400">
                  <Search className="w-4 h-4" />
                </div>
              </div>
            </div>

            {/* Live Search Quick Results Dropdown/Chips */}
            {searchResults.length > 0 && (
              <div className="p-2 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5 max-h-48 overflow-y-auto">
                <div className="text-[11px] text-slate-400 px-2 py-1">نتائج البحث الفوري ({searchResults.length}):</div>
                {searchResults.map((p) => {
                  const status = storageService.getEffectiveStatus(p);
                  return (
                    <button
                      key={p.id}
                      onClick={() => handleSelectPassToVerify(p)}
                      className={`w-full text-right p-2.5 rounded-xl text-xs transition-all flex items-center justify-between ${
                        lastScannedPass?.id === p.id 
                          ? 'bg-amber-500/20 border border-amber-500/40 text-amber-200' 
                          : 'bg-slate-900 hover:bg-slate-800 text-slate-300'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span className="font-mono font-bold text-amber-400">{p.passNumber}</span>
                        <span className="font-bold text-white">{p.visitorName}</span>
                        <span className="text-slate-400">({p.companyName})</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {status === 'expired' && <span className="text-red-400 text-[11px] font-bold">منتهي الصلاحية</span>}
                        {status === 'inside' && <span className="text-emerald-400 text-[11px] font-bold">داخل الموقع</span>}
                        {status === 'approved' && <span className="text-blue-400 text-[11px] font-bold">مصرّح</span>}
                        {getVisitorTypeBadge(p.visitorType)}
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* Scanned/Verified Pass Inspection Display */}
          {lastScannedPass ? (
            <div className={`p-6 rounded-3xl border shadow-2xl transition-all ${
              storageService.getEffectiveStatus(lastScannedPass) === 'expired'
                ? 'bg-red-950/20 border-red-500/50'
                : lastScannedPass.visitorType === 'vip'
                ? 'bg-gradient-to-b from-amber-950/30 to-slate-900 border-amber-500/50'
                : 'bg-slate-900 border-slate-800'
            }`}>
              
              {/* Inspection Status Header */}
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-4 mb-4">
                <div className="flex items-center gap-3">
                  <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-xl ${
                    storageService.getEffectiveStatus(lastScannedPass) === 'expired'
                      ? 'bg-red-600 text-white'
                      : lastScannedPass.visitorType === 'vip'
                      ? 'bg-amber-500 text-slate-950'
                      : 'bg-blue-600 text-white'
                  }`}>
                    {storageService.getEffectiveStatus(lastScannedPass) === 'expired' ? (
                      <AlertTriangle className="w-7 h-7" />
                    ) : lastScannedPass.visitorType === 'vip' ? (
                      <Crown className="w-7 h-7" />
                    ) : (
                      <ShieldCheck className="w-7 h-7" />
                    )}
                  </div>
                  <div>
                    <div className="text-xs font-mono font-bold text-amber-400">{lastScannedPass.passNumber}</div>
                    <h3 className="text-lg font-black text-white">{lastScannedPass.visitorName}</h3>
                  </div>
                </div>

                <div className="text-left">
                  {getVisitorTypeBadge(lastScannedPass.visitorType)}
                </div>
              </div>

              {/* CRITICAL WARNING: IF EXPIRED */}
              {storageService.getEffectiveStatus(lastScannedPass) === 'expired' && (
                <div className="mb-5 p-4 rounded-2xl bg-red-600/20 border-2 border-red-500 text-red-200 space-y-2 animate-pulse">
                  <div className="flex items-center gap-2 text-sm font-black text-red-400">
                    <AlertTriangle className="w-6 h-6 shrink-0" />
                    <span>تحذير أمني: هذا التصريح منتهي الصلاحية! يمنع الدخول منعاً باتاً!</span>
                  </div>
                  <p className="text-xs text-slate-300">
                    انتهت صلاحية التصريح في: <span className="font-bold text-red-300">{new Date(lastScannedPass.validTo).toLocaleString('ar-IQ')}</span>.
                    مدة التصريح المقررة كانت: ({lastScannedPass.durationLabel}).
                  </p>
                </div>
              )}

              {/* WARNING: IF PENDING */}
              {lastScannedPass.status === 'pending_security' && (
                <div className="mb-5 p-4 rounded-2xl bg-amber-500/20 border border-amber-500 text-amber-200 text-xs font-bold flex items-center gap-2">
                  <Clock className="w-5 h-5 shrink-0" />
                  <span>تنبيه: هذا النداء قيد مراجعة السيطرة الأمنية ولم يتم التصريح له بعد! يرجى انتظار الموافقة الرسمية.</span>
                </div>
              )}

              {/* WARNING: IF WRONG GATE */}
              {!isCurrentGateMatched(lastScannedPass) && (
                <div className="mb-5 p-3 rounded-2xl bg-orange-500/20 border border-orange-500 text-orange-200 text-xs font-bold flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>تنبيه البوابة: هذا التصريح مخصص لـ ({lastScannedPass.destinationGate === 'gate_1' ? 'بوابة 1 فقط' : 'بوابة 2 فقط'})</span>
                </div>
              )}

              {/* Details Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs mb-5">
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <div className="text-[11px] text-slate-400 mb-0.5">الشركة المستضيفة:</div>
                  <div className="font-bold text-white truncate">{lastScannedPass.companyName}</div>
                </div>
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <div className="text-[11px] text-slate-400 mb-0.5">رقم الهوية / الجواز:</div>
                  <div className="font-bold font-mono text-amber-300">{lastScannedPass.nationalIdOrPassport}</div>
                </div>
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <div className="text-[11px] text-slate-400 mb-0.5">الهاتف والجنسية:</div>
                  <div className="font-bold text-slate-200">{lastScannedPass.visitorPhone} • {lastScannedPass.nationality}</div>
                </div>
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <div className="text-[11px] text-slate-400 mb-0.5">بيانات المركبة:</div>
                  <div className="font-bold text-slate-200">{lastScannedPass.vehiclePlate || 'بدون سيارة'}</div>
                </div>
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <div className="text-[11px] text-slate-400 mb-0.5">مدة التصريح:</div>
                  <div className="font-bold text-amber-400">{lastScannedPass.durationLabel}</div>
                </div>
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <div className="text-[11px] text-slate-400 mb-0.5">صلاحية التصريح حتى:</div>
                  <div className="font-bold text-slate-200">{new Date(lastScannedPass.validTo).toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' })}</div>
                </div>
              </div>

              {/* Purpose & Materials checklist */}
              <div className="space-y-2 mb-5">
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs">
                  <span className="text-slate-400">الغرض من الزيارة: </span>
                  <span className="text-white font-medium">{lastScannedPass.purpose}</span>
                </div>

                {lastScannedPass.materialsList && (
                  <div className="p-3.5 rounded-xl bg-amber-950/20 border border-amber-500/30 text-xs space-y-2">
                    <div className="font-bold text-amber-300">قائمة المواد والأجهزة المرافقة للتفتيش:</div>
                    <div className="text-slate-200">{lastScannedPass.materialsList}</div>
                    <label className="flex items-center gap-2 text-emerald-400 font-bold pt-1 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={materialsChecked}
                        onChange={(e) => setMaterialsChecked(e.target.checked)}
                        className="w-4 h-4 rounded text-amber-500 focus:ring-amber-400"
                      />
                      <span>تمت معاينة ومطابقة المواد بالبوابة وتفتيشها أمنياً</span>
                    </label>
                  </div>
                )}
              </div>

              {/* Guard Action Buttons */}
              <div className="pt-2 flex flex-wrap items-center justify-between gap-3 border-t border-slate-800">
                <button
                  onClick={() => onOpenPassDetails(lastScannedPass)}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-1.5"
                >
                  <Eye className="w-4 h-4" />
                  عرض البطاقة والطباعة
                </button>

                <div className="flex items-center gap-2">
                  {/* If Approved & outside -> CHECK IN */}
                  {storageService.getEffectiveStatus(lastScannedPass) === 'approved' && (
                    <button
                      onClick={() => handleQuickCheckIn(lastScannedPass)}
                      className="px-6 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs shadow-lg shadow-emerald-600/30 flex items-center gap-2 transition-transform active:scale-95"
                    >
                      <LogIn className="w-4 h-4" />
                      تسجيل دخول للموقع (Check In)
                    </button>
                  )}

                  {/* If Inside -> CHECK OUT */}
                  {storageService.getEffectiveStatus(lastScannedPass) === 'inside' && (
                    <button
                      onClick={() => handleQuickCheckOut(lastScannedPass)}
                      className="px-6 py-3 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-black text-xs shadow-lg shadow-blue-600/30 flex items-center gap-2 transition-transform active:scale-95"
                    >
                      <LogOut className="w-4 h-4" />
                      تسجيل خروج ومغادرة (Check Out)
                    </button>
                  )}

                  {/* If Expired */}
                  {storageService.getEffectiveStatus(lastScannedPass) === 'expired' && (
                    <button
                      disabled
                      className="px-6 py-3 rounded-2xl bg-red-900/50 text-red-300 border border-red-500/40 font-bold text-xs cursor-not-allowed flex items-center gap-2"
                    >
                      <Ban className="w-4 h-4" />
                      ممنوع الدخول (منتهي الصلاحية)
                    </button>
                  )}
                </div>
              </div>

            </div>
          ) : (
            /* Standby / Ready to scan state */
            <div className="p-12 rounded-3xl bg-slate-900/60 border border-slate-800/80 text-center text-slate-400 space-y-3">
              <div className="w-16 h-16 mx-auto rounded-3xl bg-slate-800/60 border border-slate-700 flex items-center justify-center text-amber-400 shadow-inner">
                <QrCode className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold text-slate-200">الكابينة جاهزة لمسح واستقبال التصاريح</h3>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                اكتب في خانة البحث بالأعلى أو اختر من القوائم الجانبية لتسجيل الدخول والخروج الفوري
              </p>
            </div>
          )}

        </div>

        {/* Right Column: Gate Lists & Tabs (Span 5) */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* Tabs */}
          <div className="flex items-center gap-1.5 p-1.5 bg-slate-900 rounded-2xl border border-slate-800 text-xs">
            <button
              onClick={() => setActiveTab('inside')}
              className={`flex-1 py-2 px-2 rounded-xl font-bold transition-all text-center ${
                activeTab === 'inside'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              داخل الموقع ({insideCurrentGatePasses.length})
            </button>
            <button
              onClick={() => setActiveTab('approved')}
              className={`flex-1 py-2 px-2 rounded-xl font-bold transition-all text-center ${
                activeTab === 'approved'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              المصرّح لهم ({approvedReadyPasses.length})
            </button>
            <button
              onClick={() => setActiveTab('history')}
              className={`flex-1 py-2 px-2 rounded-xl font-bold transition-all text-center ${
                activeTab === 'history'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              سجل الحركات ({gateMovements.length})
            </button>
          </div>

          {/* Tab 1: Inside Current Site */}
          {activeTab === 'inside' && (
            <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                <span>المتواجدون حالياً عبر هذه البوابة:</span>
                <span className="text-emerald-400 font-bold font-mono">{insideCurrentGatePasses.length} شخص</span>
              </div>

              {insideCurrentGatePasses.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500">لا يوجد أشخاص مسجلين داخل الموقع حالياً عبر هذه البوابة</div>
              ) : (
                <div className="space-y-2 max-h-[500px] overflow-y-auto">
                  {insideCurrentGatePasses.map((p) => (
                    <div
                      key={p.id}
                      className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition-colors flex items-center justify-between"
                    >
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-white text-xs">{p.visitorName}</span>
                          {p.visitorType === 'vip' && <Crown className="w-3.5 h-3.5 text-amber-400" />}
                        </div>
                        <div className="text-[11px] text-slate-400">{p.companyName}</div>
                        <div className="text-[10px] text-emerald-400 font-mono mt-0.5">
                          دخول: {p.entryTime ? new Date(p.entryTime).toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' }) : 'مسجل'}
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleQuickCheckOut(p)}
                          className="px-3 py-1.5 rounded-xl bg-blue-600/30 hover:bg-blue-600 text-blue-300 hover:text-white text-xs font-bold transition-colors"
                        >
                          خروج
                        </button>
                        <button
                          onClick={() => handleSelectPassToVerify(p)}
                          className="p-1.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Tab 2: Approved Passes Ready for Entry */}
          {activeTab === 'approved' && (
            <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-400 px-1">
                <span>التصاريح المعتمدة الجاهزة للدخول:</span>
                <span className="text-blue-400 font-bold font-mono">{approvedReadyPasses.length} تصريح</span>
              </div>

              {approvedReadyPasses.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500">لا توجد تصاريح معتمدة معلقة للدخول</div>
              ) : (
                <div className="space-y-2 max-h-[500px] overflow-y-auto">
                  {approvedReadyPasses.map((p) => (
                    <div
                      key={p.id}
                      className="p-3 rounded-2xl bg-slate-950 border border-slate-800 hover:border-slate-700 transition-colors flex items-center justify-between"
                    >
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-white text-xs">{p.visitorName}</span>
                          {p.visitorType === 'vip' && <Crown className="w-3.5 h-3.5 text-amber-400" />}
                        </div>
                        <div className="text-[11px] text-slate-400">{p.companyName}</div>
                        <div className="text-[10px] text-amber-400 font-mono mt-0.5">{p.passNumber} • {p.durationLabel}</div>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleQuickCheckIn(p)}
                          className="px-3 py-1.5 rounded-xl bg-emerald-600/30 hover:bg-emerald-600 text-emerald-300 hover:text-white text-xs font-bold transition-colors"
                        >
                          دخول
                        </button>
                        <button
                          onClick={() => handleSelectPassToVerify(p)}
                          className="p-1.5 rounded-xl bg-slate-800 text-slate-300 hover:text-white"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Tab 3: Gate Movement Feed */}
          {activeTab === 'history' && (
            <div className="p-4 rounded-3xl bg-slate-900 border border-slate-800 space-y-3">
              <div className="text-xs text-slate-400 px-1">سجل حركات الدخول والخروج عبر البوابة:</div>

              {gateMovements.length === 0 ? (
                <div className="p-8 text-center text-xs text-slate-500">لا توجد حركات مسجلة حتى الآن</div>
              ) : (
                <div className="space-y-2 max-h-[500px] overflow-y-auto">
                  {gateMovements.map((m) => (
                    <div
                      key={m.id}
                      className="p-2.5 rounded-2xl bg-slate-950 border border-slate-800 text-xs flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2.5">
                        <div className={`p-1.5 rounded-xl ${
                          m.movementType === 'check_in' 
                            ? 'bg-emerald-500/20 text-emerald-400' 
                            : 'bg-blue-500/20 text-blue-400'
                        }`}>
                          {m.movementType === 'check_in' ? <LogIn className="w-4 h-4" /> : <LogOut className="w-4 h-4" />}
                        </div>
                        <div>
                          <div className="font-bold text-white">{m.visitorName}</div>
                          <div className="text-[10px] text-slate-400">{m.companyName} {m.vehiclePlate ? `• ${m.vehiclePlate}` : ''}</div>
                        </div>
                      </div>
                      <div className="text-left text-[10px] text-slate-400 font-mono">
                        {new Date(m.timestamp).toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

        </div>

      </div>

    </div>
  );
};

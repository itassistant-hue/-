import React, { useState, useEffect } from 'react';
import { User, SystemLicense, Language, CustomNomenclature } from '../types';
import { storageService } from '../services/storage';
import { soundService } from '../services/audio';
import { translations } from '../services/i18n';
import { 
  ShieldCheck, 
  Volume2, 
  VolumeX, 
  Clock, 
  Users, 
  Radio, 
  AlertOctagon, 
  LogOut, 
  Building, 
  ChevronDown, 
  Sparkles, 
  Lock, 
  Globe, 
  DoorOpen, 
  ShieldAlert, 
  Sliders, 
  Edit3,
  Key
} from 'lucide-react';

interface HeaderProps {
  currentUser: User;
  onUserChange: (user: User) => void;
  onOpenSecretGateway: () => void;
  onOpenLoginModal: () => void;
  onOpenEmergencyModal: () => void;
  onOpenCustomizeModal?: (tab?: 'branding' | 'views' | 'kpis') => void;
  onLogout: () => void;
  lang?: Language;
  onLanguageChange?: (lang: Language) => void;
  activeInsideCount: number;
  pendingCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  onUserChange,
  onOpenSecretGateway,
  onOpenLoginModal,
  onOpenEmergencyModal,
  onOpenCustomizeModal,
  onLogout,
  lang = 'ar',
  onLanguageChange,
  activeInsideCount,
  pendingCount
}) => {
  const t = translations[lang] || translations.ar;
  const [timeStr, setTimeStr] = useState('');
  const [dateStr, setDateStr] = useState('');
  const [soundEnabled, setSoundEnabled] = useState(soundService.isSoundEnabled());
  const [showRoleDropdown, setShowRoleDropdown] = useState(false);
  const [license, setLicense] = useState<SystemLicense>(() => storageService.getLicense());
  const [nomenclature, setNomenclature] = useState<CustomNomenclature>(() => storageService.getNomenclature());

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString(lang === 'ar' ? 'ar-IQ' : 'en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      setDateStr(now.toLocaleDateString(lang === 'ar' ? 'ar-IQ' : 'en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [lang]);

  useEffect(() => {
    const handleStorageChange = () => {
      setLicense(storageService.getLicense());
      setNomenclature(storageService.getNomenclature());
    };
    window.addEventListener('gatepass_storage_event', handleStorageChange);
    return () => window.removeEventListener('gatepass_storage_event', handleStorageChange);
  }, []);

  const toggleSound = () => {
    const next = !soundEnabled;
    soundService.setSoundEnabled(next);
    setSoundEnabled(next);
    if (next) soundService.playScanBeep();
  };

  const handleToggleLang = () => {
    const nextLang: Language = lang === 'ar' ? 'en' : 'ar';
    storageService.setLanguage(nextLang);
    if (onLanguageChange) onLanguageChange(nextLang);
  };

  const getRoleLabel = (role: string, gateId?: string, companyName?: string) => {
    switch (role) {
      case 'admin': return lang === 'ar' ? 'مسؤول النظام (Super Admin)' : 'System Super Admin';
      case 'security_ops': return nomenclature ? (lang === 'ar' ? nomenclature.socNameAr : nomenclature.socNameEn) : (lang === 'ar' ? 'السيطرة والعمليات (SOC)' : 'Security Operations (SOC)');
      case 'gate_1': return nomenclature ? (lang === 'ar' ? nomenclature.gate1NameAr : nomenclature.gate1NameEn) : (lang === 'ar' ? 'حرس بوابة 1 (الشمالية)' : 'Gate 1 Guard (North)');
      case 'gate_2': return nomenclature ? (lang === 'ar' ? nomenclature.gate2NameAr : nomenclature.gate2NameEn) : (lang === 'ar' ? 'حرس بوابة 2 (الجنوبية)' : 'Gate 2 Guard (South)');
      case 'company_user': return companyName ? `${lang === 'ar' ? 'ممثل' : 'Rep'}: ${companyName}` : (lang === 'ar' ? 'ممثل شركة مستضافة' : 'Host Company Rep');
      default: return role;
    }
  };

  const displayAppName = lang === 'ar' 
    ? (nomenclature.appNameAr || license.appNameAr || 'GatePass Security')
    : (nomenclature.appNameEn || license.appNameEn || 'GatePass Security');

  const displayFacilityName = lang === 'ar'
    ? (nomenclature.facilityNameAr || license.facilityNameAr || license.facilityName)
    : (nomenclature.facilityNameEn || license.facilityNameEn || license.facilityName);

  const isAdmin = currentUser.role === 'admin';

  return (
    <header className="sticky top-0 z-40 bg-slate-950/95 backdrop-blur-md border-b border-slate-800 text-slate-100 font-['Tajawal',sans-serif] shadow-lg">
      
      {/* Top Banner for Maintenance if active */}
      {license.maintenanceMode && (
        <div className="bg-red-600 px-4 py-1 text-center text-xs font-bold text-white flex items-center justify-center gap-2 animate-pulse">
          <AlertOctagon className="w-4 h-4" />
          <span>{lang === 'ar' ? 'تنبيه: وضع الصيانة الأمني نشط حالياً! يتم تقييد بعض الإجراءات بأمر الإدارة.' : 'Notice: Security Maintenance Mode is Active.'}</span>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2 flex flex-col md:flex-row items-center justify-between gap-2.5">
        
        {/* Logo & Facility Title */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
          <div className="flex items-center gap-2.5">
            <div className="relative shrink-0">
              {nomenclature.appLogoUrl ? (
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-slate-900 border border-amber-500/50 p-1 flex items-center justify-center shadow-lg shadow-amber-500/10 overflow-hidden">
                  <img 
                    src={nomenclature.appLogoUrl} 
                    alt="App Logo" 
                    className="w-full h-full object-contain" 
                  />
                </div>
              ) : (
                <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-gradient-to-br from-amber-500 via-amber-600 to-amber-700 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-amber-500/20">
                  <ShieldCheck className="w-5 h-5" />
                </div>
              )}
              <span className="absolute -bottom-1 -right-1 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500 border-2 border-slate-950"></span>
              </span>
            </div>

            <div>
              <div className="flex items-center gap-1.5">
                <h1 className="text-sm sm:text-base font-black text-white tracking-tight truncate max-w-[200px] sm:max-w-xs">{displayAppName}</h1>
                <span className="px-1.5 py-0.2 rounded-md bg-amber-500/20 text-amber-300 text-[9px] font-mono font-bold border border-amber-500/30">V2.5</span>
                
                {/* Admin Quick Edit Button on App Branding */}
                {isAdmin && onOpenCustomizeModal && (
                  <button
                    onClick={() => onOpenCustomizeModal('branding')}
                    className="p-1 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 border border-amber-500/30 transition-colors ml-1"
                    title={lang === 'ar' ? 'تعديل اسم التطبيق والشعار والمنشأة' : 'Edit App & Facility Branding'}
                  >
                    <Edit3 className="w-3 h-3" />
                  </button>
                )}
              </div>
              <p className="text-[10px] text-slate-400 truncate max-w-[220px] sm:max-w-sm">{displayFacilityName}</p>
            </div>
          </div>

          {/* Mobile Fast Action Buttons */}
          <div className="flex md:hidden items-center gap-1">
            <button
              onClick={onOpenEmergencyModal}
              title={t.emergency_title}
              className="p-1.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-700 text-white shadow-md shadow-red-900/30 border border-red-400/40"
            >
              <Radio className="w-4 h-4 animate-pulse" />
            </button>
            <button
              onClick={onLogout}
              title={lang === 'ar' ? 'قفل المنظومة' : 'Lock Terminal'}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white"
            >
              <Lock className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Center Live Counters & Digital Clock */}
        <div className="flex items-center gap-2 sm:gap-3 w-full md:w-auto justify-center">
          
          {/* Active on site badge */}
          <div className="px-3 py-1 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-1.5 text-xs">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="text-slate-400 text-[11px] font-bold">
              {nomenclature.kpiOnSiteAr && lang === 'ar' ? nomenclature.kpiOnSiteAr : t.on_site}:
            </span>
            <span className="font-black text-emerald-400 font-mono text-xs">{activeInsideCount}</span>
          </div>

          {/* Pending requests badge */}
          {pendingCount > 0 && (
            <div className="px-3 py-1 rounded-xl bg-amber-950/40 border border-amber-500/30 flex items-center gap-1.5 text-xs text-amber-300">
              <Clock className="w-3 h-3 text-amber-400 animate-spin" />
              <span className="text-[11px] font-bold">
                {nomenclature.kpiPendingAr && lang === 'ar' ? nomenclature.kpiPendingAr : t.pending_soc_review}:
              </span>
              <span className="font-black font-mono text-xs">{pendingCount}</span>
            </div>
          )}

          {/* Clock */}
          <div className="hidden lg:flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-900/80 border border-slate-800 text-[11px] font-mono text-slate-300">
            <Clock className="w-3 h-3 text-slate-400" />
            <span className="font-bold text-amber-400">{timeStr}</span>
          </div>
        </div>

        {/* Right Tools & User Persona Switcher */}
        <div className="flex items-center gap-2 w-full md:w-auto justify-end">
          
          {/* Admin Customization Trigger */}
          {isAdmin && onOpenCustomizeModal && (
            <button
              onClick={() => onOpenCustomizeModal('views')}
              title={lang === 'ar' ? 'تخصيص وتعديل خانات وواجهات المنظومة' : 'Customize System Views & KPIs'}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold transition-colors"
            >
              <Sliders className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden xl:inline">{lang === 'ar' ? 'تعديل الخانات' : 'Edit Labels'}</span>
            </button>
          )}

          {/* Language Switcher Button (Arabic / English) */}
          <button
            onClick={handleToggleLang}
            title={lang === 'ar' ? 'Switch to English' : 'التحويل للغة العربية'}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-amber-400 border border-slate-800 text-xs font-bold transition-colors"
          >
            <Globe className="w-3.5 h-3.5 text-amber-400" />
            <span>{lang === 'ar' ? 'English' : 'عربي'}</span>
          </button>

          {/* Emergency SOS Broadcast Button - Refined, Compact & Luxurious */}
          <button
            onClick={onOpenEmergencyModal}
            title={t.emergency_title}
            className="flex items-center gap-1.5 px-2.5 py-1 sm:py-1.5 rounded-xl bg-gradient-to-r from-red-600/90 via-rose-600/90 to-red-700/90 hover:from-red-500 hover:to-rose-500 text-white border border-rose-400/50 shadow-md shadow-red-950/60 text-xs font-bold transition-all group"
          >
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-300 opacity-80"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-400"></span>
            </span>
            <Radio className="w-3.5 h-3.5 text-rose-100 group-hover:scale-110 transition-transform" />
            <span className="hidden sm:inline text-[11px] font-black tracking-wide">{lang === 'ar' ? 'نداء استغاثة (SOS)' : 'Emergency SOS'}</span>
          </button>

          {/* Sound Toggle */}
          <button
            onClick={toggleSound}
            title={soundEnabled ? 'كتم الصوت' : 'تشغيل الصوت'}
            className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 transition-colors"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4 text-slate-500" />}
          </button>

          {/* User Persona Switcher Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowRoleDropdown(!showRoleDropdown)}
              className="flex items-center gap-2 px-2.5 sm:px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700/80 text-xs font-medium transition-colors"
            >
              {currentUser.avatar ? (
                <img 
                  src={currentUser.avatar} 
                  alt={currentUser.fullName} 
                  className="w-6 h-6 rounded-lg object-cover border border-amber-500/50 shrink-0" 
                />
              ) : (
                <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs shrink-0">
                  {currentUser.fullName.charAt(0)}
                </div>
              )}
              <div className="text-right hidden sm:block">
                <div className="font-bold text-white leading-tight truncate max-w-[120px]">{currentUser.fullName}</div>
                <div className="text-[9px] text-amber-400/90 leading-none mt-0.5 truncate max-w-[120px]">
                  {getRoleLabel(currentUser.role, currentUser.gateId, currentUser.companyName)}
                </div>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {/* Dropdown Menu */}
            {showRoleDropdown && (
              <div className="absolute left-0 mt-2 w-72 bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl z-50 overflow-hidden text-xs">
                <div className="p-3 bg-slate-950 border-b border-slate-800">
                  <div className="text-[10px] text-slate-400 font-bold mb-1">{lang === 'ar' ? 'بيانات الحساب الحالي' : 'Active Account Profile'}</div>
                  <div className="flex items-center gap-2.5">
                    {currentUser.avatar ? (
                      <img 
                        src={currentUser.avatar} 
                        alt={currentUser.fullName} 
                        className="w-10 h-10 rounded-xl object-cover border border-amber-500/40 shrink-0" 
                      />
                    ) : (
                      <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-300 font-bold flex items-center justify-center border border-amber-500/30 text-sm shrink-0">
                        {currentUser.fullName.charAt(0)}
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-white text-xs truncate">{currentUser.fullName}</div>
                      <div className="text-[10px] text-amber-400 font-mono">@{currentUser.username}</div>
                      <div className="text-[10px] text-slate-400 truncate mt-0.5">
                        {getRoleLabel(currentUser.role, currentUser.gateId, currentUser.companyName)}
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-2.5 bg-slate-900/90 flex flex-col gap-1.5">
                  <button
                    onClick={() => {
                      setShowRoleDropdown(false);
                      onOpenLoginModal();
                    }}
                    className="w-full text-xs text-slate-200 hover:text-white py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 flex items-center justify-center gap-2 font-bold transition-colors"
                  >
                    <Key className="w-3.5 h-3.5 text-amber-400" />
                    <span>{lang === 'ar' ? 'تسجيل دخول بحساب آخر' : 'Login with Another Account'}</span>
                  </button>

                  <button
                    onClick={() => {
                      setShowRoleDropdown(false);
                      onLogout();
                    }}
                    className="w-full text-xs text-red-300 hover:text-white py-2 px-3 rounded-xl bg-red-950/40 hover:bg-red-900/60 border border-red-500/30 flex items-center justify-center gap-2 font-bold transition-colors"
                  >
                    <Lock className="w-3.5 h-3.5 text-red-400" />
                    <span>{lang === 'ar' ? 'قفل المنظومة والخروج' : 'Lock Terminal & Logout'}</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Quick Lock / Logout Icon */}
          <button
            onClick={onLogout}
            title={lang === 'ar' ? 'قفل المنظومة وتسجيل الخروج' : 'Lock Screen & Logout'}
            className="p-2 rounded-xl bg-slate-900 hover:bg-red-950/50 hover:text-red-300 text-slate-400 border border-slate-800 transition-colors"
          >
            <Lock className="w-4 h-4" />
          </button>

        </div>

      </div>
    </header>
  );
};

import React, { useState, useRef } from 'react';
import { Language, SystemLicense } from '../types';
import { storageService } from '../services/storage';
import { soundService } from '../services/audio';
import { ShieldCheck, Lock, Sparkles, CheckCircle2 } from 'lucide-react';

interface FooterProps {
  license: SystemLicense;
  lang?: Language;
  onUnlockSecretGateway: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  license,
  lang = 'ar',
  onUnlockSecretGateway
}) => {
  const [clickCount, setClickCount] = useState(0);
  const [showSecretHint, setShowSecretHint] = useState(false);
  const clickTimeoutRef = useRef<any>(null);

  const handleCopyrightClick = () => {
    // Clear existing timer
    if (clickTimeoutRef.current) {
      clearTimeout(clickTimeoutRef.current);
    }

    const nextCount = clickCount + 1;
    setClickCount(nextCount);

    // If 10 clicks reached: Unlock!
    if (nextCount >= 10) {
      setClickCount(0);
      setShowSecretHint(false);
      soundService.playAccessGranted();
      onUnlockSecretGateway();
      return;
    }

    // Show subtle counter when getting closer (>= 5 clicks)
    if (nextCount >= 5) {
      setShowSecretHint(true);
    }

    // Reset click counter if user stops clicking for 3 seconds
    clickTimeoutRef.current = setTimeout(() => {
      setClickCount(0);
      setShowSecretHint(false);
    }, 3000);
  };

  const devNotice = lang === 'ar'
    ? (license.copyrightAr || 'برمجة وتطوير: المهندس علي أحمد عنيد • جميع الحقوق محفوظة')
    : (license.copyrightEn || 'Engineered & Developed by Eng. Ali Ahmed Aneed • All Rights Reserved');

  const devTitle = lang === 'ar'
    ? (license.developerTitleAr || 'المطور والمصمم البرمجي للمنظومة')
    : (license.developerTitleEn || 'Software Architect & System Engineer');

  return (
    <footer className="fixed bottom-0 left-0 right-0 z-40 bg-slate-950/95 backdrop-blur-md border-t border-slate-800 py-2 px-4 text-slate-400 text-xs font-['Tajawal',sans-serif] select-none shadow-2xl">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
        
        {/* Left: Facility Identifier */}
        <div className="text-[10px] text-slate-400 font-mono flex items-center gap-1.5 order-3 sm:order-1">
          <ShieldCheck className="w-3.5 h-3.5 text-amber-500/80" />
          <span className="tracking-wider font-bold text-slate-300">SEC-ID: 7941-PRO</span>
        </div>

        {/* Center: Secret 10-Click Target Copyright Area */}
        <div className="relative text-center order-1 sm:order-2">
          <button
            type="button"
            onClick={handleCopyrightClick}
            className="group px-3 py-1 rounded-xl hover:bg-slate-900/90 transition-all text-slate-200 hover:text-amber-300 text-[11px] font-medium flex items-center justify-center gap-1.5 focus:outline-none"
            title={lang === 'ar' ? 'انقر 10 مرات متتالية لفتح بوابة الإدارة الفنية والترخيص' : 'Click 10 times to unlock Technical & Licensing Gateway'}
          >
            <span>{devNotice}</span>
          </button>

          {/* Discreet unlock feedback indicator */}
          {showSecretHint && (
            <div className="absolute left-1/2 -translate-x-1/2 -top-8 bg-slate-900 border border-amber-500/50 text-amber-300 text-[10px] px-2.5 py-0.5 rounded-full shadow-2xl font-mono animate-bounce whitespace-nowrap z-50">
              {lang === 'ar' ? `المتبقي لفتح البوابة السرية: ${10 - clickCount}` : `Clicks to unlock: ${10 - clickCount}`}
            </div>
          )}
        </div>

        {/* Right: System Status & Security Badge */}
        <div className="flex items-center gap-2 text-[11px] text-slate-400 order-2 sm:order-3">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className="font-mono text-slate-200 font-bold">
            {lang === 'ar' ? 'نظام البوابات المشفر' : 'Encrypted GatePass Core'}
          </span>
          <span className="text-slate-600">|</span>
          <span className="text-[10px] text-emerald-400 font-medium">
            {lang === 'ar' ? 'ترخيص نشط ومصرح' : 'Active Licensed'}
          </span>
        </div>

      </div>
    </footer>
  );
};

import React, { useState, useEffect } from 'react';
import { PassRequest, User, Company } from '../types';
import { storageService } from '../services/storage';
import { 
  Building2, 
  Plus, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  Ban, 
  UserCheck, 
  Eye, 
  Printer, 
  Search, 
  Crown,
  Send,
  Calendar,
  Sparkles,
  Phone,
  FileText
} from 'lucide-react';

interface CompanyPortalProps {
  currentUser: User;
  onOpenPassDetails: (pass: PassRequest) => void;
  onOpenNewPassModal: () => void;
}

export const CompanyPortal: React.FC<CompanyPortalProps> = ({
  currentUser,
  onOpenPassDetails,
  onOpenNewPassModal
}) => {
  const [passes, setPasses] = useState<PassRequest[]>(() => storageService.getPasses());
  const [companies, setCompanies] = useState<Company[]>(() => storageService.getCompanies());
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  useEffect(() => {
    const handleStorageChange = () => {
      setPasses(storageService.getPasses());
      setCompanies(storageService.getCompanies());
    };
    window.addEventListener('gatepass_storage_event', handleStorageChange);
    return () => window.removeEventListener('gatepass_storage_event', handleStorageChange);
  }, []);

  const currentCompany = companies.find(c => c.id === currentUser.companyId) || {
    id: currentUser.companyId || 'comp_1',
    name: currentUser.companyName || 'شركة مستضافة',
    code: 'COMP-SITE',
    contactPerson: currentUser.fullName,
    phone: currentUser.phone || '07800000000',
    email: 'info@site-company.iq',
    sector: 'الخدمات والتشغيل',
    locationInsideSite: 'المجمع الرئيسي',
    active: true,
    createdAt: new Date().toISOString()
  };

  // Filter passes belonging to this company (or all if admin viewing)
  const companyPasses = passes.filter(p => 
    currentUser.role === 'admin' || p.companyId === currentCompany.id || p.companyName === currentCompany.name
  );

  const effectivePasses = companyPasses.map(p => ({
    ...p,
    effectiveStatus: storageService.getEffectiveStatus(p)
  }));

  const pendingCount = effectivePasses.filter(p => p.status === 'pending_security').length;
  const insideCount = effectivePasses.filter(p => p.effectiveStatus === 'inside').length;
  const approvedCount = effectivePasses.filter(p => p.effectiveStatus === 'approved').length;
  const expiredCount = effectivePasses.filter(p => p.effectiveStatus === 'expired').length;

  const filteredPasses = effectivePasses.filter(p => {
    const matchesSearch = 
      p.visitorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.passNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.nationalIdOrPassport.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.vehiclePlate && p.vehiclePlate.toLowerCase().includes(searchQuery.toLowerCase()));

    if (!matchesSearch) return false;

    if (statusFilter === 'pending') return p.status === 'pending_security';
    if (statusFilter === 'inside') return p.effectiveStatus === 'inside';
    if (statusFilter === 'approved') return p.effectiveStatus === 'approved';
    if (statusFilter === 'expired') return p.effectiveStatus === 'expired';
    if (statusFilter === 'rejected') return p.status === 'rejected';

    return true;
  });

  return (
    <div className="space-y-6 font-['Tajawal',sans-serif]">
      
      {/* Company Header Card */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl flex flex-col md:flex-row items-center justify-between gap-5">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-white font-black text-2xl shadow-lg shadow-blue-600/20">
            <Building2 className="w-9 h-9" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-white">{currentCompany.name}</h2>
              <span className="px-2.5 py-0.5 rounded-full bg-blue-500/20 text-blue-300 text-xs font-mono font-bold border border-blue-500/30">
                {currentCompany.code}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 flex flex-wrap items-center gap-3">
              <span>الموقع الداخلي: <span className="text-slate-200 font-bold">{currentCompany.locationInsideSite}</span></span>
              <span>الممثل المعتمد: <span className="text-slate-200">{currentCompany.contactPerson}</span></span>
              <span>الهاتف: <span className="text-slate-200">{currentCompany.phone}</span></span>
            </p>
          </div>
        </div>

        <button
          onClick={onOpenNewPassModal}
          className="w-full md:w-auto px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 transition-transform active:scale-95"
        >
          <Send className="w-4 h-4" />
          <span>إرسال نداء وتصريح جديد</span>
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div 
          onClick={() => setStatusFilter('pending')}
          className={`p-4 rounded-3xl border cursor-pointer transition-all ${
            statusFilter === 'pending' ? 'bg-amber-950/30 border-amber-500' : 'bg-slate-900 border-slate-800'
          }`}
        >
          <div className="text-xs text-slate-400 mb-1">بانتظار موافقة السيطرة</div>
          <div className="text-2xl font-black text-amber-400 font-mono">{pendingCount}</div>
        </div>

        <div 
          onClick={() => setStatusFilter('approved')}
          className={`p-4 rounded-3xl border cursor-pointer transition-all ${
            statusFilter === 'approved' ? 'bg-blue-950/30 border-blue-500' : 'bg-slate-900 border-slate-800'
          }`}
        >
          <div className="text-xs text-slate-400 mb-1">مصرح وجاهز للدخول</div>
          <div className="text-2xl font-black text-blue-400 font-mono">{approvedCount}</div>
        </div>

        <div 
          onClick={() => setStatusFilter('inside')}
          className={`p-4 rounded-3xl border cursor-pointer transition-all ${
            statusFilter === 'inside' ? 'bg-emerald-950/30 border-emerald-500' : 'bg-slate-900 border-slate-800'
          }`}
        >
          <div className="text-xs text-slate-400 mb-1">متواجدون بالموقع حالياً</div>
          <div className="text-2xl font-black text-emerald-400 font-mono">{insideCount}</div>
        </div>

        <div 
          onClick={() => setStatusFilter('expired')}
          className={`p-4 rounded-3xl border cursor-pointer transition-all ${
            statusFilter === 'expired' ? 'bg-red-950/30 border-red-500' : 'bg-slate-900 border-slate-800'
          }`}
        >
          <div className="text-xs text-slate-400 mb-1">منتهية الصلاحية</div>
          <div className="text-2xl font-black text-red-400 font-mono">{expiredCount}</div>
        </div>
      </div>

      {/* Passes Management & Tracker Table */}
      <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          {/* Status Filters */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-950 rounded-2xl border border-slate-800 text-xs w-full sm:w-auto overflow-x-auto">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-colors shrink-0 ${
                statusFilter === 'all' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              الكل ({effectivePasses.length})
            </button>
            <button
              onClick={() => setStatusFilter('pending')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-colors shrink-0 ${
                statusFilter === 'pending' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              المعلقة ({pendingCount})
            </button>
            <button
              onClick={() => setStatusFilter('approved')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-colors shrink-0 ${
                statusFilter === 'approved' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              المصرحة ({approvedCount})
            </button>
            <button
              onClick={() => setStatusFilter('inside')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-colors shrink-0 ${
                statusFilter === 'inside' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              داخل الموقع ({insideCount})
            </button>
            <button
              onClick={() => setStatusFilter('expired')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-colors shrink-0 ${
                statusFilter === 'expired' ? 'bg-red-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              المنتهية ({expiredCount})
            </button>
          </div>

          {/* Search Box */}
          <div className="relative w-full sm:w-64">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="بحث باسم الزائر، الهوية، أو الرقم..."
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 pl-9 text-xs text-white placeholder:text-slate-500 focus:border-amber-400 outline-none"
            />
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          </div>
        </div>

        {/* List of Company Passes */}
        {filteredPasses.length === 0 ? (
          <div className="p-12 text-center text-slate-500 text-xs">
            لا توجد تصاريح مسجلة لهذه الفئة حتى الآن
          </div>
        ) : (
          <div className="space-y-3">
            {filteredPasses.map((p) => {
              const effStatus = p.effectiveStatus;
              return (
                <div
                  key={p.id}
                  className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 hover:border-slate-700 transition-colors flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
                >
                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono font-bold text-amber-400 text-xs">{p.passNumber}</span>
                      <h4 className="text-sm font-black text-white">{p.visitorName}</h4>
                      {p.visitorType === 'vip' && (
                        <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 text-[10px] font-black border border-amber-500/40">VIP</span>
                      )}
                    </div>

                    <div className="text-xs text-slate-400 flex flex-wrap items-center gap-3">
                      <span>هوية: <span className="font-mono text-slate-300">{p.nationalIdOrPassport}</span></span>
                      {p.vehiclePlate && <span>مركبة: <span className="text-slate-300 font-bold">{p.vehiclePlate}</span></span>}
                      <span>الغرض: <span className="text-slate-300">{p.purpose}</span></span>
                    </div>

                    <div className="text-xs text-slate-400 flex flex-wrap items-center gap-3">
                      <span>المدة: <span className="text-amber-300 font-bold">{p.durationLabel}</span></span>
                      <span>الصلاحية حتى: {new Date(p.validTo).toLocaleString('ar-IQ')}</span>
                    </div>
                  </div>

                  {/* Status & Preview Button */}
                  <div className="flex items-center gap-3 self-end md:self-center">
                    <div>
                      {effStatus === 'pending_security' && (
                        <span className="px-3 py-1 rounded-xl bg-amber-500/10 text-amber-300 border border-amber-500/30 text-xs font-bold flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" /> بانتظار السيطرة
                        </span>
                      )}
                      {effStatus === 'approved' && (
                        <span className="px-3 py-1 rounded-xl bg-blue-500/10 text-blue-300 border border-blue-500/30 text-xs font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" /> مصرّح للدخول
                        </span>
                      )}
                      {effStatus === 'inside' && (
                        <span className="px-3 py-1 rounded-xl bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 text-xs font-bold flex items-center gap-1">
                          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
                          داخل الموقع
                        </span>
                      )}
                      {effStatus === 'expired' && (
                        <span className="px-3 py-1 rounded-xl bg-red-500/10 text-red-400 border border-red-500/30 text-xs font-bold flex items-center gap-1">
                          <AlertTriangle className="w-3.5 h-3.5" /> منتهي الصلاحية
                        </span>
                      )}
                      {effStatus === 'rejected' && (
                        <span className="px-3 py-1 rounded-xl bg-rose-500/10 text-rose-300 border border-rose-500/30 text-xs font-bold flex items-center gap-1">
                          <Ban className="w-3.5 h-3.5" /> مرفوض أمنياً
                        </span>
                      )}
                      {effStatus === 'completed' && (
                        <span className="px-3 py-1 rounded-xl bg-slate-800 text-slate-400 text-xs font-bold">
                          مكتمل وغادر
                        </span>
                      )}
                    </div>

                    <button
                      onClick={() => onOpenPassDetails(p)}
                      className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5 text-amber-400" />
                      <span>عرض البطاقة</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

      </div>

    </div>
  );
};

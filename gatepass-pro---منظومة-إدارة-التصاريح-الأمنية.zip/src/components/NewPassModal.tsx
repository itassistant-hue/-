import React, { useState, useRef, useEffect } from 'react';
import { Company, PassRequest, PassType, User, GateDefinition, CustomFieldDefinition } from '../types';
import { storageService } from '../services/storage';
import { soundService } from '../services/audio';
import { 
  Send, 
  Crown, 
  User as UserIcon, 
  Briefcase, 
  Truck, 
  Wrench, 
  Car, 
  Clock, 
  Building2, 
  FileText, 
  X, 
  ShieldAlert, 
  CheckCircle,
  Package,
  Camera,
  Image as ImageIcon,
  Eye,
  Trash2,
  UploadCloud,
  Tag,
  DoorOpen
} from 'lucide-react';

interface NewPassModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: User;
  onPassCreated: (pass: PassRequest) => void;
}

export const NewPassModal: React.FC<NewPassModalProps> = ({ isOpen, onClose, currentUser, onPassCreated }) => {
  const companies = storageService.getCompanies();
  const [gates, setGates] = useState<GateDefinition[]>(() => storageService.getGates().filter(g => g.enabled));
  const [customFields, setCustomFields] = useState<CustomFieldDefinition[]>(() => storageService.getCustomFields().filter(f => f.enabled));

  // If user is company_user, fix their company
  const initialCompanyId = currentUser.companyId || (companies.length > 0 ? companies[0].id : '');
  const [selectedCompanyId, setSelectedCompanyId] = useState(initialCompanyId);
  const [visitorName, setVisitorName] = useState('');
  const [nationalId, setNationalId] = useState('');
  const [nationality, setNationality] = useState('عراقي');
  const [visitorPhone, setVisitorPhone] = useState('');
  const [visitorType, setVisitorType] = useState<PassType>('guest');
  const [escortPerson, setEscortPerson] = useState('');
  const [vehiclePlate, setVehiclePlate] = useState('');
  const [vehicleModel, setVehicleModel] = useState('');
  const [destinationGate, setDestinationGate] = useState<string>('both');
  const [purpose, setPurpose] = useState('');
  const [materialsList, setMaterialsList] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [customFieldValues, setCustomFieldValues] = useState<Record<string, string>>({});
  const [isPreviewPhotoOpen, setIsPreviewPhotoOpen] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Duration state
  const [durationPreset, setDurationPreset] = useState<'2h' | '4h' | '8h' | '24h' | '3d' | '7d' | 'custom'>('8h');
  const [customExpiryDate, setCustomExpiryDate] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (isOpen) {
      setGates(storageService.getGates().filter(g => g.enabled));
      setCustomFields(storageService.getCustomFields().filter(f => f.enabled));
      setErrorMsg('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleImageFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setErrorMsg('حجم الصورة كبير جداً، يرجى اختيار صورة أقل من 5 ميغابايت');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setPhotoUrl(event.target.result as string);
        setErrorMsg('');
        soundService.playSuccessSound();
      }
    };
    reader.readAsDataURL(file);
  };

  const calculateExpiry = (): { validFrom: string; validTo: string; durationHours: number; durationLabel: string } => {
    const from = new Date();
    let to = new Date();
    let durationHours = 8;
    let durationLabel = '8 ساعات (يوم عمل)';

    if (durationPreset === '2h') {
      durationHours = 2;
      durationLabel = 'ساعتان (زيارة سريعة)';
      to = new Date(from.getTime() + 2 * 3600 * 1000);
    } else if (durationPreset === '4h') {
      durationHours = 4;
      durationLabel = '4 ساعات (نصف يوم)';
      to = new Date(from.getTime() + 4 * 3600 * 1000);
    } else if (durationPreset === '8h') {
      durationHours = 8;
      durationLabel = '8 ساعات (يوم عمل كامل)';
      to = new Date(from.getTime() + 8 * 3600 * 1000);
    } else if (durationPreset === '24h') {
      durationHours = 24;
      durationLabel = '24 ساعة (يوم كامل)';
      to = new Date(from.getTime() + 24 * 3600 * 1000);
    } else if (durationPreset === '3d') {
      durationHours = 72;
      durationLabel = '3 أيام عمل';
      to = new Date(from.getTime() + 72 * 3600 * 1000);
    } else if (durationPreset === '7d') {
      durationHours = 168;
      durationLabel = 'أسبوع كامل (7 أيام)';
      to = new Date(from.getTime() + 168 * 3600 * 1000);
    } else if (durationPreset === 'custom' && customExpiryDate) {
      to = new Date(customExpiryDate);
      const diffMs = to.getTime() - from.getTime();
      durationHours = Math.max(1, Math.round(diffMs / (3600 * 1000)));
      durationLabel = `مخصص (${durationHours} ساعة)`;
    }

    return {
      validFrom: from.toISOString(),
      validTo: to.toISOString(),
      durationHours,
      durationLabel
    };
  };

  const handleCustomFieldChange = (key: string, value: string) => {
    setCustomFieldValues(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!visitorName.trim()) {
      setErrorMsg('يرجى كتابة اسم الزائر / الشخص بالكامل');
      return;
    }
    if (!nationalId.trim()) {
      setErrorMsg('يرجى إدخال رقم الهوية أو جواز السفر');
      return;
    }
    if (!purpose.trim()) {
      setErrorMsg('يرجى توضيح الغرض من الزيارة');
      return;
    }

    // Check if any custom required field is missing
    const missingRequired = customFields.find(f => f.required && !f.isSystemDefault && !customFieldValues[f.key]?.trim());
    if (missingRequired) {
      setErrorMsg(`يرجى ملء خانة "${missingRequired.labelAr}" الإجبارية`);
      return;
    }

    const companyObj = companies.find(c => c.id === selectedCompanyId);
    const companyName = companyObj ? companyObj.name : 'شركة مستضافة';
    const { validFrom, validTo, durationHours, durationLabel } = calculateExpiry();

    const newPass = storageService.createPass(
      {
        companyId: selectedCompanyId,
        companyName,
        requesterName: currentUser.fullName,
        requesterPhone: currentUser.phone || '07800000000',
        visitorName: visitorName.trim(),
        nationalIdOrPassport: nationalId.trim(),
        nationality: nationality.trim() || 'عراقي',
        visitorPhone: visitorPhone.trim() || 'غير مسجل',
        visitorType,
        escortPerson: escortPerson.trim() || undefined,
        vehiclePlate: vehiclePlate.trim() || undefined,
        vehicleModel: vehicleModel.trim() || undefined,
        destinationGate,
        purpose: purpose.trim(),
        materialsList: materialsList.trim() || undefined,
        photoUrl: photoUrl.trim() || undefined,
        customFieldValues,
        validFrom,
        validTo,
        durationHours,
        durationLabel,
        status: currentUser.role === 'admin' || currentUser.role === 'security_ops' ? 'approved' : 'pending_security',
        approvedBy: currentUser.role === 'admin' || currentUser.role === 'security_ops' ? currentUser.fullName : undefined,
        approvedAt: currentUser.role === 'admin' || currentUser.role === 'security_ops' ? new Date().toISOString() : undefined
      },
      currentUser
    );

    if (visitorType === 'vip') {
      soundService.playVipFanfare();
    } else {
      soundService.playSuccessSound();
    }

    onPassCreated(newPass);
    onClose();
  };

  // Check which standard fields are enabled
  const isFieldEnabled = (key: string) => {
    const found = customFields.find(f => f.key === key);
    return found ? found.enabled : true;
  };

  // Additional custom fields added dynamically by Admin
  const extraCustomFields = customFields.filter(f => !f.isSystemDefault && f.enabled);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md font-['Tajawal',sans-serif]">
      <div className="relative w-full max-w-2xl max-h-[92vh] overflow-y-auto bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl text-slate-100">
        
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 bg-slate-950/95 backdrop-blur-md border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400">
              <Send className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">إرسال نداء وتصريح دخول / خروج جديد</h3>
              <p className="text-xs text-slate-400">سيتم إرسال الطلب لغرفة السيطرة الأمنية للموافقة والاعتماد</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          
          {errorMsg && (
            <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs font-bold flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 shrink-0" />
              {errorMsg}
            </div>
          )}

          {/* Visitor Category Selection */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-2">نوع التصريح والفئة:</label>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {[
                { type: 'guest' as PassType, label: 'ضيف / زائر', icon: UserIcon, color: 'hover:border-blue-400 text-blue-400' },
                { type: 'contractor' as PassType, label: 'مقاول / صيانة', icon: Wrench, color: 'hover:border-amber-400 text-amber-400' },
                { type: 'materials' as PassType, label: 'شاحنة / مواد', icon: Truck, color: 'hover:border-purple-400 text-purple-400' },
                { type: 'vip' as PassType, label: 'VIP شخصية هامة', icon: Crown, color: 'hover:border-yellow-400 text-yellow-400' },
                { type: 'employee' as PassType, label: 'موظف موقع', icon: Briefcase, color: 'hover:border-emerald-400 text-emerald-400' }
              ].map(({ type, label, icon: Icon, color }) => (
                <button
                  type="button"
                  key={type}
                  onClick={() => setVisitorType(type)}
                  className={`p-2.5 rounded-2xl border flex flex-col items-center justify-center gap-1.5 transition-all ${
                    visitorType === type 
                      ? 'bg-slate-800 border-amber-400 shadow-md shadow-amber-500/10 text-white' 
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200'
                  } ${color}`}
                >
                  <Icon className={`w-5 h-5 ${visitorType === type ? 'text-amber-400' : ''}`} />
                  <span className="text-[11px] font-bold text-center leading-tight">{label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Company & Destination Gate (Dynamic Gates) */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">الشركة المرسلة للتصريح:</label>
              {currentUser.role === 'company_user' ? (
                <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-bold text-slate-200 flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-blue-400" />
                  {currentUser.companyName}
                </div>
              ) : (
                <select
                  value={selectedCompanyId}
                  onChange={(e) => setSelectedCompanyId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                >
                  {companies.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.code})
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1">
                <DoorOpen className="w-3.5 h-3.5 text-blue-400" />
                <span>البوابة المصرح بها (ديناميكية):</span>
              </label>
              <select
                value={destinationGate}
                onChange={(e) => setDestinationGate(e.target.value)}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none font-bold"
              >
                <option value="both">كافة البوابات المصرح بها (مفتوح)</option>
                {gates.map((g) => (
                  <option key={g.id} value={g.id}>
                    {g.nameAr} ({g.location || g.id})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Visitor Details */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800/80 space-y-3">
            <h4 className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <UserIcon className="w-4 h-4 text-amber-400" />
              بيانات الشخص أو السائق:
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">الاسم الكامل (ثلاثي / رباعي): *</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: المهندس أحمد علي كريم"
                  value={visitorName}
                  onChange={(e) => setVisitorName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                />
              </div>

              <div>
                <label className="block text-[11px] text-slate-400 mb-1">رقم الهوية الوطنية / جواز السفر: *</label>
                <input
                  type="text"
                  required
                  placeholder="مثال: 199012849102"
                  value={nationalId}
                  onChange={(e) => setNationalId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none font-mono"
                />
              </div>

              {isFieldEnabled('visitorPhone') && (
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">رقم الهاتف للتواصل:</label>
                  <input
                    type="tel"
                    placeholder="0780XXXXXXX"
                    value={visitorPhone}
                    onChange={(e) => setVisitorPhone(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none font-mono"
                  />
                </div>
              )}

              {isFieldEnabled('nationality') && (
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">الجنسية:</label>
                  <input
                    type="text"
                    placeholder="عراقي"
                    value={nationality}
                    onChange={(e) => setNationality(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                  />
                </div>
              )}
            </div>

            {isFieldEnabled('escortPerson') && (
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">الشخص المستضيف / المرافق في الموقع (اختياري):</label>
                <input
                  type="text"
                  placeholder="مثال: المهندس وسام عبد الله (قسم الصيانة)"
                  value={escortPerson}
                  onChange={(e) => setEscortPerson(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                />
              </div>
            )}
          </div>

          {/* Vehicle & Logistics */}
          {isFieldEnabled('vehiclePlate') && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1 flex items-center gap-1">
                  <Car className="w-3.5 h-3.5 text-amber-400" />
                  رقم لوحة المركبة (إن وجدت):
                </label>
                <input
                  type="text"
                  placeholder="مثال: بغداد 48921 خصوصي"
                  value={vehiclePlate}
                  onChange={(e) => setVehiclePlate(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                />
              </div>
              {isFieldEnabled('vehicleModel') && (
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">نوع ولون المركبة:</label>
                  <input
                    type="text"
                    placeholder="مثال: تويوتا هايلوكس بيضاء"
                    value={vehicleModel}
                    onChange={(e) => setVehicleModel(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                  />
                </div>
              )}
            </div>
          )}

          {/* Purpose of Visit */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-1">الغرض من الزيارة والمهمة: *</label>
            <textarea
              rows={2}
              required
              placeholder="اكتب تفاصيل المهمة أو سبب الزيارة..."
              value={purpose}
              onChange={(e) => setPurpose(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none resize-none"
            />
          </div>

          {/* Materials / Equipment list */}
          {isFieldEnabled('materialsList') && (visitorType === 'materials' || visitorType === 'contractor') && (
            <div>
              <label className="block text-xs font-bold text-amber-300 mb-1 flex items-center gap-1">
                <Package className="w-3.5 h-3.5" />
                قائمة المواد أو الأجهزة المرافقة للتفتيش والفحص الجمركي:
              </label>
              <textarea
                rows={2}
                placeholder="اكتب أعداد ونوعية الأجهزة، الأرقام التسلسلية، أو نوع الحمولة..."
                value={materialsList}
                onChange={(e) => setMaterialsList(e.target.value)}
                className="w-full bg-slate-950 border border-amber-500/30 rounded-xl px-3 py-2 text-xs text-amber-100 focus:border-amber-400 outline-none resize-none"
              />
            </div>
          )}

          {/* Dynamic Extra Custom Fields added by Admin */}
          {extraCustomFields.length > 0 && (
            <div className="p-4 rounded-2xl bg-slate-950/80 border border-emerald-500/30 space-y-3">
              <h4 className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                <Tag className="w-4 h-4 text-emerald-400" />
                <span>حقول وخانات مخصصة إضافية:</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {extraCustomFields.map((field) => (
                  <div key={field.id}>
                    <label className="block text-[11px] text-slate-300 mb-1">
                      {field.labelAr} {field.required && <span className="text-red-400 font-bold">*</span>}:
                    </label>
                    {field.type === 'textarea' ? (
                      <textarea
                        rows={2}
                        placeholder={field.placeholderAr || `أدخل ${field.labelAr}...`}
                        value={customFieldValues[field.key] || ''}
                        onChange={(e) => handleCustomFieldChange(field.key, e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-emerald-400 outline-none resize-none"
                      />
                    ) : (
                      <input
                        type={field.type === 'number' ? 'number' : field.type === 'date' ? 'date' : 'text'}
                        placeholder={field.placeholderAr || `أدخل ${field.labelAr}...`}
                        value={customFieldValues[field.key] || ''}
                        onChange={(e) => handleCustomFieldChange(field.key, e.target.value)}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-emerald-400 outline-none"
                      />
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Photo / ID / Cargo Attachment Upload with Live Preview */}
          {isFieldEnabled('photoUrl') && (
            <div className="p-4 rounded-2xl bg-slate-950/90 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <Camera className="w-4 h-4 text-amber-400" />
                  <span>إرفاق صورة شخصية / صورة الهوية / أو صورة الحمولة (معاينة فورية):</span>
                </label>
                <span className="text-[10px] text-slate-400">تدعم المعاينة الفورية</span>
              </div>

              {photoUrl ? (
                <div className="p-3 rounded-xl bg-slate-900 border border-amber-500/30 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="relative group cursor-pointer" onClick={() => setIsPreviewPhotoOpen(true)}>
                      <img 
                        src={photoUrl} 
                        alt="Attachment Preview" 
                        className="w-14 h-14 rounded-xl object-cover border border-amber-500/50 shadow-md transition-transform group-hover:scale-105" 
                      />
                      <div className="absolute inset-0 bg-black/40 rounded-xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <Eye className="w-4 h-4 text-white" />
                      </div>
                    </div>
                    <div>
                      <div className="text-xs font-bold text-white flex items-center gap-1.5">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                        <span>تم إرفاق الصورة بنجاح</span>
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">انقر على الصورة لمعاينتها بالحجم الكامل</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setIsPreviewPhotoOpen(true)}
                      className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 text-xs font-bold flex items-center gap-1 transition-colors"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>معاينة</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setPhotoUrl('')}
                      className="p-2 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs font-bold flex items-center gap-1 transition-colors"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ) : (
                <div className="flex flex-wrap items-center gap-3">
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-black flex items-center gap-2 shadow-lg shadow-amber-500/20"
                  >
                    <UploadCloud className="w-4 h-4" />
                    <span>رفع صورة من جهازك</span>
                  </button>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleImageFileChange}
                  />

                  <div className="flex-1 min-w-[200px]">
                    <input
                      type="url"
                      placeholder="أو الصق رابط الصورة المباشر (URL)..."
                      value={photoUrl}
                      onChange={(e) => setPhotoUrl(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                    />
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Modal Preview Zoom */}
          {isPreviewPhotoOpen && photoUrl && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in">
              <div className="relative max-w-xl max-h-[85vh] bg-slate-900 border border-slate-700 rounded-3xl p-4 flex flex-col items-center">
                <button
                  onClick={() => setIsPreviewPhotoOpen(false)}
                  className="absolute top-3 left-3 p-2 bg-slate-800 hover:bg-slate-700 text-white rounded-full transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
                <h4 className="text-xs font-bold text-slate-300 mb-3 flex items-center gap-1.5">
                  <ImageIcon className="w-4 h-4 text-amber-400" />
                  <span>معاينة صورة المرفق بالحجم الكامل</span>
                </h4>
                <div className="overflow-hidden rounded-2xl border border-slate-800 max-h-[70vh] flex items-center justify-center bg-slate-950">
                  <img src={photoUrl} alt="Full Preview" className="max-w-full max-h-[70vh] object-contain rounded-xl" />
                </div>
              </div>
            </div>
          )}

          {/* Validity Duration Preset */}
          <div>
            <label className="block text-xs font-bold text-slate-300 mb-2 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-amber-400" />
              مدة صلاحية التصريح الممنوحة:
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-2 text-xs">
              {[
                { id: '2h', label: 'ساعتان' },
                { id: '4h', label: '4 ساعات' },
                { id: '8h', label: '8 ساعات' },
                { id: '24h', label: '24 ساعة' },
                { id: '3d', label: '3 أيام' },
                { id: '7d', label: 'أسبوع' }
              ].map((p) => (
                <button
                  type="button"
                  key={p.id}
                  onClick={() => setDurationPreset(p.id as any)}
                  className={`py-2 px-1 rounded-xl border text-center font-bold transition-all ${
                    durationPreset === p.id 
                      ? 'bg-amber-500 text-slate-950 border-amber-400 shadow-md shadow-amber-500/20' 
                      : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-white'
                  }`}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Submit Actions */}
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-colors"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-black shadow-lg shadow-amber-500/20 flex items-center gap-2 transition-all"
            >
              <Send className="w-4 h-4" />
              <span>إرسال التصريح والنداء</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};

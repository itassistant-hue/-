import React, { useState, useRef } from 'react';
import { User, UserRole, Company } from '../types';
import { storageService } from '../services/storage';
import { soundService } from '../services/audio';
import { 
  Users, 
  UserPlus, 
  Shield, 
  X, 
  Trash2, 
  CheckCircle, 
  Lock, 
  Edit3, 
  Camera, 
  UploadCloud, 
  Image as ImageIcon, 
  Building2, 
  Save, 
  UserCheck 
} from 'lucide-react';

interface UserManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const UserManagerModal: React.FC<UserManagerModalProps> = ({ isOpen, onClose }) => {
  const [users, setUsers] = useState<User[]>(() => storageService.getUsers());
  const [companies] = useState<Company[]>(() => storageService.getCompanies());
  const [isAddingNew, setIsAddingNew] = useState(false);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);

  // Form State
  const [username, setUsername] = useState('');
  const [fullName, setFullName] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('company_user');
  const [companyId, setCompanyId] = useState(companies.length > 0 ? companies[0].id : '');
  const [gateId, setGateId] = useState<string>('gate_1');
  const [phone, setPhone] = useState('');
  const [avatar, setAvatar] = useState('');
  const [statusMsg, setStatusMsg] = useState('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setAvatar(event.target.result as string);
        soundService.playSuccessSound();
      }
    };
    reader.readAsDataURL(file);
  };

  const handleStartEdit = (user: User) => {
    setEditingUserId(user.id);
    setIsAddingNew(false);
    setUsername(user.username);
    setFullName(user.fullName);
    setPassword(user.password);
    setRole(user.role);
    setCompanyId(user.companyId || (companies.length > 0 ? companies[0].id : ''));
    setGateId(user.gateId || 'gate_1');
    setPhone(user.phone || '');
    setAvatar(user.avatar || '');
  };

  const handleCancelForm = () => {
    setIsAddingNew(false);
    setEditingUserId(null);
    setUsername('');
    setFullName('');
    setPassword('');
    setPhone('');
    setAvatar('');
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password.trim() || !fullName.trim()) {
      alert('يرجى ملء كافة الحقول الأساسية');
      return;
    }

    const selectedComp = companies.find(c => c.id === companyId);

    if (editingUserId) {
      // Editing existing user
      const existing = users.find(u => u.id === editingUserId);
      if (existing) {
        const updatedUser: User = {
          ...existing,
          fullName: fullName.trim(),
          password: password.trim(),
          role,
          companyId: role === 'company_user' ? companyId : undefined,
          companyName: role === 'company_user' ? (selectedComp ? selectedComp.name : undefined) : undefined,
          gateId: role === 'gate_1' ? 'gate_1' : role === 'gate_2' ? 'gate_2' : undefined,
          phone: phone.trim() || undefined,
          avatar: avatar.trim() || undefined,
        };
        storageService.saveUser(updatedUser);
        setUsers(storageService.getUsers());
        setStatusMsg('تم تحديث بيانات الحساب وصورة البروفايل بنجاح!');
      }
    } else {
      // Creating new user
      const newUser: User = {
        id: 'user_' + Date.now(),
        username: username.trim().toLowerCase(),
        fullName: fullName.trim(),
        password: password.trim(),
        role,
        companyId: role === 'company_user' ? companyId : undefined,
        companyName: role === 'company_user' ? (selectedComp ? selectedComp.name : undefined) : undefined,
        gateId: role === 'gate_1' ? 'gate_1' : role === 'gate_2' ? 'gate_2' : undefined,
        phone: phone.trim() || undefined,
        avatar: avatar.trim() || undefined,
        active: true,
        createdAt: new Date().toISOString()
      };
      storageService.saveUser(newUser);
      setUsers(storageService.getUsers());
      setStatusMsg('تمت إضافة المستخدم وشعار الحساب بنجاح!');
    }

    handleCancelForm();
    soundService.playSuccessSound();
    setTimeout(() => setStatusMsg(''), 3000);
  };

  const handleToggleUser = (user: User) => {
    if (user.username === 'admin') {
      alert('لا يمكن تعطيل الحساب الإداري الرئيسي');
      return;
    }
    const updated = { ...user, active: !user.active };
    storageService.saveUser(updated);
    setUsers(storageService.getUsers());
    soundService.playScanBeep();
  };

  const handleDeleteUser = (user: User) => {
    if (user.username === 'admin') {
      alert('لا يمكن حذف الحساب الإداري الرئيسي');
      return;
    }
    if (window.confirm(`هل أنت متأكد من حذف المستخدم (${user.fullName})؟`)) {
      storageService.deleteUser(user.id);
      setUsers(storageService.getUsers());
      soundService.playAccessDenied();
    }
  };

  const getRoleBadge = (r: UserRole) => {
    switch (r) {
      case 'admin': return <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 text-[10px] font-bold">مسؤول النظام IT</span>;
      case 'security_ops': return <span className="px-2 py-0.5 rounded-md bg-purple-500/20 text-purple-300 text-[10px] font-bold">السيطرة الأمنية SOC</span>;
      case 'gate_1': return <span className="px-2 py-0.5 rounded-md bg-blue-500/20 text-blue-300 text-[10px] font-bold">حرس بوابة 1</span>;
      case 'gate_2': return <span className="px-2 py-0.5 rounded-md bg-indigo-500/20 text-indigo-300 text-[10px] font-bold">حرس بوابة 2</span>;
      case 'company_user': return <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">ممثل شركة</span>;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md font-['Tajawal',sans-serif]">
      <div className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl text-slate-100">
        
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 bg-slate-950 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <Users className="w-5 h-5 text-amber-400" />
            <div>
              <h3 className="text-base font-bold text-white">إدارة حسابات المستخدمين وصور البروفايل والشعارات</h3>
              <p className="text-xs text-slate-400">تخصيص شعار الشركة وصورة البروفايل وكلمة السر لكل حساب</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          
          {statusMsg && (
            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center gap-2">
              <CheckCircle className="w-4 h-4" />
              {statusMsg}
            </div>
          )}

          {/* Add New User Toggle */}
          <div className="flex items-center justify-between">
            <p className="text-xs text-slate-400">إجمالي الحسابات المسجلة: <span className="text-white font-bold">{users.length}</span></p>
            {!editingUserId && (
              <button
                onClick={() => {
                  if (isAddingNew) {
                    handleCancelForm();
                  } else {
                    handleCancelForm();
                    setIsAddingNew(true);
                  }
                }}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md"
              >
                <UserPlus className="w-4 h-4" />
                <span>{isAddingNew ? 'إلغاء الإضافة' : 'إضافة حساب مستخدم جديد'}</span>
              </button>
            )}
          </div>

          {/* Add / Edit User Form */}
          {(isAddingNew || editingUserId) && (
            <form onSubmit={handleSaveUser} className="p-5 rounded-2xl bg-slate-950 border border-amber-500/30 space-y-4 animate-in fade-in">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <h4 className="text-xs font-bold text-amber-400 flex items-center gap-2">
                  <Edit3 className="w-4 h-4" />
                  <span>{editingUserId ? 'تعديل بيانات الحساب وصورة الشعار' : 'إنشاء حساب مستخدم جديد وتعيين الشعار'}</span>
                </h4>
                <button
                  type="button"
                  onClick={handleCancelForm}
                  className="text-xs text-slate-400 hover:text-white"
                >
                  إلغاء
                </button>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-slate-400 mb-1">الاسم الكامل:</label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: الرقيب حيدر علي"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white outline-none focus:border-amber-400"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">اسم الدخول (Username):</label>
                  <input
                    type="text"
                    required
                    disabled={!!editingUserId && username === 'admin'}
                    placeholder="مثال: guard_gate1"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white outline-none focus:border-amber-400 font-mono disabled:opacity-50"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">كلمة المرور (Password):</label>
                  <input
                    type="text"
                    required
                    placeholder="••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white outline-none focus:border-amber-400 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">الدور والصلاحية:</label>
                  <select
                    value={role}
                    disabled={editingUserId !== null && username === 'admin'}
                    onChange={(e) => setRole(e.target.value as UserRole)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white outline-none focus:border-amber-400 disabled:opacity-50"
                  >
                    <option value="company_user">ممثل شركة مستضافة (إرسال نداءات فقط)</option>
                    <option value="gate_1">حرس بوابة 1 (تسجيل دخول وخروج)</option>
                    <option value="gate_2">حرس بوابة 2 (تسجيل دخول وخروج)</option>
                    <option value="security_ops">السيطرة والعمليات الأمنية SOC (موافقة ورفض)</option>
                    <option value="admin">مسؤول النظام IT Super Admin (كافة الصلاحيات)</option>
                  </select>
                </div>

                {role === 'company_user' && (
                  <div>
                    <label className="block text-slate-400 mb-1">اختر الشركة التابع لها:</label>
                    <select
                      value={companyId}
                      onChange={(e) => setCompanyId(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white outline-none focus:border-amber-400"
                    >
                      {companies.map((c) => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                  </div>
                )}

                <div>
                  <label className="block text-slate-400 mb-1">رقم الهاتف:</label>
                  <input
                    type="tel"
                    placeholder="0780XXXXXXX"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white outline-none focus:border-amber-400"
                  />
                </div>
              </div>

              {/* Profile Picture / Company Logo Upload */}
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
                <label className="block text-xs font-bold text-slate-200 flex items-center gap-1.5">
                  <Camera className="w-3.5 h-3.5 text-amber-400" />
                  <span>صورة البروفايل أو شعار الشركة للحساب:</span>
                </label>

                <div className="flex flex-wrap items-center gap-3">
                  {avatar ? (
                    <div className="flex items-center gap-3">
                      <img 
                        src={avatar} 
                        alt="User Profile" 
                        className="w-12 h-12 rounded-xl object-cover border-2 border-amber-500/50 shadow-md"
                      />
                      <button
                        type="button"
                        onClick={() => setAvatar('')}
                        className="px-3 py-1 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs border border-red-500/30"
                      >
                        إزالة الصورة
                      </button>
                    </div>
                  ) : (
                    <div className="w-12 h-12 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-500">
                      <ImageIcon className="w-6 h-6" />
                    </div>
                  )}

                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold flex items-center gap-1.5 border border-slate-700"
                  >
                    <UploadCloud className="w-3.5 h-3.5 text-amber-400" />
                    <span>رفع صورة / شعار</span>
                  </button>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleImageUpload}
                  />

                  <div className="flex-1 min-w-[200px]">
                    <input
                      type="url"
                      placeholder="أو ضع رابط مباشر لصورة الشعار (URL)..."
                      value={avatar}
                      onChange={(e) => setAvatar(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white outline-none focus:border-amber-400"
                    />
                  </div>
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={handleCancelForm}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md flex items-center gap-1.5"
                >
                  <Save className="w-4 h-4" />
                  <span>{editingUserId ? 'حفظ التعديلات' : 'حفظ الحساب الآن'}</span>
                </button>
              </div>
            </form>
          )}

          {/* Users List Table */}
          <div className="rounded-2xl border border-slate-800 overflow-hidden">
            <table className="w-full text-right text-xs">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="p-3">المستخدم / الشعار</th>
                  <th className="p-3">اسم الدخول</th>
                  <th className="p-3">الصلاحية</th>
                  <th className="p-3">الجهة / البوابة</th>
                  <th className="p-3">الحالة</th>
                  <th className="p-3 text-left">إجراءات وتعديل</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 bg-slate-900/60">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="p-3 font-bold text-white">
                      <div className="flex items-center gap-2.5">
                        {u.avatar ? (
                          <img 
                            src={u.avatar} 
                            alt={u.fullName} 
                            className="w-8 h-8 rounded-lg object-cover border border-amber-500/40 shrink-0" 
                          />
                        ) : (
                          <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center text-slate-400 font-bold text-[11px] shrink-0">
                            {u.fullName.charAt(0)}
                          </div>
                        )}
                        <div>
                          <div className="text-white">{u.fullName}</div>
                          {u.phone && <div className="text-[10px] text-slate-400">{u.phone}</div>}
                        </div>
                      </div>
                    </td>
                    <td className="p-3 font-mono text-amber-400">{u.username}</td>
                    <td className="p-3">{getRoleBadge(u.role)}</td>
                    <td className="p-3 text-slate-300">{u.companyName || (u.gateId ? `بوابة ${u.gateId === 'gate_1' ? '1' : '2'}` : 'الإدارة العامة')}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${u.active ? 'bg-emerald-500/20 text-emerald-300' : 'bg-red-500/20 text-red-300'}`}>
                        {u.active ? 'نشط' : 'معطل'}
                      </span>
                    </td>
                    <td className="p-3 text-left">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => handleStartEdit(u)}
                          className="p-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/30 transition-colors"
                          title="تعديل بيانات الحساب والشعار"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                        {u.username !== 'admin' && (
                          <>
                            <button
                              onClick={() => handleToggleUser(u)}
                              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px]"
                              title={u.active ? 'تعطيل الحساب' : 'تفعيل الحساب'}
                            >
                              {u.active ? 'تعطيل' : 'تفعيل'}
                            </button>
                            <button
                              onClick={() => handleDeleteUser(u)}
                              className="p-1.5 rounded-lg bg-red-950/40 hover:bg-red-600 text-red-400 hover:text-white"
                              title="حذف"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </div>

      </div>
    </div>
  );
};

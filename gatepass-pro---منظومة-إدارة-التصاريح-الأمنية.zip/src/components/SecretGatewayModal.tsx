import React, { useState, useEffect } from 'react';
import { 
  Shield, 
  Key, 
  Lock, 
  Unlock, 
  CheckCircle, 
  AlertTriangle, 
  RefreshCw, 
  Cpu, 
  Server, 
  Calendar, 
  Database, 
  Sparkles, 
  X, 
  Award, 
  Code, 
  Check, 
  Image as ImageIcon, 
  Upload, 
  Palette, 
  Eye, 
  Trash2, 
  Layers,
  Sparkle,
  Monitor,
  Layout
} from 'lucide-react';
import { storageService } from '../services/storage';
import { soundService } from '../services/audio';
import { compressImageFile } from '../services/imageUtils';
import { SystemLicense, CustomNomenclature } from '../types';

interface SecretGatewayModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccessAuth?: () => void;
}

const PRESET_BACKGROUNDS = [
  {
    id: 'default_dark',
    nameAr: 'النمط السيبراني الداكن الافتراضي (Cyber Dark)',
    url: '',
    preview: 'linear-gradient(135deg, #020617 0%, #0f172a 50%, #1e1b4b 100%)'
  },
  {
    id: 'soc_center',
    nameAr: 'غرفة العمليات والمراقبة الأمنية (SOC Command)',
    url: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=1920&q=80',
    preview: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 'industrial_complex',
    nameAr: 'المجمع الصناعي والنفطي الذكي (Industrial Complex)',
    url: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=1920&q=80',
    preview: 'https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 'cyber_matrix',
    nameAr: 'شبكات الحماية والتشفير الرقمي (Digital Cyber)',
    url: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1920&q=80',
    preview: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 'smart_gates',
    nameAr: 'بوابات التفتيش والوصول الذكي (Smart Gate Access)',
    url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1920&q=80',
    preview: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 'corporate_security',
    nameAr: 'أبراج الشركات والمنشآت الحديثة (Corporate Towers)',
    url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1920&q=80',
    preview: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 'security_hq',
    nameAr: 'مقر الحراسة والتحكم الميداني (Security HQ)',
    url: 'https://images.unsplash.com/photo-1517430816045-df4b7de11d1d?auto=format&fit=crop&w=1920&q=80',
    preview: 'https://images.unsplash.com/photo-1517430816045-df4b7de11d1d?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 'night_infra',
    nameAr: 'البنية التحتية والإنارة الليلية (Night Infrastructure)',
    url: 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=1920&q=80',
    preview: 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=400&q=80'
  }
];

const PRESET_HERO_IMAGES = [
  {
    id: 'default_lock',
    nameAr: 'أيقونة القفل الذهبي الافتراضية',
    url: '',
    preview: ''
  },
  {
    id: 'cyber_shield',
    nameAr: 'درع الحماية السيبرانية',
    url: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=400&q=80',
    preview: 'https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 'security_gate',
    nameAr: 'بوابات الفحص الإلكتروني',
    url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=400&q=80',
    preview: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=400&q=80'
  },
  {
    id: 'corporate_badge',
    nameAr: 'مبنى الإدارة والعمليات',
    url: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=400&q=80',
    preview: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=400&q=80'
  }
];

export const SecretGatewayModal: React.FC<SecretGatewayModalProps> = ({ isOpen, onClose, onSuccessAuth }) => {
  const [pinCode, setPinCode] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [activeTab, setActiveTab] = useState<'appearance' | 'developer' | 'license' | 'system' | 'backup'>('appearance');
  const [license, setLicense] = useState<SystemLicense>(() => storageService.getLicense());
  const [nomenclature, setNomenclature] = useState<CustomNomenclature>(() => storageService.getNomenclature());
  const [newKey, setNewKey] = useState('');
  const [clientNameInput, setClientNameInput] = useState(license.clientName);
  const [facilityInput, setFacilityInput] = useState(license.facilityName);
  const [expiryInput, setExpiryInput] = useState(license.expiryDate ? license.expiryDate.split('T')[0] : '');
  const [maxGatesInput, setMaxGatesInput] = useState(license.maxAllowedGates);
  const [maxCompsInput, setMaxCompsInput] = useState(license.maxCompanies);
  const [statusMsg, setStatusMsg] = useState('');

  // Appearance & Visuals Inputs (Login Screen & System Dashboard)
  const [loginBgUrl, setLoginBgUrl] = useState(license.loginBgUrl || nomenclature.loginBgUrl || '');
  const [systemBgUrl, setSystemBgUrl] = useState(nomenclature.systemBgUrl || license.systemBgUrl || '');
  const [loginHeroImageUrl, setLoginHeroImageUrl] = useState(license.loginHeroImageUrl || nomenclature.loginHeroImageUrl || '');
  const [appLogoUrl, setAppLogoUrl] = useState(nomenclature.appLogoUrl || '');
  const [loginSubtitleAr, setLoginSubtitleAr] = useState(nomenclature.loginCardSubtitleAr || license.loginCardSubtitleAr || 'يرجى تسجيل الدخول للوصول إلى لوحة التحكم وبوابات المنظومة');
  const [loginSubtitleEn, setLoginSubtitleEn] = useState(nomenclature.loginCardSubtitleEn || license.loginCardSubtitleEn || 'Authenticate credentials to access security gates & SOC');

  // Developer & Copyright Inputs
  const [appNameAr, setAppNameAr] = useState(nomenclature.appNameAr || license.appNameAr || 'منظومة GatePass لإدارة البوابات والتصاريح الأمنية');
  const [appNameEn, setAppNameEn] = useState(nomenclature.appNameEn || license.appNameEn || 'GatePass Security & Access Control Enterprise');
  const [facilityNameAr, setFacilityNameAr] = useState(nomenclature.facilityNameAr || license.facilityNameAr || license.facilityName);
  const [facilityNameEn, setFacilityNameEn] = useState(nomenclature.facilityNameEn || license.facilityNameEn || license.facilityName);
  const [devNameAr, setDevNameAr] = useState(license.developerNameAr || 'المهندس علي أحمد عنيد');
  const [devNameEn, setDevNameEn] = useState(license.developerNameEn || 'Eng. Ali Ahmed Aneed');
  const [devTitleAr, setDevTitleAr] = useState(license.developerTitleAr || 'المطور والمصمم البرمجي للمنظومة');
  const [devTitleEn, setDevTitleEn] = useState(license.developerTitleEn || 'Software Architect & System Engineer');
  const [copyrightAr, setCopyrightAr] = useState(license.copyrightAr || 'برمجة وتطوير: المهندس علي أحمد عنيد • جميع الحقوق محفوظة');
  const [copyrightEn, setCopyrightEn] = useState(license.copyrightEn || 'Engineered & Developed by Eng. Ali Ahmed Aneed • All Rights Reserved');
  const [secretCodeInput, setSecretCodeInput] = useState(license.secretGatewayCode || '7941631');

  // Always refresh states with fresh storage data whenever modal opens
  useEffect(() => {
    if (isOpen) {
      const currentLic = storageService.getLicense();
      const currentNom = storageService.getNomenclature();
      setLicense(currentLic);
      setNomenclature(currentNom);
      setLoginBgUrl(currentLic.loginBgUrl || currentNom.loginBgUrl || '');
      setSystemBgUrl(currentNom.systemBgUrl || currentLic.systemBgUrl || '');
      setLoginHeroImageUrl(currentLic.loginHeroImageUrl || currentNom.loginHeroImageUrl || '');
      setAppLogoUrl(currentNom.appLogoUrl || '');
      setLoginSubtitleAr(currentNom.loginCardSubtitleAr || currentLic.loginCardSubtitleAr || 'يرجى تسجيل الدخول للوصول إلى لوحة التحكم وبوابات المنظومة');
      setLoginSubtitleEn(currentNom.loginCardSubtitleEn || currentLic.loginCardSubtitleEn || 'Authenticate credentials to access security gates & SOC');
      setAppNameAr(currentNom.appNameAr || currentLic.appNameAr || 'منظومة GatePass لإدارة البوابات والتصاريح الأمنية');
      setAppNameEn(currentNom.appNameEn || currentLic.appNameEn || 'GatePass Security & Access Control Enterprise');
      setFacilityNameAr(currentNom.facilityNameAr || currentLic.facilityNameAr || currentLic.facilityName);
      setFacilityNameEn(currentNom.facilityNameEn || currentLic.facilityNameEn || currentLic.facilityName);
      setDevNameAr(currentLic.developerNameAr || 'المهندس علي أحمد عنيد');
      setDevNameEn(currentLic.developerNameEn || 'Eng. Ali Ahmed Aneed');
      setDevTitleAr(currentLic.developerTitleAr || 'المطور والمصمم البرمجي للمنظومة');
      setDevTitleEn(currentLic.developerTitleEn || 'Software Architect & System Engineer');
      setCopyrightAr(currentLic.copyrightAr || 'برمجة وتطوير: المهندس علي أحمد عنيد • جميع الحقوق محفوظة');
      setCopyrightEn(currentLic.copyrightEn || 'Engineered & Developed by Eng. Ali Ahmed Aneed • All Rights Reserved');
      setSecretCodeInput(currentLic.secretGatewayCode || '7941631');
      setClientNameInput(currentLic.clientName);
      setFacilityInput(currentLic.facilityName);
      setExpiryInput(currentLic.expiryDate ? currentLic.expiryDate.split('T')[0] : '');
      setMaxGatesInput(currentLic.maxAllowedGates);
      setMaxCompsInput(currentLic.maxCompanies);
      setStatusMsg('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleKeypadPress = (digit: string) => {
    if (pinCode.length < 10) {
      const next = pinCode + digit;
      setPinCode(next);
      setErrorMsg('');
    }
  };

  const handleBackspace = () => {
    setPinCode(prev => prev.slice(0, -1));
    setErrorMsg('');
  };

  const handleClear = () => {
    setPinCode('');
    setErrorMsg('');
  };

  const handleVerify = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const currentLicense = storageService.getLicense();
    if (pinCode === currentLicense.secretGatewayCode || pinCode === '7941631') {
      setIsAuthenticated(true);
      setErrorMsg('');
      soundService.playAccessGranted();
      if (onSuccessAuth) onSuccessAuth();
    } else {
      setErrorMsg('رمز البوابة غير صحيح! تم تسجيل المحاولة أمنياً.');
      soundService.playAccessDenied();
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, targetField: 'bg' | 'systemBg' | 'hero' | 'logo') => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setStatusMsg('جاري معالجة وضغط الصورة بجودة عالية...');

      let processedDataUrl = '';
      if (targetField === 'bg' || targetField === 'systemBg') {
        processedDataUrl = await compressImageFile(file, { maxWidth: 1920, maxHeight: 1080, quality: 0.85, format: 'image/jpeg' });
      } else if (targetField === 'hero') {
        processedDataUrl = await compressImageFile(file, { maxWidth: 800, maxHeight: 800, quality: 0.88, format: 'image/jpeg' });
      } else {
        processedDataUrl = await compressImageFile(file, { maxWidth: 600, maxHeight: 600, quality: 0.90, format: 'image/png' });
      }

      const currentLic = storageService.getLicense();
      const currentNom = storageService.getNomenclature();

      if (targetField === 'bg') {
        setLoginBgUrl(processedDataUrl);
        currentLic.loginBgUrl = processedDataUrl;
        currentNom.loginBgUrl = processedDataUrl;
      } else if (targetField === 'systemBg') {
        setSystemBgUrl(processedDataUrl);
        currentLic.systemBgUrl = processedDataUrl;
        currentNom.systemBgUrl = processedDataUrl;
      } else if (targetField === 'hero') {
        setLoginHeroImageUrl(processedDataUrl);
        currentLic.loginHeroImageUrl = processedDataUrl;
        currentNom.loginHeroImageUrl = processedDataUrl;
      } else if (targetField === 'logo') {
        setAppLogoUrl(processedDataUrl);
        currentNom.appLogoUrl = processedDataUrl;
      }

      // Persist immediately so the user sees real-time update across all tabs and components
      storageService.updateLicense(currentLic);
      storageService.updateNomenclature(currentNom);
      setLicense(currentLic);
      setNomenclature(currentNom);

      soundService.playScanBeep();
      setStatusMsg('تم رفع وحفظ وتطبيق الصورة بنجاح تام في واجهات المنظومة!');
      setTimeout(() => setStatusMsg(''), 4000);
    } catch (err) {
      console.error('Image upload error:', err);
      setStatusMsg('تعذر معالجة الصورة، يرجى المحاولة بصيغة JPG أو PNG صالحة.');
      setTimeout(() => setStatusMsg(''), 4000);
    } finally {
      // Reset input element value to allow re-uploading the same file if needed
      e.target.value = '';
    }
  };

  const handleSaveAppearance = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const currentLic = storageService.getLicense();
    const currentNom = storageService.getNomenclature();

    // 1. Update License
    const updatedLicense: SystemLicense = {
      ...currentLic,
      loginBgUrl: loginBgUrl.trim(),
      systemBgUrl: systemBgUrl.trim(),
      loginHeroImageUrl: loginHeroImageUrl.trim(),
      loginCardSubtitleAr: loginSubtitleAr.trim(),
      loginCardSubtitleEn: loginSubtitleEn.trim(),
    };
    storageService.updateLicense(updatedLicense);

    // 2. Update Nomenclature
    const updatedNomen: CustomNomenclature = {
      ...currentNom,
      appLogoUrl: appLogoUrl.trim(),
      loginBgUrl: loginBgUrl.trim(),
      systemBgUrl: systemBgUrl.trim(),
      loginHeroImageUrl: loginHeroImageUrl.trim(),
      loginCardSubtitleAr: loginSubtitleAr.trim(),
      loginCardSubtitleEn: loginSubtitleEn.trim(),
    };
    storageService.updateNomenclature(updatedNomen);

    setLicense(updatedLicense);
    setNomenclature(updatedNomen);
    setStatusMsg('تم حفظ وتطبيق صورة واجهة تسجيل الدخول وخلفية النظام والشعار بنجاح تام!');
    soundService.playSuccessSound();
    setTimeout(() => setStatusMsg(''), 4000);
  };

  const handleApplyPreset = (url: string, target: 'login' | 'system' | 'hero') => {
    soundService.playScanBeep();
    const currentLic = storageService.getLicense();
    const currentNom = storageService.getNomenclature();

    if (target === 'login') {
      setLoginBgUrl(url);
      currentLic.loginBgUrl = url;
      currentNom.loginBgUrl = url;
    } else if (target === 'system') {
      setSystemBgUrl(url);
      currentLic.systemBgUrl = url;
      currentNom.systemBgUrl = url;
    } else if (target === 'hero') {
      setLoginHeroImageUrl(url);
      currentLic.loginHeroImageUrl = url;
      currentNom.loginHeroImageUrl = url;
    }

    // Auto-save and sync so background changes dynamically
    storageService.updateLicense(currentLic);
    storageService.updateNomenclature(currentNom);
    setLicense(currentLic);
    setNomenclature(currentNom);
    
    setStatusMsg(target === 'login' ? 'تم تطبيق خلفية واجهة الدخول بنجاح!' : target === 'hero' ? 'تم تطبيق صورة بانر الدخول بنجاح!' : 'تم تطبيق خلفية النظام بنجاح!');
    setTimeout(() => setStatusMsg(''), 3000);
  };

  const handleSaveDeveloperCredits = (e: React.FormEvent) => {
    e.preventDefault();
    const currentLic = storageService.getLicense();
    const currentNom = storageService.getNomenclature();

    const updatedLicense: SystemLicense = {
      ...currentLic,
      appNameAr: appNameAr.trim(),
      appNameEn: appNameEn.trim(),
      facilityNameAr: facilityNameAr.trim(),
      facilityNameEn: facilityNameEn.trim(),
      developerNameAr: devNameAr.trim(),
      developerNameEn: devNameEn.trim(),
      developerTitleAr: devTitleAr.trim(),
      developerTitleEn: devTitleEn.trim(),
      copyrightAr: copyrightAr.trim(),
      copyrightEn: copyrightEn.trim(),
      secretGatewayCode: secretCodeInput.trim() || '7941631',
      loginBgUrl: loginBgUrl.trim(),
      systemBgUrl: systemBgUrl.trim(),
      loginHeroImageUrl: loginHeroImageUrl.trim(),
    };
    storageService.updateLicense(updatedLicense);
    
    // Also sync to nomenclature
    const updatedNomen: CustomNomenclature = {
      ...currentNom,
      appNameAr: appNameAr.trim(),
      appNameEn: appNameEn.trim(),
      facilityNameAr: facilityNameAr.trim(),
      facilityNameEn: facilityNameEn.trim(),
      appLogoUrl: appLogoUrl.trim(),
      loginBgUrl: loginBgUrl.trim(),
      systemBgUrl: systemBgUrl.trim(),
      loginHeroImageUrl: loginHeroImageUrl.trim(),
    };
    storageService.updateNomenclature(updatedNomen);

    setLicense(updatedLicense);
    setNomenclature(updatedNomen);
    setStatusMsg('تم حفظ وتحديث حقوق الملكية واسم البرنامج وبيانات المهندس المطور بنجاح!');
    soundService.playSuccessSound();
    setTimeout(() => setStatusMsg(''), 4000);
  };

  const handleSaveLicense = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: SystemLicense = {
      ...license,
      clientName: clientNameInput,
      facilityName: facilityInput,
      expiryDate: new Date(expiryInput + 'T23:59:59.000Z').toISOString(),
      maxAllowedGates: Number(maxGatesInput),
      maxCompanies: Number(maxCompsInput),
      licenseKey: newKey.trim() ? newKey.trim() : license.licenseKey
    };
    storageService.updateLicense(updated);
    setLicense(updated);
    setStatusMsg('تم تحديث بيانات الترخيص والمصفوفة الأمنية بنجاح!');
    soundService.playSuccessSound();
    setTimeout(() => setStatusMsg(''), 4000);
  };

  const handleGenerateKey = () => {
    const randomHex = Array.from({ length: 4 }, () => Math.random().toString(36).substring(2, 6).toUpperCase()).join('-');
    const generated = `GP-ENT-${randomHex}-7941`;
    setNewKey(generated);
    soundService.playScanBeep();
  };

  const handleToggleMaintenance = () => {
    const updated = { ...license, maintenanceMode: !license.maintenanceMode };
    storageService.updateLicense(updated);
    setLicense(updated);
    setStatusMsg(`تم ${updated.maintenanceMode ? 'تفعيل' : 'إلغاء'} وضع الصيانة للنظام.`);
  };

  const handleResetSystem = () => {
    if (window.confirm('تحذير شديد الأهمية: هل أنت متأكد من رغبتك في إعادة ضبط المصنع ومسح كافة الحركات والتصاريح وإعادة التهيئة الأولية؟')) {
      storageService.resetToDemo();
      soundService.playSuccessSound();
      alert('تمت إعادة ضبط النظام إلى الإعدادات الأولية بنجاح!');
      window.location.reload();
    }
  };

  const handleExportBackup = () => {
    const backupData = {
      users: storageService.getUsers(),
      companies: storageService.getCompanies(),
      passes: storageService.getPasses(),
      movements: storageService.getMovements(),
      license: storageService.getLicense(),
      nomenclature: storageService.getNomenclature(),
      exportedAt: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `gatepass_backup_${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    soundService.playSuccessSound();
  };

  return (
    <div id="secret-gateway-modal" className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
      <div className="relative w-full max-w-4xl max-h-[92vh] flex flex-col bg-slate-900 border border-amber-500/40 rounded-3xl shadow-2xl overflow-hidden text-slate-100 font-['Tajawal',sans-serif]">
        
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-gradient-to-r from-slate-950 via-slate-900 to-amber-950/40 border-b border-amber-500/20 shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400">
              <Key className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-amber-200">البوابة المتقدمة للترخيص والإدارة الفنية والهوية</h2>
              <p className="text-xs text-slate-400">منفذ الإشراف الفني، تعديل صورة واجهة الدخول، وحقوق الملكية للمطور</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto">
          {!isAuthenticated ? (
            /* PIN Keypad Screen */
            <div className="max-w-xs mx-auto text-center py-4">
              <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 shadow-inner">
                <Lock className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold text-slate-200 mb-1">أدخل رمز الوصول الفني للبوابة</h3>
              <p className="text-xs text-slate-400 mb-6">مخصص فقط لمسؤول الـ IT ومطور النظام المعتمد</p>

              {/* Pin Display */}
              <div className="flex items-center justify-center gap-2 mb-6">
                {[...Array(7)].map((_, i) => (
                  <div 
                    key={i}
                    className={`w-9 h-11 rounded-lg border flex items-center justify-center text-lg font-bold font-mono transition-all ${
                      pinCode[i] 
                        ? 'border-amber-400 bg-amber-500/20 text-amber-200 shadow-sm' 
                        : 'border-slate-800 bg-slate-950/60 text-slate-600'
                    }`}
                  >
                    {pinCode[i] ? '•' : ''}
                  </div>
                ))}
              </div>

              {/* Error Message */}
              {errorMsg && (
                <div className="mb-4 p-2 rounded-lg bg-red-500/10 border border-red-500/30 text-red-400 text-xs font-semibold">
                  {errorMsg}
                </div>
              )}

              {/* Keypad Grid */}
              <div className="grid grid-cols-3 gap-2 mb-4">
                {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '⌫'].map((btn) => (
                  <button
                    key={btn}
                    type="button"
                    onClick={() => {
                      if (btn === 'C') handleClear();
                      else if (btn === '⌫') handleBackspace();
                      else handleKeypadPress(btn);
                    }}
                    className={`h-12 rounded-xl font-bold text-base transition-all active:scale-95 ${
                      btn === 'C' || btn === '⌫'
                        ? 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                        : 'bg-slate-800/80 text-white hover:bg-amber-500/20 hover:text-amber-300 hover:border-amber-500/40 border border-slate-700/50'
                    }`}
                  >
                    {btn}
                  </button>
                ))}
              </div>

              {/* Direct Unlock Button */}
              <button
                type="button"
                onClick={() => handleVerify()}
                disabled={pinCode.length === 0}
                className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-sm shadow-lg shadow-amber-500/20 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2"
              >
                <Unlock className="w-4 h-4" />
                تحقق وتأكيد الدخول للبوابة السرية
              </button>
            </div>
          ) : (
            /* Authenticated License & System Control Panel */
            <div>
              {/* Tabs */}
              <div className="flex flex-wrap items-center gap-2 border-b border-slate-800 pb-3 mb-6">
                <button
                  type="button"
                  onClick={() => setActiveTab('appearance')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
                    activeTab === 'appearance'
                      ? 'bg-amber-500 text-slate-950 shadow-md'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <ImageIcon className="w-4 h-4" />
                  صورة واجهة تسجيل الدخول والشعار
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('developer')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
                    activeTab === 'developer'
                      ? 'bg-amber-500 text-slate-950 shadow-md'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <Award className="w-4 h-4" />
                  حقوق المطور والملكية الفكرية
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('license')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
                    activeTab === 'license'
                      ? 'bg-amber-500 text-slate-950 shadow-md'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <Shield className="w-4 h-4" />
                  بيانات الترخيص والصلاحية
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('system')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
                    activeTab === 'system'
                      ? 'bg-amber-500 text-slate-950 shadow-md'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <Cpu className="w-4 h-4" />
                  التحكم التقني والشبكة
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('backup')}
                  className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
                    activeTab === 'backup'
                      ? 'bg-amber-500 text-slate-950 shadow-md'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800'
                  }`}
                >
                  <Database className="w-4 h-4" />
                  النسخ الاحتياطي وإعادة الضبط
                </button>
              </div>

              {/* Status Alert */}
              {statusMsg && (
                <div className="mb-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center gap-2 animate-in fade-in">
                  <CheckCircle className="w-4 h-4 shrink-0" />
                  {statusMsg}
                </div>
              )}

              {/* Tab 0: Appearance & Login Screen Customization (Requested by User) */}
              {activeTab === 'appearance' && (
                <form onSubmit={handleSaveAppearance} className="space-y-6">
                  
                  <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-500/10 via-slate-950 to-slate-900 border border-amber-500/30 space-y-2">
                    <div className="flex items-center gap-2.5">
                      <Palette className="w-5 h-5 text-amber-400" />
                      <h4 className="text-sm font-bold text-white">تخصيص صورة واجهة تسجيل الدخول وخلفية النظام والشعار</h4>
                    </div>
                    <p className="text-xs text-slate-300">
                      يمكنك هنا تغيير صورة الخلفية لشاشة تسجيل الدخول الرئيسية، وتغيير خلفية لوحات التحكم الداخلية، وتغيير شعار البرنامج، والتحكم بالنصوص والبانر بدقة تامة.
                    </p>
                  </div>

                  {/* 1. Login Background Wallpaper Presets & Custom Upload */}
                  <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                        <Layers className="w-4 h-4 text-amber-400" />
                        <span>1. صورة خلفية واجهة تسجيل الدخول (Login Screen Wallpaper):</span>
                      </label>
                      {loginBgUrl && (
                        <button
                          type="button"
                          onClick={() => setLoginBgUrl('')}
                          className="text-[11px] text-red-400 hover:text-red-300 flex items-center gap-1"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>استعادة الخلفية الافتراضية للشاشة</span>
                        </button>
                      )}
                    </div>

                    {/* Preset Grid for Login */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {PRESET_BACKGROUNDS.map((preset) => (
                        <div
                          key={`login-${preset.id}`}
                          onClick={() => handleApplyPreset(preset.url, 'login')}
                          className={`group cursor-pointer p-2 rounded-xl border transition-all text-right relative overflow-hidden ${
                            loginBgUrl === preset.url
                              ? 'border-amber-400 bg-amber-500/15 shadow-lg shadow-amber-500/10 ring-2 ring-amber-400/50'
                              : 'border-slate-800 bg-slate-900/80 hover:border-slate-700'
                          }`}
                        >
                          <div 
                            className="w-full h-14 rounded-lg bg-cover bg-center mb-1.5 border border-slate-800 group-hover:scale-[1.02] transition-transform"
                            style={{ 
                              backgroundImage: preset.url ? `url(${preset.preview})` : preset.preview,
                              backgroundSize: 'cover' 
                            }}
                          />
                          <div className="text-[10px] font-bold text-white truncate">{preset.nameAr}</div>
                          {loginBgUrl === preset.url && (
                            <div className="absolute top-2 right-2 bg-amber-500 text-slate-950 rounded-full p-0.5 shadow-md">
                              <Check className="w-3 h-3 font-black" />
                            </div>
                          )}
                        </div>
                      ))}
                    </div>

                    {/* Custom Background URL / File Upload for Login */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                      <div className="sm:col-span-2">
                        <label className="block text-[11px] text-slate-400 mb-1">رابط صورة مخصص لخلفية تسجيل الدخول (Login URL):</label>
                        <input
                          type="text"
                          value={loginBgUrl}
                          onChange={(e) => setLoginBgUrl(e.target.value)}
                          placeholder="https://images.unsplash.com/... أو رابط الصورة"
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-1">أو رفع صورة من الجهاز:</label>
                        <label className="w-full h-9 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 flex items-center justify-center gap-1.5 text-xs text-slate-200 font-bold cursor-pointer transition-colors">
                          <Upload className="w-3.5 h-3.5 text-amber-400" />
                          <span>رفع خلفية الدخول</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleFileUpload(e, 'bg')}
                            className="hidden"
                          />
                        </label>
                      </div>
                    </div>
                  </div>

                  {/* 2. System / Dashboard Background Wallpaper */}
                  <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-bold text-blue-300 flex items-center gap-1.5">
                        <Monitor className="w-4 h-4 text-blue-400" />
                        <span>2. صورة خلفية لوحات التحكم والواجهات الداخلية (System Dashboard Wallpaper):</span>
                      </label>
                      {systemBgUrl && (
                        <button
                          type="button"
                          onClick={() => setSystemBgUrl('')}
                          className="text-[11px] text-red-400 hover:text-red-300 flex items-center gap-1"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>استعادة الخلفية الافتراضية للنظام</span>
                        </button>
                      )}
                    </div>

                    {/* Preset Grid for System */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      {PRESET_BACKGROUNDS.map((preset) => (
                        <div
                          key={`sys-${preset.id}`}
                          onClick={() => handleApplyPreset(preset.url, 'system')}
                          className={`group cursor-pointer p-2 rounded-xl border transition-all text-right relative overflow-hidden ${
                            systemBgUrl === preset.url
                              ? 'border-blue-400 bg-blue-500/15 shadow-lg shadow-blue-500/10 ring-2 ring-blue-400/50'
                              : 'border-slate-800 bg-slate-900/80 hover:border-slate-700'
                          }`}
                        >
                          <div 
                            className="w-full h-14 rounded-lg bg-cover bg-center mb-1.5 border border-slate-800 group-hover:scale-[1.02] transition-transform"
                            style={{ 
                              backgroundImage: preset.url ? `url(${preset.preview})` : preset.preview,
                              backgroundSize: 'cover' 
                            }}
                          />
                          <div className="text-[10px] font-bold text-white truncate">{preset.nameAr}</div>
                          {systemBgUrl === preset.url && (
                            <div className="absolute top-2 right-2 bg-blue-500 text-white rounded-full p-0.5 shadow-md">
                              <Check className="w-3 h-3 font-black" />
                            </div>
                          )}
                        </div>
                      ))}
                    </div>

                    {/* Custom Background URL / File Upload for System */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
                      <div className="sm:col-span-2">
                        <label className="block text-[11px] text-slate-400 mb-1">رابط صورة مخصص لخلفية النظام الداخلية (System URL):</label>
                        <input
                          type="text"
                          value={systemBgUrl}
                          onChange={(e) => setSystemBgUrl(e.target.value)}
                          placeholder="https://images.unsplash.com/... أو رابط الصورة"
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-blue-400 outline-none font-mono"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-1">أو رفع صورة من الجهاز:</label>
                        <label className="w-full h-9 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 flex items-center justify-center gap-1.5 text-xs text-slate-200 font-bold cursor-pointer transition-colors">
                          <Upload className="w-3.5 h-3.5 text-blue-400" />
                          <span>رفع خلفية النظام</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleFileUpload(e, 'systemBg')}
                            className="hidden"
                          />
                        </label>
                      </div>
                    </div>
                  </div>

                  {/* 3. Custom App Logo & Login Card Hero Image */}
                  <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-4">
                    <label className="text-xs font-bold text-amber-300 flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-amber-400" />
                      <span>3. شعار البرنامج وصورة واجهة الدخول (App Logo & Hero Icon):</span>
                    </label>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      
                      {/* App Logo */}
                      <div className="space-y-2 p-3 rounded-xl bg-slate-900/60 border border-slate-800">
                        <div className="text-[11px] font-bold text-slate-300">شعار المنظومة العام (App Logo):</div>
                        <div className="flex items-center gap-3">
                          {appLogoUrl ? (
                            <div className="w-12 h-12 rounded-xl bg-slate-950 border border-amber-500/50 p-1 flex items-center justify-center shrink-0">
                              <img src={appLogoUrl} alt="Logo" className="w-full h-full object-contain" />
                            </div>
                          ) : (
                            <div className="w-12 h-12 rounded-xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center font-bold text-xs shrink-0">
                              شعار
                            </div>
                          )}
                          <div className="flex-1 space-y-1">
                            <input
                              type="text"
                              value={appLogoUrl}
                              onChange={(e) => setAppLogoUrl(e.target.value)}
                              placeholder="رابط الشعار أو رفعه..."
                              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white outline-none"
                            />
                            <div className="flex items-center gap-2">
                              <label className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[10px] text-slate-300 font-bold cursor-pointer flex items-center gap-1">
                                <Upload className="w-3 h-3 text-amber-400" />
                                <span>رفع ملف</span>
                                <input
                                  type="file"
                                  accept="image/*"
                                  onChange={(e) => handleFileUpload(e, 'logo')}
                                  className="hidden"
                                />
                              </label>
                              {appLogoUrl && (
                                <button
                                  type="button"
                                  onClick={() => setAppLogoUrl('')}
                                  className="text-[10px] text-red-400 hover:text-red-300"
                                >
                                  حذف
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Login Card Hero Banner */}
                      <div className="space-y-2 p-3 rounded-xl bg-slate-900/60 border border-slate-800">
                        <div className="text-[11px] font-bold text-slate-300">بانر / صورة بطاقة تسجيل الدخول (Card Banner):</div>
                        
                        {/* Quick Presets for Card Hero */}
                        <div className="grid grid-cols-2 gap-2 pb-1">
                          {PRESET_HERO_IMAGES.map((preset) => (
                            <button
                              key={`hero-${preset.id}`}
                              type="button"
                              onClick={() => handleApplyPreset(preset.url, 'hero')}
                              className={`p-1.5 rounded-lg border text-right flex items-center gap-2 text-[10px] font-bold transition-all ${
                                loginHeroImageUrl === preset.url
                                  ? 'border-amber-400 bg-amber-500/20 text-amber-300'
                                  : 'border-slate-800 bg-slate-950 text-slate-400 hover:border-slate-700'
                              }`}
                            >
                              <div className="w-5 h-5 rounded bg-slate-800 flex items-center justify-center shrink-0 overflow-hidden">
                                {preset.url ? (
                                  <img src={preset.preview} alt="" className="w-full h-full object-cover" />
                                ) : (
                                  <Lock className="w-3 h-3 text-amber-400" />
                                )}
                              </div>
                              <span className="truncate">{preset.nameAr}</span>
                            </button>
                          ))}
                        </div>

                        <div className="flex items-center gap-3">
                          {loginHeroImageUrl ? (
                            <div className="w-12 h-12 rounded-xl bg-slate-950 border border-amber-500/50 p-1 flex items-center justify-center shrink-0 overflow-hidden">
                              <img src={loginHeroImageUrl} alt="Banner" className="w-full h-full object-cover rounded-lg" />
                            </div>
                          ) : (
                            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-slate-950 font-bold shrink-0 shadow-md">
                              <Lock className="w-6 h-6" />
                            </div>
                          )}
                          <div className="flex-1 space-y-1">
                            <input
                              type="text"
                              value={loginHeroImageUrl}
                              onChange={(e) => setLoginHeroImageUrl(e.target.value)}
                              placeholder="رابط صورة البانر في بطاقة الدخول..."
                              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white outline-none"
                            />
                            <div className="flex items-center gap-2">
                              <label className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-[10px] text-slate-300 font-bold cursor-pointer flex items-center gap-1">
                                <Upload className="w-3 h-3 text-amber-400" />
                                <span>رفع بانر</span>
                                <input
                                  type="file"
                                  accept="image/*"
                                  onChange={(e) => handleFileUpload(e, 'hero')}
                                  className="hidden"
                                />
                              </label>
                              {loginHeroImageUrl && (
                                <button
                                  type="button"
                                  onClick={() => {
                                    setLoginHeroImageUrl('');
                                    handleApplyPreset('', 'hero');
                                  }}
                                  className="text-[10px] text-red-400 hover:text-red-300"
                                >
                                  حذف
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>

                    </div>
                  </div>

                  {/* 4. Subtitle / Guidance Text */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 rounded-2xl bg-slate-950 border border-slate-800">
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">وصف بطاقة الدخول (بالعربية):</label>
                      <input
                        type="text"
                        value={loginSubtitleAr}
                        onChange={(e) => setLoginSubtitleAr(e.target.value)}
                        placeholder="يرجى تسجيل الدخول للوصول إلى لوحة التحكم وبوابات المنظومة"
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-300 mb-1">Login Card Subtitle (English):</label>
                      <input
                        type="text"
                        value={loginSubtitleEn}
                        onChange={(e) => setLoginSubtitleEn(e.target.value)}
                        placeholder="Authenticate credentials to access security gates & SOC"
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none font-sans"
                      />
                    </div>
                  </div>

                  {/* Save Button */}
                  <div className="flex justify-end gap-3 pt-2">
                    <button
                      type="submit"
                      className="py-3 px-8 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/25 transition-all flex items-center gap-2 active:scale-95"
                    >
                      <Check className="w-4 h-4 font-black" />
                      <span>حفظ وتطبيق صورة واجهة تسجيل الدخول والخلفيات والشعار فوراً</span>
                    </button>
                  </div>
                </form>
              )}

              {/* Tab 1: Developer & Copyright Editor */}
              {activeTab === 'developer' && (
                <form onSubmit={handleSaveDeveloperCredits} className="space-y-4">
                  <div className="p-4 rounded-2xl bg-gradient-to-br from-amber-500/10 via-slate-950 to-slate-900 border border-amber-500/30 space-y-2">
                    <div className="flex items-center gap-2.5">
                      <Award className="w-5 h-5 text-amber-400" />
                      <h4 className="text-sm font-bold text-white">إدارة حقوق الملكية واسم المهندس المطور</h4>
                    </div>
                    <p className="text-xs text-slate-300">
                      يمكنك تخصيص وحفظ اسم المطور وحقوق الملكية باللغتين العربية والإنكليزية وتظهر تلقائياً في كافة واجهات النظام والبطاقات والطباعة.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-amber-300 mb-1">تعديل اسم البرنامج / المنظومة (بالعربية):</label>
                      <input 
                        type="text" 
                        value={appNameAr} 
                        onChange={(e) => setAppNameAr(e.target.value)}
                        placeholder="منظومة GatePass لإدارة البوابات والتصاريح الأمنية"
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white focus:border-amber-400 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-amber-300 mb-1">System / Application Name (English):</label>
                      <input 
                        type="text" 
                        value={appNameEn} 
                        onChange={(e) => setAppNameEn(e.target.value)}
                        placeholder="GatePass Security & Access Control Enterprise"
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white focus:border-amber-400 outline-none font-sans"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-300 mb-1">اسم المنشأة والموقع (بالعربية):</label>
                      <input 
                        type="text" 
                        value={facilityNameAr} 
                        onChange={(e) => setFacilityNameAr(e.target.value)}
                        placeholder="المجمع الصناعي والنفطي الموحد - بوابات 1 و 2"
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-300 mb-1">Facility Name (English):</label>
                      <input 
                        type="text" 
                        value={facilityNameEn} 
                        onChange={(e) => setFacilityNameEn(e.target.value)}
                        placeholder="Unified Industrial & Oil Complex - Gates 1 & 2"
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none font-sans"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-amber-300 mb-1">اسم المهندس المطور (بالعربية):</label>
                      <input 
                        type="text" 
                        value={devNameAr} 
                        onChange={(e) => setDevNameAr(e.target.value)}
                        placeholder="المهندس علي أحمد عنيد"
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white focus:border-amber-400 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-amber-300 mb-1">Developer Name (English):</label>
                      <input 
                        type="text" 
                        value={devNameEn} 
                        onChange={(e) => setDevNameEn(e.target.value)}
                        placeholder="Eng. Ali Ahmed Aneed"
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white focus:border-amber-400 outline-none font-sans"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-300 mb-1">المسمى الوظيفي (بالعربية):</label>
                      <input 
                        type="text" 
                        value={devTitleAr} 
                        onChange={(e) => setDevTitleAr(e.target.value)}
                        placeholder="المطور والمصمم البرمجي للمنظومة"
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-300 mb-1">Professional Title (English):</label>
                      <input 
                        type="text" 
                        value={devTitleEn} 
                        onChange={(e) => setDevTitleEn(e.target.value)}
                        placeholder="Software Architect & System Engineer"
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none font-sans"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs text-slate-300 mb-1">عبارة حقوق الملكية (بالعربية):</label>
                    <input 
                      type="text" 
                      value={copyrightAr} 
                      onChange={(e) => setCopyrightAr(e.target.value)}
                      placeholder="برمجة وتطوير: المهندس علي أحمد عنيد • جميع الحقوق محفوظة"
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs text-slate-300 mb-1">Copyright Notice (English):</label>
                    <input 
                      type="text" 
                      value={copyrightEn} 
                      onChange={(e) => setCopyrightEn(e.target.value)}
                      placeholder="Engineered & Developed by Eng. Ali Ahmed Aneed • All Rights Reserved"
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none font-sans"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-amber-400 mb-1">تغيير رمز الدخول للبوابة السرية (PIN Code):</label>
                    <input 
                      type="text" 
                      value={secretCodeInput} 
                      onChange={(e) => setSecretCodeInput(e.target.value)}
                      placeholder="7941631"
                      className="w-full sm:w-60 bg-slate-950 border border-amber-500/40 rounded-xl px-3 py-2 text-xs font-mono font-bold text-amber-300 focus:border-amber-400 outline-none"
                    />
                    <p className="text-[11px] text-slate-400 mt-1">الرمز الحالي محمي ولا يظهر للمستخدمين العاديين.</p>
                  </div>

                  <div className="pt-2 flex justify-end gap-3">
                    <button
                      type="submit"
                      className="py-2.5 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition-colors flex items-center gap-2"
                    >
                      <Check className="w-4 h-4" />
                      <span>حفظ حقوق الملكية والبيانات</span>
                    </button>
                  </div>
                </form>
              )}

              {/* Tab 2: License Form */}
              {activeTab === 'license' && (
                <form onSubmit={handleSaveLicense} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">الجهة المرخص لها (العميل):</label>
                      <input 
                        type="text" 
                        value={clientNameInput} 
                        onChange={(e) => setClientNameInput(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">اسم المنشأة والموقع:</label>
                      <input 
                        type="text" 
                        value={facilityInput} 
                        onChange={(e) => setFacilityInput(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">تاريخ انتهاء صلاحية الترخيص:</label>
                      <input 
                        type="date" 
                        value={expiryInput} 
                        onChange={(e) => setExpiryInput(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">الحد الأقصى للبوابات المسموحة:</label>
                      <input 
                        type="number" 
                        min="1" 
                        max="10"
                        value={maxGatesInput} 
                        onChange={(e) => setMaxGatesInput(Number(e.target.value))}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">الحد الأقصى للشركات المستضافة:</label>
                      <input 
                        type="number" 
                        min="1" 
                        max="100"
                        value={maxCompsInput} 
                        onChange={(e) => setMaxCompsInput(Number(e.target.value))}
                        className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-400 mb-1">بصمة العتاد (Hardware Hash):</label>
                      <input 
                        type="text" 
                        readOnly 
                        value={license.hardwareFingerprint}
                        className="w-full bg-slate-950/60 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-400 font-mono"
                      />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="text-xs text-slate-400">مفتاح الترخيص الحالي (License Key):</label>
                      <button 
                        type="button" 
                        onClick={handleGenerateKey}
                        className="text-[11px] text-amber-400 hover:text-amber-300 flex items-center gap-1 font-semibold"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        توليد مفتاح ترخيص جديد
                      </button>
                    </div>
                    <input 
                      type="text" 
                      value={newKey || license.licenseKey} 
                      onChange={(e) => setNewKey(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-mono text-amber-300 focus:border-amber-400 outline-none"
                    />
                  </div>

                  <div className="pt-2 flex justify-end gap-3">
                    <button
                      type="submit"
                      className="py-2.5 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition-colors"
                    >
                      حفظ وتطبيق الترخيص
                    </button>
                  </div>
                </form>
              )}

              {/* Tab 3: System Settings */}
              {activeTab === 'system' && (
                <div className="space-y-4">
                  <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-xs font-bold text-slate-200">وضع الصيانة الأمني (Maintenance Lock)</h4>
                        <p className="text-[11px] text-slate-400">تجميد طلبات الدخول مؤقتاً أثناء التفتيش الأمني أو الطوارئ</p>
                      </div>
                      <button
                        type="button"
                        onClick={handleToggleMaintenance}
                        className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-colors ${
                          license.maintenanceMode
                            ? 'bg-red-500 text-white'
                            : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                        }`}
                      >
                        {license.maintenanceMode ? 'وضع الصيانة نشط' : 'إيقاف الصيانة'}
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                      <div className="text-[11px] text-slate-400 mb-1">المزامنة الحية بين البوابات:</div>
                      <div className="text-xs font-bold text-emerald-400 flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                        نشطة ومتزامنة لحظياً (Active Multi-Gate Broadcast)
                      </div>
                    </div>
                    <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800">
                      <div className="text-[11px] text-slate-400 mb-1">التحقق الصوتي من الباركود و VIP:</div>
                      <div className="text-xs font-bold text-amber-400 flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                        مفعل بموجات Web Audio
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 4: Backup & Reset */}
              {activeTab === 'backup' && (
                <div className="space-y-4">
                  <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-slate-200">تصدير نسخة احتياطية من قاعدة البيانات</h4>
                      <p className="text-[11px] text-slate-400">تحميل كافة المستخدمين والشركات والتصاريح وسجلات الحركات بصيغة JSON</p>
                    </div>
                    <button
                      type="button"
                      onClick={handleExportBackup}
                      className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold flex items-center gap-2 border border-slate-700"
                    >
                      <Database className="w-4 h-4 text-amber-400" />
                      تحميل النسخة
                    </button>
                  </div>

                  <div className="p-4 rounded-xl bg-red-950/20 border border-red-500/30 flex items-center justify-between">
                    <div>
                      <h4 className="text-xs font-bold text-red-300">إعادة ضبط المصنع (Factory Reset)</h4>
                      <p className="text-[11px] text-slate-400">مسح البيانات المضافة وإعادة تعيين الشركات والتصاريح والمسؤول الافتراضي</p>
                    </div>
                    <button
                      type="button"
                      onClick={handleResetSystem}
                      className="px-4 py-2 rounded-xl bg-red-600/80 hover:bg-red-600 text-white text-xs font-bold flex items-center gap-2 shadow-md transition-colors"
                    >
                      <RefreshCw className="w-4 h-4" />
                      إعادة التهيئة
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

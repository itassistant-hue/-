import React, { useState, useEffect } from 'react';
import { PassRequest, User, PassType } from '../types';
import { storageService } from '../services/storage';
import { soundService } from '../services/audio';
import { 
  ShieldCheck, 
  Clock, 
  CheckCircle, 
  XCircle, 
  AlertTriangle, 
  Crown, 
  Car, 
  Building2, 
  UserCheck, 
  Search, 
  Filter, 
  Eye, 
  Printer, 
  Plus, 
  Check, 
  X,
  FileText,
  AlertOctagon,
  Sparkles,
  RefreshCw
} from 'lucide-react';

interface SecurityOpsDashboardProps {
  currentUser: User;
  onOpenPassDetails: (pass: PassRequest) => void;
  onOpenNewPassModal: () => void;
}

export const SecurityOpsDashboard: React.FC<SecurityOpsDashboardProps> = ({
  currentUser,
  onOpenPassDetails,
  onOpenNewPassModal
}) => {
  const [passes, setPasses] = useState<PassRequest[]>(() => storageService.getPasses());
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [rejectingPassId, setRejectingPassId] = useState<string | null>(null);
  const [rejectionReasonInput, setRejectionReasonInput] = useState('');
  const [activeTab, setActiveTab] = useState<'pending' | 'inside' | 'all' | 'expired'>('pending');

  useEffect(() => {
    const handleStorageChange = () => {
      setPasses(storageService.getPasses());
    };
    window.addEventListener('gatepass_storage_event', handleStorageChange);
    return () => window.removeEventListener('gatepass_storage_event', handleStorageChange);
  }, []);

  const handleApprove = (pass: PassRequest, customNotes?: string) => {
    const updated = storageService.approvePass(pass.id, currentUser, customNotes);
    if (updated) {
      if (pass.visitorType === 'vip') {
        soundService.playVipFanfare();
      } else {
        soundService.playSuccessSound();
      }
    }
  };

  const handleRejectSubmit = (passId: string) => {
    if (!rejectionReasonInput.trim()) {
      alert('يرجى كتابة سبب الرفض الأمني');
      return;
    }
    storageService.rejectPass(passId, currentUser, rejectionReasonInput.trim());
    setRejectingPassId(null);
    setRejectionReasonInput('');
    soundService.playAccessDenied();
  };

  const effectivePasses = passes.map(p => ({
    ...p,
    effectiveStatus: storageService.getEffectiveStatus(p)
  }));

  const pendingPasses = effectivePasses.filter(p => p.status === 'pending_security');
  const insidePasses = effectivePasses.filter(p => p.effectiveStatus === 'inside');
  const expiredPasses = effectivePasses.filter(p => p.effectiveStatus === 'expired');

  // Filtered master list
  const filteredPasses = effectivePasses.filter(p => {
    const matchesSearch = 
      p.visitorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.passNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.companyName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.nationalIdOrPassport.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.vehiclePlate && p.vehiclePlate.toLowerCase().includes(searchQuery.toLowerCase()));

    if (!matchesSearch) return false;

    if (activeTab === 'pending') return p.status === 'pending_security';
    if (activeTab === 'inside') return p.effectiveStatus === 'inside';
    if (activeTab === 'expired') return p.effectiveStatus === 'expired';

    if (filterType !== 'all') {
      return p.visitorType === filterType;
    }
    return true;
  });

  return (
    <div className="space-y-6 font-['Tajawal',sans-serif]">
      
      {/* Top SOC Operations Header */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-amber-500/20">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl font-black text-white">مركز السيطرة والعمليات الأمنية (SOC)</h2>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/30">
                مباشر
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              إدارة نداءات الشركات المستضافة، التدقيق الأمني، ومنح تصاريح الدخول للبوابات 1 و 2
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onOpenNewPassModal}
            className="px-5 py-2.5 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-lg shadow-amber-500/20 flex items-center gap-2 transition-transform active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>إصدار تصريح مباشر</span>
          </button>
        </div>
      </div>

      {/* Quick Metrics Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div 
          onClick={() => setActiveTab('pending')}
          className={`p-4 rounded-3xl border transition-all cursor-pointer ${
            activeTab === 'pending'
              ? 'bg-amber-950/30 border-amber-500 ring-1 ring-amber-500/50'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 font-bold">نداءات قيد التدقيق</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-black text-amber-400 font-mono">{pendingPasses.length}</div>
          <div className="text-[10px] text-slate-400 mt-1">تتطلب موافقة السيطرة</div>
        </div>

        <div 
          onClick={() => setActiveTab('inside')}
          className={`p-4 rounded-3xl border transition-all cursor-pointer ${
            activeTab === 'inside'
              ? 'bg-emerald-950/30 border-emerald-500 ring-1 ring-emerald-500/50'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 font-bold">المتواجدون بالموقع</span>
            <UserCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-black text-emerald-400 font-mono">{insidePasses.length}</div>
          <div className="text-[10px] text-slate-400 mt-1">سجلوا دخول عبر البوابات</div>
        </div>

        <div 
          onClick={() => setActiveTab('expired')}
          className={`p-4 rounded-3xl border transition-all cursor-pointer ${
            activeTab === 'expired'
              ? 'bg-red-950/30 border-red-500 ring-1 ring-red-500/50'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 font-bold">تصاريح منتهية</span>
            <AlertTriangle className="w-4 h-4 text-red-400" />
          </div>
          <div className="text-2xl font-black text-red-400 font-mono">{expiredPasses.length}</div>
          <div className="text-[10px] text-slate-400 mt-1">انقضت مدة صلاحيتها</div>
        </div>

        <div 
          onClick={() => setActiveTab('all')}
          className={`p-4 rounded-3xl border transition-all cursor-pointer ${
            activeTab === 'all'
              ? 'bg-blue-950/30 border-blue-500 ring-1 ring-blue-500/50'
              : 'bg-slate-900 border-slate-800 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-slate-400 font-bold">إجمالي التصاريح</span>
            <ShieldCheck className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-black text-blue-400 font-mono">{passes.length}</div>
          <div className="text-[10px] text-slate-400 mt-1">كافة الحالات المسجلة</div>
        </div>
      </div>

      {/* Main Action Tabs & Search Filter */}
      <div className="p-5 rounded-3xl bg-slate-900 border border-slate-800 shadow-xl space-y-4">
        
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          {/* Tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-950 rounded-2xl border border-slate-800 text-xs w-full sm:w-auto">
            <button
              onClick={() => setActiveTab('pending')}
              className={`flex-1 sm:flex-initial px-4 py-2 rounded-xl font-bold transition-colors flex items-center justify-center gap-1.5 ${
                activeTab === 'pending'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>النداءات المعلقة ({pendingPasses.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('inside')}
              className={`flex-1 sm:flex-initial px-4 py-2 rounded-xl font-bold transition-colors flex items-center justify-center gap-1.5 ${
                activeTab === 'inside'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <UserCheck className="w-3.5 h-3.5" />
              <span>المتواجدون بالموقع ({insidePasses.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('expired')}
              className={`flex-1 sm:flex-initial px-4 py-2 rounded-xl font-bold transition-colors flex items-center justify-center gap-1.5 ${
                activeTab === 'expired'
                  ? 'bg-red-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>المنتهية ({expiredPasses.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('all')}
              className={`flex-1 sm:flex-initial px-4 py-2 rounded-xl font-bold transition-colors flex items-center justify-center gap-1.5 ${
                activeTab === 'all'
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>كافة السجلات ({passes.length})</span>
            </button>
          </div>

          {/* Search Box */}
          <div className="relative w-full sm:w-72">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="بحث بالاسم، رقم التصريح، الشركة، أو اللوحة..."
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 pl-9 text-xs text-white placeholder:text-slate-500 focus:border-amber-400 outline-none"
            />
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          </div>
        </div>

        {/* Filter Type Pills */}
        <div className="flex flex-wrap items-center gap-1.5 pt-1 text-xs">
          <span className="text-slate-400 text-[11px] ml-1">تصفية حسب الفئة:</span>
          {[
            { id: 'all', label: 'الكل' },
            { id: 'vip', label: 'شخصيات VIP' },
            { id: 'guest', label: 'ضيوف' },
            { id: 'employee', label: 'موظفين' },
            { id: 'contractor', label: 'مقاولين' },
            { id: 'materials', label: 'شحنات ومواد' }
          ].map((f) => (
            <button
              key={f.id}
              onClick={() => setFilterType(f.id)}
              className={`px-3 py-1 rounded-xl text-xs font-medium transition-colors ${
                filterType === f.id
                  ? 'bg-slate-800 text-amber-400 font-bold border border-amber-500/30'
                  : 'bg-slate-950/60 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        {/* List of Passes */}
        {filteredPasses.length === 0 ? (
          <div className="p-12 text-center text-slate-500 text-xs">
            لا توجد نداءات أو تصاريح مطابقة للشروط المحددة
          </div>
        ) : (
          <div className="space-y-3">
            {filteredPasses.map((p) => {
              const effStatus = p.effectiveStatus;
              const isPending = p.status === 'pending_security';
              const isVip = p.visitorType === 'vip';

              return (
                <div
                  key={p.id}
                  className={`p-4 rounded-2xl border transition-all ${
                    isPending
                      ? 'bg-amber-950/10 border-amber-500/40 hover:border-amber-500'
                      : effStatus === 'expired'
                      ? 'bg-red-950/10 border-red-500/30'
                      : isVip
                      ? 'bg-gradient-to-r from-amber-950/20 via-slate-900 to-slate-950 border-amber-500/30'
                      : 'bg-slate-950/80 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
                    
                    {/* Left: Info details */}
                    <div className="space-y-1.5 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono font-bold text-amber-400 text-xs">{p.passNumber}</span>
                        <h4 className="text-sm font-black text-white">{p.visitorName}</h4>
                        {isVip && (
                          <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 text-[10px] font-black border border-amber-500/40 flex items-center gap-1">
                            <Crown className="w-3 h-3" /> VIP
                          </span>
                        )}
                        <span className="text-xs text-slate-400">({p.companyName})</span>
                      </div>

                      <div className="flex flex-wrap items-center gap-3 text-xs text-slate-300">
                        <span>هوية: <span className="font-mono text-slate-200">{p.nationalIdOrPassport}</span></span>
                        <span>هاتف: {p.visitorPhone}</span>
                        {p.vehiclePlate && <span>مركبة: <span className="font-bold text-slate-200">{p.vehiclePlate}</span></span>}
                        <span>البوابة: <span className="text-amber-400">{p.destinationGate === 'both' ? 'كافة البوابات' : p.destinationGate === 'gate_1' ? 'بوابة 1' : 'بوابة 2'}</span></span>
                      </div>

                      <div className="text-xs text-slate-400 flex flex-wrap items-center gap-3">
                        <span>الغرض: <span className="text-slate-200">{p.purpose}</span></span>
                        <span>المدة: <span className="font-bold text-amber-300">{p.durationLabel}</span></span>
                        <span>الصلاحية حتى: {new Date(p.validTo).toLocaleString('ar-IQ')}</span>
                      </div>

                      {p.materialsList && (
                        <div className="text-xs text-amber-200 bg-amber-950/30 px-2.5 py-1 rounded-lg border border-amber-500/20 inline-block mt-1">
                          مواد مرافقة: {p.materialsList}
                        </div>
                      )}
                    </div>

                    {/* Right: SOC Actions */}
                    <div className="flex flex-wrap items-center gap-2 self-end lg:self-center">
                      
                      {/* If Pending Approval */}
                      {isPending ? (
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => handleApprove(p)}
                            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md flex items-center gap-1.5 transition-transform active:scale-95"
                          >
                            <Check className="w-4 h-4" />
                            موافقة وتصريح
                          </button>
                          <button
                            onClick={() => setRejectingPassId(p.id)}
                            className="px-3 py-2 rounded-xl bg-red-600/30 hover:bg-red-600 text-red-300 hover:text-white font-bold text-xs flex items-center gap-1"
                          >
                            <X className="w-4 h-4" />
                            رفض
                          </button>
                        </div>
                      ) : (
                        /* Status Badge */
                        <div className="px-3 py-1 rounded-xl text-xs font-bold">
                          {effStatus === 'inside' && <span className="text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-xl border border-emerald-500/30">داخل الموقع</span>}
                          {effStatus === 'approved' && <span className="text-blue-400 bg-blue-500/10 px-3 py-1 rounded-xl border border-blue-500/30">مصرّح</span>}
                          {effStatus === 'expired' && <span className="text-red-400 bg-red-500/10 px-3 py-1 rounded-xl border border-red-500/30">منتهي الصلاحية</span>}
                          {effStatus === 'rejected' && <span className="text-rose-400 bg-rose-500/10 px-3 py-1 rounded-xl border border-rose-500/30">مرفوض</span>}
                          {effStatus === 'completed' && <span className="text-slate-400 bg-slate-800 px-3 py-1 rounded-xl">مكتمل وغادر</span>}
                        </div>
                      )}

                      <button
                        onClick={() => onOpenPassDetails(p)}
                        className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
                        title="معاينة وطباعة"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                    </div>

                  </div>

                  {/* Inline Rejection Reason Box */}
                  {rejectingPassId === p.id && (
                    <div className="mt-3 p-3 rounded-xl bg-red-950/40 border border-red-500/40 space-y-2">
                      <label className="block text-xs font-bold text-red-300">أدخل سبب الرفض الأمني للشركة:</label>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          autoFocus
                          placeholder="مثال: عدم اكتمال التدقيق المسبق / سيارة غير مطابقة..."
                          value={rejectionReasonInput}
                          onChange={(e) => setRejectionReasonInput(e.target.value)}
                          className="flex-1 bg-slate-900 border border-red-500/40 rounded-xl px-3 py-1.5 text-xs text-white outline-none"
                        />
                        <button
                          onClick={() => handleRejectSubmit(p.id)}
                          className="px-4 py-1.5 rounded-xl bg-red-600 text-white font-bold text-xs shadow-md"
                        >
                          تأكيد الرفض
                        </button>
                        <button
                          onClick={() => setRejectingPassId(null)}
                          className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 text-xs"
                        >
                          إلغاء
                        </button>
                      </div>
                    </div>
                  )}

                </div>
              );
            })}
          </div>
        )}

      </div>

    </div>
  );
};

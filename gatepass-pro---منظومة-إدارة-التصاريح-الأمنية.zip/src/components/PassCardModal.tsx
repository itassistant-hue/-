import React, { useRef, useState } from 'react';
import { PassRequest } from '../types';
import { storageService } from '../services/storage';
import { soundService } from '../services/audio';
import { 
  Printer, 
  ShieldCheck, 
  Clock, 
  Car, 
  Building2, 
  UserCheck, 
  Phone, 
  FileText, 
  AlertTriangle, 
  QrCode, 
  Crown, 
  X, 
  CheckCircle2, 
  Ban,
  Calendar,
  Share2,
  Camera,
  Eye
} from 'lucide-react';

interface PassCardModalProps {
  pass: PassRequest | null;
  isOpen: boolean;
  onClose: () => void;
  onExtendValidity?: (passId: string) => void;
}

export const PassCardModal: React.FC<PassCardModalProps> = ({ pass, isOpen, onClose, onExtendValidity }) => {
  const printRef = useRef<HTMLDivElement>(null);
  const [isPreviewPhotoOpen, setIsPreviewPhotoOpen] = useState(false);

  if (!isOpen || !pass) return null;

  const effectiveStatus = storageService.getEffectiveStatus(pass);
  const isExpired = effectiveStatus === 'expired';
  const isVip = pass.visitorType === 'vip';

  const handlePrint = () => {
    soundService.playScanBeep();
    window.print();
  };

  const getStatusBadge = () => {
    switch (effectiveStatus) {
      case 'inside':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            متواجد داخل الموقع حالياً
          </span>
        );
      case 'approved':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-blue-500/20 text-blue-300 border border-blue-500/40">
            <CheckCircle2 className="w-3.5 h-3.5" />
            مصرّح وساري المفعول
          </span>
        );
      case 'pending_security':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40">
            <Clock className="w-3.5 h-3.5" />
            قيد تدقيق السيطرة الأمنية
          </span>
        );
      case 'expired':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-red-500/20 text-red-300 border border-red-500/40">
            <AlertTriangle className="w-3.5 h-3.5" />
            منتهي الصلاحية ⛔
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-500/20 text-rose-300 border border-rose-500/40">
            <Ban className="w-3.5 h-3.5" />
            مرفوض أمنياً
          </span>
        );
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-slate-500/20 text-slate-300 border border-slate-500/40">
            <UserCheck className="w-3.5 h-3.5" />
            اكتملت الزيارة وغادر
          </span>
        );
      default:
        return null;
    }
  };

  const getVisitorTypeLabel = (type: string) => {
    switch (type) {
      case 'vip': return 'شخصية هامة (VIP)';
      case 'employee': return 'موظف موقع';
      case 'contractor': return 'مقاول / صيانة فنية';
      case 'materials': return 'سائق شحنة / معدات';
      default: return 'ضيف / زائر عادي';
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md font-['Tajawal',sans-serif]">
      <div className="relative w-full max-w-2xl max-h-[92vh] overflow-y-auto bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl text-slate-100">
        
        {/* Action Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between px-6 py-4 bg-slate-950/90 backdrop-blur-md border-b border-slate-800">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-amber-400" />
            <h3 className="text-sm font-bold text-white">بطاقة وتصريح المرور الأمني الموحد</h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shadow-md transition-colors"
            >
              <Printer className="w-4 h-4" />
              طباعة التصريح
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Pass Container */}
        <div ref={printRef} id="printable-pass" className="p-6">
          <div className={`p-6 rounded-2xl border ${isVip ? 'bg-gradient-to-b from-amber-950/20 to-slate-950 border-amber-500/40' : 'bg-slate-950 border-slate-800'} relative overflow-hidden shadow-inner`}>
            
            {/* Top Security Banner */}
            <div className="flex items-center justify-between border-b border-slate-800/80 pb-4 mb-5">
              <div className="flex items-center gap-3">
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-bold text-lg ${isVip ? 'bg-amber-500 text-slate-950' : 'bg-blue-600 text-white'}`}>
                  {isVip ? <Crown className="w-7 h-7" /> : <ShieldCheck className="w-7 h-7" />}
                </div>
                <div>
                  <div className="text-[11px] font-bold tracking-wider text-slate-400 uppercase">منظومة أمن البوابات والمنشآت الموحدة</div>
                  <h2 className="text-base font-black text-white">{pass.companyName}</h2>
                </div>
              </div>
              <div className="text-left">
                <div className="text-xs font-mono font-bold text-amber-400">{pass.passNumber}</div>
                <div className="mt-1">{getStatusBadge()}</div>
              </div>
            </div>

            {/* Expired Alert if expired */}
            {isExpired && (
              <div className="mb-5 p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs font-bold flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 shrink-0" />
                  <span>تنبيه أمني: لقد انتهت صلاحية هذا التصريح بتاريخ ({new Date(pass.validTo).toLocaleString('ar-IQ')}). الدخول غير مصرح به!</span>
                </div>
                {onExtendValidity && (
                  <button
                    onClick={() => onExtendValidity(pass.id)}
                    className="px-3 py-1 rounded-lg bg-red-600 hover:bg-red-500 text-white font-bold text-[11px] shrink-0"
                  >
                    تمديد الصلاحية
                  </button>
                )}
              </div>
            )}

            {/* Rejection Alert if rejected */}
            {pass.status === 'rejected' && (
              <div className="mb-5 p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs font-bold flex items-center gap-2">
                <Ban className="w-5 h-5 shrink-0" />
                <span>سبب الرفض الأمني: {pass.rejectionReason || 'عدم استيفاء الشروط الأمنية'}</span>
              </div>
            )}

            {/* Main Info Grid */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-6">
              
              {/* Visitor Details (Span 2) */}
              <div className="md:col-span-2 space-y-3">
                <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-between gap-3">
                  <div className="space-y-1 flex-1">
                    <div className="text-[11px] text-slate-400 mb-1">اسم الشخص المصرح له / الزائر:</div>
                    <div className="text-base font-black text-white flex items-center gap-2">
                      {pass.visitorName}
                      {isVip && <span className="px-2 py-0.5 rounded-md bg-amber-500/20 text-amber-300 text-[10px] font-extrabold border border-amber-500/30">VIP</span>}
                    </div>
                    <div className="text-xs text-slate-300 mt-1">الصفة: {getVisitorTypeLabel(pass.visitorType)}</div>
                  </div>

                  {pass.photoUrl && (
                    <div className="relative group shrink-0 cursor-pointer" onClick={() => setIsPreviewPhotoOpen(true)}>
                      <img 
                        src={pass.photoUrl} 
                        alt={pass.visitorName} 
                        className="w-16 h-16 rounded-xl object-cover border-2 border-amber-500/60 shadow-md transition-transform group-hover:scale-105"
                      />
                      <div className="absolute inset-0 bg-black/40 rounded-xl flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <Eye className="w-4 h-4 text-white" />
                      </div>
                      <span className="absolute -bottom-1 -right-1 bg-amber-500 text-slate-950 text-[9px] font-bold px-1 rounded">
                        صورة
                      </span>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800">
                    <div className="text-[11px] text-slate-400 mb-0.5">رقم الهوية / الجواز:</div>
                    <div className="text-xs font-bold font-mono text-slate-200">{pass.nationalIdOrPassport}</div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800">
                    <div className="text-[11px] text-slate-400 mb-0.5">الجنسية ورقم الهاتف:</div>
                    <div className="text-xs font-bold text-slate-200">{pass.nationality} • {pass.visitorPhone}</div>
                  </div>
                </div>

                {/* Logistics */}
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800">
                    <div className="text-[11px] text-slate-400 mb-0.5 flex items-center gap-1">
                      <Car className="w-3.5 h-3.5 text-amber-400" />
                      بيانات المركبة (إن وجدت):
                    </div>
                    <div className="text-xs font-bold text-slate-200">
                      {pass.vehiclePlate ? `${pass.vehiclePlate} (${pass.vehicleModel || 'غير محدد'})` : 'دخول راجل (بدون مركبة)'}
                    </div>
                  </div>
                  <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800">
                    <div className="text-[11px] text-slate-400 mb-0.5 flex items-center gap-1">
                      <Building2 className="w-3.5 h-3.5 text-blue-400" />
                      البوابة المصرح بها:
                    </div>
                    <div className="text-xs font-bold text-amber-300">
                      {(() => {
                        if (!pass.destinationGate || pass.destinationGate === 'both') return 'كافة البوابات المصرح بها';
                        const foundGate = storageService.getGates().find(g => g.id === pass.destinationGate);
                        return foundGate ? foundGate.nameAr : (pass.destinationGate === 'gate_1' ? 'بوابة 1 (الشمالية)' : pass.destinationGate === 'gate_2' ? 'بوابة 2 (الجنوبية)' : pass.destinationGate);
                      })()}
                    </div>
                  </div>
                </div>

                {/* Purpose */}
                <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800">
                  <div className="text-[11px] text-slate-400 mb-0.5">الغرض من الزيارة والمهمة:</div>
                  <div className="text-xs text-slate-200 font-medium">{pass.purpose}</div>
                </div>

                {/* Materials List if any */}
                {pass.materialsList && (
                  <div className="p-3 rounded-xl bg-amber-950/20 border border-amber-500/20 text-amber-200">
                    <div className="text-[11px] font-bold text-amber-300 mb-0.5">قائمة المواد والأجهزة المرافقة للتفتيش:</div>
                    <div className="text-xs">{pass.materialsList}</div>
                  </div>
                )}

                {/* Dynamic Custom Fields if any */}
                {pass.customFieldValues && Object.keys(pass.customFieldValues).length > 0 && (
                  <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 grid grid-cols-2 gap-2">
                    {Object.entries(pass.customFieldValues).map(([k, val]) => {
                      const def = storageService.getCustomFields().find(f => f.key === k);
                      return (
                        <div key={k} className="text-xs">
                          <span className="text-slate-400 text-[11px]">{def ? def.labelAr : k}: </span>
                          <span className="font-bold text-emerald-300">{val}</span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* QR Code & Validity Box (Span 1) */}
              <div className="flex flex-col justify-between p-4 rounded-xl bg-slate-900 border border-slate-800 text-center">
                
                {/* QR Code Box */}
                <div className="flex flex-col items-center justify-center p-3 bg-white rounded-xl shadow-md mb-3">
                  <div className="w-32 h-32 flex items-center justify-center relative">
                    {/* SVG Realistic QR representation */}
                    <svg viewBox="0 0 100 100" className="w-full h-full text-slate-950">
                      <rect width="100" height="100" fill="white" />
                      {/* Corner 1 */}
                      <rect x="10" y="10" width="24" height="24" fill="black" />
                      <rect x="14" y="14" width="16" height="16" fill="white" />
                      <rect x="18" y="18" width="8" height="8" fill="black" />
                      {/* Corner 2 */}
                      <rect x="66" y="10" width="24" height="24" fill="black" />
                      <rect x="70" y="14" width="16" height="16" fill="white" />
                      <rect x="74" y="18" width="8" height="8" fill="black" />
                      {/* Corner 3 */}
                      <rect x="10" y="66" width="24" height="24" fill="black" />
                      <rect x="14" y="70" width="16" height="16" fill="white" />
                      <rect x="18" y="74" width="8" height="8" fill="black" />
                      {/* Random Matrix Dots */}
                      <rect x="42" y="12" width="6" height="6" fill="black" />
                      <rect x="52" y="18" width="6" height="6" fill="black" />
                      <rect x="42" y="28" width="6" height="6" fill="black" />
                      <rect x="12" y="44" width="6" height="6" fill="black" />
                      <rect x="24" y="48" width="6" height="6" fill="black" />
                      <rect x="44" y="44" width="12" height="12" fill="black" />
                      <rect x="64" y="44" width="6" height="6" fill="black" />
                      <rect x="76" y="48" width="8" height="8" fill="black" />
                      <rect x="40" y="64" width="8" height="8" fill="black" />
                      <rect x="56" y="68" width="6" height="6" fill="black" />
                      <rect x="70" y="74" width="14" height="6" fill="black" />
                      <rect x="48" y="80" width="12" height="8" fill="black" />
                    </svg>
                  </div>
                  <div className="text-[10px] font-mono font-bold text-slate-800 mt-1">SCAN AT GATE</div>
                </div>

                {/* Validity Card */}
                <div className="space-y-2 text-right">
                  <div className="p-2.5 rounded-lg bg-slate-950/80 border border-slate-800">
                    <div className="text-[10px] text-slate-400">صالح اعتباراً من:</div>
                    <div className="text-xs font-bold text-slate-200">{new Date(pass.validFrom).toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' })} • {new Date(pass.validFrom).toLocaleDateString('ar-IQ')}</div>
                  </div>
                  <div className={`p-2.5 rounded-lg border ${isExpired ? 'bg-red-950/30 border-red-500/40 text-red-300' : 'bg-slate-950/80 border-slate-800'}`}>
                    <div className="text-[10px] text-slate-400">ينتهي التصريح في:</div>
                    <div className="text-xs font-bold text-amber-300">{new Date(pass.validTo).toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' })} • {new Date(pass.validTo).toLocaleDateString('ar-IQ')}</div>
                    <div className="text-[10px] text-slate-400 mt-0.5">مدة التصريح: {pass.durationLabel}</div>
                  </div>
                </div>
              </div>

            </div>

            {/* Movement Logs History */}
            {pass.logs && pass.logs.length > 0 && (
              <div className="border-t border-slate-800 pt-4 mt-4">
                <h4 className="text-xs font-bold text-slate-300 mb-3 flex items-center gap-1.5">
                  <FileText className="w-4 h-4 text-amber-400" />
                  سجل حركة التصريح والتدقيق الأمني:
                </h4>
                <div className="space-y-2 max-h-36 overflow-y-auto">
                  {pass.logs.map((log) => (
                    <div key={log.id} className="flex items-center justify-between text-xs p-2 rounded-lg bg-slate-900/60 border border-slate-800/80">
                      <div className="flex items-center gap-2">
                        <span className="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
                        <span className="font-bold text-slate-200">{log.actionArabic}</span>
                        {log.notes && <span className="text-slate-400 text-[11px]">({log.notes})</span>}
                      </div>
                      <div className="text-slate-400 text-[11px]">
                        {log.operatorName} • {new Date(log.timestamp).toLocaleTimeString('ar-IQ', { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Official Security Stamp Footer */}
            <div className="border-t border-slate-800/80 pt-4 mt-5 flex items-center justify-between text-[11px] text-slate-400">
              <div>
                <div>الجهة المصدرة: إدارة أمن الموقع والسيطرة المركزية</div>
                <div>الضابط المعتمد: {pass.approvedBy || 'قيد الاعتماد'}</div>
              </div>
              <div className="text-left font-mono">
                <div>GATEPASS-SEC-VERIFIED</div>
                <div className="text-[10px] text-slate-500">{pass.id}</div>
              </div>
            </div>

          </div>
        </div>

      </div>

      {/* Lightbox Full Image Preview */}
      {isPreviewPhotoOpen && pass.photoUrl && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md animate-in fade-in">
          <div className="relative max-w-xl max-h-[85vh] bg-slate-900 border border-slate-700 rounded-3xl p-4 flex flex-col items-center">
            <div className="w-full flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
              <span className="text-xs font-bold text-slate-200">معاينة صورة الزائر / المستمسك المرفق</span>
              <button
                type="button"
                onClick={() => setIsPreviewPhotoOpen(false)}
                className="p-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <img 
              src={pass.photoUrl} 
              alt={pass.visitorName} 
              className="max-h-[65vh] w-auto max-w-full rounded-2xl object-contain border border-slate-800" 
            />
            <div className="mt-3 flex justify-end w-full">
              <button
                type="button"
                onClick={() => setIsPreviewPhotoOpen(false)}
                className="px-4 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs"
              >
                إغلاق
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

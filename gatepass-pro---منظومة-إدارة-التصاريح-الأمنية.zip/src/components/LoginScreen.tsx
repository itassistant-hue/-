import React, { useState, useEffect, useRef } from 'react';
import { User, SystemLicense, Language, CustomNomenclature } from '../types';
import { storageService } from '../services/storage';
import { soundService } from '../services/audio';
import { SecretGatewayModal } from './SecretGatewayModal';
import { 
  Lock, 
  User as UserIcon, 
  Key, 
  ShieldCheck, 
  AlertCircle, 
  LogIn, 
  Clock, 
  Globe, 
  Award,
  Palette
} from 'lucide-react';

interface LoginScreenProps {
  onLoginSuccess: (user: User) => void;
  lang?: Language;
  onLanguageChange?: (lang: Language) => void;
  onOpenSecretGateway?: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  onLoginSuccess,
  lang = 'ar',
  onLanguageChange,
  onOpenSecretGateway
}) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [license, setLicense] = useState<SystemLicense>(() => storageService.getLicense());
  const [nomenclature, setNomenclature] = useState<CustomNomenclature>(() => storageService.getNomenclature());
  const [timeStr, setTimeStr] = useState('');
  const [dateStr, setDateStr] = useState('');
  const [isSecretGatewayOpen, setIsSecretGatewayOpen] = useState(false);

  // Hidden 10-click trigger on Developer's Name
  const [devClickCount, setDevClickCount] = useState(0);
  const clickTimerRef = useRef<NodeJS.Timeout | null>(null);

  const users = storageService.getUsers();

  // Listen to live changes to license / nomenclature from Secret Gateway
  useEffect(() => {
    const unsub = storageService.subscribe((event) => {
      if (
        event === 'license_updated' || 
        event === 'nomenclature_updated' || 
        event === 'reset_complete' || 
        event === 'backup_restored'
      ) {
        setLicense(storageService.getLicense());
        setNomenclature(storageService.getNomenclature());
      }
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString(lang === 'ar' ? 'ar-IQ' : 'en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      setDateStr(now.toLocaleDateString(lang === 'ar' ? 'ar-IQ' : 'en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [lang]);

  const handleOpenSecret = () => {
    soundService.playScanBeep();
    if (onOpenSecretGateway) {
      onOpenSecretGateway();
    } else {
      setIsSecretGatewayOpen(true);
    }
  };

  // Trigger secret gateway upon exactly 10 consecutive clicks on Developer's Name
  const handleDeveloperNameClick = () => {
    const nextCount = devClickCount + 1;
    setDevClickCount(nextCount);

    // Reset counter if user stops clicking for more than 3.5 seconds
    if (clickTimerRef.current) {
      clearTimeout(clickTimerRef.current);
    }
    clickTimerRef.current = setTimeout(() => {
      setDevClickCount(0);
    }, 3500);

    if (nextCount >= 10) {
      setDevClickCount(0);
      if (clickTimerRef.current) clearTimeout(clickTimerRef.current);
      handleOpenSecret();
    }
  };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const found = users.find(
      u => u.username.toLowerCase() === username.trim().toLowerCase() && u.password === password.trim()
    );

    if (found) {
      if (!found.active) {
        setErrorMsg(lang === 'ar' ? 'هذا الحساب معطل حالياً من قبل إدارة المنظومة الأمنية' : 'This account is disabled by security admin.');
        soundService.playAccessDenied();
        return;
      }
      storageService.setCurrentUser(found);
      storageService.setSessionAuthenticated(true);
      soundService.playAccessGranted();
      onLoginSuccess(found);
    } else {
      setErrorMsg(lang === 'ar' ? 'اسم المستخدم أو كلمة المرور غير صحيحة! يرجى التحقق وإعادة المحاولة.' : 'Invalid username or password. Please verify and try again.');
      soundService.playAccessDenied();
    }
  };

  const handleToggleLang = () => {
    const nextLang: Language = lang === 'ar' ? 'en' : 'ar';
    storageService.setLanguage(nextLang);
    if (onLanguageChange) onLanguageChange(nextLang);
  };

  const displayAppName = lang === 'ar' 
    ? (nomenclature.appNameAr || license.appNameAr || 'منظومة GatePass لإدارة البوابات والتصاريح الأمنية')
    : (nomenclature.appNameEn || license.appNameEn || 'GatePass Security & Access Control Enterprise');

  const displayFacilityName = lang === 'ar'
    ? (nomenclature.facilityNameAr || license.facilityNameAr || license.facilityName)
    : (nomenclature.facilityNameEn || license.facilityNameEn || license.facilityName);

  const displaySubtitle = lang === 'ar'
    ? (nomenclature.loginCardSubtitleAr || license.loginCardSubtitleAr || 'يرجى تسجيل الدخول للوصول إلى لوحة التحكم وبوابات المنظومة')
    : (nomenclature.loginCardSubtitleEn || license.loginCardSubtitleEn || 'Authenticate credentials to access security gates & SOC');

  const loginBg = nomenclature.loginBgUrl || license.loginBgUrl || '';
  const appLogo = nomenclature.appLogoUrl || '';
  const cardBanner = nomenclature.loginHeroImageUrl || license.loginHeroImageUrl || '';

  const getLoginBgStyle = (): React.CSSProperties | undefined => {
    if (!loginBg) return undefined;
    if (loginBg.startsWith('linear-gradient') || loginBg.startsWith('radial-gradient')) {
      return { background: loginBg };
    }
    return {
      backgroundImage: `linear-gradient(rgba(2, 6, 23, 0.35), rgba(2, 6, 23, 0.60)), url("${loginBg}")`,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundRepeat: 'no-repeat',
      backgroundAttachment: 'fixed'
    };
  };

  return (
    <div 
      id="login-screen-root"
      className={`min-h-screen bg-slate-950 text-slate-100 font-['Tajawal',sans-serif] flex flex-col justify-between relative overflow-hidden selection:bg-amber-500/30 selection:text-amber-200 ${lang === 'en' ? 'ltr' : 'rtl'}`} 
      dir={lang === 'en' ? 'ltr' : 'rtl'}
      style={getLoginBgStyle()}
    >
      
      {/* Background Decorative Tech Grids & Lighting */}
      {!loginBg && (
        <>
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-amber-900/20 via-slate-950 to-slate-950 pointer-events-none" />
          <div className="absolute -top-40 -left-40 w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        </>
      )}

      {/* Top Header Strip */}
      <header className="relative z-10 w-full px-6 py-4 flex items-center justify-between border-b border-slate-900/80 bg-slate-950/75 backdrop-blur-md">
        
        {/* Clean Logo & App Name Header */}
        <div className="flex items-center gap-3 select-none">
          <div className="relative">
            {appLogo ? (
              <div className="w-10 h-10 rounded-2xl bg-slate-900 border border-amber-500/50 p-1 flex items-center justify-center shadow-lg shadow-amber-500/20 overflow-hidden">
                <img src={appLogo} alt="App Logo" className="w-full h-full object-contain" />
              </div>
            ) : (
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-amber-500/20">
                <ShieldCheck className="w-5 h-5" />
              </div>
            )}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm sm:text-base font-black text-white">
                {displayAppName}
              </h1>
              <span className="px-1.5 py-0.5 rounded-md bg-amber-500/20 text-amber-300 text-[9px] font-mono font-bold border border-amber-500/30">
                PRO V2.5
              </span>
            </div>
            <p className="text-[10px] text-slate-400">{displayFacilityName}</p>
          </div>
        </div>

        {/* Right Controls: Quick Visual Customizer, Clock & Language Switch */}
        <div className="flex items-center gap-2 sm:gap-3">
          
          {/* Quick Visual Customizer Trigger Button */}
          <button
            type="button"
            onClick={handleOpenSecret}
            title={lang === 'ar' ? 'تغيير صورة الخلفية وشعار الواجهة' : 'Customize Wallpaper & Visuals'}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 hover:text-amber-200 border border-amber-500/30 text-xs font-bold transition-all active:scale-95 shadow-sm"
          >
            <Palette className="w-3.5 h-3.5 text-amber-400" />
            <span className="hidden sm:inline">{lang === 'ar' ? 'تغيير الخلفية والصورة' : 'Customize Visuals'}</span>
          </button>

          {/* Clock */}
          <div className="hidden md:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800 text-[11px] font-mono text-slate-300">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-bold text-amber-300">{timeStr}</span>
          </div>

          {/* Language Switch */}
          <button
            onClick={handleToggleLang}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-amber-400 border border-slate-800 text-xs font-bold transition-colors"
          >
            <Globe className="w-3.5 h-3.5 text-amber-400" />
            <span>{lang === 'ar' ? 'English' : 'عربي'}</span>
          </button>
        </div>
      </header>

      {/* Center Main Login Card */}
      <main className="relative z-10 flex-1 flex items-center justify-center px-4 py-8">
        <div className="w-full max-w-md bg-slate-900/90 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden backdrop-blur-xl animate-in zoom-in-95 duration-200">
          
          {/* Card Title Banner */}
          <div className="p-6 text-center border-b border-slate-800/80 bg-slate-950/60 relative">
            
            <div className="w-14 h-14 mx-auto rounded-3xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-slate-950 font-black shadow-xl shadow-amber-500/20 mb-3 overflow-hidden">
              {cardBanner ? (
                <img src={cardBanner} alt="Card Banner" className="w-full h-full object-cover" />
              ) : (
                <Lock className="w-7 h-7" />
              )}
            </div>

            <h2 className="text-lg font-black text-white">
              {lang === 'ar' ? 'بوابة تسجيل الدخول والتحقق الأمني' : 'Security Terminal Access Control'}
            </h2>
            <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">
              {displaySubtitle}
            </p>
          </div>

          {/* Card Body */}
          <div className="p-6 space-y-4">
            
            {errorMsg && (
              <div className="p-3 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs font-bold flex items-center gap-2 animate-shake">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  {lang === 'ar' ? 'اسم المستخدم (Username):' : 'Username:'}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder={lang === 'ar' ? 'أدخل اسم المستخدم المصرح...' : 'Enter your authorized username...'}
                    className="w-full bg-slate-950 border border-slate-700 rounded-2xl px-3.5 py-3 pl-10 text-xs text-white focus:border-amber-400 outline-none transition-all"
                  />
                  <UserIcon className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  {lang === 'ar' ? 'كلمة المرور (Password):' : 'Password:'}
                </label>
                <div className="relative">
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-slate-950 border border-slate-700 rounded-2xl px-3.5 py-3 pl-10 text-xs text-white focus:border-amber-400 outline-none font-mono transition-all"
                  />
                  <Key className="w-4 h-4 text-slate-500 absolute left-3.5 top-3.5" />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/20 transition-all flex items-center justify-center gap-2 active:scale-95"
              >
                <LogIn className="w-4 h-4" />
                <span>{lang === 'ar' ? 'دخول النظام الأمني الموحد' : 'Authorize & Enter Terminal'}</span>
              </button>
            </form>

            {/* Developer Branding Footer Box: 10 Clicks on Developer Name opens the Secret Gateway */}
            <div className="pt-3 border-t border-slate-800/80 text-center space-y-1 bg-slate-950/40 p-3 rounded-2xl border border-slate-800/40 select-none">
              <div 
                onClick={handleDeveloperNameClick}
                title=""
                className="inline-flex items-center justify-center gap-1.5 text-amber-400 text-xs font-bold cursor-pointer hover:text-amber-300 active:scale-95 transition-all"
              >
                <Award className="w-3.5 h-3.5" />
                <span>{lang === 'ar' ? (license.developerNameAr || 'المهندس علي أحمد عنيد') : (license.developerNameEn || 'Eng. Ali Ahmed Aneed')}</span>
              </div>
              <p className="text-[10px] text-slate-400">{license.copyrightAr || 'برمجة وتطوير: المهندس علي أحمد عنيد • جميع الحقوق محفوظة'}</p>
              <p className="text-[9px] text-slate-500 font-sans tracking-wide">{license.copyrightEn || 'Engineered & Developed by Eng. Ali Ahmed Aneed • All Rights Reserved'}</p>
            </div>

          </div>

        </div>
      </main>

      {/* Bottom Sticky Security Bar in Login Screen */}
      <footer className="relative z-10 w-full bg-slate-950/90 border-t border-slate-900 py-2.5 px-4 text-slate-400 text-xs flex flex-col sm:flex-row items-center justify-between gap-2">
        <div 
          onClick={handleDeveloperNameClick}
          className="text-[10px] text-slate-400 hover:text-slate-300 font-mono flex items-center gap-1.5 cursor-pointer transition-colors select-none"
        >
          <ShieldCheck className="w-3.5 h-3.5 text-amber-500/80" />
          <span>SEC-ID: 7941-PRO</span>
        </div>

        <div className="text-[11px] text-slate-300 text-center select-none">
          <span 
            onClick={handleDeveloperNameClick}
            className="cursor-pointer hover:text-white transition-colors"
          >
            {license.copyrightAr || 'برمجة وتطوير: المهندس علي أحمد عنيد • جميع الحقوق محفوظة'}
          </span>
        </div>

        <div className="flex items-center gap-2 text-[11px] select-none">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
          <span className="text-slate-200 font-bold">{lang === 'ar' ? 'نظام البوابات المشفر' : 'Encrypted GatePass'}</span>
          <span className="text-slate-600">|</span>
          <span className="text-[10px] text-emerald-400">{lang === 'ar' ? 'ترخيص نشط ومصرح' : 'Active Licensed'}</span>
        </div>
      </footer>

      {/* Secret Gateway Modal */}
      <SecretGatewayModal
        isOpen={isSecretGatewayOpen}
        onClose={() => setIsSecretGatewayOpen(false)}
      />

    </div>
  );
};

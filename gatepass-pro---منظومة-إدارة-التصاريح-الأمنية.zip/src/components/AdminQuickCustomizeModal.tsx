import React, { useState, useEffect, useRef } from 'react';
import { CustomNomenclature, Language, SystemLicense, GateDefinition, CustomFieldDefinition, SystemViewDefinition } from '../types';
import { storageService, DEFAULT_NOMENCLATURE, DEFAULT_GATES, DEFAULT_CUSTOM_FIELDS, DEFAULT_SYSTEM_VIEWS } from '../services/storage';
import { soundService } from '../services/audio';
import { translations } from '../services/i18n';
import { compressImageFile } from '../services/imageUtils';
import { 
  Sliders, 
  X, 
  Save, 
  RotateCcw, 
  CheckCircle2, 
  Sparkles, 
  Building2, 
  DoorOpen, 
  Radio, 
  Activity, 
  Layers,
  LayoutGrid,
  Camera,
  UploadCloud,
  Image as ImageIcon,
  Trash2,
  Plus,
  Edit2,
  Check,
  Eye,
  EyeOff,
  Tag,
  ShieldCheck,
  FileText,
  AlertCircle,
  Upload
} from 'lucide-react';

interface AdminQuickCustomizeModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang?: Language;
  initialTab?: 'branding' | 'fields' | 'gates' | 'views' | 'kpis';
}

export const AdminQuickCustomizeModal: React.FC<AdminQuickCustomizeModalProps> = ({
  isOpen,
  onClose,
  lang = 'ar',
  initialTab = 'branding'
}) => {
  const t = translations[lang] || translations.ar;
  const [activeTab, setActiveTab] = useState<'branding' | 'fields' | 'gates' | 'views' | 'kpis'>(initialTab);
  const [nomenclature, setNomenclature] = useState<CustomNomenclature>(() => storageService.getNomenclature());
  const [license, setLicense] = useState<SystemLicense>(() => storageService.getLicense());
  const [gates, setGates] = useState<GateDefinition[]>(() => storageService.getGates());
  const [customFields, setCustomFields] = useState<CustomFieldDefinition[]>(() => storageService.getCustomFields());
  const [systemViews, setSystemViews] = useState<SystemViewDefinition[]>(() => storageService.getSystemViews());
  
  const [savedSuccess, setSavedSuccess] = useState(false);
  const logoInputRef = useRef<HTMLInputElement>(null);

  // New Gate Form state
  const [isAddingGate, setIsAddingGate] = useState(false);
  const [newGateNameAr, setNewGateNameAr] = useState('');
  const [newGateNameEn, setNewGateNameEn] = useState('');
  const [newGateLocation, setNewGateLocation] = useState('');
  const [newGateType, setNewGateType] = useState<'entry_exit' | 'entry_only' | 'exit_only' | 'cargo' | 'vip'>('entry_exit');
  const [newGateColor, setNewGateColor] = useState<string>('emerald');

  // New Field Form state
  const [isAddingField, setIsAddingField] = useState(false);
  const [newFieldLabelAr, setNewFieldLabelAr] = useState('');
  const [newFieldLabelEn, setNewFieldLabelEn] = useState('');
  const [newFieldType, setNewFieldType] = useState<'text' | 'number' | 'select' | 'textarea' | 'date'>('text');
  const [newFieldCategory, setNewFieldCategory] = useState<'visitor' | 'vehicle' | 'materials' | 'security' | 'custom'>('custom');
  const [newFieldRequired, setNewFieldRequired] = useState(false);
  const [newFieldPlaceholder, setNewFieldPlaceholder] = useState('');

  useEffect(() => {
    if (isOpen) {
      setNomenclature(storageService.getNomenclature());
      setLicense(storageService.getLicense());
      setGates(storageService.getGates());
      setCustomFields(storageService.getCustomFields());
      setSystemViews(storageService.getSystemViews());
      setActiveTab(initialTab);
      setSavedSuccess(false);
      setIsAddingGate(false);
      setIsAddingField(false);
    }
  }, [isOpen, initialTab]);

  if (!isOpen) return null;

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const processed = await compressImageFile(file, { maxWidth: 600, maxHeight: 600, quality: 0.90, format: 'image/png' });
      setNomenclature(prev => ({ ...prev, appLogoUrl: processed }));
      soundService.playSuccess();
    } catch (err) {
      console.error('Logo upload error:', err);
    } finally {
      e.target.value = '';
    }
  };

  const handleBgUpload = async (e: React.ChangeEvent<HTMLInputElement>, target: 'login' | 'system') => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const processed = await compressImageFile(file, { maxWidth: 1920, maxHeight: 1080, quality: 0.85, format: 'image/jpeg' });
      if (target === 'login') {
        setNomenclature(prev => ({ ...prev, loginBgUrl: processed }));
      } else {
        setNomenclature(prev => ({ ...prev, systemBgUrl: processed }));
      }
      soundService.playSuccess();
    } catch (err) {
      console.error('Background upload error:', err);
    } finally {
      e.target.value = '';
    }
  };

  const handleSaveAll = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    
    // 1. Save Nomenclature
    storageService.updateNomenclature(nomenclature);
    
    // 2. Sync app name and visual assets to license
    const currentLic = storageService.getLicense();
    storageService.updateLicense({
      ...currentLic,
      appNameAr: nomenclature.appNameAr,
      appNameEn: nomenclature.appNameEn,
      facilityNameAr: nomenclature.facilityNameAr,
      facilityNameEn: nomenclature.facilityNameEn,
      loginBgUrl: nomenclature.loginBgUrl || currentLic.loginBgUrl,
      loginHeroImageUrl: nomenclature.loginHeroImageUrl || currentLic.loginHeroImageUrl,
      systemBgUrl: nomenclature.systemBgUrl || currentLic.systemBgUrl,
    });

    // 3. Save Gates, Custom Fields, and Views
    storageService.saveGates(gates);
    storageService.saveCustomFields(customFields);
    storageService.saveSystemViews(systemViews);

    soundService.playSuccess();
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 1200);
  };

  // --- Gate Handlers ---
  const handleAddNewGate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGateNameAr.trim()) return;

    const newGate: GateDefinition = {
      id: 'gate_' + (gates.length + 1) + '_' + Date.now().toString().slice(-4),
      nameAr: newGateNameAr.trim(),
      nameEn: newGateNameEn.trim() || newGateNameAr.trim(),
      location: newGateLocation.trim() || 'مدخل معتمد',
      type: newGateType,
      enabled: true,
      isSystemDefault: false,
      color: newGateColor
    };

    const updated = [...gates, newGate];
    setGates(updated);
    storageService.saveGates(updated);
    
    // Also add to system views
    const newView: SystemViewDefinition = {
      id: newGate.id,
      nameAr: newGate.nameAr,
      nameEn: newGate.nameEn,
      icon: 'DoorOpen',
      enabled: true,
      isSystemDefault: false,
      gateId: newGate.id
    };
    const updatedViews = [...systemViews, newView];
    setSystemViews(updatedViews);
    storageService.saveSystemViews(updatedViews);

    setNewGateNameAr('');
    setNewGateNameEn('');
    setNewGateLocation('');
    setIsAddingGate(false);
    soundService.playSuccess();
  };

  const handleDeleteGate = (gateId: string) => {
    if (gates.length <= 1) {
      alert(lang === 'ar' ? 'يجب أن تظل بوابة واحدة على الأقل في المنظومة.' : 'At least one gate must remain active.');
      return;
    }
    if (window.confirm(lang === 'ar' ? 'هل أنت متأكد من حذف هذه البوابة نهائياً من المنظومة؟' : 'Are you sure you want to delete this gate?')) {
      const updated = gates.filter(g => g.id !== gateId);
      setGates(updated);
      storageService.saveGates(updated);
      const updatedViews = systemViews.filter(v => v.gateId !== gateId);
      setSystemViews(updatedViews);
      storageService.saveSystemViews(updatedViews);
      soundService.playSuccess();
    }
  };

  const handleToggleGate = (gateId: string) => {
    const updated = gates.map(g => g.id === gateId ? { ...g, enabled: !g.enabled } : g);
    setGates(updated);
    storageService.saveGates(updated);
  };

  const handleUpdateGateField = (gateId: string, key: keyof GateDefinition, val: any) => {
    const updated = gates.map(g => g.id === gateId ? { ...g, [key]: val } : g);
    setGates(updated);
  };

  // --- Field Handlers ---
  const handleAddNewField = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFieldLabelAr.trim()) return;

    const newField: CustomFieldDefinition = {
      id: 'f_custom_' + Date.now(),
      key: 'cf_' + Date.now().toString().slice(-6),
      labelAr: newFieldLabelAr.trim(),
      labelEn: newFieldLabelEn.trim() || newFieldLabelAr.trim(),
      type: newFieldType,
      category: newFieldCategory,
      required: newFieldRequired,
      enabled: true,
      isSystemDefault: false,
      placeholderAr: newFieldPlaceholder.trim()
    };

    const updated = [...customFields, newField];
    setCustomFields(updated);
    storageService.saveCustomFields(updated);

    setNewFieldLabelAr('');
    setNewFieldLabelEn('');
    setNewFieldPlaceholder('');
    setIsAddingField(false);
    soundService.playSuccess();
  };

  const handleDeleteField = (fieldId: string) => {
    if (window.confirm(lang === 'ar' ? 'هل تريد بالتأكيد حذف هذه الخانة من نماذج الإدخال؟' : 'Delete this input field?')) {
      const updated = customFields.filter(f => f.id !== fieldId);
      setCustomFields(updated);
      storageService.saveCustomFields(updated);
      soundService.playSuccess();
    }
  };

  const handleToggleField = (fieldId: string) => {
    const updated = customFields.map(f => f.id === fieldId ? { ...f, enabled: !f.enabled } : f);
    setCustomFields(updated);
    storageService.saveCustomFields(updated);
  };

  const handleUpdateFieldProp = (fieldId: string, key: keyof CustomFieldDefinition, val: any) => {
    const updated = customFields.map(f => f.id === fieldId ? { ...f, [key]: val } : f);
    setCustomFields(updated);
  };

  // --- View Handlers ---
  const handleToggleView = (viewId: string) => {
    const updated = systemViews.map(v => v.id === viewId ? { ...v, enabled: !v.enabled } : v);
    setSystemViews(updated);
    storageService.saveSystemViews(updated);
  };

  const handleUpdateViewName = (viewId: string, key: 'nameAr' | 'nameEn', val: string) => {
    const updated = systemViews.map(v => v.id === viewId ? { ...v, [key]: val } : v);
    setSystemViews(updated);
  };

  const handleResetToDefaults = () => {
    if (window.confirm(lang === 'ar' ? 'هل تريد استعادة كافة المسميات والبوابات والخانات الافتراضية للنظام؟' : 'Reset all labels and fields to defaults?')) {
      setNomenclature(DEFAULT_NOMENCLATURE);
      setGates(DEFAULT_GATES);
      setCustomFields(DEFAULT_CUSTOM_FIELDS);
      setSystemViews(DEFAULT_SYSTEM_VIEWS);
      storageService.updateNomenclature(DEFAULT_NOMENCLATURE);
      storageService.saveGates(DEFAULT_GATES);
      storageService.saveCustomFields(DEFAULT_CUSTOM_FIELDS);
      storageService.saveSystemViews(DEFAULT_SYSTEM_VIEWS);
      soundService.playSuccess();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/85 backdrop-blur-md font-['Tajawal',sans-serif] animate-in fade-in duration-200">
      <div className="relative w-full max-w-3xl bg-slate-900 border border-amber-500/50 rounded-3xl shadow-2xl overflow-hidden text-slate-100 flex flex-col max-h-[92vh]">
        
        {/* Top Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-950 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-amber-500 to-amber-600 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-amber-500/20">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-white">
                  {lang === 'ar' ? 'تخصيص وإدارة واجهات وبوابات وخانات المنظومة' : 'System Gates, Views & Dynamic Fields Manager'}
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-mono font-bold border border-amber-500/30">
                  ADMIN ONLY
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {lang === 'ar' ? 'إضافة وحذف وتعديل الخانات، البوابات، الواجهات والشعار بكل حرية وسهولة' : 'Add, delete, and customize form inputs, gate terminals, views, and branding'}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center border-b border-slate-800 bg-slate-950/80 px-4 sm:px-6 pt-2 gap-1 sm:gap-2 overflow-x-auto shrink-0">
          <button
            type="button"
            onClick={() => setActiveTab('branding')}
            className={`pb-2.5 px-3 text-xs font-bold transition-all border-b-2 flex items-center gap-1.5 shrink-0 ${
              activeTab === 'branding'
                ? 'border-amber-400 text-amber-300 bg-amber-500/10 rounded-t-xl'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>{lang === 'ar' ? 'اسم التطبيق والشعار' : 'Branding & Logo'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('fields')}
            className={`pb-2.5 px-3 text-xs font-bold transition-all border-b-2 flex items-center gap-1.5 shrink-0 ${
              activeTab === 'fields'
                ? 'border-amber-400 text-amber-300 bg-amber-500/10 rounded-t-xl'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Tag className="w-3.5 h-3.5 text-emerald-400" />
            <span>{lang === 'ar' ? 'إضافة وحذف الخانات' : 'Dynamic Form Fields'}</span>
            <span className="px-1.5 py-0.2 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-mono">
              {customFields.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('gates')}
            className={`pb-2.5 px-3 text-xs font-bold transition-all border-b-2 flex items-center gap-1.5 shrink-0 ${
              activeTab === 'gates'
                ? 'border-amber-400 text-amber-300 bg-amber-500/10 rounded-t-xl'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <DoorOpen className="w-3.5 h-3.5 text-blue-400" />
            <span>{lang === 'ar' ? 'إدارة وبوابات المنظومة' : 'Gates & Terminals'}</span>
            <span className="px-1.5 py-0.2 rounded-full bg-blue-500/20 text-blue-300 text-[10px] font-mono">
              {gates.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('views')}
            className={`pb-2.5 px-3 text-xs font-bold transition-all border-b-2 flex items-center gap-1.5 shrink-0 ${
              activeTab === 'views'
                ? 'border-amber-400 text-amber-300 bg-amber-500/10 rounded-t-xl'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-purple-400" />
            <span>{lang === 'ar' ? 'واجهات المنظومة' : 'System Views'}</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('kpis')}
            className={`pb-2.5 px-3 text-xs font-bold transition-all border-b-2 flex items-center gap-1.5 shrink-0 ${
              activeTab === 'kpis'
                ? 'border-amber-400 text-amber-300 bg-amber-500/10 rounded-t-xl'
                : 'border-transparent text-slate-400 hover:text-white'
            }`}
          >
            <LayoutGrid className="w-3.5 h-3.5 text-amber-400" />
            <span>{lang === 'ar' ? 'خانات الإحصائيات' : 'KPIs & Telemetry'}</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-4 overflow-y-auto max-h-[68vh] flex-1">
          {savedSuccess ? (
            <div className="py-12 text-center space-y-3">
              <div className="w-16 h-16 mx-auto rounded-3xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 animate-pulse">
                <CheckCircle2 className="w-9 h-9" />
              </div>
              <h4 className="text-lg font-black text-white">
                {lang === 'ar' ? 'تم حفظ وتطبيق كافة التعديلات بنجاح تام!' : 'All Configurations Applied Successfully!'}
              </h4>
              <p className="text-xs text-slate-400 max-w-md mx-auto">
                {lang === 'ar' ? 'تم تحديث كافة البوابات والخانات والواجهات المخصصة وانعكست فوراً على المنظومة.' : 'Custom fields, gates, and views have been updated in real-time across the platform.'}
              </p>
            </div>
          ) : (
            <form onSubmit={(e) => { e.preventDefault(); handleSaveAll(); }} className="space-y-4">
              
              {/* TAB 1: App & Facility Branding */}
              {activeTab === 'branding' && (
                <div className="space-y-4">
                  <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 flex items-center gap-2">
                    <Sparkles className="w-4 h-4 shrink-0 text-amber-400" />
                    <span>{lang === 'ar' 
                      ? 'تعديل اسم التطبيق الرسمي، اسم المنشأة والشعار الذي يظهر في رأس الصفحة وكافة بطاقات وتصاريح الزوار.' 
                      : 'Customize application title, host facility name, and application logo.'}</span>
                  </div>

                  {/* App Logo Customization */}
                  <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
                    <label className="block text-xs font-bold text-slate-200 flex items-center gap-1.5">
                      <Camera className="w-4 h-4 text-amber-400" />
                      <span>{lang === 'ar' ? 'تغيير صورة وشعار المنظومة الرسمي (App Logo):' : 'Application Logo:'}</span>
                    </label>

                    <div className="flex flex-wrap items-center gap-3">
                      {nomenclature.appLogoUrl ? (
                        <div className="flex items-center gap-3">
                          <img 
                            src={nomenclature.appLogoUrl} 
                            alt="App Logo" 
                            className="w-14 h-14 rounded-2xl object-contain bg-slate-900 border-2 border-amber-500/60 p-1 shadow-md shadow-amber-500/10"
                          />
                          <button
                            type="button"
                            onClick={() => setNomenclature({ ...nomenclature, appLogoUrl: '' })}
                            className="px-3 py-1.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs border border-red-500/30 flex items-center gap-1 font-bold"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>{lang === 'ar' ? 'استعادة الشعار الافتراضي' : 'Reset to Default'}</span>
                          </button>
                        </div>
                      ) : (
                        <div className="w-14 h-14 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-500">
                          <ImageIcon className="w-7 h-7" />
                        </div>
                      )}

                      <button
                        type="button"
                        onClick={() => logoInputRef.current?.click()}
                        className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-black flex items-center gap-2 shadow-lg shadow-amber-500/20"
                      >
                        <UploadCloud className="w-4 h-4" />
                        <span>{lang === 'ar' ? 'رفع صورة شعار من جهازك' : 'Upload Logo File'}</span>
                      </button>

                      <input
                        ref={logoInputRef}
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handleLogoUpload}
                      />

                      <div className="flex-1 min-w-[220px]">
                        <input
                          type="url"
                          placeholder={lang === 'ar' ? 'أو ضع رابط مباشر لشعار المنظومة (URL)...' : 'Or paste direct image URL...'}
                          value={nomenclature.appLogoUrl || ''}
                          onChange={(e) => setNomenclature({ ...nomenclature, appLogoUrl: e.target.value })}
                          className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-amber-400"
                        />
                      </div>
                    </div>
                  </div>

                  {/* App Name Arabic & English */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
                      <label className="block text-xs font-bold text-slate-300">
                        {lang === 'ar' ? 'اسم المنظومة (باللغة العربية):' : 'App Title (Arabic):'}
                      </label>
                      <input
                        type="text"
                        value={nomenclature.appNameAr || ''}
                        onChange={(e) => setNomenclature({ ...nomenclature, appNameAr: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                      />
                    </div>

                    <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
                      <label className="block text-xs font-bold text-slate-300">
                        {lang === 'ar' ? 'اسم المنظومة (باللغة الإنجليزية):' : 'App Title (English):'}
                      </label>
                      <input
                        type="text"
                        value={nomenclature.appNameEn || ''}
                        onChange={(e) => setNomenclature({ ...nomenclature, appNameEn: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none font-mono"
                      />
                    </div>
                  </div>

                  {/* Facility Name Arabic & English */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
                      <label className="block text-xs font-bold text-slate-300">
                        {lang === 'ar' ? 'اسم المنشأة / المجمع (بالعربية):' : 'Facility Name (Arabic):'}
                      </label>
                      <input
                        type="text"
                        value={nomenclature.facilityNameAr || ''}
                        onChange={(e) => setNomenclature({ ...nomenclature, facilityNameAr: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                      />
                    </div>

                    <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
                      <label className="block text-xs font-bold text-slate-300">
                        {lang === 'ar' ? 'اسم المنشأة / المجمع (بالإنجليزية):' : 'Facility Name (English):'}
                      </label>
                      <input
                        type="text"
                        value={nomenclature.facilityNameEn || ''}
                        onChange={(e) => setNomenclature({ ...nomenclature, facilityNameEn: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none font-mono"
                      />
                    </div>
                  </div>

                  {/* Login & System Backgrounds in Admin Quick Customize */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="block text-xs font-bold text-amber-300">
                          {lang === 'ar' ? 'صورة خلفية شاشة تسجيل الدخول:' : 'Login Screen Wallpaper:'}
                        </label>
                        <label className="text-[10px] text-amber-400 hover:text-amber-300 cursor-pointer flex items-center gap-1 font-bold">
                          <Upload className="w-3 h-3" />
                          <span>رفع صورة</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleBgUpload(e, 'login')}
                            className="hidden"
                          />
                        </label>
                      </div>
                      <input
                        type="text"
                        value={nomenclature.loginBgUrl || ''}
                        onChange={(e) => setNomenclature({ ...nomenclature, loginBgUrl: e.target.value })}
                        placeholder="https://... أو رابط الصورة"
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none font-mono"
                      />
                    </div>

                    <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-2">
                      <div className="flex items-center justify-between">
                        <label className="block text-xs font-bold text-blue-300">
                          {lang === 'ar' ? 'صورة خلفية النظام واللوحات:' : 'System Dashboard Wallpaper:'}
                        </label>
                        <label className="text-[10px] text-blue-400 hover:text-blue-300 cursor-pointer flex items-center gap-1 font-bold">
                          <Upload className="w-3 h-3" />
                          <span>رفع صورة</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) => handleBgUpload(e, 'system')}
                            className="hidden"
                          />
                        </label>
                      </div>
                      <input
                        type="text"
                        value={nomenclature.systemBgUrl || ''}
                        onChange={(e) => setNomenclature({ ...nomenclature, systemBgUrl: e.target.value })}
                        placeholder="https://... أو رابط الصورة"
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-blue-400 outline-none font-mono"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: Dynamic Form Fields (إضافة وحذف وتعديل الخانات) */}
              {activeTab === 'fields' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/20">
                    <div>
                      <h4 className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                        <Tag className="w-4 h-4" />
                        <span>{lang === 'ar' ? 'التحكم بخانات وحقول نماذج التصاريح' : 'Manage Pass Form Input Fields'}</span>
                      </h4>
                      <p className="text-[11px] text-slate-300 mt-0.5">
                        {lang === 'ar' ? 'يمكنك إضافة خانات جديدة مخصصة، حذف أي خانة مضافة، أو تعطيل/تفعيل الخانات حسب احتياج المنشأة.' : 'Add custom input fields, delete custom fields, or toggle field visibility.'}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsAddingField(!isAddingField)}
                      className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1 shadow-md shadow-emerald-950/40 shrink-0"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>{isAddingField ? (lang === 'ar' ? 'إلغاء' : 'Cancel') : (lang === 'ar' ? 'إضافة خانة جديدة' : 'Add New Field')}</span>
                    </button>
                  </div>

                  {/* Add New Field Box */}
                  {isAddingField && (
                    <div className="p-4 rounded-2xl bg-slate-950 border-2 border-emerald-500/50 space-y-3 animate-in fade-in">
                      <div className="text-xs font-black text-emerald-400 flex items-center gap-1.5">
                        <Plus className="w-4 h-4" />
                        <span>{lang === 'ar' ? 'بيانات الخانة الجديدة المراد إضافتها:' : 'New Custom Field Details:'}</span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[11px] text-slate-300 mb-1">{lang === 'ar' ? 'اسم الخانة بالعربية: *' : 'Field Label (Arabic): *'}</label>
                          <input
                            type="text"
                            required
                            placeholder={lang === 'ar' ? 'مثال: رقم بطاقة السلامة المهنية، القسم المستهدف...' : 'e.g. Target Department'}
                            value={newFieldLabelAr}
                            onChange={(e) => setNewFieldLabelAr(e.target.value)}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-emerald-400 outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] text-slate-300 mb-1">{lang === 'ar' ? 'اسم الخانة بالإنجليزية:' : 'Field Label (English):'}</label>
                          <input
                            type="text"
                            placeholder="e.g. Target Department / HSE Badge"
                            value={newFieldLabelEn}
                            onChange={(e) => setNewFieldLabelEn(e.target.value)}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-emerald-400 outline-none font-mono"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="block text-[11px] text-slate-300 mb-1">{lang === 'ar' ? 'نوع الإدخال:' : 'Input Type:'}</label>
                          <select
                            value={newFieldType}
                            onChange={(e) => setNewFieldType(e.target.value as any)}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-emerald-400 outline-none"
                          >
                            <option value="text">{lang === 'ar' ? 'نص عادي (Text)' : 'Text'}</option>
                            <option value="number">{lang === 'ar' ? 'رقم (Number)' : 'Number'}</option>
                            <option value="textarea">{lang === 'ar' ? 'مربع نص كبير (Textarea)' : 'Textarea'}</option>
                            <option value="date">{lang === 'ar' ? 'تاريخ (Date)' : 'Date'}</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-[11px] text-slate-300 mb-1">{lang === 'ar' ? 'تصنيف الخانة:' : 'Category:'}</label>
                          <select
                            value={newFieldCategory}
                            onChange={(e) => setNewFieldCategory(e.target.value as any)}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-emerald-400 outline-none"
                          >
                            <option value="custom">{lang === 'ar' ? 'خانة إضافية مخصصة' : 'Custom Field'}</option>
                            <option value="visitor">{lang === 'ar' ? 'بيانات الزائر / الشخص' : 'Visitor Info'}</option>
                            <option value="vehicle">{lang === 'ar' ? 'بيانات المركبة واللوجستيات' : 'Vehicle Info'}</option>
                            <option value="materials">{lang === 'ar' ? 'المواد والمعدات' : 'Materials'}</option>
                            <option value="security">{lang === 'ar' ? 'تدقيق أمني خاص' : 'Security Check'}</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-[11px] text-slate-300 mb-1">{lang === 'ar' ? 'نص توضيحي (Placeholder):' : 'Placeholder text:'}</label>
                          <input
                            type="text"
                            placeholder={lang === 'ar' ? 'مثال: اكتب هنا...' : 'Placeholder...'}
                            value={newFieldPlaceholder}
                            onChange={(e) => setNewFieldPlaceholder(e.target.value)}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-emerald-400 outline-none"
                          />
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t border-slate-800">
                        <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-300">
                          <input
                            type="checkbox"
                            checked={newFieldRequired}
                            onChange={(e) => setNewFieldRequired(e.target.checked)}
                            className="rounded border-slate-700 text-emerald-500 focus:ring-emerald-400 bg-slate-900"
                          />
                          <span>{lang === 'ar' ? 'خانة إجبارية في نموذج التصريح' : 'Required Field'}</span>
                        </label>

                        <button
                          type="button"
                          onClick={handleAddNewField}
                          className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-black flex items-center gap-1.5 shadow-lg shadow-emerald-500/20"
                        >
                          <Check className="w-4 h-4" />
                          <span>{lang === 'ar' ? 'تأكيد إضافة الخانة' : 'Confirm Add Field'}</span>
                        </button>
                      </div>
                    </div>
                  )}

                  {/* List of current fields */}
                  <div className="space-y-2.5">
                    {customFields.map((field) => (
                      <div 
                        key={field.id}
                        className={`p-3 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                          field.enabled 
                            ? 'bg-slate-950 border-slate-800 hover:border-slate-700' 
                            : 'bg-slate-950/40 border-slate-800/40 opacity-60'
                        }`}
                      >
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <button
                            type="button"
                            onClick={() => handleToggleField(field.id)}
                            className={`w-7 h-7 rounded-xl flex items-center justify-center transition-colors shrink-0 ${
                              field.enabled 
                                ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40' 
                                : 'bg-slate-800 text-slate-500 border border-slate-700'
                            }`}
                            title={field.enabled ? 'مفعلة (انقر للتعطيل)' : 'معطلة (انقر للتفعيل)'}
                          >
                            {field.enabled ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                          </button>

                          <div className="flex-1 min-w-0 grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <div>
                              <input
                                type="text"
                                value={field.labelAr}
                                onChange={(e) => handleUpdateFieldProp(field.id, 'labelAr', e.target.value)}
                                className="w-full bg-slate-900 border border-slate-800 focus:border-amber-400 rounded-lg px-2.5 py-1 text-xs text-white font-bold outline-none"
                                title="تعديل اسم الخانة بالعربية"
                              />
                            </div>
                            <div>
                              <input
                                type="text"
                                value={field.labelEn || ''}
                                onChange={(e) => handleUpdateFieldProp(field.id, 'labelEn', e.target.value)}
                                className="w-full bg-slate-900 border border-slate-800 focus:border-amber-400 rounded-lg px-2.5 py-1 text-xs text-slate-300 font-mono outline-none"
                                title="Edit Field Label English"
                              />
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                          <span className="px-2 py-0.5 rounded-lg bg-slate-900 text-slate-400 text-[10px] border border-slate-800">
                            {field.type}
                          </span>

                          {field.required && (
                            <span className="px-2 py-0.5 rounded-lg bg-amber-500/10 text-amber-300 text-[10px] border border-amber-500/20 font-bold">
                              إلزامي
                            </span>
                          )}

                          {field.isSystemDefault ? (
                            <span className="px-2 py-0.5 rounded-lg bg-blue-500/10 text-blue-300 text-[10px] border border-blue-500/20">
                              نظام
                            </span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleDeleteField(field.id)}
                              className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs border border-red-500/30 transition-colors"
                              title={lang === 'ar' ? 'حذف الخانة نهائياً' : 'Delete Field'}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 3: Gates & Terminals Management (إدارة وإضافة وحذف البوابات) */}
              {activeTab === 'gates' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3.5 rounded-2xl bg-blue-500/10 border border-blue-500/20">
                    <div>
                      <h4 className="text-xs font-bold text-blue-300 flex items-center gap-1.5">
                        <DoorOpen className="w-4 h-4" />
                        <span>{lang === 'ar' ? 'إدارة وبوابات المنظومة وكبائن الحرس' : 'System Gates & Terminal Guard Cabins'}</span>
                      </h4>
                      <p className="text-[11px] text-slate-300 mt-0.5">
                        {lang === 'ar' ? 'يمكنك إضافة بوابات جديدة (مثل بوابة 3، بوابة VIP، بوابة الشحن)، تعديل الأسماء أو حذف البوابات.' : 'Add new gates (e.g. Gate 3, VIP Gate), rename, or delete gates.'}
                      </p>
                    </div>
                    <button
                      type="button"
                      onClick={() => setIsAddingGate(!isAddingGate)}
                      className="px-3 py-1.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold flex items-center gap-1 shadow-md shadow-blue-950/40 shrink-0"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>{isAddingGate ? (lang === 'ar' ? 'إلغاء' : 'Cancel') : (lang === 'ar' ? 'إضافة بوابة جديدة' : 'Add New Gate')}</span>
                    </button>
                  </div>

                  {/* Add New Gate Box */}
                  {isAddingGate && (
                    <div className="p-4 rounded-2xl bg-slate-950 border-2 border-blue-500/50 space-y-3 animate-in fade-in">
                      <div className="text-xs font-black text-blue-400 flex items-center gap-1.5">
                        <Plus className="w-4 h-4" />
                        <span>{lang === 'ar' ? 'بيانات البوابة الجديدة المراد إضافتها:' : 'New Gate Terminal Details:'}</span>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[11px] text-slate-300 mb-1">{lang === 'ar' ? 'اسم البوابة بالعربية: *' : 'Gate Name (Arabic): *'}</label>
                          <input
                            type="text"
                            required
                            placeholder={lang === 'ar' ? 'مثال: كابينة حرس بوابة 3 (الشرقية والخدمات)' : 'Gate 3'}
                            value={newGateNameAr}
                            onChange={(e) => setNewGateNameAr(e.target.value)}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-blue-400 outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] text-slate-300 mb-1">{lang === 'ar' ? 'اسم البوابة بالإنجليزية:' : 'Gate Name (English):'}</label>
                          <input
                            type="text"
                            placeholder="Gate 3 Terminal (East Sector)"
                            value={newGateNameEn}
                            onChange={(e) => setNewGateNameEn(e.target.value)}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-blue-400 outline-none font-mono"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="block text-[11px] text-slate-300 mb-1">{lang === 'ar' ? 'موقع البوابة:' : 'Gate Location:'}</label>
                          <input
                            type="text"
                            placeholder={lang === 'ar' ? 'مثال: المدخل الشرقي والورش' : 'East Sector'}
                            value={newGateLocation}
                            onChange={(e) => setNewGateLocation(e.target.value)}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-blue-400 outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] text-slate-300 mb-1">{lang === 'ar' ? 'نوع حركة البوابة:' : 'Gate Type:'}</label>
                          <select
                            value={newGateType}
                            onChange={(e) => setNewGateType(e.target.value as any)}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-blue-400 outline-none"
                          >
                            <option value="entry_exit">{lang === 'ar' ? 'دخول وخروج عام' : 'Entry & Exit'}</option>
                            <option value="cargo">{lang === 'ar' ? 'شحن ولوجستيات ومواد' : 'Cargo & Materials'}</option>
                            <option value="vip">{lang === 'ar' ? 'شخصيات هامة VIP ووفود' : 'VIP & Delegations'}</option>
                            <option value="entry_only">{lang === 'ar' ? 'دخول فقط' : 'Entry Only'}</option>
                            <option value="exit_only">{lang === 'ar' ? 'خروج فقط' : 'Exit Only'}</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-[11px] text-slate-300 mb-1">{lang === 'ar' ? 'لون التمييز:' : 'Accent Color:'}</label>
                          <select
                            value={newGateColor}
                            onChange={(e) => setNewGateColor(e.target.value)}
                            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-blue-400 outline-none"
                          >
                            <option value="blue">{lang === 'ar' ? 'أزرق (Blue)' : 'Blue'}</option>
                            <option value="indigo">{lang === 'ar' ? 'نيلي (Indigo)' : 'Indigo'}</option>
                            <option value="emerald">{lang === 'ar' ? 'زمردي (Emerald)' : 'Emerald'}</option>
                            <option value="purple">{lang === 'ar' ? 'بنفسجي (Purple)' : 'Purple'}</option>
                            <option value="amber">{lang === 'ar' ? 'كهرماني (Amber)' : 'Amber'}</option>
                            <option value="rose">{lang === 'ar' ? 'وردي (Rose)' : 'Rose'}</option>
                          </select>
                        </div>
                      </div>

                      <div className="flex justify-end pt-2 border-t border-slate-800">
                        <button
                          type="button"
                          onClick={handleAddNewGate}
                          className="px-4 py-2 rounded-xl bg-blue-500 hover:bg-blue-400 text-slate-950 text-xs font-black flex items-center gap-1.5 shadow-lg shadow-blue-500/20"
                        >
                          <Check className="w-4 h-4" />
                          <span>{lang === 'ar' ? 'تأكيد إضافة البوابة' : 'Confirm Add Gate'}</span>
                        </button>
                      </div>
                    </div>
                  )}

                  {/* List of current gates */}
                  <div className="space-y-3">
                    {gates.map((gate) => (
                      <div 
                        key={gate.id}
                        className={`p-3.5 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                          gate.enabled 
                            ? 'bg-slate-950 border-slate-800 hover:border-slate-700' 
                            : 'bg-slate-950/40 border-slate-800/40 opacity-60'
                        }`}
                      >
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <button
                            type="button"
                            onClick={() => handleToggleGate(gate.id)}
                            className={`w-8 h-8 rounded-xl flex items-center justify-center transition-colors shrink-0 ${
                              gate.enabled 
                                ? 'bg-blue-500/20 text-blue-400 border border-blue-500/40' 
                                : 'bg-slate-800 text-slate-500 border border-slate-700'
                            }`}
                            title={gate.enabled ? 'مفعلة (انقر للتعطيل)' : 'معطلة (انقر للتفعيل)'}
                          >
                            <DoorOpen className="w-4 h-4" />
                          </button>

                          <div className="flex-1 min-w-0 grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <div>
                              <input
                                type="text"
                                value={gate.nameAr}
                                onChange={(e) => handleUpdateGateField(gate.id, 'nameAr', e.target.value)}
                                className="w-full bg-slate-900 border border-slate-800 focus:border-amber-400 rounded-lg px-2.5 py-1 text-xs text-white font-bold outline-none"
                                title="تعديل اسم البوابة بالعربية"
                              />
                            </div>
                            <div>
                              <input
                                type="text"
                                value={gate.nameEn || ''}
                                onChange={(e) => handleUpdateGateField(gate.id, 'nameEn', e.target.value)}
                                className="w-full bg-slate-900 border border-slate-800 focus:border-amber-400 rounded-lg px-2.5 py-1 text-xs text-slate-300 font-mono outline-none"
                                title="Edit Gate Name English"
                              />
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                          <span className="px-2 py-0.5 rounded-lg bg-slate-900 text-slate-400 text-[10px] border border-slate-800 font-mono">
                            {gate.id}
                          </span>

                          <span className="px-2 py-0.5 rounded-lg bg-blue-500/10 text-blue-300 text-[10px] border border-blue-500/20 font-bold">
                            {gate.type || 'entry_exit'}
                          </span>

                          {gate.isSystemDefault ? (
                            <span className="px-2 py-0.5 rounded-lg bg-slate-800 text-slate-400 text-[10px]">
                              افتراضي
                            </span>
                          ) : (
                            <button
                              type="button"
                              onClick={() => handleDeleteGate(gate.id)}
                              className="p-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-red-400 text-xs border border-red-500/30 transition-colors"
                              title={lang === 'ar' ? 'حذف البوابة نهائياً' : 'Delete Gate'}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 4: System Views & Tabs (واجهات المنظومة) */}
              {activeTab === 'views' && (
                <div className="space-y-4">
                  <div className="p-3.5 rounded-2xl bg-purple-500/10 border border-purple-500/20 text-xs text-purple-300 flex items-center gap-2">
                    <Layers className="w-4 h-4 shrink-0 text-purple-400" />
                    <span>{lang === 'ar' 
                      ? 'تعديل وتخصيص أسماء واجهات المنظومة الرئيسية (SOC، Admin، البوابات، بوابة الشركات).' 
                      : 'Customize interface names and navigation tabs.'}</span>
                  </div>

                  <div className="space-y-3">
                    {systemViews.map((view) => (
                      <div 
                        key={view.id}
                        className={`p-3.5 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                          view.enabled 
                            ? 'bg-slate-950 border-slate-800 hover:border-slate-700' 
                            : 'bg-slate-950/40 border-slate-800/40 opacity-60'
                        }`}
                      >
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <button
                            type="button"
                            onClick={() => handleToggleView(view.id)}
                            className={`w-8 h-8 rounded-xl flex items-center justify-center transition-colors shrink-0 ${
                              view.enabled 
                                ? 'bg-purple-500/20 text-purple-400 border border-purple-500/40' 
                                : 'bg-slate-800 text-slate-500 border border-slate-700'
                            }`}
                            title={view.enabled ? 'واجهة مفعلة' : 'واجهة معطلة'}
                          >
                            <Layers className="w-4 h-4" />
                          </button>

                          <div className="flex-1 min-w-0 grid grid-cols-1 sm:grid-cols-2 gap-2">
                            <div>
                              <input
                                type="text"
                                value={view.nameAr}
                                onChange={(e) => handleUpdateViewName(view.id, 'nameAr', e.target.value)}
                                className="w-full bg-slate-900 border border-slate-800 focus:border-amber-400 rounded-lg px-2.5 py-1 text-xs text-white font-bold outline-none"
                                title="تعديل اسم الواجهة بالعربية"
                              />
                            </div>
                            <div>
                              <input
                                type="text"
                                value={view.nameEn || ''}
                                onChange={(e) => handleUpdateViewName(view.id, 'nameEn', e.target.value)}
                                className="w-full bg-slate-900 border border-slate-800 focus:border-amber-400 rounded-lg px-2.5 py-1 text-xs text-slate-300 font-mono outline-none"
                                title="Edit View Name English"
                              />
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                          <span className="px-2 py-0.5 rounded-lg bg-slate-900 text-slate-400 text-[10px] border border-slate-800 font-mono">
                            {view.id}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 5: KPIs & Telemetry */}
              {activeTab === 'kpis' && (
                <div className="space-y-4">
                  <div className="p-3.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-300 flex items-center gap-2">
                    <LayoutGrid className="w-4 h-4 shrink-0 text-amber-400" />
                    <span>{lang === 'ar' 
                      ? 'تخصيص تسميات خانات الإحصائيات وبطاقات المتواجدين في الموقع المعروضة في شريط المنظومة.' 
                      : 'Customize telemetry KPI card labels and dashboard metric counters.'}</span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
                      <label className="block text-xs font-bold text-slate-300">
                        {lang === 'ar' ? 'خانة (المتواجدين داخل الموقع):' : 'Active On-Site Label:'}
                      </label>
                      <input
                        type="text"
                        value={nomenclature.kpiOnSiteAr || ''}
                        onChange={(e) => setNomenclature({ ...nomenclature, kpiOnSiteAr: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                        placeholder="المتواجدين حالياً"
                      />
                    </div>

                    <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
                      <label className="block text-xs font-bold text-slate-300">
                        {lang === 'ar' ? 'خانة (بانتظار موافقة السيطرة):' : 'Pending Approval Label:'}
                      </label>
                      <input
                        type="text"
                        value={nomenclature.kpiPendingAr || ''}
                        onChange={(e) => setNomenclature({ ...nomenclature, kpiPendingAr: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                        placeholder="بانتظار السيطرة"
                      />
                    </div>

                    <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
                      <label className="block text-xs font-bold text-slate-300">
                        {lang === 'ar' ? 'خانة (إجمالي التصاريح اليومية):' : 'Total Passes Label:'}
                      </label>
                      <input
                        type="text"
                        value={nomenclature.kpiTotalPassesAr || ''}
                        onChange={(e) => setNomenclature({ ...nomenclature, kpiTotalPassesAr: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                        placeholder="إجمالي التصاريح"
                      />
                    </div>

                    <div className="p-3 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
                      <label className="block text-xs font-bold text-slate-300">
                        {lang === 'ar' ? 'خانة (التصاريح المنتهية الصلاحية):' : 'Expired Passes Label:'}
                      </label>
                      <input
                        type="text"
                        value={nomenclature.kpiExpiredAr || ''}
                        onChange={(e) => setNomenclature({ ...nomenclature, kpiExpiredAr: e.target.value })}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none"
                        placeholder="منتهية الصلاحية"
                      />
                    </div>
                  </div>

                  {/* Max site capacity */}
                  <div className="p-3.5 rounded-2xl bg-slate-950 border border-slate-800 space-y-1.5">
                    <label className="block text-xs font-bold text-slate-300">
                      {lang === 'ar' ? 'السعة الاستيعابية القصوى للمنشأة (لإطلاق التنبيهات الذكية):' : 'Maximum Site Headcount Capacity:'}
                    </label>
                    <input
                      type="number"
                      value={nomenclature.maxSiteCapacity || 500}
                      onChange={(e) => setNomenclature({ ...nomenclature, maxSiteCapacity: parseInt(e.target.value) || 500 })}
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-amber-400 outline-none font-mono"
                    />
                  </div>
                </div>
              )}

              {/* Bottom Actions */}
              <div className="flex flex-wrap items-center justify-between pt-4 border-t border-slate-800 gap-3">
                <button
                  type="button"
                  onClick={handleResetToDefaults}
                  className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-bold flex items-center gap-1.5 transition-colors border border-slate-700"
                >
                  <RotateCcw className="w-3.5 h-3.5 text-amber-400" />
                  <span>{lang === 'ar' ? 'استعادة الافتراضيات' : 'Reset Defaults'}</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={onClose}
                    className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-colors"
                  >
                    {lang === 'ar' ? 'إلغاء' : 'Cancel'}
                  </button>

                  <button
                    type="button"
                    onClick={() => handleSaveAll()}
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs font-black flex items-center gap-2 shadow-lg shadow-amber-500/20 transition-all"
                  >
                    <Save className="w-4 h-4" />
                    <span>{lang === 'ar' ? 'حفظ وتطبيق التغييرات' : 'Save & Apply All'}</span>
                  </button>
                </div>
              </div>

            </form>
          )}
        </div>

      </div>
    </div>
  );
};

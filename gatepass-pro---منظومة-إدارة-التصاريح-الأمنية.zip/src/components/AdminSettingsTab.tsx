import React, { useState, useEffect } from 'react';
import { CustomNomenclature, AutoBackupSettings, Language, User } from '../types';
import { storageService, DEFAULT_NOMENCLATURE, DEFAULT_AUTO_BACKUP } from '../services/storage';
import { soundService } from '../services/audio';
import { translations } from '../services/i18n';
import { 
  Sliders, 
  Download, 
  Upload, 
  Trash2, 
  RotateCcw, 
  ShieldAlert, 
  CheckCircle2, 
  AlertCircle, 
  Save, 
  Server, 
  Clock, 
  FileJson,
  FolderArchive,
  Edit3,
  Wifi,
  Laptop,
  Network,
  Copy,
  RefreshCw,
  Check,
  ExternalLink,
  ShieldCheck
} from 'lucide-react';

interface AdminSettingsTabProps {
  currentUser: User;
  lang?: Language;
  onDataReset?: () => void;
}

export const AdminSettingsTab: React.FC<AdminSettingsTabProps> = ({
  currentUser,
  lang = 'ar',
  onDataReset
}) => {
  const t = translations[lang] || translations.ar;
  
  // States
  const [nomenclature, setNomenclature] = useState<CustomNomenclature>(() => storageService.getNomenclature());
  const [backupSettings, setBackupSettings] = useState<AutoBackupSettings>(() => storageService.getAutoBackupSettings());
  const [saveSuccessMsg, setSaveSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [serverInfo, setServerInfo] = useState<any>(null);
  const [isCopied, setIsCopied] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  useEffect(() => {
    const fetchInfo = async () => {
      const info = await storageService.getServerInfo();
      if (info) {
        setServerInfo(info);
      }
    };
    fetchInfo();
    const timer = setInterval(fetchInfo, 5000);
    return () => clearInterval(timer);
  }, []);

  const handleCopyUrl = (url: string) => {
    navigator.clipboard.writeText(url);
    setIsCopied(true);
    soundService.playSuccess();
    setTimeout(() => setIsCopied(false), 2500);
  };

  const handleForceSync = async () => {
    setIsSyncing(true);
    storageService.scheduleServerPush(true);
    await storageService.initServerSync();
    soundService.playSuccess();
    setSaveSuccessMsg(lang === 'ar' ? 'تمت المزامنة القسرية مع السيرفر المركزي وحفظ البيانات بنجاح!' : 'Forced server synchronization completed successfully!');
    setTimeout(() => {
      setIsSyncing(false);
      setSaveSuccessMsg('');
    }, 2000);
  };

  // Confirmation Modals
  const [showClearPassesModal, setShowClearPassesModal] = useState(false);
  const [showFactoryResetModal, setShowFactoryResetModal] = useState(false);
  const [confirmText, setConfirmText] = useState('');

  // Handle Save Nomenclature
  const handleSaveNomenclature = (e: React.FormEvent) => {
    e.preventDefault();
    storageService.updateNomenclature(nomenclature);
    
    // Also sync to license
    const license = storageService.getLicense();
    license.appNameAr = nomenclature.appNameAr;
    license.appNameEn = nomenclature.appNameEn;
    license.facilityNameAr = nomenclature.facilityNameAr;
    license.facilityNameEn = nomenclature.facilityNameEn;
    if (nomenclature.loginBgUrl) license.loginBgUrl = nomenclature.loginBgUrl;
    if (nomenclature.loginHeroImageUrl) license.loginHeroImageUrl = nomenclature.loginHeroImageUrl;
    if (nomenclature.systemBgUrl) license.systemBgUrl = nomenclature.systemBgUrl;
    storageService.updateLicense(license);

    soundService.playSuccess();
    setSaveSuccessMsg(lang === 'ar' ? 'تم حفظ وتحديث التسميات بنجاح في كافة واجهات المنظومة!' : 'Nomenclature updated and applied successfully!');
    setTimeout(() => setSaveSuccessMsg(''), 4000);
  };

  // Handle Save Backup Settings
  const handleSaveBackupSettings = (e: React.FormEvent) => {
    e.preventDefault();
    storageService.updateAutoBackupSettings(backupSettings);
    soundService.playSuccess();
    setSaveSuccessMsg(lang === 'ar' ? 'تم حفظ إعدادات النسخ الاحتياطي بنجاح!' : 'Backup configuration saved successfully!');
    setTimeout(() => setSaveSuccessMsg(''), 4000);
  };

  // Handle Manual Export Backup
  const handleExportBackupNow = () => {
    const jsonStr = storageService.exportBackupJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    a.href = url;
    a.download = `GatePass_Full_Backup_${timestamp}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    // Update last backup time
    const updated = { ...backupSettings, lastBackupTime: new Date().toISOString() };
    setBackupSettings(updated);
    storageService.updateAutoBackupSettings(updated);
    soundService.playSuccess();
    setSaveSuccessMsg(lang === 'ar' ? 'تم تنزيل النسخة الاحتياطية بنجاح إلى جهازك/السيرفر!' : 'Backup JSON file exported and downloaded successfully!');
    setTimeout(() => setSaveSuccessMsg(''), 4000);
  };

  // Handle Restore Backup from File
  const handleRestoreFromFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const result = storageService.importBackupJSON(content);
        if (result.success) {
          soundService.playSuccess();
          setSaveSuccessMsg(lang === 'ar' ? 'تمت استعادة كافة البيانات والمنظومة بنجاح!' : 'System restored from backup successfully!');
          if (onDataReset) onDataReset();
          setTimeout(() => {
            window.location.reload();
          }, 1500);
        } else {
          setErrorMsg(result.message);
          soundService.playAccessDenied();
        }
      } catch (err: any) {
        setErrorMsg(err.message || 'خطأ في معالجة الملف');
      }
    };
    reader.readAsText(file);
  };

  // Handle Clear Passes
  const handleConfirmClearPasses = () => {
    if (confirmText.trim() !== '7941631' && confirmText.trim().toLowerCase() !== 'clear') {
      setErrorMsg(lang === 'ar' ? 'الرمز التأكيدي غير صحيح! أدخل 7941631 للتأكيد.' : 'Invalid confirmation code! Enter 7941631.');
      return;
    }
    storageService.clearAllPasses();
    soundService.playSuccess();
    setShowClearPassesModal(false);
    setConfirmText('');
    setSaveSuccessMsg(lang === 'ar' ? 'تم تصفير سجلات التصاريح وحركات البوابات بالكامل بنجاح!' : 'All pass records and movements purged successfully!');
    if (onDataReset) onDataReset();
    setTimeout(() => setSaveSuccessMsg(''), 4000);
  };

  // Handle Full Factory Reset
  const handleConfirmFactoryReset = () => {
    if (confirmText.trim() !== '7941631' && confirmText.trim().toLowerCase() !== 'reset') {
      setErrorMsg(lang === 'ar' ? 'الرمز التأكيدي غير صحيح! أدخل 7941631 للتأكيد.' : 'Invalid confirmation code! Enter 7941631.');
      return;
    }
    storageService.factoryResetSystem();
    soundService.playSuccess();
    setShowFactoryResetModal(false);
    setConfirmText('');
    setSaveSuccessMsg(lang === 'ar' ? 'تمت إعادة تهيئة المنظومة بالكامل بنجاح!' : 'System factory reset completed!');
    if (onDataReset) onDataReset();
    setTimeout(() => {
      window.location.reload();
    }, 1500);
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      
      {/* Toast Alert */}
      {saveSuccessMsg && (
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-5 h-5 shrink-0" />
          <span>{saveSuccessMsg}</span>
        </div>
      )}

      {errorMsg && (
        <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs font-bold flex items-center justify-between animate-fadeIn">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-5 h-5 shrink-0" />
            <span>{errorMsg}</span>
          </div>
          <button onClick={() => setErrorMsg('')} className="text-slate-400 hover:text-white text-xs">✕</button>
        </div>
      )}

      {/* 0. Central Host Server & Multi-PC Connection (شبكة الخادم المحلي وربط الحواسيب) */}
      <div className="p-6 rounded-3xl bg-gradient-to-br from-slate-900 via-slate-900 to-blue-950/30 border border-blue-500/30 space-y-5 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-64 h-64 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center text-white shadow-lg shadow-blue-500/20">
              <Server className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-white">
                  {lang === 'ar' ? 'إعدادات شبكة الخادم المركزي (Host Server & Multi-PC)' : 'Central Host Server & Multi-PC Network'}
                </h3>
                <span className="flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/30">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  {lang === 'ar' ? 'السيرفر جاهز للربط' : 'Server Ready'}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-0.5">
                {lang === 'ar' 
                  ? 'تشغيل المنظومة كـ خادم رئيسي على هذه الحاسبة لتمكين باقي حواسيب البوابات والسيطرة والشركات من الدخول والمزامنة الحية'
                  : 'Host this machine as the central server for all gate guard terminals and SOC PCs over LAN'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={handleForceSync}
              disabled={isSyncing}
              className="px-3.5 py-2 rounded-xl bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/40 text-xs font-bold transition-all flex items-center gap-1.5 active:scale-95 disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{lang === 'ar' ? 'مزامنة السيرفر الآن' : 'Sync Server Now'}</span>
            </button>
          </div>
        </div>

        {/* Server URLs Box */}
        <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 space-y-3 relative z-10">
          <div className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
            <Network className="w-4 h-4 text-blue-400" />
            <span>{lang === 'ar' ? 'روابط الدخول من الحواسيب الأخرى عبر شبكة LAN / Wi-Fi:' : 'Access URLs for Other PCs on Local Network:'}</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {/* Primary LAN URL */}
            <div className="p-3 rounded-xl bg-slate-900 border border-blue-500/30 flex items-center justify-between gap-2">
              <div>
                <div className="text-[10px] text-blue-400 font-bold uppercase tracking-wider">
                  {lang === 'ar' ? 'رابط الشبكة المحلية (LAN IP):' : 'LAN Network IP:'}
                </div>
                <div className="font-mono text-xs font-black text-white select-all mt-0.5">
                  {serverInfo?.primaryUrl || 'http://192.168.1.X:3000'}
                </div>
              </div>
              <button
                onClick={() => handleCopyUrl(serverInfo?.primaryUrl || `http://${window.location.hostname}:3000`)}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 shrink-0 ${
                  isCopied ? 'bg-emerald-600 text-white' : 'bg-blue-600 hover:bg-blue-500 text-white shadow-md'
                }`}
              >
                {isCopied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{isCopied ? (lang === 'ar' ? 'تم النسخ!' : 'Copied!') : (lang === 'ar' ? 'نسخ الرابط' : 'Copy')}</span>
              </button>
            </div>

            {/* Localhost URL */}
            <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between gap-2">
              <div>
                <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                  {lang === 'ar' ? 'الحاسبة الرئيسية (Host Machine):' : 'Host PC:'}
                </div>
                <div className="font-mono text-xs font-bold text-slate-300 mt-0.5">
                  http://localhost:3000
                </div>
              </div>
              <span className="px-2 py-1 rounded bg-slate-800 text-[10px] text-slate-400 font-mono">
                Port 3000 (0.0.0.0)
              </span>
            </div>
          </div>

          {/* Quick Setup Instructions for Local Server */}
          <div className="pt-2 border-t border-slate-800/80">
            <div className="text-xs font-bold text-amber-400 mb-2 flex items-center gap-1.5">
              <Laptop className="w-4 h-4" />
              <span>{lang === 'ar' ? 'خطوات تشغيل المنظومة كـ سيرفر لباقي الحواسيب:' : 'Steps to Connect Other PCs to this Server:'}</span>
            </div>

            <ol className="list-decimal list-inside space-y-1.5 text-xs text-slate-300 pr-1">
              <li>
                <strong className="text-white">{lang === 'ar' ? 'تشغيل السيرفر على الحاسبة الرئيسية:' : 'Run on Main PC:'}</strong>{' '}
                {lang === 'ar' 
                  ? 'عند تنزيل المنظومة إلى حاسوبك، قم بتشغيل ملف (start-server.bat) أو تشغيل الأمر (npm run dev).'
                  : 'On the main computer, launch (start-server.bat) or execute (npm run dev).'}
              </li>
              <li>
                <strong className="text-white">{lang === 'ar' ? 'اتصال الحواسيب بنفس الشبكة:' : 'Same Network Connection:'}</strong>{' '}
                {lang === 'ar' 
                  ? 'تأكد أن جميع حواسيب البوابات (بوابة 1، بوابة 2، غرفة السيطرة SOC، مكاتب الشركات) متصلة بنفس شبكة الراوتر أو السويتش LAN.'
                  : 'Ensure all gate terminals and SOC computers are connected to the same LAN / Wi-Fi router.'}
              </li>
              <li>
                <strong className="text-white">{lang === 'ar' ? 'فتح الرابط في باقي الحواسيب:' : 'Open in Browser:'}</strong>{' '}
                {lang === 'ar' 
                  ? 'انسخ الرابط أعلاه وافتحه في متصفح أي حاسبة أخرى (مثل Google Chrome أو Edge) دون الحاجة لتثبيت أي برامج!'
                  : 'Open the copied IP URL in any browser on the other computers without installing software.'}
              </li>
              <li>
                <strong className="text-white">{lang === 'ar' ? 'المزامنة الحية التلقائية:' : 'Real-time Cross Sync:'}</strong>{' '}
                {lang === 'ar' 
                  ? 'البيانات تُحفظ تلقائياً على قرص السيرفر وتتم المزامنة الحية الفورية بين كافة الشاشات والحواسيب المتصلة.'
                  : 'All pass updates, gate logs, and approvals sync automatically across all connected PCs.'}
              </li>
            </ol>
          </div>
        </div>

      </div>

      {/* 1. System Nomenclature & Custom Renaming */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Edit3 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">{t.settings_nomenclature_title}</h3>
            <p className="text-xs text-slate-400">{t.settings_nomenclature_desc}</p>
          </div>
        </div>

        <form onSubmit={handleSaveNomenclature} className="space-y-4">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">اسم البرنامج / المنظومة (بالعربية):</label>
              <input
                type="text"
                required
                value={nomenclature.appNameAr}
                onChange={(e) => setNomenclature({ ...nomenclature, appNameAr: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-amber-400 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">App Name (English):</label>
              <input
                type="text"
                required
                value={nomenclature.appNameEn}
                onChange={(e) => setNomenclature({ ...nomenclature, appNameEn: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-amber-400 outline-none font-sans"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">اسم المجمع أو المنشأة (بالعربية):</label>
              <input
                type="text"
                required
                value={nomenclature.facilityNameAr}
                onChange={(e) => setNomenclature({ ...nomenclature, facilityNameAr: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-amber-400 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Facility Name (English):</label>
              <input
                type="text"
                required
                value={nomenclature.facilityNameEn}
                onChange={(e) => setNomenclature({ ...nomenclature, facilityNameEn: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-amber-400 outline-none font-sans"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">مسمى كابينة بوابة 1 (بالعربية):</label>
              <input
                type="text"
                required
                value={nomenclature.gate1NameAr}
                onChange={(e) => setNomenclature({ ...nomenclature, gate1NameAr: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-amber-400 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Gate 1 Name (English):</label>
              <input
                type="text"
                required
                value={nomenclature.gate1NameEn}
                onChange={(e) => setNomenclature({ ...nomenclature, gate1NameEn: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-amber-400 outline-none font-sans"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">مسمى كابينة بوابة 2 (بالعربية):</label>
              <input
                type="text"
                required
                value={nomenclature.gate2NameAr}
                onChange={(e) => setNomenclature({ ...nomenclature, gate2NameAr: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-amber-400 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Gate 2 Name (English):</label>
              <input
                type="text"
                required
                value={nomenclature.gate2NameEn}
                onChange={(e) => setNomenclature({ ...nomenclature, gate2NameEn: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-amber-400 outline-none font-sans"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">مسمى غرفة السيطرة SOC (بالعربية):</label>
              <input
                type="text"
                required
                value={nomenclature.socNameAr}
                onChange={(e) => setNomenclature({ ...nomenclature, socNameAr: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-amber-400 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">Security Operations Center Name (English):</label>
              <input
                type="text"
                required
                value={nomenclature.socNameEn}
                onChange={(e) => setNomenclature({ ...nomenclature, socNameEn: e.target.value })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-amber-400 outline-none font-sans"
              />
            </div>

          </div>

          <div className="flex items-center justify-between pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={() => setNomenclature(DEFAULT_NOMENCLATURE)}
              className="text-xs text-slate-400 hover:text-white"
            >
              {lang === 'ar' ? 'استعادة التسميات الافتراضية' : 'Reset to Defaults'}
            </button>

            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-amber-500/20 active:scale-95 transition-all"
            >
              <Save className="w-4 h-4" />
              <span>{t.save}</span>
            </button>
          </div>

        </form>
      </div>

      {/* 2. Automated & Manual Backup Server Configuration */}
      <div className="p-6 rounded-3xl bg-slate-900 border border-slate-800 space-y-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-blue-500/10 border border-blue-500/30 flex items-center justify-center text-blue-400">
            <Server className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">{t.settings_backup_title}</h3>
            <p className="text-xs text-slate-400">{t.settings_backup_desc}</p>
          </div>
        </div>

        <form onSubmit={handleSaveBackupSettings} className="space-y-4">
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">{t.auto_backup_status}:</label>
              <select
                value={backupSettings.enabled ? 'true' : 'false'}
                onChange={(e) => setBackupSettings({ ...backupSettings, enabled: e.target.value === 'true' })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white outline-none focus:border-blue-400"
              >
                <option value="true">{lang === 'ar' ? 'مفعل (تلقائي دوري)' : 'Enabled (Automatic Periodic)'}</option>
                <option value="false">{lang === 'ar' ? 'معطل (يدوي فقط)' : 'Disabled (Manual Only)'}</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">{t.backup_interval}:</label>
              <select
                value={backupSettings.intervalMinutes}
                onChange={(e) => setBackupSettings({ ...backupSettings, intervalMinutes: Number(e.target.value) })}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white outline-none focus:border-blue-400"
              >
                <option value={60}>{lang === 'ar' ? 'كل ساعة (1 Hour)' : 'Every 1 Hour'}</option>
                <option value={180}>{lang === 'ar' ? 'كل 3 ساعات (3 Hours)' : 'Every 3 Hours'}</option>
                <option value={360}>{lang === 'ar' ? 'كل 6 ساعات (6 Hours)' : 'Every 6 Hours'}</option>
                <option value={720}>{lang === 'ar' ? 'كل 12 ساعة (12 Hours)' : 'Every 12 Hours'}</option>
                <option value={1440}>{lang === 'ar' ? 'يومياً (Every 24 Hours)' : 'Daily (24 Hours)'}</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1">{t.backup_server_path}:</label>
              <input
                type="text"
                value={backupSettings.serverDestinationName}
                onChange={(e) => setBackupSettings({ ...backupSettings, serverDestinationName: e.target.value })}
                placeholder="C:\GatePass_Server_Backups\"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2.5 text-xs text-white outline-none font-mono focus:border-blue-400"
              />
            </div>

          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800">
            <div className="text-[11px] text-slate-400 flex items-center gap-1.5 font-mono">
              <Clock className="w-3.5 h-3.5 text-blue-400" />
              <span>{lang === 'ar' ? 'آخر حفظ موثق:' : 'Last Snapshot:'} {backupSettings.lastBackupTime ? new Date(backupSettings.lastBackupTime).toLocaleString(lang === 'ar' ? 'ar-IQ' : 'en-US') : '—'}</span>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleExportBackupNow}
                className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-md shadow-blue-600/20 active:scale-95"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{t.backup_now}</span>
              </button>

              <label className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs flex items-center gap-1.5 cursor-pointer transition-all border border-slate-700 active:scale-95">
                <Upload className="w-3.5 h-3.5 text-amber-400" />
                <span>{t.restore_backup}</span>
                <input
                  type="file"
                  accept=".json"
                  onChange={handleRestoreFromFile}
                  className="hidden"
                />
              </label>

              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 transition-all shadow-md shadow-amber-500/20 active:scale-95"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{t.save}</span>
              </button>
            </div>
          </div>

        </form>
      </div>

      {/* 3. Danger Zone: Clear Passes & Full Factory Reset */}
      <div className="p-6 rounded-3xl bg-red-950/20 border border-red-900/40 space-y-5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-red-400">{t.danger_zone}</h3>
            <p className="text-xs text-slate-400">
              {lang === 'ar' 
                ? 'إجراءات حساسة مخصصة للمسؤول العام فقط لإعادة تهيئة البيانات أو تنظيف الأرشيف'
                : 'Restricted high-privilege operations for master administrator to purge logs or reset'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          
          {/* Option 1: Clear Passes */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between space-y-3">
            <div>
              <div className="font-bold text-white text-xs">{t.zero_out_passes}</div>
              <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">{t.zero_out_passes_desc}</p>
            </div>
            <button
              type="button"
              onClick={() => { setShowClearPassesModal(true); setConfirmText(''); setErrorMsg(''); }}
              className="w-full py-2 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/30 text-xs font-bold transition-all flex items-center justify-center gap-1.5"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{t.zero_out_passes}</span>
            </button>
          </div>

          {/* Option 2: Full Factory Reset */}
          <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 flex flex-col justify-between space-y-3">
            <div>
              <div className="font-bold text-red-400 text-xs">{t.factory_reset}</div>
              <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">{t.factory_reset_desc}</p>
            </div>
            <button
              type="button"
              onClick={() => { setShowFactoryResetModal(true); setConfirmText(''); setErrorMsg(''); }}
              className="w-full py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-black transition-all flex items-center justify-center gap-1.5 shadow-lg shadow-red-600/30"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{t.factory_reset}</span>
            </button>
          </div>

        </div>
      </div>

      {/* Confirmation Modal 1: Clear Passes */}
      {showClearPassesModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-md bg-slate-900 border border-red-800/80 rounded-3xl p-6 space-y-4 text-white shadow-2xl">
            <div className="flex items-center gap-2 text-red-400 font-bold">
              <Trash2 className="w-5 h-5" />
              <h4>{t.zero_out_passes}</h4>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {lang === 'ar'
                ? 'هل أنت متأكد من رغبتك في مسح وتصفير كافة سجلات التصاريح السابقة وحركات البوابات؟ لا يمكن التراجع عن هذا الإجراء إلا باستعادة نسخة احتياطية.'
                : 'Are you sure you want to clear all passes and movement logs? This action is permanent.'}
            </p>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1 font-mono">
                {lang === 'ar' ? 'أدخل رمز التأكيد (7941631):' : 'Enter confirmation code (7941631):'}
              </label>
              <input
                type="password"
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                placeholder="•••••••"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono outline-none focus:border-red-400"
              />
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowClearPassesModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold hover:bg-slate-700"
              >
                {t.cancel}
              </button>
              <button
                onClick={handleConfirmClearPasses}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold shadow-lg shadow-red-600/30"
              >
                {t.confirm}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal 2: Full Factory Reset */}
      {showFactoryResetModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
          <div className="relative w-full max-w-md bg-slate-900 border border-red-800 rounded-3xl p-6 space-y-4 text-white shadow-2xl">
            <div className="flex items-center gap-2 text-red-400 font-black">
              <RotateCcw className="w-5 h-5" />
              <h4>{t.factory_reset}</h4>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {lang === 'ar'
                ? 'تحذير أمني عالي: ستتم إعادة ضبط المصنع الكامل وتصفير كافة البيانات وإعادة بناء التكوين الأولي للمنظومة.'
                : 'High Security Alert: This will perform a full factory reset and wipe all system records.'}
            </p>
            <div>
              <label className="block text-[11px] text-slate-400 mb-1 font-mono">
                {lang === 'ar' ? 'أدخل رمز التأكيد (7941631):' : 'Enter confirmation code (7941631):'}
              </label>
              <input
                type="password"
                value={confirmText}
                onChange={(e) => setConfirmText(e.target.value)}
                placeholder="•••••••"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono outline-none focus:border-red-400"
              />
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowFactoryResetModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold hover:bg-slate-700"
              >
                {t.cancel}
              </button>
              <button
                onClick={handleConfirmFactoryReset}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold shadow-lg shadow-red-600/30"
              >
                {t.confirm}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

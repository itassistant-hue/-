import React from 'react';
import { EmergencyBroadcast, Language } from '../types';
import { storageService } from '../services/storage';
import { translations } from '../services/i18n';
import { AlertTriangle, BellOff, ShieldAlert, Radio, Volume2 } from 'lucide-react';

interface EmergencyBannerProps {
  broadcast: EmergencyBroadcast;
  lang?: Language;
  onDismiss: () => void;
}

export const EmergencyBanner: React.FC<EmergencyBannerProps> = ({
  broadcast,
  lang = 'ar',
  onDismiss
}) => {
  const t = translations[lang] || translations.ar;

  const handleDismiss = () => {
    storageService.dismissEmergencyBroadcast(broadcast.id);
    onDismiss();
  };

  const getTargetLabels = (targets: string[]) => {
    const map: { [key: string]: string } = {
      gate_1: lang === 'ar' ? 'بوابة 1' : 'Gate 1',
      gate_2: lang === 'ar' ? 'بوابة 2' : 'Gate 2',
      security_ops: lang === 'ar' ? 'السيطرة SOC' : 'SOC',
      all_guards: lang === 'ar' ? 'كافة الحراس' : 'All Guards',
      fire: lang === 'ar' ? 'الإطفاء' : 'Fire',
      medical: lang === 'ar' ? 'الإسعاف' : 'Medical',
      companies: lang === 'ar' ? 'الشركات' : 'Companies'
    };
    return targets.map(t => map[t] || t).join(' • ');
  };

  return (
    <div className="bg-gradient-to-r from-red-700 via-red-600 to-red-700 text-white px-4 py-3 shadow-2xl border-b-2 border-red-500 relative z-50 animate-pulse font-['Tajawal',sans-serif]">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
        
        <div className="flex items-center gap-3 w-full md:w-auto">
          <div className="w-10 h-10 rounded-2xl bg-white/20 flex items-center justify-center text-white shrink-0 shadow-lg">
            <AlertTriangle className="w-6 h-6 animate-bounce" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-black text-sm md:text-base tracking-wide uppercase">
                🚨 {broadcast.title || t.emergency_active_alert}
              </span>
              <span className="px-2 py-0.5 rounded-full bg-black/40 text-[10px] font-mono font-bold">
                {new Date(broadcast.timestamp).toLocaleTimeString(lang === 'ar' ? 'ar-IQ' : 'en-US')}
              </span>
            </div>
            <p className="text-xs font-semibold text-red-100 mt-0.5 leading-relaxed">
              {broadcast.message}
            </p>
            <div className="text-[10px] text-red-200 mt-1 flex items-center gap-2">
              <span>{lang === 'ar' ? 'المرسل:' : 'Sender:'} {broadcast.sender}</span>
              <span>•</span>
              <span>{lang === 'ar' ? 'المستهدفون:' : 'Targets:'} {getTargetLabels(broadcast.targets)}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 self-end md:self-auto">
          <button
            onClick={handleDismiss}
            className="px-4 py-2 rounded-xl bg-slate-950 hover:bg-slate-900 text-amber-400 border border-amber-500/40 text-xs font-bold flex items-center gap-1.5 shadow-lg active:scale-95 transition-all"
          >
            <BellOff className="w-4 h-4" />
            <span>{t.emergency_dismiss}</span>
          </button>
        </div>

      </div>
    </div>
  );
};

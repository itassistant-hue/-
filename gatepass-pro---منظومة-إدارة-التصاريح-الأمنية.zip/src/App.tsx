import React, { useState, useEffect } from 'react';
import { User, PassRequest, SystemNotification, Language, GateDefinition, SystemViewDefinition } from './types';
import { storageService } from './services/storage';
import { soundService } from './services/audio';
import { translations } from './services/i18n';

import { Header } from './components/Header';
import { Footer } from './components/Footer';
import { LoginScreen } from './components/LoginScreen';
import { AdminDashboard } from './components/AdminDashboard';
import { SecurityOpsDashboard } from './components/SecurityOpsDashboard';
import { GateGuardTerminal } from './components/GateGuardTerminal';
import { CompanyPortal } from './components/CompanyPortal';
import { SecretGatewayModal } from './components/SecretGatewayModal';
import { PassCardModal } from './components/PassCardModal';
import { NewPassModal } from './components/NewPassModal';
import { LoginModal } from './components/LoginModal';
import { UserManagerModal } from './components/UserManagerModal';
import { CompanyManagerModal } from './components/CompanyManagerModal';
import { EmergencyModal } from './components/EmergencyModal';
import { EmergencyBanner } from './components/EmergencyBanner';
import { AdminQuickCustomizeModal } from './components/AdminQuickCustomizeModal';

import { 
  ShieldCheck, 
  DoorOpen, 
  Building2, 
  Sliders, 
  Radio, 
  Bell, 
  X, 
  CheckCircle, 
  AlertTriangle,
  Crown,
  Key,
  Lock,
  Edit3
} from 'lucide-react';

export default function App() {
  const [lang, setLang] = useState<Language>(() => storageService.getLanguage());
  const [currentUser, setCurrentUser] = useState<User>(() => storageService.getCurrentUser());
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => storageService.isSessionAuthenticated());
  const [activeViewMode, setActiveViewMode] = useState<string>('auto');
  
  // Modals state
  const [isSecretGatewayOpen, setIsSecretGatewayOpen] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isNewPassModalOpen, setIsNewPassModalOpen] = useState(false);
  const [isUserManagerOpen, setIsUserManagerOpen] = useState(false);
  const [isCompanyManagerOpen, setIsCompanyManagerOpen] = useState(false);
  const [isEmergencyModalOpen, setIsEmergencyModalOpen] = useState(false);
  const [isCustomizeModalOpen, setIsCustomizeModalOpen] = useState(false);
  const [customizeInitialTab, setCustomizeInitialTab] = useState<'branding' | 'views' | 'kpis'>('branding');
  const [selectedPassForCard, setSelectedPassForCard] = useState<PassRequest | null>(null);

  // Live state
  const [passes, setPasses] = useState<PassRequest[]>(() => storageService.getPasses());
  const [notifications, setNotifications] = useState<SystemNotification[]>(() => storageService.getNotifications());
  const [latestToast, setLatestToast] = useState<SystemNotification | null>(null);
  const [license, setLicense] = useState(() => storageService.getLicense());
  const [nomenclature, setNomenclature] = useState(() => storageService.getNomenclature());
  const [gates, setGates] = useState<GateDefinition[]>(() => storageService.getGates().filter(g => g.enabled));
  const [systemViews, setSystemViews] = useState<SystemViewDefinition[]>(() => storageService.getSystemViews().filter(v => v.enabled));
  const [activeEmergency, setActiveEmergency] = useState(() => storageService.getActiveEmergencyBroadcast());

  const t = translations[lang] || translations.ar;

  // Storage listener for live multi-tab & multi-user updates
  useEffect(() => {
    const handleStorageChange = () => {
      setPasses(storageService.getPasses());
      setNotifications(storageService.getNotifications());
      setCurrentUser(storageService.getCurrentUser());
      setLicense(storageService.getLicense());
      setNomenclature(storageService.getNomenclature());
      setGates(storageService.getGates().filter(g => g.enabled));
      setSystemViews(storageService.getSystemViews().filter(v => v.enabled));
      setLang(storageService.getLanguage());
      setActiveEmergency(storageService.getActiveEmergencyBroadcast());
      setIsAuthenticated(storageService.isSessionAuthenticated());
    };

    const handleCustomStorageEvent = (e: Event) => {
      const custom = e as CustomEvent<{ event: string; data?: unknown }>;
      if (custom.detail?.event === 'notification_added' && custom.detail?.data) {
        const notif = custom.detail.data as SystemNotification;
        setLatestToast(notif);
        setTimeout(() => setLatestToast(null), 5000);
      }
      setPasses(storageService.getPasses());
      setNotifications(storageService.getNotifications());
      setCurrentUser(storageService.getCurrentUser());
      setLicense(storageService.getLicense());
      setNomenclature(storageService.getNomenclature());
      setGates(storageService.getGates().filter(g => g.enabled));
      setSystemViews(storageService.getSystemViews().filter(v => v.enabled));
      setLang(storageService.getLanguage());
      setActiveEmergency(storageService.getActiveEmergencyBroadcast());
      setIsAuthenticated(storageService.isSessionAuthenticated());
    };

    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('gatepass_storage_event', handleCustomStorageEvent);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('gatepass_storage_event', handleCustomStorageEvent);
    };
  }, []);

  const activeInsideCount = passes.filter(p => storageService.getEffectiveStatus(p) === 'inside').length;
  const pendingCount = passes.filter(p => p.status === 'pending_security').length;

  const handleOpenPassCard = (pass: PassRequest) => {
    setSelectedPassForCard(pass);
  };

  const handleExtendValidity = (passId: string) => {
    storageService.extendPass(passId, 4, currentUser);
    const updated = storageService.getPasses().find(p => p.id === passId);
    if (updated) setSelectedPassForCard(updated);
    soundService.playSuccess();
  };

  const handleLanguageChange = (newLang: Language) => {
    setLang(newLang);
    storageService.setLanguage(newLang);
  };

  const handleLogout = () => {
    storageService.logout();
    setIsAuthenticated(false);
  };

  const handleOpenCustomize = (tab: 'branding' | 'views' | 'kpis' = 'branding') => {
    setCustomizeInitialTab(tab);
    setIsCustomizeModalOpen(true);
  };

  // If user is not authenticated, show the full-screen secure Login Gate
  if (!isAuthenticated) {
    return (
      <>
        <LoginScreen
          lang={lang}
          onLanguageChange={handleLanguageChange}
          onOpenSecretGateway={() => setIsSecretGatewayOpen(true)}
          onLoginSuccess={(user) => {
            setCurrentUser(user);
            setIsAuthenticated(true);
            setActiveViewMode('auto');
          }}
        />
        <SecretGatewayModal
          isOpen={isSecretGatewayOpen}
          onClose={() => setIsSecretGatewayOpen(false)}
        />
      </>
    );
  }

  // Determine which component to render
  const renderCurrentView = () => {
    if (activeViewMode === 'admin') {
      return (
        <AdminDashboard
          currentUser={currentUser}
          lang={lang}
          onOpenPassDetails={handleOpenPassCard}
          onOpenNewPassModal={() => setIsNewPassModalOpen(true)}
          onOpenUserManager={() => setIsUserManagerOpen(true)}
          onOpenCompanyManager={() => setIsCompanyManagerOpen(true)}
          onOpenSecretGateway={() => setIsSecretGatewayOpen(true)}
          onOpenCustomizeModal={handleOpenCustomize}
        />
      );
    }
    if (activeViewMode === 'soc') {
      return (
        <SecurityOpsDashboard
          currentUser={currentUser}
          onOpenPassDetails={handleOpenPassCard}
          onOpenNewPassModal={() => setIsNewPassModalOpen(true)}
        />
      );
    }
    if (activeViewMode === 'company') {
      return (
        <CompanyPortal
          currentUser={currentUser}
          onOpenPassDetails={handleOpenPassCard}
          onOpenNewPassModal={() => setIsNewPassModalOpen(true)}
        />
      );
    }
    // Any dynamic gate matching
    if (activeViewMode === 'gate1' || activeViewMode === 'gate2' || activeViewMode.startsWith('gate_') || gates.some(g => g.id === activeViewMode)) {
      const targetGateId = activeViewMode === 'gate1' ? 'gate_1' : activeViewMode === 'gate2' ? 'gate_2' : activeViewMode;
      return (
        <GateGuardTerminal
          currentUser={{ ...currentUser, gateId: targetGateId }}
          onOpenPassDetails={handleOpenPassCard}
          onOpenNewPassModal={() => setIsNewPassModalOpen(true)}
        />
      );
    }

    // Auto view based on user role:
    if (currentUser.role === 'admin') {
      return (
        <AdminDashboard
          currentUser={currentUser}
          lang={lang}
          onOpenPassDetails={handleOpenPassCard}
          onOpenNewPassModal={() => setIsNewPassModalOpen(true)}
          onOpenUserManager={() => setIsUserManagerOpen(true)}
          onOpenCompanyManager={() => setIsCompanyManagerOpen(true)}
          onOpenSecretGateway={() => setIsSecretGatewayOpen(true)}
          onOpenCustomizeModal={handleOpenCustomize}
        />
      );
    }
    if (currentUser.role === 'security_ops') {
      return (
        <SecurityOpsDashboard
          currentUser={currentUser}
          onOpenPassDetails={handleOpenPassCard}
          onOpenNewPassModal={() => setIsNewPassModalOpen(true)}
        />
      );
    }
    if (currentUser.role === 'gate_1' || currentUser.role === 'gate_2' || (currentUser.gateId && currentUser.gateId.length > 0)) {
      return (
        <GateGuardTerminal
          currentUser={currentUser}
          onOpenPassDetails={handleOpenPassCard}
          onOpenNewPassModal={() => setIsNewPassModalOpen(true)}
        />
      );
    }
    return (
      <CompanyPortal
        currentUser={currentUser}
        onOpenPassDetails={handleOpenPassCard}
        onOpenNewPassModal={() => setIsNewPassModalOpen(true)}
      />
    );
  };

  const gate1Label = lang === 'ar' ? (nomenclature.gate1NameAr || 'بوابة 1') : (nomenclature.gate1NameEn || 'Gate 1');
  const gate2Label = lang === 'ar' ? (nomenclature.gate2NameAr || 'بوابة 2') : (nomenclature.gate2NameEn || 'Gate 2');
  const socLabel = lang === 'ar' ? (nomenclature.socNameAr || 'السيطرة الأمنية (SOC)') : (nomenclature.socNameEn || 'Security SOC');
  const companyLabel = lang === 'ar' ? (nomenclature.companyPortalNameAr || 'بوابة الشركات') : (nomenclature.companyPortalNameEn || 'Company Portal');
  const adminLabel = lang === 'ar' ? (nomenclature.adminNameAr || t.admin_dashboard) : (nomenclature.adminNameEn || t.admin_dashboard);

  const systemBg = nomenclature.systemBgUrl || license.systemBgUrl || '';

  const getSystemBgStyle = (): React.CSSProperties | undefined => {
    if (!systemBg) return undefined;
    if (systemBg.startsWith('linear-gradient') || systemBg.startsWith('radial-gradient')) {
      return { background: systemBg };
    }
    return {
      backgroundImage: `linear-gradient(rgba(2, 6, 23, 0.88), rgba(2, 6, 23, 0.94)), url("${systemBg}")`,
      backgroundSize: 'cover',
      backgroundPosition: 'center',
      backgroundAttachment: 'fixed'
    };
  };

  return (
    <div 
      className={`min-h-screen bg-slate-950 text-slate-100 font-['Tajawal',sans-serif] flex flex-col selection:bg-amber-500/30 selection:text-amber-200 ${lang === 'en' ? 'ltr' : 'rtl'}`} 
      dir={lang === 'en' ? 'ltr' : 'rtl'}
      style={getSystemBgStyle()}
    >
      
      {/* Top Emergency Active Broadcast Banner */}
      {activeEmergency && (
        <EmergencyBanner
          broadcast={activeEmergency}
          lang={lang}
          onDismiss={() => setActiveEmergency(null)}
        />
      )}

      {/* Top Sticky Header */}
      <Header
        currentUser={currentUser}
        lang={lang}
        onLanguageChange={handleLanguageChange}
        onUserChange={(user) => {
          setCurrentUser(user);
          setActiveViewMode('auto');
        }}
        onOpenSecretGateway={() => setIsSecretGatewayOpen(true)}
        onOpenLoginModal={() => setIsLoginModalOpen(true)}
        onOpenEmergencyModal={() => setIsEmergencyModalOpen(true)}
        onOpenCustomizeModal={handleOpenCustomize}
        onLogout={handleLogout}
        activeInsideCount={activeInsideCount}
        pendingCount={pendingCount}
      />

      {/* Live Navigation Sub-Bar for Quick View Switching (Restricted strictly to Admin as requested) */}
      {currentUser.role === 'admin' && (
        <div className="bg-slate-900/90 border-b border-slate-800/80 px-4 sm:px-6 py-2">
          <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3 text-xs">
            
            <div className="flex items-center gap-1.5 overflow-x-auto py-1">
              <span className="text-slate-400 font-bold ml-1 shrink-0 flex items-center gap-1">
                <span>{lang === 'ar' ? 'واجهات المنظومة:' : 'System Views:'}</span>
                <button 
                  onClick={() => handleOpenCustomize('views')}
                  className="p-1 rounded text-slate-400 hover:text-amber-400"
                  title={lang === 'ar' ? 'تعديل تسميات الواجهات' : 'Edit View Names'}
                >
                  <Edit3 className="w-3 h-3" />
                </button>
              </span>
              
              <button
                onClick={() => setActiveViewMode('auto')}
                className={`px-3 py-1 rounded-xl font-bold transition-colors shrink-0 ${
                  activeViewMode === 'auto'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'bg-slate-950/60 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {lang === 'ar' ? 'الافتراضي (حسب الصلاحية)' : 'Default (Role-based)'}
              </button>

              <button
                onClick={() => setActiveViewMode('admin')}
                className={`px-3 py-1 rounded-xl font-bold transition-colors shrink-0 flex items-center gap-1 ${
                  activeViewMode === 'admin'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'bg-slate-950/60 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                <Sliders className="w-3 h-3" />
                <span className="truncate max-w-[120px]">{adminLabel}</span>
              </button>

              <button
                onClick={() => setActiveViewMode('soc')}
                className={`px-3 py-1 rounded-xl font-bold transition-colors shrink-0 flex items-center gap-1 ${
                  activeViewMode === 'soc'
                    ? 'bg-amber-500 text-slate-950 shadow-sm'
                    : 'bg-slate-950/60 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                <Radio className="w-3 h-3" />
                <span className="truncate max-w-[140px]">{socLabel}</span>
              </button>

              {gates.map((g, idx) => {
                const isActive = activeViewMode === g.id || (activeViewMode === 'gate1' && g.id === 'gate_1') || (activeViewMode === 'gate2' && g.id === 'gate_2');
                const colors = [
                  'bg-blue-600 text-white',
                  'bg-indigo-600 text-white',
                  'bg-cyan-600 text-white',
                  'bg-violet-600 text-white',
                  'bg-teal-600 text-white',
                ];
                const activeColor = colors[idx % colors.length];

                return (
                  <button
                    key={g.id}
                    onClick={() => setActiveViewMode(g.id)}
                    className={`px-3 py-1 rounded-xl font-bold transition-colors shrink-0 flex items-center gap-1 ${
                      isActive
                        ? `${activeColor} shadow-sm`
                        : 'bg-slate-950/60 text-slate-400 hover:text-white border border-slate-800'
                    }`}
                  >
                    <DoorOpen className="w-3 h-3" />
                    <span className="truncate max-w-[130px]">{g.nameAr}</span>
                  </button>
                );
              })}

              <button
                onClick={() => setActiveViewMode('company')}
                className={`px-3 py-1 rounded-xl font-bold transition-colors shrink-0 flex items-center gap-1 ${
                  activeViewMode === 'company'
                    ? 'bg-emerald-600 text-white shadow-sm'
                    : 'bg-slate-950/60 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                <Building2 className="w-3 h-3" />
                <span>{companyLabel}</span>
              </button>
            </div>

            {/* Quick User & Security Status */}
            <div className="hidden md:flex items-center gap-3 text-[11px] text-slate-400">
              <span className="flex items-center gap-1 text-slate-300">
                <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                {lang === 'ar' ? (nomenclature.facilityNameAr || license.facilityName) : (nomenclature.facilityNameEn || license.facilityName)}
              </span>
              <span>•</span>
              <button
                onClick={handleLogout}
                className="text-red-400 hover:text-red-300 font-bold flex items-center gap-1 transition-colors"
              >
                <Lock className="w-3 h-3" />
                <span>{lang === 'ar' ? 'قفل المنظومة' : 'Lock Terminal'}</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* Main Content Area (with pb-24 so content is never hidden behind fixed sticky footer) */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 pb-24">
        {renderCurrentView()}
      </main>

      {/* Real-time Toast Alert Notification */}
      {latestToast && (
        <div className="fixed bottom-14 left-5 z-50 max-w-sm p-4 rounded-2xl bg-slate-900/95 border-2 border-amber-500 shadow-2xl backdrop-blur-md animate-bounce">
          <div className="flex items-start justify-between gap-3">
            <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400 shrink-0">
              <Bell className="w-5 h-5" />
            </div>
            <div className="flex-1">
              <h4 className="text-xs font-bold text-white">{latestToast.title}</h4>
              <p className="text-[11px] text-slate-300 mt-0.5">{latestToast.message}</p>
            </div>
            <button onClick={() => setLatestToast(null)} className="text-slate-400 hover:text-white p-1">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Secret Gateway Modal (Triggered by 10 clicks on Copyright Footer) */}
      <SecretGatewayModal
        isOpen={isSecretGatewayOpen}
        onClose={() => setIsSecretGatewayOpen(false)}
      />

      {/* Admin Quick Customize Modal for Nomenclature & KPI cards */}
      <AdminQuickCustomizeModal
        isOpen={isCustomizeModalOpen}
        onClose={() => setIsCustomizeModalOpen(false)}
        lang={lang}
        initialTab={customizeInitialTab}
      />

      {/* Pass Card Details & Badge Printable Modal */}
      <PassCardModal
        pass={selectedPassForCard}
        isOpen={!!selectedPassForCard}
        onClose={() => setSelectedPassForCard(null)}
        onExtendValidity={handleExtendValidity}
      />

      {/* New Pass / Access Request Modal */}
      <NewPassModal
        isOpen={isNewPassModalOpen}
        onClose={() => setIsNewPassModalOpen(false)}
        currentUser={currentUser}
        onPassCreated={(pass) => {
          setSelectedPassForCard(pass);
        }}
      />

      {/* Login Modal for In-Session Switch */}
      <LoginModal
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onLoginSuccess={(user) => {
          setCurrentUser(user);
          setActiveViewMode('auto');
        }}
      />

      {/* Emergency Broadcast SOS Modal */}
      <EmergencyModal
        isOpen={isEmergencyModalOpen}
        onClose={() => setIsEmergencyModalOpen(false)}
        currentUser={currentUser}
        lang={lang}
      />

      {/* User Manager Modal */}
      <UserManagerModal
        isOpen={isUserManagerOpen}
        onClose={() => setIsUserManagerOpen(false)}
      />

      {/* Company Manager Modal */}
      <CompanyManagerModal
        isOpen={isCompanyManagerOpen}
        onClose={() => setIsCompanyManagerOpen(false)}
      />

      {/* Sticky Fixed Bottom Footer with 10-Click Secret Unlock & Ownership Notice */}
      <Footer
        license={license}
        lang={lang}
        onUnlockSecretGateway={() => setIsSecretGatewayOpen(true)}
      />

    </div>
  );
}

import { Language } from '../types';

export const translations = {
  ar: {
    // Header & Brand
    appName: 'منظومة GatePass لإدارة البوابات والتصاريح الأمنية',
    systemTagline: 'المنظومة الأمنية المتكاملة لحراسة وتدقيق البوابات والمجمعات',
    facilityDefault: 'المجمع الصناعي والنفطي الموحد - بوابات 1 و 2',
    adminRoleName: 'لوحة الإدارة الشاملة (Admin)',
    socRoleName: 'غرفة السيطرة والعمليات (SOC)',
    gate1RoleName: 'كابينة حرس بوابة 1 (الشمالية)',
    gate2RoleName: 'كابينة حرس بوابة 2 (الجنوبية)',
    companyRoleName: 'بوابة نداءات وتصاريح الشركات',
    
    // Actions & Buttons
    login: 'تسجيل الدخول',
    logout: 'تسجيل الخروج',
    switchUser: 'تبديل المستخدم',
    login_switch_user: 'تسجيل الدخول / تبديل المستخدم',
    newPass: 'طلب تصريح جديد',
    issue_pass: 'إصدار تصريح',
    panicSos: 'نداء استغاثة وطوارئ',
    liveSyncConnected: 'المزامنة الحية متصلة',
    searchPlaceholder: 'بحث برقم التصريح، اسم الزائر، رقم الهوية، أو لوحة المركبة...',
    filter: 'تصفية',
    all: 'الكل',
    viewCard: 'عرض وطباعة التصريح',
    view_details: 'عرض تفاصيل البطاقة',
    approve: 'موافقة وتصريح',
    reject: 'رفض أمني',
    checkIn: 'تسجيل دخول (دخول الموقع)',
    checkOut: 'تسجيل خروج (مغادرة)',
    renew: 'تمديد الصلاحية',
    deletePass: 'حذف التصريح نهائياً',
    cancelPass: 'إلغاء التصريح',
    confirm: 'تأكيد',
    cancel: 'إلغاء',
    save: 'حفظ التعديلات',
    close: 'إغلاق',
    exportExcel: 'تصدير كشف Excel/CSV',
    exportPdf: 'تصدير تقرير PDF',
    printPass: 'طباعة البطاقة الرسمية',
    actions: 'إجراءات المدير',
    
    // Statuses
    status: 'الحالة',
    status_pending: 'بانتظار السيطرة',
    status_pending_security: 'بانتظار السيطرة',
    status_approved: 'مصرّح وساري',
    status_rejected: 'مرفوض أمنياً',
    status_inside: 'داخل الموقع',
    status_completed: 'مكتمل ومغادر',
    status_expired: 'منتهي الصلاحية',
    status_cancelled: 'ملغي',
    
    // Pass Table Headers
    pass_number: 'رقم التصريح',
    visitor_name: 'اسم الشخص / الزائر',
    company_name: 'الشركة المستضيفة',
    national_id: 'الهوية / الجواز',
    vehicle_plate: 'لوحة المركبة',
    gate: 'البوابة المخصصة',
    validity: 'صلاحية التصريح',

    // Visitor Types
    type_guest: 'زائر / ضيف',
    type_employee: 'موظف',
    type_vip: 'شخصية هامة (VIP)',
    type_contractor: 'مقاول / مهندس',
    type_materials: 'شحن ومعدات',

    // Admin Dashboard Tabs & Sections
    admin_dashboard: 'لوحة الإدارة الشاملة للمسؤول العام',
    company_portal: 'بوابة الشركات المستضافة',
    user_mgmt: 'المستخدمين والصلاحيات',
    company_mgmt: 'الشركات المعتمدة',
    tab_analytics: 'التقارير والرسوم البيانية (Analytics)',
    tab_passes: 'سجل التصاريح والنداءات',
    tab_movements: 'سجل حركات البوابات',
    tab_companies: 'الشركات المعتمدة',
    tab_users: 'حسابات الحرس والمشغلين',
    tab_settings: 'إعدادات المنظومة والنسخ الاحتياطي',

    // KPIs
    total_passes: 'إجمالي التصاريح',
    on_site: 'المتواجدون بالموقع الآن',
    pending_soc_review: 'نداءات بانتظار السيطرة',
    movement_checkin: 'تسجيل دخول (دخول الموقع)',
    movement_checkout: 'تسجيل خروج (مغادرة)',

    // Analytics Labels
    analytics_title: 'مركز التحليلات والمؤشرات الإحصائية الميدانية',
    analytics_subtitle: 'رصد تفاعلي بالرسوم البيانية لنشاط البوابات، تدفق الزوار، وتوزيع الشركات',
    analytics_daily_trend: 'المعدل اليومي للتصاريح والنشاط',
    analytics_company_dist: 'تصنيف التصاريح حسب الشركات المستضيفة',
    analytics_visitor_type: 'توزيع التصاريح حسب نوع الزائر / المهمة',
    analytics_gate_compare: 'مقارنة حركة الدخول والخروج (بوابة 1 مقابل بوابة 2)',
    analytics_hourly_traffic: 'أوقات الذروة وتدفق المركبات والزوار على مدار اليوم',
    analytics_total_passes: 'إجمالي التصاريح الصادرة',
    analytics_active_inside: 'المتواجدون بالموقع الآن',
    analytics_pending_review: 'نداءات بانتظار الموافقة',
    analytics_expired_passes: 'تصاريح منتهية',
    analytics_gate1_total: 'حركات بوابة 1 (الشمالية)',
    analytics_gate2_total: 'حركات بوابة 2 (الجنوبية)',
    
    // Settings & Nomenclature
    settings_nomenclature_title: 'تخصيص أسماء ومسميات المنظومة',
    settings_nomenclature_desc: 'تعديل وتخصيص أسماء البوابات، المراكز، وأقسام النظام لتطابق متطلبات الموقع بدقة',
    settings_backup_title: 'النسخ الاحتياطي التلقائي واليدوي',
    settings_backup_desc: 'جدولة الحفظ التلقائي للبيانات وحفظ النسخ الاحتياطية على السيرفر الخاص بك',
    backup_now: 'أخذ نسخة احتياطية فورية (JSON)',
    restore_backup: 'استعادة نسخة احتياطية من ملف',
    auto_backup_status: 'النسخ الاحتياطي المجدول',
    backup_interval: 'فترة التكرار التلقائي',
    backup_server_path: 'مسار التخزين المقترح على حاسبة السيرفر',
    
    // Reset & Zero-out
    danger_zone: 'منطقة العمليات الحساسة وإعادة التهيئة',
    zero_out_passes: 'تصفير كافة التصاريح وحركات البوابات',
    zero_out_passes_desc: 'مسح سجلات التصاريح السابقة مع الإبقاء على الشركات وحسابات المستخدمين',
    factory_reset: 'تصفير المصنع الشامل للمنظومة (Factory Reset)',
    factory_reset_desc: 'إعادة تعيين المنظومة بالكامل وحذف كافة البيانات واستعادة التكوين الافتراضي',
    
    // Emergency SOS
    emergency_title: 'غرفة البث الأمني الطارئ وإطلاق صافرة الاستغاثة',
    emergency_desc: 'توجيه تعليمات أمنية فورية وتنبيه صريح مع صوت الإنذار للبوابات المستهدفة',
    emergency_target_recipients: 'الجهات المستهدفة بالنداء الطارئ',
    emergency_severity: 'مستوى خطورة البلاغ',
    emergency_custom_msg: 'نص رسالة الطوارئ والتعليمات الميدانية',
    emergency_send_broadcast: 'بث نداء الطوارئ وصافرة الإنذار فوراً',
    emergency_dismiss: 'إنهاء حالة الطوارئ وإسكات الإنذار',
    emergency_active_alert: 'حالة طوارئ نشطة معلنة في المنظومة!',

    // Developer & Copyright
    developer_rights_ar: 'برمجة وتطوير: المهندس علي أحمد عنيد • جميع الحقوق محفوظة',
    developer_rights_en: 'Engineered & Developed by Eng. Ali Ahmed Aneed • All Rights Reserved',
    secret_gateway_title: 'البوابة السرية للترخيص والإدارة الفنية',
    secret_gateway_hint: 'انقر 10 مرات متتالية على شريط حقوق الملكية للدخول'
  },
  en: {
    // Header & Brand
    appName: 'GatePass Security & Access Control Enterprise',
    systemTagline: 'Integrated Security Platform for Industrial & High-Security Gates',
    facilityDefault: 'Unified Industrial & Oil Complex - Gates 1 & 2',
    adminRoleName: 'Comprehensive Admin Dashboard',
    socRoleName: 'Security Operations Center (SOC)',
    gate1RoleName: 'Gate 1 Terminal (North Gate)',
    gate2RoleName: 'Gate 2 Terminal (South Gate)',
    companyRoleName: 'Company Requests Portal',
    
    // Actions & Buttons
    login: 'Log In',
    logout: 'Log Out',
    switchUser: 'Switch User',
    login_switch_user: 'Sign In / Switch User',
    newPass: 'New Pass Request',
    issue_pass: 'Issue Gate Pass',
    panicSos: 'SOS Emergency Panic',
    liveSyncConnected: 'Live Sync Online',
    searchPlaceholder: 'Search by Pass #, Visitor Name, National ID, or Plate...',
    filter: 'Filter',
    all: 'All',
    viewCard: 'View & Print Pass',
    view_details: 'View Badge Details',
    approve: 'Approve Pass',
    reject: 'Security Reject',
    checkIn: 'Check In (Site Entry)',
    checkOut: 'Check Out (Site Exit)',
    renew: 'Extend Duration',
    deletePass: 'Delete Pass Permanently',
    cancelPass: 'Cancel Pass',
    confirm: 'Confirm',
    cancel: 'Cancel',
    save: 'Save Changes',
    close: 'Close',
    exportExcel: 'Export to Excel/CSV',
    exportPdf: 'Export PDF Report',
    printPass: 'Print Badge Card',
    actions: 'Admin Actions',
    
    // Statuses
    status: 'Status',
    status_pending: 'Pending SOC Review',
    status_pending_security: 'Pending SOC Review',
    status_approved: 'Active & Approved',
    status_rejected: 'Security Rejected',
    status_inside: 'Inside Site',
    status_completed: 'Completed & Exited',
    status_expired: 'Expired',
    status_cancelled: 'Cancelled',
    
    // Pass Table Headers
    pass_number: 'Pass #',
    visitor_name: 'Visitor / Subject Name',
    company_name: 'Host Company',
    national_id: 'National ID / Passport',
    vehicle_plate: 'Vehicle Plate',
    gate: 'Assigned Gate',
    validity: 'Validity Duration',

    // Visitor Types
    type_guest: 'Guest / Visitor',
    type_employee: 'Employee',
    type_vip: 'VIP Dignitary',
    type_contractor: 'Contractor / Engineer',
    type_materials: 'Cargo & Materials',

    // Admin Dashboard Tabs & Sections
    admin_dashboard: 'Comprehensive Master Admin Dashboard',
    company_portal: 'Host Companies Portal',
    user_mgmt: 'Users & Permissions',
    company_mgmt: 'Registered Companies',
    tab_analytics: 'Analytics & Visual Charts',
    tab_passes: 'Passes & Requests Log',
    tab_movements: 'Gate Movements Log',
    tab_companies: 'Registered Companies',
    tab_users: 'Guards & Staff Accounts',
    tab_settings: 'System Settings & Backups',

    // KPIs
    total_passes: 'Total Passes',
    on_site: 'On-Site Now',
    pending_soc_review: 'Pending SOC Review',
    movement_checkin: 'Check-In Entry',
    movement_checkout: 'Check-Out Exit',

    // Analytics Labels
    analytics_title: 'Operational Analytics & Gate Telemetry',
    analytics_subtitle: 'Real-time interactive data visualizer for gate throughput, visitor types, and company distribution',
    analytics_daily_trend: 'Daily Pass Volume & Flow',
    analytics_company_dist: 'Passes Distribution by Host Company',
    analytics_visitor_type: 'Passes Breakdown by Visitor Classification',
    analytics_gate_compare: 'Gate Traffic Comparison (Gate 1 vs Gate 2)',
    analytics_hourly_traffic: 'Peak Traffic & Hourly Distribution',
    analytics_total_passes: 'Total Issued Passes',
    analytics_active_inside: 'Currently Inside Site',
    analytics_pending_review: 'Pending SOC Approval',
    analytics_expired_passes: 'Expired Passes',
    analytics_gate1_total: 'Gate 1 Movements (North)',
    analytics_gate2_total: 'Gate 2 Movements (South)',
    
    // Settings & Nomenclature
    settings_nomenclature_title: 'System Nomenclature & Renaming',
    settings_nomenclature_desc: 'Customize terminal names, gates, and system labels to match your site specifications',
    settings_backup_title: 'Automated & Manual Data Backups',
    settings_backup_desc: 'Configure automated background snapshots and save copies to your local server machine',
    backup_now: 'Export Instant Backup (JSON)',
    restore_backup: 'Restore Database from JSON File',
    auto_backup_status: 'Automated Scheduled Backup',
    backup_interval: 'Backup Interval Frequency',
    backup_server_path: 'Target Server Machine Backup Directory',
    
    // Reset & Zero-out
    danger_zone: 'Sensitive Maintenance & Factory Reset',
    zero_out_passes: 'Zero-out All Passes & Movements',
    zero_out_passes_desc: 'Wipe all historical pass and movement logs while keeping company and user accounts intact',
    factory_reset: 'Full Factory Reset',
    factory_reset_desc: 'Completely reset system state to factory defaults',
    
    // Emergency SOS
    emergency_title: 'Security Emergency & SOS Broadcast Center',
    emergency_desc: 'Direct immediate tactical orders and audible alarm to targeted gate terminals',
    emergency_target_recipients: 'Targeted Terminals & Gates',
    emergency_severity: 'Alert Severity Level',
    emergency_custom_msg: 'Tactical Instructions / Emergency Message',
    emergency_send_broadcast: 'Broadcast SOS & Trigger Siren Now',
    emergency_dismiss: 'Dismiss Emergency & Silence Alarm',
    emergency_active_alert: 'ACTIVE EMERGENCY ALERT BROADCASTED!',

    // Developer & Copyright
    developer_rights_ar: 'برمجة وتطوير: المهندس علي أحمد عنيد • جميع الحقوق محفوظة',
    developer_rights_en: 'Engineered & Developed by Eng. Ali Ahmed Aneed • All Rights Reserved',
    secret_gateway_title: 'Secret Gateway & Technical Licensing',
    secret_gateway_hint: 'Click 10 consecutive times on the copyright footer to unlock'
  }
};

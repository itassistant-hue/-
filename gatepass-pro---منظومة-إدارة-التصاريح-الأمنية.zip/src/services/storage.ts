import { 
  Company, 
  GateMovement, 
  PassRequest, 
  PassStatus, 
  PassType, 
  SystemLicense, 
  SystemNotification, 
  User,
  Language,
  EmergencyBroadcast,
  CustomNomenclature,
  AutoBackupSettings,
  GateDefinition,
  CustomFieldDefinition,
  SystemViewDefinition
} from '../types';

const STORAGE_KEYS = {
  USERS: 'gatepass_users_v2',
  COMPANIES: 'gatepass_companies_v2',
  PASSES: 'gatepass_passes_v2',
  MOVEMENTS: 'gatepass_movements_v2',
  LICENSE: 'gatepass_license_v2',
  CURRENT_USER: 'gatepass_current_user_v2',
  NOTIFICATIONS: 'gatepass_notifications_v2',
  LANGUAGE: 'gatepass_language_v2',
  NOMENCLATURE: 'gatepass_nomenclature_v2',
  AUTO_BACKUP: 'gatepass_auto_backup_v2',
  EMERGENCY: 'gatepass_emergency_v2',
  INITIALIZED: 'gatepass_initialized_v2',
  SESSION_AUTHENTICATED: 'gatepass_session_auth_v2',
  GATES: 'gatepass_gates_v2',
  CUSTOM_FIELDS: 'gatepass_custom_fields_v2',
  SYSTEM_VIEWS: 'gatepass_system_views_v2',
};

export const DEFAULT_GATES: GateDefinition[] = [
  {
    id: 'gate_1',
    nameAr: 'كابينة حرس بوابة 1 (الشمالية)',
    nameEn: 'Gate 1 Terminal (North Gate)',
    location: 'المدخل الشمالي الرئيسي للمجمع',
    type: 'entry_exit',
    enabled: true,
    isSystemDefault: true,
    color: 'blue'
  },
  {
    id: 'gate_2',
    nameAr: 'كابينة حرس بوابة 2 (الجنوبية)',
    nameEn: 'Gate 2 Terminal (South Gate)',
    location: 'المدخل الجنوبي واللوجستي',
    type: 'entry_exit',
    enabled: true,
    isSystemDefault: true,
    color: 'indigo'
  },
  {
    id: 'gate_3',
    nameAr: 'كابينة حرس بوابة 3 (الشرقية والخدمات)',
    nameEn: 'Gate 3 Terminal (East Cargo Gate)',
    location: 'قطاع المستودعات والورش الشرقية',
    type: 'cargo',
    enabled: true,
    isSystemDefault: false,
    color: 'emerald'
  }
];

export const DEFAULT_CUSTOM_FIELDS: CustomFieldDefinition[] = [
  {
    id: 'f_escort',
    key: 'escortPerson',
    labelAr: 'الشخص / الجهة المستضيفة',
    labelEn: 'Host / Escort Person',
    type: 'text',
    category: 'visitor',
    required: false,
    enabled: true,
    isSystemDefault: true,
    placeholderAr: 'اسم الموظف أو القسم المستضيف'
  },
  {
    id: 'f_plate',
    key: 'vehiclePlate',
    labelAr: 'رقم لوحة المركبة',
    labelEn: 'Vehicle Plate Number',
    type: 'text',
    category: 'vehicle',
    required: false,
    enabled: true,
    isSystemDefault: true,
    placeholderAr: 'مثال: بغداد 12345 خصوصي / نقل'
  },
  {
    id: 'f_model',
    key: 'vehicleModel',
    labelAr: 'نوع وطراز المركبة',
    labelEn: 'Vehicle Model & Make',
    type: 'text',
    category: 'vehicle',
    required: false,
    enabled: true,
    isSystemDefault: true,
    placeholderAr: 'مثال: تويوتا هايلوكس، شاحنة مرسيدس، بيك آب'
  },
  {
    id: 'f_materials',
    key: 'materialsList',
    labelAr: 'قائمة المواد والأجهزة والمعدات',
    labelEn: 'Materials & Equipment List',
    type: 'textarea',
    category: 'materials',
    required: false,
    enabled: true,
    isSystemDefault: true,
    placeholderAr: 'تفاصيل المواد والأدوات المصرح بإدخالها أو إخراجها'
  },
  {
    id: 'f_photo',
    key: 'photoUrl',
    labelAr: 'صورة الزائر / الهوية / الشحنة',
    labelEn: 'Visitor / ID / Cargo Photo',
    type: 'text',
    category: 'visitor',
    required: false,
    enabled: true,
    isSystemDefault: true
  },
  {
    id: 'f_dept',
    key: 'cf_department',
    labelAr: 'القسم أو الموقع المستهدف بالزيارة',
    labelEn: 'Target Department / Site Unit',
    type: 'text',
    category: 'custom',
    required: false,
    enabled: true,
    isSystemDefault: false,
    placeholderAr: 'مثال: قطاع الهندسة، إدارة الحفر، مستودع B4'
  },
  {
    id: 'f_job_title',
    key: 'cf_job_title',
    labelAr: 'المسمى الوظيفي / التخصص',
    labelEn: 'Job Title / Specialization',
    type: 'text',
    category: 'custom',
    required: false,
    enabled: true,
    isSystemDefault: false,
    placeholderAr: 'مثال: مهندس موقع، فني كهرباء، سائق ناقلة'
  },
  {
    id: 'f_permit_no',
    key: 'cf_work_permit',
    labelAr: 'رقم تصريح العمل المسبق (Work Permit)',
    labelEn: 'Work Permit / HSE Permit No',
    type: 'text',
    category: 'custom',
    required: false,
    enabled: true,
    isSystemDefault: false,
    placeholderAr: 'مثال: HSE-WP-8819'
  }
];

export const DEFAULT_SYSTEM_VIEWS: SystemViewDefinition[] = [
  {
    id: 'admin',
    nameAr: 'لوحة الإدارة الشاملة (Admin)',
    nameEn: 'Admin Dashboard',
    icon: 'Sliders',
    enabled: true,
    isSystemDefault: true,
    roleRequired: 'admin'
  },
  {
    id: 'soc',
    nameAr: 'السيطرة والعمليات الأمنية (SOC)',
    nameEn: 'Security Operations (SOC)',
    icon: 'Radio',
    enabled: true,
    isSystemDefault: true,
    roleRequired: 'security_ops'
  },
  {
    id: 'gate_1',
    nameAr: 'كابينة حرس بوابة 1 (الشمالية)',
    nameEn: 'Gate 1 Terminal',
    icon: 'DoorOpen',
    enabled: true,
    isSystemDefault: true,
    gateId: 'gate_1'
  },
  {
    id: 'gate_2',
    nameAr: 'كابينة حرس بوابة 2 (الجنوبية)',
    nameEn: 'Gate 2 Terminal',
    icon: 'DoorOpen',
    enabled: true,
    isSystemDefault: true,
    gateId: 'gate_2'
  },
  {
    id: 'gate_3',
    nameAr: 'كابينة حرس بوابة 3 (الشرقية والخدمات)',
    nameEn: 'Gate 3 Terminal',
    icon: 'DoorOpen',
    enabled: true,
    isSystemDefault: false,
    gateId: 'gate_3'
  },
  {
    id: 'company',
    nameAr: 'بوابة الشركات والجهات الطالبة',
    nameEn: 'Company Portal',
    icon: 'Building2',
    enabled: true,
    isSystemDefault: true,
    roleRequired: 'company_user'
  }
];

export const DEFAULT_NOMENCLATURE: CustomNomenclature = {
  appNameAr: 'منظومة GatePass لإدارة البوابات والتصاريح الأمنية',
  appNameEn: 'GatePass Security & Access Control Enterprise',
  facilityNameAr: 'المجمع الصناعي والنفطي الموحد - بوابات 1 و 2',
  facilityNameEn: 'Unified Industrial & Oil Complex - Gates 1 & 2',
  gate1NameAr: 'كابينة حرس بوابة 1 (الشمالية)',
  gate1NameEn: 'Gate 1 Terminal (North Gate)',
  gate2NameAr: 'كابينة حرس بوابة 2 (الجنوبية)',
  gate2NameEn: 'Gate 2 Terminal (South Gate)',
  socNameAr: 'غرفة السيطرة والعمليات (SOC)',
  socNameEn: 'Security Operations Center (SOC)',
  adminNameAr: 'لوحة الإدارة الشاملة (Master Admin)',
  adminNameEn: 'Comprehensive Admin Dashboard',
  companyPortalNameAr: 'بوابة نداءات وتصاريح الشركات',
  companyPortalNameEn: 'Company Requests Portal',
  kpiTotalPassesAr: 'إجمالي التصاريح الصادرة',
  kpiTotalPassesEn: 'Total Issued Passes',
  kpiOnSiteAr: 'المتواجدون بالموقع الآن',
  kpiOnSiteEn: 'On-Site Personnel & Visitors',
  kpiPendingAr: 'نداءات بانتظار السيطرة (SOC)',
  kpiPendingEn: 'Pending SOC Review',
  kpiExpiredAr: 'التصاريح المنتهية',
  kpiExpiredEn: 'Expired Passes',
  kpiGate1Ar: 'حركات بوابة 1 (الشمالية)',
  kpiGate1En: 'Gate 1 Movements',
  kpiGate2Ar: 'حركات بوابة 2 (الجنوبية)',
  kpiGate2En: 'Gate 2 Movements',
  maxSiteCapacity: 500,
};

export const DEFAULT_AUTO_BACKUP: AutoBackupSettings = {
  enabled: true,
  intervalMinutes: 360, // every 6 hours
  autoDownload: true,
  lastBackupTime: new Date().toISOString(),
  serverDestinationName: 'C:\\GatePass_Server_Backups\\',
};

// Initial Seed Companies (12 Companies)
const INITIAL_COMPANIES: Company[] = [
  {
    id: 'comp_1',
    name: 'شركة نفط ميسان وبغداد للطاقة',
    code: 'NOC-01',
    contactPerson: 'م. عمر عبد الرحمن',
    phone: '07801234567',
    email: 'ops@nocoil-iq.com',
    sector: 'النفط والغاز والطاقة',
    locationInsideSite: 'المجمع الجنوبي - مبنى B2',
    active: true,
    createdAt: '2025-01-10T08:00:00.000Z'
  },
  {
    id: 'comp_2',
    name: 'شركة الرافدين لتقنية المعلومات والاتصالات',
    code: 'RIC-02',
    contactPerson: 'م. سارة قاسم',
    phone: '07709876543',
    email: 'info@rafidain-tech.iq',
    sector: 'الاتصالات والشبكات',
    locationInsideSite: 'المجمع التقني - الطابق الثالث',
    active: true,
    createdAt: '2025-01-12T09:00:00.000Z'
  },
  {
    id: 'comp_3',
    name: 'شركة أور للإنشاءات والمقاولات الهندسية',
    code: 'URC-03',
    contactPerson: 'أ. حيدر جاسم',
    phone: '07812233445',
    email: 'contracts@ur-construction.com',
    sector: 'المقاولات والإنشاءات',
    locationInsideSite: 'ساحة المشاريع الهندسية C1',
    active: true,
    createdAt: '2025-01-15T10:00:00.000Z'
  },
  {
    id: 'comp_4',
    name: 'شركة سومر للخدمات اللوجستية والنقل الدولي',
    code: 'SLS-04',
    contactPerson: 'أ. أحمد فاروق',
    phone: '07504455667',
    email: 'logistics@sumer-logistics.iq',
    sector: 'النقل والشحن واللوجستيات',
    locationInsideSite: 'منطقة المستودعات المركزية W3',
    active: true,
    createdAt: '2025-01-20T08:30:00.000Z'
  },
  {
    id: 'comp_5',
    name: 'شركة دجلة للأمن والسلامة المهنية والبيئة',
    code: 'TSS-05',
    contactPerson: 'د. ليث كمال',
    phone: '07718899001',
    email: 'hse@tigris-safety.com',
    sector: 'السلامة والصحة المهنية (HSE)',
    locationInsideSite: 'مقر السلامة الميداني H1',
    active: true,
    createdAt: '2025-01-25T11:00:00.000Z'
  },
  {
    id: 'comp_6',
    name: 'شركة بابل للحلول الهندسية والصيانة الكهروميكانيكية',
    code: 'BBL-06',
    contactPerson: 'م. فراس مهدي',
    phone: '07823344556',
    email: 'support@babel-engineering.iq',
    sector: 'الصيانة الكهروميكانيكية',
    locationInsideSite: 'ورشة الصيانة العامة M4',
    active: true,
    createdAt: '2025-02-01T09:15:00.000Z'
  },
  {
    id: 'comp_7',
    name: 'شركة آشور للاستشارات والتطوير الإداري',
    code: 'ASH-07',
    contactPerson: 'د. رنا خالد',
    phone: '07705566778',
    email: 'consult@ashur-consulting.com',
    sector: 'الاستشارات وإدارة المشاريع',
    locationInsideSite: 'المبنى الإداري الرئيسي - الطابق الثاني',
    active: true,
    createdAt: '2025-02-05T10:30:00.000Z'
  },
  {
    id: 'comp_8',
    name: 'شركة الفاو للخدمات النفطية المساندة',
    code: 'FAW-08',
    contactPerson: 'أ. سلام عبد الأمير',
    phone: '07806677889',
    email: 'ops@faw-petroleum.com',
    sector: 'الخدمات النفطية والمساندة',
    locationInsideSite: 'المجمع الجنوبي - ورش الدعم',
    active: true,
    createdAt: '2025-02-10T12:00:00.000Z'
  },
  {
    id: 'comp_9',
    name: 'شركة نينوى للتموين والإعاشة المركزية',
    code: 'NIN-09',
    contactPerson: 'الشيف نبيل يوسف',
    phone: '07517788990',
    email: 'catering@nineveh-food.iq',
    sector: 'التموين والأغذية والإعاشة',
    locationInsideSite: 'مجمع المطاعم والخدمات الغذائية K2',
    active: true,
    createdAt: '2025-02-12T07:00:00.000Z'
  },
  {
    id: 'comp_10',
    name: 'شركة أوروك الدولية للتخليص الجمركي والمناولة',
    code: 'URK-10',
    contactPerson: 'أ. مصطفى حميد',
    phone: '07728899112',
    email: 'customs@uruk-shipping.com',
    sector: 'التخليص الجمركي والمناولة',
    locationInsideSite: 'ساحة الفحص الجمركي G1',
    active: true,
    createdAt: '2025-02-15T08:45:00.000Z'
  },
  {
    id: 'comp_11',
    name: 'شركة المنصور لتأجير المعدات والرافعات الثقيلة',
    code: 'MAN-11',
    contactPerson: 'أ. عمار شاكر',
    phone: '07831122334',
    email: 'heavy@mansour-machinery.iq',
    sector: 'المعدات الثقيلة والآليات',
    locationInsideSite: 'ساحة الآليات والمعدات R2',
    active: true,
    createdAt: '2025-02-18T10:00:00.000Z'
  },
  {
    id: 'comp_12',
    name: 'شركة الهدى للخدمات الطبية والإسعاف الميداني',
    code: 'HUD-12',
    contactPerson: 'د. وسام طارق',
    phone: '07739988776',
    email: 'clinic@huda-medical.iq',
    sector: 'الخدمات الطبية والرعاية الصحية',
    locationInsideSite: 'العيادة الطبية الميدانية C0',
    active: true,
    createdAt: '2025-02-20T08:00:00.000Z'
  }
];

// Initial Seed Users
const INITIAL_USERS: User[] = [
  {
    id: 'user_admin',
    username: 'admin',
    password: '7941631', // Specific requested password
    fullName: 'م. علي السعدي (مدير الـ IT والأمن الرقمي)',
    role: 'admin',
    phone: '07800001122',
    active: true,
    createdAt: '2025-01-01T00:00:00.000Z'
  },
  {
    id: 'user_soc',
    username: 'security_soc',
    password: '123',
    fullName: 'الملازم حسام البصري (ضابط السيطرة والعمليات الأمنية)',
    role: 'security_ops',
    phone: '07800003344',
    active: true,
    createdAt: '2025-01-01T00:00:00.000Z'
  },
  {
    id: 'user_gate1',
    username: 'gate1_guard',
    password: '123',
    fullName: 'الرقيب أول عباس كريم (كابينة حرس بوابة 1 - الشمالية)',
    role: 'gate_1',
    gateId: 'gate_1',
    phone: '07800005566',
    active: true,
    createdAt: '2025-01-01T00:00:00.000Z'
  },
  {
    id: 'user_gate2',
    username: 'gate2_guard',
    password: '123',
    fullName: 'العريف مصطفى جبار (كابينة حرس بوابة 2 - الجنوبية)',
    role: 'gate_2',
    gateId: 'gate_2',
    phone: '07800007788',
    active: true,
    createdAt: '2025-01-01T00:00:00.000Z'
  },
  {
    id: 'user_comp1',
    username: 'company_oil',
    password: '123',
    fullName: 'أ. عمر عبد الرحمن (ممثل شركة نفط ميسان وبغداد)',
    role: 'company_user',
    companyId: 'comp_1',
    companyName: 'شركة نفط ميسان وبغداد للطاقة',
    phone: '07801234567',
    active: true,
    createdAt: '2025-01-10T08:00:00.000Z'
  },
  {
    id: 'user_comp2',
    username: 'company_tech',
    password: '123',
    fullName: 'م. سارة قاسم (ممثلة شركة الرافدين للتقنية)',
    role: 'company_user',
    companyId: 'comp_2',
    companyName: 'شركة الرافدين لتقنية المعلومات والاتصالات',
    phone: '07709876543',
    active: true,
    createdAt: '2025-01-12T09:00:00.000Z'
  },
  {
    id: 'user_comp3',
    username: 'company_ur',
    password: '123',
    fullName: 'أ. حيدر جاسم (ممثل شركة أور للمقاولات)',
    role: 'company_user',
    companyId: 'comp_3',
    companyName: 'شركة أور للإنشاءات والمقاولات الهندسية',
    phone: '07812233445',
    active: true,
    createdAt: '2025-01-15T10:00:00.000Z'
  }
];

// Initial License Configuration
const INITIAL_LICENSE: SystemLicense = {
  licenseKey: 'GP-ENTERPRISE-7941-6310-8899-SEC',
  clientName: 'الشركة الأمنية المتحدة للحراسة وحماية المنشآت',
  facilityName: 'المجمع الصناعي والنفطي الموحد - بوابات 1 و 2',
  appNameAr: 'منظومة GatePass لإدارة البوابات والتصاريح الأمنية',
  appNameEn: 'GatePass Security & Access Control Enterprise',
  facilityNameAr: 'المجمع الصناعي والنفطي الموحد - بوابات 1 و 2',
  facilityNameEn: 'Unified Industrial & Oil Complex - Gates 1 & 2',
  issuedDate: '2025-01-01T00:00:00.000Z',
  expiryDate: '2028-12-31T23:59:59.000Z',
  status: 'active',
  maxAllowedGates: 4,
  maxCompanies: 50,
  hardwareFingerprint: 'SRV-NODE-7941-X86-SECURE',
  secretGatewayCode: '7941631',
  encryptedSignature: 'SHA256:e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
  maintenanceMode: false,
  developerNameAr: 'المهندس علي أحمد عنيد',
  developerNameEn: 'Eng. Ali Ahmed Aneed',
  developerTitleAr: 'المطور والمصمم البرمجي للمنظومة',
  developerTitleEn: 'Software Architect & System Engineer',
  copyrightAr: 'برمجة وتطوير: المهندس علي أحمد عنيد • جميع الحقوق محفوظة',
  copyrightEn: 'Engineered & Developed by Eng. Ali Ahmed Aneed • All Rights Reserved',
  features: {
    vipFastTrack: true,
    smsNotifications: true,
    barcodeScanning: true,
    unlimitedArchive: true,
    multiGateSync: true
  }
};

// Generate realistic initial passes
const now = new Date();
const hoursAgo = (h: number) => new Date(now.getTime() - h * 3600 * 1000).toISOString();
const hoursLater = (h: number) => new Date(now.getTime() + h * 3600 * 1000).toISOString();

const INITIAL_PASSES: PassRequest[] = [
  {
    id: 'pass_101',
    passNumber: 'GP-2026-0811',
    qrCodeData: 'GP:0811:VIP:JOHN_SMITH:NOC-01',
    companyId: 'comp_1',
    companyName: 'شركة نفط ميسان وبغداد للطاقة',
    requesterName: 'م. عمر عبد الرحمن',
    requesterPhone: '07801234567',
    visitorName: 'السيد جون سميث (John Smith)',
    nationalIdOrPassport: 'P-98421045GB',
    nationality: 'بريطاني',
    visitorPhone: '+447911122334',
    visitorType: 'vip',
    escortPerson: 'المهندس رائد الخفاجي',
    vehiclePlate: 'بغداد 48921 خصوصي',
    vehicleModel: 'تويوتا لاندكروزر VXR أسود',
    destinationGate: 'both',
    purpose: 'اجتماع مجلس الإدارة وتفقد مشاريع الطاقة المشتركة',
    validFrom: hoursAgo(1),
    validTo: hoursLater(8),
    durationHours: 9,
    durationLabel: '9 ساعات (يوم عمل)',
    status: 'inside', // currently inside
    entryTime: hoursAgo(0.5),
    entryGate: 'gate_1',
    entryOperator: 'الرقيب أول عباس كريم',
    logs: [
      {
        id: 'log_1',
        timestamp: hoursAgo(2),
        action: 'requested',
        actionArabic: 'تم إرسال النداء من الشركة',
        operatorName: 'م. عمر عبد الرحمن',
        operatorRole: 'ممثل شركة نفط ميسان'
      },
      {
        id: 'log_2',
        timestamp: hoursAgo(1.5),
        action: 'approved',
        actionArabic: 'تمت الموافقة الأمنية ومنح أولوية VIP',
        operatorName: 'الملازم حسام البصري',
        operatorRole: 'السيطرة الأمنية'
      },
      {
        id: 'log_3',
        timestamp: hoursAgo(0.5),
        action: 'check_in',
        actionArabic: 'تسجيل دخول عبر بوابة 1',
        gate: 'gate_1',
        gateArabic: 'بوابة 1 (الشمالية)',
        operatorName: 'الرقيب أول عباس كريم',
        operatorRole: 'حرس البوابة 1'
      }
    ],
    createdAt: hoursAgo(2)
  },
  {
    id: 'pass_102',
    passNumber: 'GP-2026-0812',
    qrCodeData: 'GP:0812:MATERIALS:SLS-04',
    companyId: 'comp_4',
    companyName: 'شركة سومر للخدمات اللوجستية والنقل الدولي',
    requesterName: 'أ. أحمد فاروق',
    requesterPhone: '07504455667',
    visitorName: 'السائق محمود طه البدري',
    nationalIdOrPassport: '198823491024',
    nationality: 'عراقي',
    visitorPhone: '07703344556',
    visitorType: 'materials',
    vehiclePlate: 'بصرة 12948 حمل',
    vehicleModel: 'شاحنة مرسيدس أكتروس بيضاء',
    destinationGate: 'gate_2',
    purpose: 'إدخال شحنة كابلات ألياف ضوئية ومعدات حفر لشركة الرافدين',
    materialsList: 'عدد 14 بكرة كابلات فايبر أوبتك + 4 محولات كهرباء ضغط عالي',
    validFrom: hoursAgo(3),
    validTo: hoursLater(5),
    durationHours: 8,
    durationLabel: '8 ساعات',
    status: 'approved',
    approvedBy: 'الملازم حسام البصري',
    approvedAt: hoursAgo(2),
    logs: [
      {
        id: 'log_4',
        timestamp: hoursAgo(3),
        action: 'requested',
        actionArabic: 'تم إرسال نداء دخول شحنة ومواد',
        operatorName: 'أ. أحمد فاروق',
        operatorRole: 'ممثل شركة سومر'
      },
      {
        id: 'log_5',
        timestamp: hoursAgo(2),
        action: 'approved',
        actionArabic: 'تمت الموافقة الأمنية وتخصيص بوابة 2 للشاحنات',
        operatorName: 'الملازم حسام البصري',
        operatorRole: 'السيطرة الأمنية'
      }
    ],
    createdAt: hoursAgo(3)
  },
  {
    id: 'pass_103',
    passNumber: 'GP-2026-0813',
    qrCodeData: 'GP:0813:GUEST:RIC-02',
    companyId: 'comp_2',
    companyName: 'شركة الرافدين لتقنية المعلومات والاتصالات',
    requesterName: 'م. سارة قاسم',
    requesterPhone: '07709876543',
    visitorName: 'المهندس كرم ضياء السامرائي',
    nationalIdOrPassport: '199284759103',
    nationality: 'عراقي',
    visitorPhone: '07819922883',
    visitorType: 'contractor',
    vehiclePlate: 'أربيل 77319 خصوصي',
    destinationGate: 'both',
    purpose: 'صيانة وتحديث خوادم السيرفرات لمركز البيانات الرئيسي',
    validFrom: hoursAgo(0.5),
    validTo: hoursLater(3),
    durationHours: 3.5,
    durationLabel: '3.5 ساعات',
    status: 'pending_security', // waiting approval
    logs: [
      {
        id: 'log_6',
        timestamp: hoursAgo(0.5),
        action: 'requested',
        actionArabic: 'تم إرسال طلب التصريح - بانتظار تدقيق العمليات',
        operatorName: 'م. سارة قاسم',
        operatorRole: 'ممثلة شركة الرافدين'
      }
    ],
    createdAt: hoursAgo(0.5)
  },
  {
    id: 'pass_104',
    passNumber: 'GP-2026-0790',
    qrCodeData: 'GP:0790:EXPIRED:URC-03',
    companyId: 'comp_3',
    companyName: 'شركة أور للإنشاءات والمقاولات الهندسية',
    requesterName: 'أ. حيدر جاسم',
    requesterPhone: '07812233445',
    visitorName: 'الفني وسام كريم الدليمي',
    nationalIdOrPassport: '199011883344',
    nationality: 'عراقي',
    visitorPhone: '07721144558',
    visitorType: 'contractor',
    vehiclePlate: 'بغداد 33810 أجرة',
    destinationGate: 'gate_1',
    purpose: 'تركيب سقالات البناء في قطاع C1',
    validFrom: hoursAgo(24),
    validTo: hoursAgo(4), // Expired 4 hours ago!
    durationHours: 20,
    durationLabel: '20 ساعة (منتهي الصلاحية)',
    status: 'approved', // was approved, but now time is past validTo -> automatic expiration!
    approvedBy: 'الملازم حسام البصري',
    approvedAt: hoursAgo(23),
    logs: [
      {
        id: 'log_7',
        timestamp: hoursAgo(24),
        action: 'requested',
        actionArabic: 'تم إرسال الطلب',
        operatorName: 'أ. حيدر جاسم',
        operatorRole: 'ممثل شركة أور'
      },
      {
        id: 'log_8',
        timestamp: hoursAgo(23),
        action: 'approved',
        actionArabic: 'تم التصريح',
        operatorName: 'الملازم حسام البصري',
        operatorRole: 'السيطرة الأمنية'
      }
    ],
    createdAt: hoursAgo(24)
  },
  {
    id: 'pass_105',
    passNumber: 'GP-2026-0805',
    qrCodeData: 'GP:0805:REJECTED:ASH-07',
    companyId: 'comp_7',
    companyName: 'شركة آشور للاستشارات والتطوير الإداري',
    requesterName: 'د. رنا خالد',
    requesterPhone: '07705566778',
    visitorName: 'أحمد ماجد العبيدي',
    nationalIdOrPassport: '199544332211',
    nationality: 'عراقي',
    visitorPhone: '07805544332',
    visitorType: 'guest',
    destinationGate: 'both',
    purpose: 'زيارة غير مجدولة للمبنى الإداري',
    validFrom: hoursAgo(10),
    validTo: hoursAgo(2),
    durationHours: 8,
    durationLabel: '8 ساعات',
    status: 'rejected',
    rejectionReason: 'عدم اكتمال الفحص الأمني المسبق / يرجى مراجعة إدارة الموقع وإعادة إرسال النداء قبل 24 ساعة',
    approvedBy: 'الملازم حسام البصري',
    approvedAt: hoursAgo(9),
    logs: [
      {
        id: 'log_9',
        timestamp: hoursAgo(10),
        action: 'requested',
        actionArabic: 'طلب تصريح دخول',
        operatorName: 'د. رنا خالد',
        operatorRole: 'ممثل شركة آشور'
      },
      {
        id: 'log_10',
        timestamp: hoursAgo(9),
        action: 'rejected',
        actionArabic: 'رفض أمني: عدم اكتمال التدقيق المسبق',
        operatorName: 'الملازم حسام البصري',
        operatorRole: 'السيطرة الأمنية'
      }
    ],
    createdAt: hoursAgo(10)
  },
  {
    id: 'pass_106',
    passNumber: 'GP-2026-0814',
    qrCodeData: 'GP:0814:VIP:HUD-12',
    companyId: 'comp_12',
    companyName: 'شركة الهدى للخدمات الطبية والإسعاف الميداني',
    requesterName: 'د. وسام طارق',
    requesterPhone: '07739988776',
    visitorName: 'الدكتور طارق الهاشمي (استشاري جراحة)',
    nationalIdOrPassport: '197500192834',
    nationality: 'عراقي',
    visitorPhone: '07701199228',
    visitorType: 'vip',
    vehiclePlate: 'بغداد 11209 خصوصي',
    destinationGate: 'both',
    purpose: 'معاينة حالات حرجة وتفقد التجهيزات الطبية في العيادة',
    validFrom: hoursAgo(1),
    validTo: hoursLater(12),
    durationHours: 13,
    durationLabel: '13 ساعة',
    status: 'approved',
    approvedBy: 'الملازم حسام البصري',
    approvedAt: hoursAgo(0.8),
    logs: [
      {
        id: 'log_11',
        timestamp: hoursAgo(1),
        action: 'requested',
        actionArabic: 'نداء دخول طارئ لكادر طبي VIP',
        operatorName: 'د. وسام طارق',
        operatorRole: 'ممثل شركة الهدى'
      },
      {
        id: 'log_12',
        timestamp: hoursAgo(0.8),
        action: 'approved',
        actionArabic: 'موافقة فورية ومسار سريع VIP لكافة البوابات',
        operatorName: 'الملازم حسام البصري',
        operatorRole: 'السيطرة الأمنية'
      }
    ],
    createdAt: hoursAgo(1)
  }
];

const INITIAL_MOVEMENTS: GateMovement[] = [
  {
    id: 'mov_1',
    passId: 'pass_101',
    passNumber: 'GP-2026-0811',
    visitorName: 'السيد جون سميث (John Smith)',
    visitorType: 'vip',
    companyName: 'شركة نفط ميسان وبغداد للطاقة',
    gateId: 'gate_1',
    gateName: 'بوابة 1 (الشمالية)',
    movementType: 'check_in',
    operatorName: 'الرقيب أول عباس كريم',
    timestamp: hoursAgo(0.5),
    vehiclePlate: 'بغداد 48921 خصوصي',
    notes: 'تم فحص السيارة والمركبة وتوفير مرافقة أمنية VIP'
  }
];

// Memory cache fallback in case localStorage is restricted or quota exceeded
const memoryCache: Record<string, string> = {};

function safeGet(key: string): string | null {
  if (memoryCache[key] !== undefined) {
    return memoryCache[key];
  }
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      const val = window.localStorage.getItem(key);
      if (val !== null) {
        memoryCache[key] = val;
        return val;
      }
    }
  } catch {
    // fallback
  }
  return null;
}

function safeSet(key: string, value: string): void {
  memoryCache[key] = value;
  try {
    if (typeof window !== 'undefined' && window.localStorage) {
      window.localStorage.setItem(key, value);
    }
  } catch (err) {
    console.warn(`[StorageService] localStorage.setItem failed for key "${key}", retained in memoryCache:`, err);
  }
}

// Broadcast Channel for live multi-tab communication
let broadcastChannel: BroadcastChannel | null = null;
if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
  try {
    broadcastChannel = new BroadcastChannel('gatepass_sync_channel');
  } catch {
    // fallback
  }
}

class StorageService {
  private serverVersion: number = 0;
  private pushTimer: any = null;
  private pollTimer: any = null;
  private isSyncingWithServer: boolean = false;
  private isServerOnline: boolean = false;

  constructor() {
    this.init();
    if (typeof window !== 'undefined') {
      // Start background network server synchronization
      setTimeout(() => {
        this.initServerSync();
      }, 300);
    }
  }

  public init() {
    try {
      const initialized = safeGet(STORAGE_KEYS.INITIALIZED);
      if (!initialized) {
        safeSet(STORAGE_KEYS.USERS, JSON.stringify(INITIAL_USERS));
        safeSet(STORAGE_KEYS.COMPANIES, JSON.stringify(INITIAL_COMPANIES));
        safeSet(STORAGE_KEYS.PASSES, JSON.stringify(INITIAL_PASSES));
        safeSet(STORAGE_KEYS.MOVEMENTS, JSON.stringify(INITIAL_MOVEMENTS));
        safeSet(STORAGE_KEYS.LICENSE, JSON.stringify(INITIAL_LICENSE));
        safeSet(STORAGE_KEYS.CURRENT_USER, JSON.stringify(INITIAL_USERS[0])); // Default Admin
        safeSet(STORAGE_KEYS.INITIALIZED, 'true');
      }
    } catch (e) {
      console.error('Failed to init storage', e);
    }
  }

  // --- LOCAL NETWORK SERVER REAL-TIME SYNC ---
  public isNetworkServerOnline(): boolean {
    return this.isServerOnline;
  }

  public async getServerInfo(): Promise<any> {
    try {
      const res = await fetch('/api/server-info');
      if (res.ok) {
        const json = await res.json();
        return json;
      }
      return null;
    } catch {
      return null;
    }
  }

  public getFullStateSnapshot(): Record<string, any> {
    return {
      users: this.getUsers(),
      companies: this.getCompanies(),
      passes: this.getPasses(),
      movements: this.getMovements(),
      license: this.getLicense(),
      nomenclature: this.getNomenclature(),
      autoBackupSettings: this.getAutoBackupSettings(),
      gates: this.getGates(),
      customFields: this.getCustomFields(),
      systemViews: this.getSystemViews(),
      emergency: this.getEmergencyBroadcasts(),
      notifications: this.getNotifications()
    };
  }

  public applyServerSnapshot(data: Record<string, any>, newVersion?: number) {
    if (!data || typeof data !== 'object') return;
    this.isSyncingWithServer = true;
    try {
      if (Array.isArray(data.users)) safeSet(STORAGE_KEYS.USERS, JSON.stringify(data.users));
      if (Array.isArray(data.companies)) safeSet(STORAGE_KEYS.COMPANIES, JSON.stringify(data.companies));
      if (Array.isArray(data.passes)) safeSet(STORAGE_KEYS.PASSES, JSON.stringify(data.passes));
      if (Array.isArray(data.movements)) safeSet(STORAGE_KEYS.MOVEMENTS, JSON.stringify(data.movements));
      if (Array.isArray(data.gates)) safeSet(STORAGE_KEYS.GATES, JSON.stringify(data.gates));
      if (Array.isArray(data.customFields)) safeSet(STORAGE_KEYS.CUSTOM_FIELDS, JSON.stringify(data.customFields));
      if (Array.isArray(data.systemViews)) safeSet(STORAGE_KEYS.SYSTEM_VIEWS, JSON.stringify(data.systemViews));
      if (data.license) safeSet(STORAGE_KEYS.LICENSE, JSON.stringify(data.license));
      if (data.nomenclature) safeSet(STORAGE_KEYS.NOMENCLATURE, JSON.stringify(data.nomenclature));
      if (data.autoBackupSettings) safeSet(STORAGE_KEYS.AUTO_BACKUP, JSON.stringify(data.autoBackupSettings));
      if (Array.isArray(data.emergency)) safeSet(STORAGE_KEYS.EMERGENCY, JSON.stringify(data.emergency));
      if (Array.isArray(data.notifications)) safeSet(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(data.notifications));

      if (typeof newVersion === 'number') {
        this.serverVersion = newVersion;
      }
      this.notifyChange('server_sync_applied');
    } finally {
      this.isSyncingWithServer = false;
    }
  }

  public async initServerSync() {
    try {
      const res = await fetch('/api/db');
      if (res.ok) {
        this.isServerOnline = true;
        const json = await res.json();
        if (json && json.success) {
          if (json.data && Object.keys(json.data).length > 0) {
            // Server already has data on disk, sync down to this computer
            this.applyServerSnapshot(json.data, json.version);
          } else {
            // Server data is empty on disk, upload current client data to seed disk
            this.scheduleServerPush(true);
          }
        }
      }
    } catch {
      // Standalone browser mode or offline
      this.isServerOnline = false;
    }

    // Start polling loop to sync changes across different computers on the LAN
    this.startNetworkPolling();
  }

  private startNetworkPolling() {
    if (this.pollTimer) clearInterval(this.pollTimer);
    this.pollTimer = setInterval(async () => {
      if (this.isSyncingWithServer) return;
      try {
        const res = await fetch('/api/poll-version');
        if (res.ok) {
          this.isServerOnline = true;
          const json = await res.json();
          if (json && typeof json.version === 'number') {
            if (this.serverVersion === 0) {
              this.serverVersion = json.version;
            } else if (json.version > this.serverVersion) {
              // Another PC on the LAN updated the database! Pull fresh data
              const dbRes = await fetch('/api/db');
              if (dbRes.ok) {
                const dbJson = await dbRes.json();
                if (dbJson && dbJson.data) {
                  this.applyServerSnapshot(dbJson.data, dbJson.version);
                }
              }
            }
          }
        }
      } catch {
        this.isServerOnline = false;
      }
    }, 2000);
  }

  public scheduleServerPush(immediate = false) {
    if (this.isSyncingWithServer) return;
    if (this.pushTimer) clearTimeout(this.pushTimer);

    const doPush = async () => {
      try {
        const snapshot = this.getFullStateSnapshot();
        const res = await fetch('/api/db', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(snapshot)
        });
        if (res.ok) {
          const json = await res.json();
          if (json && typeof json.version === 'number') {
            this.serverVersion = json.version;
          }
          this.isServerOnline = true;
        }
      } catch {
        this.isServerOnline = false;
      }
    };

    if (immediate) {
      doPush();
    } else {
      this.pushTimer = setTimeout(doPush, 500);
    }
  }

  private notifyChange(event: string, data?: unknown) {
    // Also trigger background server sync when data changes locally
    if (!this.isSyncingWithServer && event !== 'server_sync_applied') {
      this.scheduleServerPush();
    }

    if (typeof window !== 'undefined') {
      try {
        window.dispatchEvent(new CustomEvent('gatepass_storage_event', { detail: { event, data } }));
      } catch {
        // ignore
      }
      if (broadcastChannel) {
        try {
          broadcastChannel.postMessage({ event, data });
        } catch {
          // ignore
        }
      }
    }
  }

  public subscribe(callback: (event: string, data?: unknown) => void): () => void {
    if (typeof window === 'undefined') return () => {};

    const handleCustomEvent = (e: Event) => {
      const customEvent = e as CustomEvent;
      if (customEvent.detail) {
        callback(customEvent.detail.event, customEvent.detail.data);
      }
    };

    const handleBroadcast = (e: MessageEvent) => {
      if (e.data && e.data.event) {
        callback(e.data.event, e.data.data);
      }
    };

    window.addEventListener('gatepass_storage_event', handleCustomEvent);
    if (broadcastChannel) {
      broadcastChannel.addEventListener('message', handleBroadcast);
    }

    return () => {
      window.removeEventListener('gatepass_storage_event', handleCustomEvent);
      if (broadcastChannel) {
        broadcastChannel.removeEventListener('message', handleBroadcast);
      }
    };
  }

  // --- PASS EXPIRY HELPER ---
  public isExpired(pass: PassRequest): boolean {
    if (!pass.validTo) return false;
    const expiryDate = new Date(pass.validTo);
    return new Date() > expiryDate;
  }

  public getEffectiveStatus(pass: PassRequest): PassStatus {
    if (pass.status === 'rejected' || pass.status === 'cancelled') {
      return pass.status;
    }
    if (this.isExpired(pass)) {
      return 'expired';
    }
    return pass.status;
  }

  // --- PASSES ---
  public getPasses(): PassRequest[] {
    try {
      const raw = safeGet(STORAGE_KEYS.PASSES);
      if (!raw) return INITIAL_PASSES;
      const passes: PassRequest[] = JSON.parse(raw);
      return Array.isArray(passes) ? passes : INITIAL_PASSES;
    } catch {
      return INITIAL_PASSES;
    }
  }

  public savePasses(passes: PassRequest[]) {
    safeSet(STORAGE_KEYS.PASSES, JSON.stringify(passes));
    this.notifyChange('passes_updated');
  }

  public createPass(newPass: Omit<PassRequest, 'id' | 'passNumber' | 'qrCodeData' | 'createdAt' | 'logs'>, operator: User): PassRequest {
    const passes = this.getPasses();
    const counter = 1000 + passes.length + 1;
    const currentYear = new Date().getFullYear();
    const passNumber = `GP-${currentYear}-${counter}`;
    
    const pass: PassRequest = {
      ...newPass,
      id: 'pass_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7),
      passNumber,
      qrCodeData: `GP:${passNumber}:${newPass.visitorType}:${newPass.nationalIdOrPassport}`,
      createdAt: new Date().toISOString(),
      logs: [
        {
          id: 'log_' + Date.now(),
          timestamp: new Date().toISOString(),
          action: 'requested',
          actionArabic: 'تم إرسال النداء والتصريح من الشركة',
          operatorName: operator.fullName,
          operatorRole: operator.role === 'admin' ? 'مدير النظام' : 'ممثل الشركة'
        }
      ]
    };

    passes.unshift(pass);
    this.savePasses(passes);
    this.addNotification({
      title: 'نداء تصريح جديد 📋',
      message: `أرسلت ${pass.companyName} تصريح دخول لـ (${pass.visitorName})`,
      type: pass.visitorType === 'vip' ? 'warning' : 'info',
      passId: pass.id
    });
    return pass;
  }

  public approvePass(passId: string, operator: User, notes?: string): PassRequest | null {
    const passes = this.getPasses();
    const index = passes.findIndex(p => p.id === passId);
    if (index === -1) return null;

    const pass = passes[index];
    pass.status = 'approved';
    pass.approvedBy = operator.fullName;
    pass.approvedAt = new Date().toISOString();
    if (notes) pass.securityNotes = notes;

    pass.logs.unshift({
      id: 'log_' + Date.now(),
      timestamp: new Date().toISOString(),
      action: 'approved',
      actionArabic: 'تمت الموافقة والتصريح الأمني',
      operatorName: operator.fullName,
      operatorRole: 'السيطرة الأمنية / SOC',
      notes
    });

    this.savePasses(passes);
    this.addNotification({
      title: 'تم التصريح والموافقة الأمنية ✅',
      message: `تم اعتماد تصريح (${pass.visitorName}) التابع لـ ${pass.companyName}`,
      type: 'success',
      passId: pass.id
    });
    return pass;
  }

  public rejectPass(passId: string, operator: User, reason: string): PassRequest | null {
    const passes = this.getPasses();
    const index = passes.findIndex(p => p.id === passId);
    if (index === -1) return null;

    const pass = passes[index];
    pass.status = 'rejected';
    pass.rejectionReason = reason;

    pass.logs.unshift({
      id: 'log_' + Date.now(),
      timestamp: new Date().toISOString(),
      action: 'rejected',
      actionArabic: `رفض أمني: ${reason}`,
      operatorName: operator.fullName,
      operatorRole: 'السيطرة الأمنية / SOC',
      notes: reason
    });

    this.savePasses(passes);
    this.addNotification({
      title: 'تم رفض التصريح أمنياً ⛔',
      message: `تم رفض تصريح (${pass.visitorName}) - السبب: ${reason}`,
      type: 'warning',
      passId: pass.id
    });
    return pass;
  }

  public checkIn(passId: string, gateId: string, operator: User, notes?: string): PassRequest | null {
    const passes = this.getPasses();
    const index = passes.findIndex(p => p.id === passId);
    if (index === -1) return null;

    const pass = passes[index];
    const allGates = this.getGates();
    const currentGate = allGates.find(g => g.id === gateId);
    const gateLabel = currentGate?.nameAr || (gateId === 'gate_1' ? 'بوابة 1 (الشمالية)' : gateId === 'gate_2' ? 'بوابة 2 (الجنوبية)' : gateId);

    pass.status = 'inside';
    pass.entryTime = new Date().toISOString();
    pass.entryGate = gateId;
    pass.entryOperator = operator.fullName;

    pass.logs.unshift({
      id: 'log_' + Date.now(),
      timestamp: new Date().toISOString(),
      action: 'check_in',
      actionArabic: `تسجيل دخول عبر ${gateLabel}`,
      gate: gateId,
      gateArabic: gateLabel,
      operatorName: operator.fullName,
      operatorRole: gateLabel,
      notes
    });

    this.savePasses(passes);

    // Record movement
    this.addMovement({
      passId: pass.id,
      passNumber: pass.passNumber,
      visitorName: pass.visitorName,
      visitorType: pass.visitorType,
      companyName: pass.companyName,
      gateId,
      gateName: gateLabel,
      movementType: 'check_in',
      operatorName: operator.fullName,
      vehiclePlate: pass.vehiclePlate,
      notes
    });

    this.addNotification({
      title: `تسجيل دخول: ${pass.visitorName} 🟢`,
      message: `دخل الموقع عبر ${gateLabel} - ${pass.companyName}`,
      type: pass.visitorType === 'vip' ? 'warning' : 'success',
      passId: pass.id
    });

    return pass;
  }

  public checkOut(passId: string, gateId: string, operator: User, notes?: string): PassRequest | null {
    const passes = this.getPasses();
    const index = passes.findIndex(p => p.id === passId);
    if (index === -1) return null;

    const pass = passes[index];
    const allGates = this.getGates();
    const currentGate = allGates.find(g => g.id === gateId);
    const gateLabel = currentGate?.nameAr || (gateId === 'gate_1' ? 'بوابة 1 (الشمالية)' : gateId === 'gate_2' ? 'بوابة 2 (الجنوبية)' : gateId);

    pass.status = 'completed';
    pass.exitTime = new Date().toISOString();
    pass.exitGate = gateId;
    pass.exitOperator = operator.fullName;

    pass.logs.unshift({
      id: 'log_' + Date.now(),
      timestamp: new Date().toISOString(),
      action: 'check_out',
      actionArabic: `تسجيل خروج ومغادرة الموقع عبر ${gateLabel}`,
      gate: gateId,
      gateArabic: gateLabel,
      operatorName: operator.fullName,
      operatorRole: gateLabel,
      notes
    });

    this.savePasses(passes);

    // Record movement
    this.addMovement({
      passId: pass.id,
      passNumber: pass.passNumber,
      visitorName: pass.visitorName,
      visitorType: pass.visitorType,
      companyName: pass.companyName,
      gateId,
      gateName: gateLabel,
      movementType: 'check_out',
      operatorName: operator.fullName,
      vehiclePlate: pass.vehiclePlate,
      notes
    });

    this.addNotification({
      title: `تسجيل خروج: ${pass.visitorName} 🚪`,
      message: `غادر الموقع عبر ${gateLabel} - ${pass.companyName}`,
      type: 'info',
      passId: pass.id
    });

    return pass;
  }

  public extendPass(passId: string, additionalHours: number, operator: User): PassRequest | null {
    const passes = this.getPasses();
    const index = passes.findIndex(p => p.id === passId);
    if (index === -1) return null;

    const pass = passes[index];
    const currentExpiry = new Date(pass.validTo);
    const newExpiry = new Date(currentExpiry.getTime() + additionalHours * 3600 * 1000);
    pass.validTo = newExpiry.toISOString();
    pass.durationHours += additionalHours;
    pass.durationLabel = `${pass.durationHours} ساعة (تم التمديد)`;
    
    // If was expired, revert to inside or approved
    if (pass.entryTime && !pass.exitTime) {
      pass.status = 'inside';
    } else if (!pass.entryTime) {
      pass.status = 'approved';
    }

    pass.logs.unshift({
      id: 'log_' + Date.now(),
      timestamp: new Date().toISOString(),
      action: 'renewed',
      actionArabic: `تم تمديد صلاحية التصريح بـ ${additionalHours} ساعة`,
      operatorName: operator.fullName,
      operatorRole: operator.role
    });

    this.savePasses(passes);
    return pass;
  }

  // --- MOVEMENTS ---
  public getMovements(): GateMovement[] {
    try {
      const raw = safeGet(STORAGE_KEYS.MOVEMENTS);
      if (!raw) return INITIAL_MOVEMENTS;
      const list = JSON.parse(raw);
      return Array.isArray(list) ? list : INITIAL_MOVEMENTS;
    } catch {
      return INITIAL_MOVEMENTS;
    }
  }

  private addMovement(movement: Omit<GateMovement, 'id' | 'timestamp'>) {
    const list = this.getMovements();
    const entry: GateMovement = {
      ...movement,
      id: 'mov_' + Date.now(),
      timestamp: new Date().toISOString()
    };
    list.unshift(entry);
    safeSet(STORAGE_KEYS.MOVEMENTS, JSON.stringify(list));
    this.notifyChange('movements_updated');
  }

  // --- COMPANIES ---
  public getCompanies(): Company[] {
    try {
      const raw = safeGet(STORAGE_KEYS.COMPANIES);
      if (!raw) return INITIAL_COMPANIES;
      const list = JSON.parse(raw);
      return Array.isArray(list) ? list : INITIAL_COMPANIES;
    } catch {
      return INITIAL_COMPANIES;
    }
  }

  public saveCompany(company: Company) {
    const list = this.getCompanies();
    const idx = list.findIndex(c => c.id === company.id);
    if (idx >= 0) {
      list[idx] = company;
    } else {
      list.push(company);
    }
    safeSet(STORAGE_KEYS.COMPANIES, JSON.stringify(list));
    this.notifyChange('companies_updated');
  }

  public deleteCompany(id: string) {
    let list = this.getCompanies();
    list = list.filter(c => c.id !== id);
    safeSet(STORAGE_KEYS.COMPANIES, JSON.stringify(list));
    this.notifyChange('companies_updated');
  }

  // --- USERS ---
  public getUsers(): User[] {
    try {
      const raw = safeGet(STORAGE_KEYS.USERS);
      if (!raw) return INITIAL_USERS;
      const list = JSON.parse(raw);
      return Array.isArray(list) ? list : INITIAL_USERS;
    } catch {
      return INITIAL_USERS;
    }
  }

  public saveUser(user: User) {
    const list = this.getUsers();
    const idx = list.findIndex(u => u.id === user.id);
    if (idx >= 0) {
      list[idx] = user;
    } else {
      list.push(user);
    }
    safeSet(STORAGE_KEYS.USERS, JSON.stringify(list));
    this.notifyChange('users_updated');
  }

  public deleteUser(id: string) {
    let list = this.getUsers();
    list = list.filter(u => u.id !== id);
    safeSet(STORAGE_KEYS.USERS, JSON.stringify(list));
    this.notifyChange('users_updated');
  }

  // --- CURRENT USER ---
  public getCurrentUser(): User {
    try {
      const raw = safeGet(STORAGE_KEYS.CURRENT_USER);
      if (raw) return JSON.parse(raw);
      return INITIAL_USERS[0];
    } catch {
      return INITIAL_USERS[0];
    }
  }

  public setCurrentUser(user: User) {
    safeSet(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    this.notifyChange('user_switched', user);
  }

  // --- SESSION AUTHENTICATION ---
  public isSessionAuthenticated(): boolean {
    try {
      const raw = safeGet(STORAGE_KEYS.SESSION_AUTHENTICATED);
      return raw === 'true';
    } catch {
      return false;
    }
  }

  public setSessionAuthenticated(auth: boolean) {
    safeSet(STORAGE_KEYS.SESSION_AUTHENTICATED, auth ? 'true' : 'false');
    this.notifyChange('session_auth_changed', auth);
  }

  public logout() {
    this.setSessionAuthenticated(false);
    this.notifyChange('user_logged_out');
  }

  // --- LICENSE ---
  public getLicense(): SystemLicense {
    try {
      const raw = safeGet(STORAGE_KEYS.LICENSE);
      if (raw) {
        const parsed = JSON.parse(raw);
        return {
          ...INITIAL_LICENSE,
          ...parsed,
          features: {
            ...INITIAL_LICENSE.features,
            ...(parsed.features || {})
          }
        };
      }
      return INITIAL_LICENSE;
    } catch {
      return INITIAL_LICENSE;
    }
  }

  public updateLicense(license: SystemLicense) {
    safeSet(STORAGE_KEYS.LICENSE, JSON.stringify(license));
    this.notifyChange('license_updated', license);
  }

  // --- NOTIFICATIONS ---
  public getNotifications(): SystemNotification[] {
    try {
      const raw = safeGet(STORAGE_KEYS.NOTIFICATIONS);
      if (raw) {
        const list = JSON.parse(raw);
        return Array.isArray(list) ? list : [];
      }
      return [];
    } catch {
      return [];
    }
  }

  public addNotification(notif: Omit<SystemNotification, 'id' | 'timestamp' | 'read'>) {
    const list = this.getNotifications();
    const item: SystemNotification = {
      ...notif,
      id: 'notif_' + Date.now(),
      timestamp: new Date().toISOString(),
      read: false
    };
    list.unshift(item);
    // keep maximum 50
    if (list.length > 50) list.pop();
    safeSet(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(list));
    this.notifyChange('notification_added', item);
  }

  public markNotificationsRead() {
    const list = this.getNotifications().map(n => ({ ...n, read: true }));
    safeSet(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(list));
    this.notifyChange('notifications_read');
  }

  // --- PASS MANAGEMENT (DELETE / PURGE) ---
  public deletePass(id: string): boolean {
    let passes = this.getPasses();
    const initialLen = passes.length;
    passes = passes.filter(p => p.id !== id);
    if (passes.length !== initialLen) {
      this.savePasses(passes);
      this.notifyChange('pass_deleted', id);
      return true;
    }
    return false;
  }

  public clearAllPasses() {
    this.savePasses([]);
    safeSet(STORAGE_KEYS.MOVEMENTS, JSON.stringify([]));
    this.notifyChange('all_passes_cleared');
  }

  // --- LANGUAGE ---
  public getLanguage(): Language {
    try {
      const raw = safeGet(STORAGE_KEYS.LANGUAGE);
      return raw === 'en' ? 'en' : 'ar';
    } catch {
      return 'ar';
    }
  }

  public setLanguage(lang: Language) {
    safeSet(STORAGE_KEYS.LANGUAGE, lang);
    this.notifyChange('language_changed', lang);
  }

  // --- NOMENCLATURE / RENAMING ---
  public getNomenclature(): CustomNomenclature {
    try {
      const raw = safeGet(STORAGE_KEYS.NOMENCLATURE);
      if (raw) {
        return { ...DEFAULT_NOMENCLATURE, ...JSON.parse(raw) };
      }
      return DEFAULT_NOMENCLATURE;
    } catch {
      return DEFAULT_NOMENCLATURE;
    }
  }

  public updateNomenclature(nomenclature: CustomNomenclature) {
    safeSet(STORAGE_KEYS.NOMENCLATURE, JSON.stringify(nomenclature));
    this.notifyChange('nomenclature_updated', nomenclature);
  }

  // --- AUTO BACKUP SETTINGS ---
  public getAutoBackupSettings(): AutoBackupSettings {
    try {
      const raw = safeGet(STORAGE_KEYS.AUTO_BACKUP);
      if (raw) {
        return { ...DEFAULT_AUTO_BACKUP, ...JSON.parse(raw) };
      }
      return DEFAULT_AUTO_BACKUP;
    } catch {
      return DEFAULT_AUTO_BACKUP;
    }
  }

  public updateAutoBackupSettings(settings: AutoBackupSettings) {
    safeSet(STORAGE_KEYS.AUTO_BACKUP, JSON.stringify(settings));
    this.notifyChange('auto_backup_updated', settings);
  }

  // --- GATES MANAGEMENT (إدارة وإضافة وحذف البوابات) ---
  public getGates(): GateDefinition[] {
    try {
      const raw = safeGet(STORAGE_KEYS.GATES);
      if (raw) {
        const list = JSON.parse(raw);
        if (Array.isArray(list) && list.length > 0) return list;
      }
      return DEFAULT_GATES;
    } catch {
      return DEFAULT_GATES;
    }
  }

  public saveGates(gates: GateDefinition[]) {
    safeSet(STORAGE_KEYS.GATES, JSON.stringify(gates));
    this.notifyChange('gates_updated', gates);
  }

  public addGate(gate: Omit<GateDefinition, 'id'>): GateDefinition {
    const gates = this.getGates();
    const newId = 'gate_' + (gates.length + 1) + '_' + Date.now().toString().slice(-4);
    const newGate: GateDefinition = {
      ...gate,
      id: newId,
      isSystemDefault: false
    };
    gates.push(newGate);
    this.saveGates(gates);
    return newGate;
  }

  public updateGate(id: string, updates: Partial<GateDefinition>): GateDefinition | null {
    const gates = this.getGates();
    const index = gates.findIndex(g => g.id === id);
    if (index === -1) return null;
    gates[index] = { ...gates[index], ...updates };
    this.saveGates(gates);
    return gates[index];
  }

  public deleteGate(id: string): boolean {
    const gates = this.getGates();
    const target = gates.find(g => g.id === id);
    if (!target) return false;
    // Delete only custom gates or when there is at least one gate remaining
    if (gates.length <= 1) return false;
    const filtered = gates.filter(g => g.id !== id);
    this.saveGates(filtered);
    return true;
  }

  // --- CUSTOM FIELDS MANAGEMENT (إدارة وإضافة وحذف الخانات) ---
  public getCustomFields(): CustomFieldDefinition[] {
    try {
      const raw = safeGet(STORAGE_KEYS.CUSTOM_FIELDS);
      if (raw) {
        const list = JSON.parse(raw);
        if (Array.isArray(list) && list.length > 0) return list;
      }
      return DEFAULT_CUSTOM_FIELDS;
    } catch {
      return DEFAULT_CUSTOM_FIELDS;
    }
  }

  public saveCustomFields(fields: CustomFieldDefinition[]) {
    safeSet(STORAGE_KEYS.CUSTOM_FIELDS, JSON.stringify(fields));
    this.notifyChange('custom_fields_updated', fields);
  }

  public addCustomField(field: Omit<CustomFieldDefinition, 'id' | 'key'> & { key?: string }): CustomFieldDefinition {
    const fields = this.getCustomFields();
    const uniqueId = 'f_custom_' + Date.now();
    const newKey = field.key || ('cf_' + Date.now().toString().slice(-6));
    const newField: CustomFieldDefinition = {
      ...field,
      id: uniqueId,
      key: newKey,
      isSystemDefault: false
    };
    fields.push(newField);
    this.saveCustomFields(fields);
    return newField;
  }

  public updateCustomField(id: string, updates: Partial<CustomFieldDefinition>): CustomFieldDefinition | null {
    const fields = this.getCustomFields();
    const index = fields.findIndex(f => f.id === id);
    if (index === -1) return null;
    fields[index] = { ...fields[index], ...updates };
    this.saveCustomFields(fields);
    return fields[index];
  }

  public deleteCustomField(id: string): boolean {
    const fields = this.getCustomFields();
    const target = fields.find(f => f.id === id);
    if (!target) return false;
    // Allow deleting custom fields or disabling system fields
    const filtered = fields.filter(f => f.id !== id);
    this.saveCustomFields(filtered);
    return true;
  }

  // --- SYSTEM VIEWS MANAGEMENT (إدارة وتفعيل واجهات المنظومة) ---
  public getSystemViews(): SystemViewDefinition[] {
    try {
      const raw = safeGet(STORAGE_KEYS.SYSTEM_VIEWS);
      if (raw) {
        const list = JSON.parse(raw);
        if (Array.isArray(list) && list.length > 0) return list;
      }
      return DEFAULT_SYSTEM_VIEWS;
    } catch {
      return DEFAULT_SYSTEM_VIEWS;
    }
  }

  public saveSystemViews(views: SystemViewDefinition[]) {
    safeSet(STORAGE_KEYS.SYSTEM_VIEWS, JSON.stringify(views));
    this.notifyChange('system_views_updated', views);
  }

  public updateSystemView(id: string, updates: Partial<SystemViewDefinition>): SystemViewDefinition | null {
    const views = this.getSystemViews();
    const index = views.findIndex(v => v.id === id);
    if (index === -1) return null;
    views[index] = { ...views[index], ...updates };
    this.saveSystemViews(views);
    return views[index];
  }

  // --- EMERGENCY BROADCASTS ---
  public getEmergencyBroadcasts(): EmergencyBroadcast[] {
    try {
      const raw = safeGet(STORAGE_KEYS.EMERGENCY);
      if (raw) {
        const list = JSON.parse(raw);
        return Array.isArray(list) ? list : [];
      }
      return [];
    } catch {
      return [];
    }
  }

  public getActiveEmergencyBroadcast(): EmergencyBroadcast | null {
    const list = this.getEmergencyBroadcasts();
    return list.find(b => b.active) || null;
  }

  public sendEmergencyBroadcast(broadcast: Omit<EmergencyBroadcast, 'id' | 'timestamp' | 'active'>): EmergencyBroadcast {
    const list = this.getEmergencyBroadcasts();
    const item: EmergencyBroadcast = {
      ...broadcast,
      id: 'sos_' + Date.now(),
      timestamp: new Date().toISOString(),
      active: true,
      soundAlert: broadcast.soundAlert ?? true
    };
    // Prepend active broadcast
    list.unshift(item);
    safeSet(STORAGE_KEYS.EMERGENCY, JSON.stringify(list));
    
    // Also push a high priority notification
    this.addNotification({
      title: '🚨 ' + item.title,
      message: item.message,
      type: 'emergency'
    });

    this.notifyChange('emergency_broadcast_active', item);
    return item;
  }

  public dismissEmergencyBroadcast(id: string) {
    const list = this.getEmergencyBroadcasts().map(b => 
      b.id === id ? { ...b, active: false } : b
    );
    safeSet(STORAGE_KEYS.EMERGENCY, JSON.stringify(list));
    this.notifyChange('emergency_broadcast_dismissed', id);
  }

  // --- FULL SYSTEM EXPORT & RESTORE ---
  public exportBackupJSON(): string {
    const data = {
      version: '2.5',
      exportDate: new Date().toISOString(),
      license: this.getLicense(),
      nomenclature: this.getNomenclature(),
      autoBackupSettings: this.getAutoBackupSettings(),
      gates: this.getGates(),
      customFields: this.getCustomFields(),
      systemViews: this.getSystemViews(),
      users: this.getUsers(),
      companies: this.getCompanies(),
      passes: this.getPasses(),
      movements: this.getMovements(),
      notifications: this.getNotifications()
    };
    return JSON.stringify(data, null, 2);
  }

  public importBackupJSON(jsonStr: string): { success: boolean; message: string } {
    try {
      const data = JSON.parse(jsonStr);
      if (!data || typeof data !== 'object') {
        return { success: false, message: 'ملف غير صالح' };
      }
      if (data.users && Array.isArray(data.users)) {
        safeSet(STORAGE_KEYS.USERS, JSON.stringify(data.users));
      }
      if (data.companies && Array.isArray(data.companies)) {
        safeSet(STORAGE_KEYS.COMPANIES, JSON.stringify(data.companies));
      }
      if (data.passes && Array.isArray(data.passes)) {
        safeSet(STORAGE_KEYS.PASSES, JSON.stringify(data.passes));
      }
      if (data.movements && Array.isArray(data.movements)) {
        safeSet(STORAGE_KEYS.MOVEMENTS, JSON.stringify(data.movements));
      }
      if (data.gates && Array.isArray(data.gates)) {
        safeSet(STORAGE_KEYS.GATES, JSON.stringify(data.gates));
      }
      if (data.customFields && Array.isArray(data.customFields)) {
        safeSet(STORAGE_KEYS.CUSTOM_FIELDS, JSON.stringify(data.customFields));
      }
      if (data.systemViews && Array.isArray(data.systemViews)) {
        safeSet(STORAGE_KEYS.SYSTEM_VIEWS, JSON.stringify(data.systemViews));
      }
      if (data.license) {
        safeSet(STORAGE_KEYS.LICENSE, JSON.stringify(data.license));
      }
      if (data.nomenclature) {
        safeSet(STORAGE_KEYS.NOMENCLATURE, JSON.stringify(data.nomenclature));
      }
      if (data.autoBackupSettings) {
        safeSet(STORAGE_KEYS.AUTO_BACKUP, JSON.stringify(data.autoBackupSettings));
      }
      this.notifyChange('backup_restored');
      return { success: true, message: 'تم استعادة النسخة الاحتياطية بنجاح' };
    } catch (err: any) {
      return { success: false, message: 'خطأ في معالجة ملف النسخ الاحتياطي: ' + err.message };
    }
  }

  // --- RESET DEMO ---
  public resetToDemo() {
    safeSet(STORAGE_KEYS.USERS, JSON.stringify(INITIAL_USERS));
    safeSet(STORAGE_KEYS.COMPANIES, JSON.stringify(INITIAL_COMPANIES));
    safeSet(STORAGE_KEYS.PASSES, JSON.stringify(INITIAL_PASSES));
    safeSet(STORAGE_KEYS.MOVEMENTS, JSON.stringify(INITIAL_MOVEMENTS));
    safeSet(STORAGE_KEYS.LICENSE, JSON.stringify(INITIAL_LICENSE));
    safeSet(STORAGE_KEYS.NOMENCLATURE, JSON.stringify(DEFAULT_NOMENCLATURE));
    safeSet(STORAGE_KEYS.GATES, JSON.stringify(DEFAULT_GATES));
    safeSet(STORAGE_KEYS.CUSTOM_FIELDS, JSON.stringify(DEFAULT_CUSTOM_FIELDS));
    safeSet(STORAGE_KEYS.SYSTEM_VIEWS, JSON.stringify(DEFAULT_SYSTEM_VIEWS));
    safeSet(STORAGE_KEYS.CURRENT_USER, JSON.stringify(INITIAL_USERS[0]));
    safeSet(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify([]));
    safeSet(STORAGE_KEYS.EMERGENCY, JSON.stringify([]));
    this.notifyChange('reset_complete');
  }

  public factoryResetSystem() {
    try {
      localStorage.clear();
    } catch {}
    this.resetToDemo();
  }
}

export const storageService = new StorageService();

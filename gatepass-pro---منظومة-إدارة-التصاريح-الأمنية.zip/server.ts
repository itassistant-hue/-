import express from 'express';
import path from 'path';
import fs from 'fs';
import os from 'os';
import { createServer as createViteServer } from 'vite';

const PORT = 3000;
const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'gatepass_db.json');

// Ensure data folder exists
if (!fs.existsSync(DATA_DIR)) {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  } catch (err) {
    console.error('Failed to create data directory:', err);
  }
}

// In-memory cache & version tracking
let dbVersion = 1;
let inMemoryDB: Record<string, any> | null = null;

function loadDatabaseFromFile() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const raw = fs.readFileSync(DB_FILE, 'utf-8');
      inMemoryDB = JSON.parse(raw);
      console.log(`[GatePass Server] Loaded database from disk (${Object.keys(inMemoryDB || {}).length} keys)`);
    }
  } catch (err) {
    console.error('[GatePass Server] Error reading database file:', err);
  }
}

function saveDatabaseToFile(data: Record<string, any>) {
  try {
    inMemoryDB = data;
    dbVersion++;
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
  } catch (err) {
    console.error('[GatePass Server] Error saving database file:', err);
  }
}

// Load initial on boot
loadDatabaseFromFile();

// Helper to get local network IPv4 addresses
function getLocalNetworkIPs(): string[] {
  const interfaces = os.networkInterfaces();
  const addresses: string[] = [];

  for (const name of Object.keys(interfaces)) {
    const netList = interfaces[name];
    if (!netList) continue;
    for (const net of netList) {
      // IPv4 and not internal loopback
      if (net.family === 'IPv4' && !net.internal) {
        addresses.push(net.address);
      }
    }
  }
  return addresses;
}

async function startServer() {
  const app = express();

  // Middleware for JSON parsing with ample limit for photos/attachments
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // CORS headers so any device in the LAN can communicate
  app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
    if (req.method === 'OPTIONS') {
      return res.sendStatus(200);
    }
    next();
  });

  // --- API ROUTES ---

  // Health check
  app.get('/api/health', (req, res) => {
    res.json({ 
      status: 'ok', 
      name: 'GatePass Central Server',
      timestamp: new Date().toISOString() 
    });
  });

  // Server Info & LAN IPs for other computers
  app.get('/api/server-info', (req, res) => {
    const lanIps = getLocalNetworkIPs();
    const hostname = os.hostname();
    const primaryIp = lanIps.length > 0 ? lanIps[0] : 'localhost';

    res.json({
      success: true,
      hostname,
      port: PORT,
      lanIps,
      primaryIp,
      primaryUrl: `http://${primaryIp}:${PORT}`,
      allUrls: lanIps.map(ip => `http://${ip}:${PORT}`),
      dbVersion,
      platform: os.platform(),
      uptimeSeconds: Math.floor(process.uptime()),
      serverTime: new Date().toISOString()
    });
  });

  // Get full central database
  app.get('/api/db', (req, res) => {
    if (!inMemoryDB) {
      loadDatabaseFromFile();
    }
    res.json({
      success: true,
      version: dbVersion,
      data: inMemoryDB || null
    });
  });

  // Save/Update full central database
  app.post('/api/db', (req, res) => {
    try {
      const incomingData = req.body;
      if (incomingData && typeof incomingData === 'object') {
        saveDatabaseToFile(incomingData);
        return res.json({
          success: true,
          version: dbVersion,
          message: 'Database persisted to host server disk successfully'
        });
      }
      res.status(400).json({ success: false, error: 'Invalid data payload' });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err?.message || 'Failed to save' });
    }
  });

  // Polling version check for ultra-fast multi-device synchronization
  app.get('/api/poll-version', (req, res) => {
    res.json({
      version: dbVersion,
      timestamp: Date.now()
    });
  });

  // Vite middleware in dev or static files in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    const ips = getLocalNetworkIPs();
    console.log(`\n======================================================`);
    console.log(`🚀 [GatePass Pro] Central Host Server Running on Port ${PORT}`);
    console.log(`🌐 Local Host:   http://localhost:${PORT}`);
    ips.forEach(ip => {
      console.log(`📡 LAN Network:  http://${ip}:${PORT}  (Connect from other PCs!)`);
    });
    console.log(`======================================================\n`);
  });
}

startServer();

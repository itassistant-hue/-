@echo off
setlocal
title Enterprise System - Data & Database Backup

echo ========================================================
echo    Enterprise System - Automatic Backup
echo ========================================================
echo.

:: Generate timestamp YYYY-MM-DD_HHMMSS
for /f "tokens=2 delims==" %%I in ('wmic os get localdatetime /value') do set datetime=%%I
set TIMESTAMP=%datetime:~0,4%-%datetime:~4,2%-%datetime:~6,2%_%datetime:~8,2%%datetime:~10,2%%datetime:~12,2%

set BACKUP_DIR=backups\backup_%TIMESTAMP%

echo [1/3] Creating target backup folder: %BACKUP_DIR%...
if not exist "%BACKUP_DIR%" mkdir "%BACKUP_DIR%"

echo [2/3] Backing up configuration, logs, and system data...
if exist ".env" copy ".env" "%BACKUP_DIR%\.env.bak" >nul
if exist "logs" xcopy "logs" "%BACKUP_DIR%\logs\" /E /I /Q /Y >nul

:: Also call live API snapshot backup if server is running
powershell -Command "try { $res = Invoke-RestMethod -Uri 'http://localhost:3000/api/system/schema/tables' -Method Get -TimeoutSec 5; $res | ConvertTo-Json -Depth 10 | Out-File '%BACKUP_DIR%\database_schema_snapshot.json' -Encoding utf8; Write-Host 'Exported live schema snapshot.' } catch { Write-Host 'Server offline or live export bypassed.' }"

echo.
echo [3/3] Compressing backup into archive...
powershell -Command "Compress-Archive -Path '%BACKUP_DIR%' -DestinationPath 'backups\backup_%TIMESTAMP%.zip' -Force; Remove-Item -Recurse -Force '%BACKUP_DIR%'"

echo.
echo ========================================================
echo  [SUCCESS] Backup created successfully:
echo  backups\backup_%TIMESTAMP%.zip
echo ========================================================
echo.
pause

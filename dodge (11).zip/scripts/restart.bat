@echo off
setlocal
title Enterprise System - Restart Service

echo ========================================================
echo    Restarting Enterprise Production Server
echo ========================================================
echo.

where pm2 >nul 2>nul
if %errorlevel% equ 0 (
    echo Restarting via PM2...
    call pm2 restart enterprise-system
) else (
    echo Stopping old process...
    call "%~dp0stop.bat"
    timeout /t 2 >nul
    echo Starting new process...
    call "%~dp0start.bat"
)

echo.
echo [SUCCESS] Server restarted successfully!
echo Status check: http://localhost:3000/api/health
timeout /t 3

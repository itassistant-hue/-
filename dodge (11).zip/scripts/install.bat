@echo off
setlocal enabledelayedexpansion
title Enterprise System - Production Installation

echo ========================================================
echo    Enterprise Multi-Company System - Installer
echo ========================================================
echo.

:: Check Node.js
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed or not in PATH!
    echo Please download and install Node.js LTS from https://nodejs.org
    pause
    exit /b 1
)

echo [1/5] Checking Node.js and NPM versions...
node -v
npm -v
echo.

echo [2/5] Creating logs and backups directories...
if not exist "logs" mkdir logs
if not exist "backups" mkdir backups
echo Directories ready.
echo.

echo [3/5] Setting up production environment configuration...
if not exist ".env" (
    if exist ".env.production.example" (
        copy .env.production.example .env
        echo Created .env from .env.production.example.
    ) else if exist ".env.example" (
        copy .env.example .env
        echo Created .env from .env.example.
    )
) else (
    echo .env file already exists.
)
echo.

echo [4/5] Installing production npm dependencies...
call npm install
if %errorlevel% neq 0 (
    echo [ERROR] npm install failed!
    pause
    exit /b 1
)
echo.

echo [5/5] Building Real Production Bundle (Vite + esbuild)...
call npm run build
if %errorlevel% neq 0 (
    echo [ERROR] Production build failed!
    pause
    exit /b 1
)

echo.
echo ========================================================
echo  [SUCCESS] Production installation completed successfully!
echo.
echo  To start the application in background:
echo    - Run: scripts\start.bat
echo    OR
echo    - Run: scripts\install-windows-service.bat (For Windows Service)
echo ========================================================
echo.
pause

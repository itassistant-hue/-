@echo off
setlocal
title Enterprise System - Install Windows Service

echo ========================================================
echo    Installing System as Background Windows Service
echo    (Auto-Starts on Boot, Auto-Restarts on Crash, No CMD)
echo ========================================================
echo.

:: Check Administrative privileges
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [NOTICE] Requesting Administrator privileges...
    powershell -Command "Start-Process cmd -ArgumentList '/c %~dp0install-windows-service.bat' -Verb RunAs"
    exit /b
)

:: Ensure build exists
if not exist "dist\server.cjs" (
    echo [INFO] Production build missing. Building now...
    call npm run build
)

echo [1/3] Installing PM2 and Windows Service Manager globally...
call npm install -g pm2 pm2-windows-service
if %errorlevel% neq 0 (
    echo [WARNING] Global install had issues, trying local pm2...
    call npm install pm2 --save-dev
)

echo.
echo [2/3] Registering enterprise-system with PM2 background daemon...
call npx pm2 start ecosystem.config.cjs
call npx pm2 save

echo.
echo [3/3] Setting up Windows Auto-Start Registry / Task Scheduler...
powershell -Command "$action = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument '/c npx pm2 resurrect'; $trigger = New-ScheduledTaskTrigger -AtStartup; Register-ScheduledTask -TaskName 'EnterpriseSystemAutoStart' -Action $action -Trigger $trigger -RunLevel Highest -Force"

echo.
echo ========================================================
echo  [SUCCESS] Windows Background Service Installed!
echo.
echo  - Status: RUNNING IN BACKGROUND (Zero CMD Windows)
echo  - Auto-Start: Enabled on Windows Boot
echo  - Crash Recovery: Auto-Restarts automatically
echo  - Local URL: http://localhost:3000
echo  - Health check: http://localhost:3000/api/health
echo ========================================================
echo.
pause

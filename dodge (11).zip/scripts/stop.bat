@echo off
setlocal
title Enterprise System - Stop Service

echo ========================================================
echo    Stopping Enterprise Production Server
echo ========================================================
echo.

where pm2 >nul 2>nul
if %errorlevel% equ 0 (
    echo Stopping PM2 service...
    call pm2 stop enterprise-system
) else (
    echo Stopping running node processes on port 3000...
    for /f "tokens=5" %%a in ('netstat -aon ^| find ":3000" ^| find "LISTENING"') do (
        echo Terminating process PID %%a...
        taskkill /F /PID %%a >nul 2>&1
    )
)

echo.
echo [SUCCESS] Server stopped cleanly.
timeout /t 3

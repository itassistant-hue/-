@echo off
setlocal
title Enterprise System - Start Service

echo ========================================================
echo    Starting Enterprise Production Server
echo ========================================================
echo.

if not exist "dist\server.cjs" (
    echo [ERROR] Production build not found!
    echo Please run scripts\install.bat first.
    pause
    exit /b 1
)

:: Try PM2 first for background silent running
where pm2 >nul 2>nul
if %errorlevel% equ 0 (
    echo Starting with PM2 in background...
    call pm2 start ecosystem.config.cjs
    echo Started in background.
) else (
    echo Starting using background node process...
    powershell -Command "Start-Process node -ArgumentList 'dist/server.cjs' -WindowStyle Hidden"
    echo Started in background without CMD window.
)

echo.
echo Application started at http://localhost:3000
echo Health check available at: http://localhost:3000/api/health
echo Logs are being written to: logs\app.log and logs\error.log
echo.
timeout /t 3

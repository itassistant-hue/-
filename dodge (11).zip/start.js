#!/usr/bin/env node

/**
 * Enterprise Multi-Company Local Server Runner
 * Runs on Port 2026 inside the company local network
 */

import { existsSync } from 'fs';
import { resolve } from 'path';
import { execSync, spawn } from 'child_process';
import os from 'os';

const PORT = process.env.PORT || '2026';
process.env.PORT = PORT;
process.env.NODE_ENV = 'production';

console.log('================================================================');
console.log('    ENTERPRISE MULTI-COMPANY SYSTEM - LOCAL COMPANY SERVER');
console.log('           سيرفر النظام المؤسسي لتشغيل الموقع داخل الشركة');
console.log(`                          PORT: ${PORT}`);
console.log('================================================================\n');

const cwd = process.cwd();
const distServer = resolve(cwd, 'dist', 'server.cjs');
const distHtml = resolve(cwd, 'dist', 'index.html');
const nodeModules = resolve(cwd, 'node_modules');

// 1. Ensure dependencies are installed
if (!existsSync(nodeModules)) {
  console.log('[1/3] تثبيت حزم النظام لأول مرة (Installing npm dependencies)...');
  try {
    execSync('npm install', { stdio: 'inherit', cwd });
    console.log('✓ تم تثبيت الحزم بنجاح.\n');
  } catch (err) {
    console.error('[خطأ] فشل تثبيت الحزم via npm install.\n');
  }
}

// 2. Ensure production build exists
if (!existsSync(distServer) || !existsSync(distHtml)) {
  console.log('[2/3] بناء ملفات النظام للإنتاج (Building production bundle)...');
  try {
    execSync('npm run build', { stdio: 'inherit', cwd });
    console.log('✓ تم بناء ملفات الإنتاج بنجاح.\n');
  } catch (err) {
    console.warn('[تنبيه] فشل البناء الكامل، سيتم المحاولة بالتشغيل المباشر...\n');
  }
}

// 3. Determine Local Network IP
function getLocalNetworkIps() {
  const ips = [];
  try {
    const interfaces = os.networkInterfaces();
    for (const name of Object.keys(interfaces)) {
      for (const iface of interfaces[name] || []) {
        const isV4 = iface.family === 'IPv4' || iface.family === 4;
        if (isV4 && !iface.internal && iface.address !== '127.0.0.1') {
          ips.push(iface.address);
        }
      }
    }
  } catch {
    // Ignore network interfaces scan errors
  }
  return ips;
}

const networkIps = getLocalNetworkIps();

console.log('================================================================');
console.log(`  [SERVER READY] السيرفر جاهز للعمل داخل شبكة الشركة`);
console.log('================================================================');
console.log(`  • من هذا الجهاز (Local Host):`);
console.log(`    http://localhost:${PORT}`);
console.log();
if (networkIps.length > 0) {
  console.log(`  • من أجهزة وهواتف الموظفين في شبكة الشركة (Wi-Fi / LAN):`);
  networkIps.forEach(ip => {
    console.log(`    http://${ip}:${PORT}`);
  });
} else {
  console.log(`  • من أجهزة شبكة الشركة: http://[IP-جهازك]:${PORT}`);
}
console.log();
console.log(`  * لإيقاف السيرفر: اضغط Ctrl + C أو شغل Stop_Server.bat`);
console.log('================================================================\n');

// 4. Open browser automatically after 2 seconds
setTimeout(() => {
  try {
    const url = `http://localhost:${PORT}`;
    const startCmd = process.platform === 'darwin' ? 'open' : process.platform === 'win32' ? 'start' : 'xdg-open';
    spawn(startCmd, [url], { shell: true, detached: true, stdio: 'ignore' }).unref();
  } catch {
    // Ignore browser auto-open failure
  }
}, 2000);

// 5. Start the server (Relative paths, NO shell argument concatenation)
const hasDist = existsSync(distServer);
const targetRelative = hasDist ? 'dist/server.cjs' : 'server.ts';
const isTs = targetRelative.endsWith('.ts');

console.log(`[3/3] جاري بدء تشغيل السيرفر (${isTs ? 'وضع TypeScript المباشر' : 'وضع الإنتاج السريع'})...\n`);

let cmd = process.execPath;
let args = [targetRelative];

if (isTs) {
  cmd = process.platform === 'win32' ? 'npx.cmd' : 'npx';
  args = ['tsx', targetRelative];
}

const child = spawn(cmd, args, {
  stdio: 'inherit',
  env: process.env,
  cwd,
  shell: false, // Prevents cmd.exe argument-splitting on paths with spaces like "Aneed 10" or "dodge (9)"
});

child.on('error', (err) => {
  console.error('[خطأ في تشغيل السيرفر]:', err.message);
  process.exit(1);
});

child.on('exit', (code) => {
  if (code !== 0 && code !== null) {
    console.log(`\n[تنبيه] توقف السيرفر (كود الخروج: ${code}).`);
  }
  process.exit(code || 0);
});

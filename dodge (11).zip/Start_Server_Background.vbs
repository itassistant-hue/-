Option Explicit
Dim WshShell, fso, currentDir
Set WshShell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
currentDir = fso.GetParentFolderName(WScript.ScriptFullName)
WshShell.CurrentDirectory = currentDir
WshShell.Run "cmd /c set PORT=2026&& set NODE_ENV=production&& node start.js", 0, False
WshShell.Popup "تم تشغيل سيرفر الشركة في الخلفية على المنفذ 2026!" & vbCrLf & vbCrLf & _
               "• الرابط المحلي: http://localhost:2026" & vbCrLf & _
               "لإيقاف السيرفر: قم بتشغيل Stop_Server.bat", 5, "Enterprise Server [Port 2026]", 64

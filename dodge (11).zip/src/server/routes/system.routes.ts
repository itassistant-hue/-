import { Router, Response } from 'express';
import { requireAuth, AuthenticatedRequest } from '../middleware/auth';
import { dbStorage } from '../db/storage';

export const systemRouter = Router();

// GET /api/system/about - Retrieve system about & copyright metadata
systemRouter.get('/about', (_req: AuthenticatedRequest, res: Response): void => {
  try {
    const about = dbStorage.getSystemAbout();
    res.json({ success: true, about });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to retrieve system information' });
  }
});

// PUT /api/system/about - Update system about & copyright metadata (Super Admin only)
systemRouter.put('/about', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    if (!req.user?.isSuperAdmin) {
      res.status(403).json({
        error: 'Access Denied: Only Super Admin can modify system copyright and information.',
      });
      return;
    }

    const {
      aboutTitleAr,
      aboutTitleEn,
      aboutDescriptionAr,
      aboutDescriptionEn,
      copyrightTextAr,
      copyrightTextEn,
      developerNameAr,
      developerNameEn,
      systemVersion,
      licenseType,
      supportEmail,
    } = req.body;

    const updatePayload: any = {};
    if (aboutTitleAr !== undefined) updatePayload.aboutTitleAr = String(aboutTitleAr).trim();
    if (aboutTitleEn !== undefined) updatePayload.aboutTitleEn = String(aboutTitleEn).trim();
    if (aboutDescriptionAr !== undefined) updatePayload.aboutDescriptionAr = String(aboutDescriptionAr).trim();
    if (aboutDescriptionEn !== undefined) updatePayload.aboutDescriptionEn = String(aboutDescriptionEn).trim();
    if (copyrightTextAr !== undefined) updatePayload.copyrightTextAr = String(copyrightTextAr).trim();
    if (copyrightTextEn !== undefined) updatePayload.copyrightTextEn = String(copyrightTextEn).trim();
    if (developerNameAr !== undefined) updatePayload.developerNameAr = String(developerNameAr).trim();
    if (developerNameEn !== undefined) updatePayload.developerNameEn = String(developerNameEn).trim();
    if (systemVersion !== undefined) updatePayload.systemVersion = String(systemVersion).trim();
    if (licenseType !== undefined) updatePayload.licenseType = String(licenseType).trim();
    if (supportEmail !== undefined) updatePayload.supportEmail = String(supportEmail).trim();
    if (req.body.customSections !== undefined) updatePayload.customSections = req.body.customSections;
    if (req.body.additionalRights !== undefined) updatePayload.additionalRights = req.body.additionalRights;

    const updated = dbStorage.updateSystemAbout(
      updatePayload,
      {
        id: req.user.id,
        fullName: req.user.fullName,
        email: req.user.email,
      },
      req.ip
    );

    res.json({
      success: true,
      message: 'System about metadata updated successfully',
      about: updated,
    });
  } catch (err: any) {
    console.error('Error updating system about metadata:', err);
    res.status(500).json({ error: 'Failed to update system information' });
  }
});

// POST /api/system/reset-zero - Reset system to zero (Super Admin only)
systemRouter.post('/reset-zero', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    if (!req.user?.isSuperAdmin) {
      res.status(403).json({
        error: 'Access Denied: Only Super Admin can reset the system.',
      });
      return;
    }

    const result = dbStorage.resetToZero(
      {
        id: req.user.id,
        fullName: req.user.fullName,
        email: req.user.email,
      },
      req.ip
    );

    res.json(result);
  } catch (err: any) {
    console.error('Error resetting system to zero:', err);
    res.status(500).json({ error: err.message || 'Failed to reset system to zero' });
  }
});

// GET /api/system/backup - Generate & Download System Backup JSON
systemRouter.get('/backup', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    if (!req.user?.isSuperAdmin) {
      res.status(403).json({ error: 'Access Denied: Only Super Admin can export backups.' });
      return;
    }

    const pathMode = (req.query.pathMode as 'auto' | 'manual') || 'auto';
    const customPath = (req.query.customPath as string) || '';

    const backup = dbStorage.generateBackupData(
      pathMode,
      customPath,
      {
        id: req.user.id,
        fullName: req.user.fullName,
        email: req.user.email,
      },
      'manual'
    );

    res.setHeader('Content-Type', 'application/json');
    res.setHeader('Content-Disposition', `attachment; filename="${backup.metadata.filename}"`);
    res.send(backup.jsonString);
  } catch (err: any) {
    console.error('Error creating backup:', err);
    res.status(500).json({ error: err.message || 'Failed to generate backup' });
  }
});

// POST /api/system/backup - Trigger Backup with Custom Options and return Metadata
systemRouter.post('/backup', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    if (!req.user?.isSuperAdmin) {
      res.status(403).json({ error: 'Access Denied: Only Super Admin can create backups.' });
      return;
    }

    const { pathMode = 'auto', customPath = '', type = 'manual' } = req.body;

    const backup = dbStorage.generateBackupData(
      pathMode,
      customPath,
      {
        id: req.user.id,
        fullName: req.user.fullName,
        email: req.user.email,
      },
      type
    );

    res.json({
      success: true,
      message: 'Backup generated successfully',
      metadata: backup.metadata,
      payload: backup.payload,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to create backup' });
  }
});

// POST /api/system/restore - Restore Full System from JSON Backup
systemRouter.post('/restore', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    if (!req.user?.isSuperAdmin) {
      res.status(403).json({ error: 'Access Denied: Only Super Admin can restore backups.' });
      return;
    }

    const { backupData } = req.body;
    if (!backupData) {
      res.status(400).json({ error: 'No backup data provided in request body' });
      return;
    }

    const result = dbStorage.restoreBackupData(
      backupData,
      {
        id: req.user.id,
        fullName: req.user.fullName,
        email: req.user.email,
      },
      req.ip
    );

    res.json(result);
  } catch (err: any) {
    console.error('Error restoring backup:', err);
    res.status(400).json({ error: err.message || 'Failed to restore backup' });
  }
});

// GET /api/system/backup-config - Get Auto/Manual Backup Configuration
systemRouter.get('/backup-config', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    if (!req.user?.isSuperAdmin) {
      res.status(403).json({ error: 'Access Denied' });
      return;
    }

    const config = dbStorage.getBackupConfig();
    const history = dbStorage.getBackupsList();
    res.json({ success: true, config, history });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to get backup config' });
  }
});

// PUT /api/system/backup-config - Update Auto/Manual Backup Settings
systemRouter.put('/backup-config', requireAuth, (req: AuthenticatedRequest, res: Response): void => {
  try {
    if (!req.user?.isSuperAdmin) {
      res.status(403).json({ error: 'Access Denied' });
      return;
    }

    const updated = dbStorage.updateBackupConfig(req.body);
    res.json({ success: true, message: 'Backup configuration updated successfully', config: updated });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to update backup config' });
  }
});

import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { REPORT_EXPORT_FIELDS, ReportExportFieldKey, ReportQueryResult } from '../types/reports';

export function generateReportPdf(
  reportData: ReportQueryResult,
  selectedFields: ReportExportFieldKey[],
  isArabic: boolean = false
) {
  const doc = new jsPDF({ orientation: 'landscape', unit: 'pt', format: 'a4' });
  const title = isArabic
    ? 'تقرير المهام والمؤشرات التشغيلية للمجموعة'
    : 'Enterprise Operations & Tasks Report';
  const subtitle = `${isArabic ? 'تاريخ التوليد:' : 'Generated on:'} ${new Date().toLocaleString()} | ${
    isArabic ? 'إجمالي السجلات:' : 'Total Records:'
  } ${reportData.filteredCount || (reportData.tasks ? reportData.tasks.length : 0)}`;

  doc.setFontSize(16);
  doc.text(title, 40, 40);
  doc.setFontSize(10);
  doc.text(subtitle, 40, 58);

  const activeFields = REPORT_EXPORT_FIELDS.filter((f) => selectedFields.includes(f.key));
  const head = [activeFields.map((f) => (isArabic ? f.labelAr : f.labelEn))];
  const body = (reportData.data || reportData.tasks || []).map((row: any) =>
    activeFields.map((f) => {
      const val = row[f.key];
      if (val === null || val === undefined) return '-';
      if (typeof val === 'object') return JSON.stringify(val);
      return String(val);
    })
  );

  autoTable(doc, {
    head,
    body,
    startY: 75,
    styles: { fontSize: 8, cellPadding: 4 },
    headStyles: { fillColor: [30, 41, 59], textColor: 255, fontStyle: 'bold' },
    alternateRowStyles: { fillColor: [248, 250, 252] },
  });

  doc.save(`Operations_Report_${new Date().toISOString().substring(0, 10)}.pdf`);
}

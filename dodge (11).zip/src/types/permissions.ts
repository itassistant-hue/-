export enum PermissionKey {
  COMPANIES_VIEW = 'companies.view',
  COMPANIES_CREATE = 'companies.create',
  COMPANIES_EDIT = 'companies.edit',
  COMPANIES_DELETE = 'companies.delete',

  TASKS_VIEW = 'tasks.view',
  TASKS_CREATE = 'tasks.create',
  TASKS_EDIT = 'tasks.edit',
  TASKS_DELETE = 'tasks.delete',
  TASKS_CHANGE_STATUS = 'tasks.change_status',
  TASKS_ASSIGN = 'tasks.assign',

  REPORTS_VIEW = 'reports.view',
  REPORTS_EXPORT = 'reports.export',

  USERS_VIEW = 'users.view',
  USERS_MANAGE = 'users.manage',

  PERMISSIONS_MANAGE = 'permissions.manage',
  ROLES_MANAGE = 'roles.manage',

  CUSTOM_FIELDS_MANAGE = 'custom_fields.manage',
  AUDIT_LOGS_VIEW = 'audit_logs.view',
  SETTINGS_MANAGE = 'settings.manage',
}

export interface PermissionDefinition {
  key: PermissionKey;
  module: string;
  nameEn: string;
  nameAr: string;
  descriptionEn: string;
  descriptionAr: string;
}

export const SYSTEM_PERMISSIONS: PermissionDefinition[] = [
  {
    key: PermissionKey.COMPANIES_VIEW,
    module: 'companies',
    nameEn: 'View Companies',
    nameAr: 'عرض الشركات',
    descriptionEn: 'View companies profile, metrics, and basic info',
    descriptionAr: 'استعراض بيانات ومؤشرات أداء الشركات',
  },
  {
    key: PermissionKey.COMPANIES_CREATE,
    module: 'companies',
    nameEn: 'Create Companies',
    nameAr: 'إنشاء شركات جديدة',
    descriptionEn: 'Register new subsidiary companies into the group',
    descriptionAr: 'تسجيل وإضافة شركة تابعة جديدة للمجموعة',
  },
  {
    key: PermissionKey.COMPANIES_EDIT,
    module: 'companies',
    nameEn: 'Edit Companies',
    nameAr: 'تعديل بيانات الشركات',
    descriptionEn: 'Modify company information, settings, and branding',
    descriptionAr: 'تحديث بيانات الشركة وإعداداتها وهوية علامتها',
  },
  {
    key: PermissionKey.COMPANIES_DELETE,
    module: 'companies',
    nameEn: 'Archive/Delete Companies',
    nameAr: 'أرشفة وحذف الشركات',
    descriptionEn: 'Archive or permanently delete companies',
    descriptionAr: 'أرشفة أو حذف الشركة نهائيًا من المجموعة',
  },
  {
    key: PermissionKey.TASKS_VIEW,
    module: 'tasks',
    nameEn: 'View Tasks',
    nameAr: 'عرض المهام',
    descriptionEn: 'View tasks, milestones, and workflow boards',
    descriptionAr: 'استعراض المهام ومراحل سير العمل للمشاريع',
  },
  {
    key: PermissionKey.TASKS_CREATE,
    module: 'tasks',
    nameEn: 'Create Tasks',
    nameAr: 'إضافة مهام جديدة',
    descriptionEn: 'Create and assign operational tasks',
    descriptionAr: 'إنشاء وإسناد مهام تشغيلية جديدة',
  },
  {
    key: PermissionKey.TASKS_EDIT,
    module: 'tasks',
    nameEn: 'Edit Tasks',
    nameAr: 'تعديل المهام',
    descriptionEn: 'Edit details, dates, and hours of tasks',
    descriptionAr: 'تعديل تفاصيل المهمة وتواريخها وساعاتها',
  },
  {
    key: PermissionKey.TASKS_DELETE,
    module: 'tasks',
    nameEn: 'Delete Tasks',
    nameAr: 'حذف المهام',
    descriptionEn: 'Archive or permanently remove tasks',
    descriptionAr: 'أرشفة أو حذف المهام نهائيًا',
  },
  {
    key: PermissionKey.TASKS_CHANGE_STATUS,
    module: 'tasks',
    nameEn: 'Change Task Status',
    nameAr: 'تغيير حالة المهام',
    descriptionEn: 'Move tasks between workflow stages and log status reasons',
    descriptionAr: 'نقل المهام بين مراحل الإنجاز وتسجيل أسباب التأخير أو الإيقاف',
  },
  {
    key: PermissionKey.TASKS_ASSIGN,
    module: 'tasks',
    nameEn: 'Assign Tasks',
    nameAr: 'إسناد وتوزيع المهام',
    descriptionEn: 'Assign and delegate tasks to team members',
    descriptionAr: 'تعيين وتوزيع المهام على أعضاء الفريق',
  },
  {
    key: PermissionKey.REPORTS_VIEW,
    module: 'reports',
    nameEn: 'View Operational Reports',
    nameAr: 'عرض التقارير التشغيلية',
    descriptionEn: 'Access multi-dimensional reports and charts',
    descriptionAr: 'الوصول للتقارير الشاملة والرسوم البيانية',
  },
  {
    key: PermissionKey.REPORTS_EXPORT,
    module: 'reports',
    nameEn: 'Export Reports (Excel & PDF)',
    nameAr: 'تصدير التقارير (Excel و PDF)',
    descriptionEn: 'Export filtered operational data to Excel and PDF',
    descriptionAr: 'تصدير بيانات التقارير المفلترة إلى ملفات Excel و PDF',
  },
  {
    key: PermissionKey.USERS_VIEW,
    module: 'users',
    nameEn: 'View Users',
    nameAr: 'عرض المستخدمين',
    descriptionEn: 'View system users and their assignments',
    descriptionAr: 'استعراض بيانات المستخدمين وارتباطاتهم',
  },
  {
    key: PermissionKey.USERS_MANAGE,
    module: 'users',
    nameEn: 'Manage Users',
    nameAr: 'إدارة المستخدمين والحسابات',
    descriptionEn: 'Create, update, activate/deactivate, and reset user credentials',
    descriptionAr: 'إنشاء وتعديل وتفعيل وإعادة تعيين كلمات مرور المستخدمين',
  },
  {
    key: PermissionKey.PERMISSIONS_MANAGE,
    module: 'permissions',
    nameEn: 'Manage Permissions & Roles',
    nameAr: 'إدارة الصلاحيات والأدوار',
    descriptionEn: 'Grant or revoke capability tokens to roles',
    descriptionAr: 'منح وسحب الصلاحيات وإدارة مصفوفة الأدوار',
  },
  {
    key: PermissionKey.CUSTOM_FIELDS_MANAGE,
    module: 'custom_fields',
    nameEn: 'Manage Custom Fields (EAV)',
    nameAr: 'إدارة الحقول المخصصة',
    descriptionEn: 'Define dynamic entity fields per subsidiary company',
    descriptionAr: 'تعريف وتخصيص الحقول الإضافية لكل شركة تابعة',
  },
  {
    key: PermissionKey.AUDIT_LOGS_VIEW,
    module: 'audit',
    nameEn: 'View Audit Logs',
    nameAr: 'استعراض سجل التدقيق الأمني',
    descriptionEn: 'Inspect immutable historical security and operation records',
    descriptionAr: 'مراقبة وفحص سجلات العمليات والأمان غير القابلة للتعديل',
  },
  {
    key: PermissionKey.SETTINGS_MANAGE,
    module: 'settings',
    nameEn: 'Manage System Settings',
    nameAr: 'إدارة إعدادات النظام',
    descriptionEn: 'Configure global system parameters and backups',
    descriptionAr: 'ضبط إعدادات النظام الشاملة والنسخ الاحتياطي',
  },
];

export type Language = 'ar' | 'en';
export type SupportedLanguage = Language;
export type Direction = 'rtl' | 'ltr';

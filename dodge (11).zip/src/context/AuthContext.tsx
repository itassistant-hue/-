import React, { createContext, useContext, useState, useEffect } from 'react';
import { AuthUser } from '../types/auth';
import { PermissionKey } from '../types/permissions';
import { api } from '../services/api';

export interface AuthContextType {
  user: AuthUser | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (email: string, pass: string) => Promise<void>;
  logout: () => Promise<void>;
  hasPermission: (permission: PermissionKey) => boolean;
  canAccessCompany: (companyId: string) => boolean;
  switchRolePersona: (persona: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('auth_token'));
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const initAuth = async () => {
    const savedToken = localStorage.getItem('auth_token');
    if (!savedToken) {
      setToken(null);
      setUser(null);
      setIsLoading(false);
      return;
    }

    try {
      const res = await api.getMe();
      setUser(res.user);
    } catch (e) {
      console.warn('Session token expired or invalid, clearing:', e);
      localStorage.removeItem('auth_token');
      setToken(null);
      setUser(null);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    initAuth();
  }, []);

  const login = async (email: string, pass: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await api.login(email, pass);
      setToken(res.token);
      setUser(res.user);
      localStorage.setItem('auth_token', res.token);
      if (res.user?.assignedCompanies?.[0]) {
        localStorage.setItem('active_company_id', res.user.assignedCompanies[0].id);
      }
    } catch (err: any) {
      setError(err.message || 'Login failed');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    try {
      await api.logout();
    } catch (err) {
      console.warn('Backend logout notification failed, clearing local session:', err);
    } finally {
      localStorage.removeItem('auth_token');
      localStorage.removeItem('active_company_id');
      setToken(null);
      setUser(null);
    }
  };

  const switchRolePersona = async (persona: string) => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await api.switchPersona(persona);
      setToken(res.token);
      setUser(res.user);
      localStorage.setItem('auth_token', res.token);
      if (res.user?.assignedCompanies?.[0]) {
        localStorage.setItem('active_company_id', res.user.assignedCompanies[0].id);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to switch persona');
      throw err;
    } finally {
      setIsLoading(false);
    }
  };

  const hasPermission = (perm: PermissionKey): boolean => {
    if (!user) return false;
    if (user.isSuperAdmin) return true;
    return user.permissions?.includes(perm) || false;
  };

  const canAccessCompany = (companyId: string): boolean => {
    if (!user) return false;
    if (user.isSuperAdmin) return true;
    return user.assignedCompanies?.some((c) => c.id === companyId) || false;
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!user,
        isLoading,
        error,
        login,
        logout,
        hasPermission,
        canAccessCompany,
        switchRolePersona,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return ctx;
};

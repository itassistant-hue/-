@echo off
title Enterprise System - Stop Server [Port 2026]
cd /d "%~dp0"
echo ================================================================
echo    ENTERPRISE MULTI-COMPANY SYSTEM - STOP LOCAL SERVER
echo         إيقاف سيرفر النظام المؤسسي وتحرير المنفذ 2026
echo ================================================================
echo.
set "STOPPED=0"
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":2026" ^| findstr "LISTENING" 2^>nul') do (
    if not "%%a"=="0" (
        echo [INFO] Terminating PID %%a on port 2026...
        taskkill /F /PID %%a >nul 2>&1
        set "STOPPED=1"
    )
)
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":3000" ^| findstr "LISTENING" 2^>nul') do (
    if not "%%a"=="0" (
        echo [INFO] Terminating PID %%a on port 3000...
        taskkill /F /PID %%a >nul 2>&1
        set "STOPPED=1"
    )
)
echo.
if "%STOPPED%"=="1" (
    echo [SUCCESS] تم إيقاف السيرفر بنجاح وتحرير المنفذ 2026!
) else (
    echo [INFO] السيرفر غير شغال حالياً أو المنفذ 2026 غير مستخدم.
)
echo.
ping 127.0.0.1 -n 3 >nul

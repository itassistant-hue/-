@echo off
title Enterprise System Server [Port 2026]
cd /d "%~dp0"

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed or not in PATH!
    echo [خطأ] لم يتم العثور على برمجية Node.js في هذا الجهاز.
    echo Please install Node.js from https://nodejs.org
    pause
    exit /b 1
)

if not exist "node_modules" (
    echo [INFO] Installing dependencies for the first time...
    echo [تنبيه] جاري تثبيت حزم النظام لأول مرة، يرجى الانتظار...
    call npm install
    if %errorlevel% neq 0 (
        echo [ERROR] npm install failed.
        pause
        exit /b 1
    )
)

node start.js
if %errorlevel% neq 0 pause

import { ServiceRequest, Transaction, User, Company, Notification, Supplier } from './types.ts';

export const initialMockRequests: ServiceRequest[] = [
  { 
    id: 'REQ-001', company: 'Raban Al-Safina', service: 'flight', status: 'quoted', date: '2026-04-18', 
    cost: 0, selling: 0, supplier: '', notes: 'Business class flight to Dubai for 2 executives. Departure next Monday.', 
    details: { from: 'Baghdad (BGW)', to: 'Dubai (DXB)', departureDate: '2026-04-25', returnDate: '2026-05-02', passengers: '2' },
    assignedTo: 'Ahmed Ali', attachments: ['passports_copy.pdf'], 
    chat: [{sender: 'client', text: 'Need the flights confirmed today.'}, {sender: 'admin', text: 'Attached the quotation for the Emirates flight. Please approve to proceed.'}],
    offers: [
      { id: '1', supplier: 'Emirates Airlines', details: 'Direct Flight - Business Class (Lounge Access included)', cost: 450, selling: 550 },
      { id: '2', supplier: 'Qatar Airways', details: '1 Stop in Doha - Business Class', cost: 400, selling: 480 }
    ],
    selectedOfferId: null
  },
  { id: 'REQ-002', company: 'Raban Al-Safina', service: 'hotel', status: 'pending', date: '2026-04-17', cost: 0, selling: 0, supplier: '', notes: '5-star hotel near Burj Khalifa for 3 nights. Need corporate rates.', details: { city: 'Dubai', rooms: '2', checkIn: '2026-04-25', checkOut: '2026-04-28' }, assignedTo: 'Unassigned', attachments: [], chat: [], offers: [], selectedOfferId: null },
  { id: 'REQ-003', company: 'Ur Energy', service: 'visa', status: 'completed', date: '2026-04-10', cost: 100, selling: 150, supplier: 'Dubai Govt', notes: 'Multiple entry visa renewal.', details: { nationality: 'Iraqi', visaType: 'Business' }, assignedTo: 'Sara Smith', attachments: ['visa_approval.pdf'], chat: [], offers: [{ id: '3', supplier: 'Dubai Govt', details: 'VIP Express Visa', cost: 100, selling: 150 }], selectedOfferId: '3' },
  { id: 'REQ-004', company: 'Dijla Tech', service: 'insurance', status: 'inProgress', date: '2026-04-15', cost: 0, selling: 0, supplier: '', notes: 'Annual health insurance for 10 new employees.', details: { coverage: 'Global Comprehensive' }, assignedTo: 'Ahmed Ali', attachments: ['employee_list.xlsx'], chat: [], offers: [], selectedOfferId: null },
];

export const mockTransactions: Transaction[] = [
  { id: 'TRX-101', date: '2026-04-15', company: 'Raban Al-Safina', service: 'Flight Booking - REQ-001', desc: 'Confirmed booking to London (Executive Team)', amount: 1200, currency: 'USD', type: 'charge', status: 'Completed' },
  { id: 'TRX-102', date: '2026-04-10', company: 'Raban Al-Safina', service: 'Account Payment', desc: 'Bank Transfer - Reference #88392', amount: 2000, currency: 'USD', type: 'payment', status: 'Cleared' },
  { id: 'TRX-103', date: '2026-04-05', company: 'Raban Al-Safina', service: 'Hotel Booking - REQ-000', desc: 'Ritz Carlton - 2 Nights', amount: 800, currency: 'USD', type: 'charge', status: 'Completed' },
  { id: 'TRX-104', date: '2026-03-20', company: 'Raban Al-Safina', service: 'Previous Balance', desc: 'Carried forward', amount: 3450, currency: 'USD', type: 'charge', status: 'Completed' },
];

export const mockUsers: User[] = [
  { id: 'USR-DEV', name: 'Ali Ahmed Aneed', email: 'ali.Aneed', role: 'admin', company: '-', avatar: null, password: '7941631' },
  { id: 'USR-01', name: 'Ahmed Ali', email: 'ahmed@airlink.com', role: 'staff', company: '-', avatar: null, password: '123' },
  { id: 'USR-02', name: 'Sara Smith', email: 'sara@airlink.com', role: 'admin', company: '-', avatar: null, password: '123' },
  { id: 'USR-03', name: 'Client Rep 1', email: 'rep@raban.com', role: 'client', company: 'Raban Al-Safina', avatar: null, password: '123' },
  { id: 'USR-04', name: 'Ur Contact', email: 'contact@urenergy.com', role: 'client', company: 'Ur Energy', avatar: null, password: '123' },
  { id: 'USR-05', name: 'Management Viewer', email: 'viewer@airlink.com', role: 'viewer', company: '-', avatar: null, password: '123' },
];

export const mockCompaniesList: Company[] = [
  { id: 'COM-01', name: 'Raban Al-Safina', industry: 'Conglomerate', contactPerson: 'Mr. Khalid', phone: '+964 770 123 4567', address: 'Baghdad, Iraq', creditLimit: 50000, status: 'Active', logo: null, balanceUSD: 1000, balanceIQD: 1500000 },
  { id: 'COM-02', name: 'Ur Energy', industry: 'Energy & Power', contactPerson: 'Eng. Ali', phone: '+964 780 987 6543', address: 'Basra, Iraq', creditLimit: 20000, status: 'Active', logo: null, balanceUSD: -500, balanceIQD: 0 },
  { id: 'COM-03', name: 'Dijla Tech', industry: 'IT & Technology', contactPerson: 'Ms. Noor', phone: '+964 750 111 2222', address: 'Erbil, Iraq', creditLimit: 10000, status: 'Active', logo: null, balanceUSD: 0, balanceIQD: 0 },
];

export const mockSuppliersList: Supplier[] = [
  { id: 'SUP-01', name: 'Iraqi Airways', type: 'airline', contactPerson: 'Sales Team', phone: '+964 123456', balanceUSD: 0, balanceIQD: 0 },
  { id: 'SUP-02', name: 'Qatar Airways', type: 'airline', contactPerson: 'Support', phone: '+964 654321', balanceUSD: 0, balanceIQD: 0 },
  { id: 'SUP-03', name: 'HotelBeds', type: 'hotel_system', contactPerson: 'John', phone: '+44 000000', balanceUSD: 0, balanceIQD: 0 },
];

export const mockNotifications: Notification[] = [
  { id: '1', text: 'Quotation ready for REQ-001', time: '2 hours ago', read: false },
  { id: '2', text: 'Visa REQ-003 is Completed', time: '1 day ago', read: true }
];

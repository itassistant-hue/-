export type ServiceType = 'flight' | 'hotel' | 'visa' | 'insurance' | 'other';
export type RequestStatus = 'pending' | 'inProgress' | 'quoted' | 'approved' | 'rejected' | 'completed';
export type UserRole = 'admin' | 'staff' | 'client' | 'viewer';

export interface FlightDetails {
  from?: string;
  to?: string;
  departureDate?: string;
  returnDate?: string;
  passengers?: string;
}

export interface HotelDetails {
  city?: string;
  rooms?: string;
  checkIn?: string;
  checkOut?: string;
}

export interface VisaDetails {
  to?: string;
  nationality?: string;
  visaType?: string;
}

export interface InsuranceDetails {
  dob?: string;
  coverage?: string;
}

export type ServiceDetails = FlightDetails & HotelDetails & VisaDetails & InsuranceDetails;

export interface ChatMessage {
  sender: string;
  text: string;
  read?: boolean;
  file?: {
    name: string;
    data: string;
    type: string;
  };
}

export interface SupplierCostItem {
  id: string;
  name: string;
  cost: number;
}

export interface Offer {
  id: string;
  supplier: string;
  realSupplier?: string;
  supplierCosts?: SupplierCostItem[];
  route?: string;
  currency?: 'USD' | 'IQD';
  cost: number;
  selling: number;
  details: string;
  createdBy?: string;
  status?: 'pending' | 'approved' | 'rejected';
  // Specific detailed fields
  flightNumber?: string;
  airline?: string;
  cabinClass?: string;
  baggageAllowance?: string;
  transitInfo?: string;
  isRefundable?: boolean;
  hotelName?: string;
  starRating?: string;
  roomType?: string;
  boardBasis?: string;
  departureDate?: string;
  returnDate?: string;
}

export interface ServiceRequest {
  id: string;
  company: string;
  service: ServiceType;
  status: RequestStatus;
  date: string;
  cost: number;
  selling: number;
  supplier: string;
  airlineName?: string;
  realSupplier?: string;
  notes: string;
  details: ServiceDetails;
  assignedTo: string;
  attachments: string[];
  chat: ChatMessage[];
  offers: Offer[];
  selectedOfferId: string | null;
  chatClosed?: boolean;
  requestSubType?: 'reissue' | 'change' | 'cancellation' | 'new';
  createdBy?: string;
  costPrice?: number;
  sellingPrice?: number;
  profit?: number;
  route?: string;
}

export interface Transaction {
  id: string;
  date: string;
  company: string;
  service: string;
  desc: string;
  amount: number;
  currency: 'USD' | 'IQD';
  type: 'charge' | 'payment';
  status: string;
  supplierId?: string; // If it's a supplier transaction
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  company: string;
  avatar: string | null;
  password?: string;
}

export interface DashboardMediaItem {
  id: string;
  type: 'video' | 'image' | 'gif';
  url: string;
  title?: string;
  description?: string;
}

export interface AppSettings {
  companyName: string;
  logoUrl: string;
  backgroundImageUrl: string;
  primaryColor: string;
  footerText: string;
  companyImage: string;
  adText?: string;
  adOpacity?: number;
  loginLayout?: 'center' | 'right';
  loginBgUrl?: string;
  loginTitle?: string;
  loginSubtitle?: string;
  loginButtonText?: string;
  loginWidgetTitle?: string;
  loginWidgetHeadline?: string;
  loginWidgetDesc?: string;
  loginMetric1Title?: string;
  loginMetric1Sub?: string;
  loginMetric2Title?: string;
  loginMetric2Sub?: string;
  loginMetric3Title?: string;
  loginMetric3Sub?: string;
  loginFooterText1?: string;
  loginFooterText2?: string;
  mainImageHeight?: number;
  mainImageWidth?: string;
  mainImageObjectFit?: 'cover' | 'contain' | 'fill';
  logoWidth?: number;
  logoHeight?: number;
  notificationEmail?: string;
  googleDriveEmail?: string;
  dashboardMediaList?: DashboardMediaItem[];
  aboutContent?: string;
  ads?: string[]; // Array of base64 images or URLs
  showFinancialsToClient?: boolean;
  backupSchedule?: 'none' | 'daily' | 'weekly' | 'monthly';
  secondaryColor?: string;
  defaultCurrency?: 'USD' | 'IQD';
  exchangeRate?: number;
  chatBackupEnabled?: boolean;
  chatBackupFormat?: 'txt' | 'csv';
  // Copyright Customization
  copyrightName?: string;
  copyrightRightsText?: string;
  copyrightFontSize?: number;
  copyrightTextColor?: string;
  copyrightFontFamily?: string;
  copyrightFontWeight?: string;
  copyrightBgColor?: string;
  copyrightBorderColor?: string;
  copyrightBorderRadius?: number;
  copyrightPaddingX?: number;
  copyrightPaddingY?: number;
  copyrightWidth?: string;
  copyrightHeight?: string;
  // Automatic & Manual Backup Settings
  autoBackupEnabled?: boolean;
  autoBackupIntervalHours?: number;
  lastBackupTimestamp?: number;
  googleClientId?: string;
  // Logo Auto-Adaptation Background
  autoAdaptLogoBg?: boolean;
  extractedLogoColor?: string;
  // Official Company Stamp / Seal for Documents
  companyStampUrl?: string;
  devInfo?: {
    nameAr: string;
    nameEn: string;
    deptAr: string;
    deptEn: string;
    descriptionAr: string;
    descriptionEn: string;
  };
}

export interface Company {
  id: string;
  name: string;
  industry: string;
  contactPerson: string;
  phone: string;
  address: string;
  creditLimit: number;
  status: string;
  logo: string | null;
  balanceUSD?: number;
  balanceIQD?: number;
}

export interface Supplier {
  id: string;
  name: string;
  type: 'airline' | 'hotel_system' | 'wholesaler' | 'other';
  contactPerson: string;
  phone: string;
  balanceUSD: number;
  balanceIQD: number;
}

export interface Notification {
  id: string;
  text: string;
  description?: string;
  time: string;
  timestamp?: number;
  read: boolean;
  type?: 'offer_approved' | 'offer_rejected' | 'offer_received' | 'chat' | 'new_request' | 'status_update' | 'message' | 'status' | 'offer' | 'info';
  relatedId?: string;
  targetRole?: UserRole;
  targetEmail?: string;
}

import React, { useState, useEffect } from 'react';
import { Lock, Key, Image, Upload, Type, Mail, Cloud, Film, Video, Trash2, CheckCircle2, Sparkles, X, Sliders, Shield } from 'lucide-react';
import { AppSettings, DashboardMediaItem } from '../../types.ts';
import { optimizeImage } from '../../utils/imageOptimizer.ts';
import { requestGDriveToken, uploadBackupToGoogleDrive } from '../../utils/googleDriveBackup.ts';

interface SecretGatewayModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUnlockDevMode?: () => void;
  settings: AppSettings;
  setSettings: React.Dispatch<React.SetStateAction<AppSettings>>;
  usersList?: any[];
  requestsList?: any[];
  transactionsList?: any[];
  companiesList?: any[];
  suppliersList?: any[];
  notifications?: any[];
}

export const SecretGatewayModal: React.FC<SecretGatewayModalProps> = ({
  isOpen,
  onClose,
  onUnlockDevMode,
  settings,
  setSettings,
  usersList = [],
  requestsList = [],
  transactionsList = [],
  companiesList = [],
  suppliersList = [],
  notifications = []
}) => {
  const [passcode, setPasscode] = useState('');
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [saveSuccessMsg, setSaveSuccessMsg] = useState('');
  const [activeTab, setActiveTab] = useState<'logo' | 'mainImage' | 'copyright' | 'texts' | 'emails' | 'media'>('logo');

  const [formData, setFormData] = useState<AppSettings>({ ...settings });
  const [isGDriveSyncing, setIsGDriveSyncing] = useState(false);
  const [gdriveMsg, setGdriveMsg] = useState('');

  // New media state
  const [mediaType, setMediaType] = useState<'video' | 'image' | 'gif'>('image');
  const [mediaUrl, setMediaUrl] = useState('');
  const [mediaTitle, setMediaTitle] = useState('');

  useEffect(() => {
    if (isOpen) {
      setIsUnlocked(false);
      setPasscode('');
      setErrorMsg('');
      setFormData({ ...settings });
    }
  }, [isOpen, settings]);

  if (!isOpen) return null;

  const handleVerifyPasscode = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (passcode.trim() === '7941631') {
      setIsUnlocked(true);
      setErrorMsg('');
      if (onUnlockDevMode) {
        onUnlockDevMode();
      }
    } else {
      setErrorMsg('رمز البوابة السرية غير صحيح!');
    }
  };

  const handleSaveSettings = () => {
    setSettings(formData);
    // Trigger immediate local save & sync
    window.dispatchEvent(new CustomEvent('save-trigger-now'));
    setSaveSuccessMsg('✅ تم حفظ كافة التعديلات للبوابة السرية بنجاح!');
    setTimeout(() => setSaveSuccessMsg(''), 4000);
  };

  const handleLogoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const optimized = await optimizeImage(file, 400, 400, 0.8);
        setFormData(prev => ({ ...prev, logoUrl: optimized }));
      } catch (err) {
        console.error('Failed to optimize logo:', err);
      }
    }
  };

  const handleMainImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const optimized = await optimizeImage(file, 1600, 1024, 0.7);
        setFormData(prev => ({ ...prev, companyImage: optimized }));
      } catch (err) {
        console.error('Failed to optimize main image:', err);
      }
    }
  };

  const handleGDriveSync = () => {
    setGdriveMsg('جاري الاتصال بـ Google Drive...');
    requestGDriveToken(
      async (token) => {
        setIsGDriveSyncing(true);
        const payload = {
          users: usersList,
          requests: requestsList,
          transactions: transactionsList,
          companies: companiesList,
          suppliers: suppliersList,
          settings: formData,
          notifications: notifications,
          backupEmail: formData.googleDriveEmail || 'aloooshf9@gmail.com'
        };
        const res = await uploadBackupToGoogleDrive(payload, token);
        setIsGDriveSyncing(false);
        if (res.success) {
          setGdriveMsg(`✅ تم رفع النسخة الاحتياطية إلى Google Drive (${formData.googleDriveEmail || 'aloooshf9@gmail.com'}) بنجاح!`);
        } else {
          setGdriveMsg('❌ فشل الرفع: ' + res.error);
        }
      },
      (err) => {
        setGdriveMsg('⚠️ تعذر الربط تلقائياً بـ Google Drive');
      }
    );
  };

  const handleAddMediaItem = () => {
    if (!mediaUrl) return;
    const newItem: DashboardMediaItem = {
      id: `MEDIA-${Date.now()}`,
      type: mediaType,
      url: mediaUrl,
      title: mediaTitle || (mediaType === 'video' ? 'فيديو توضيحي' : mediaType === 'gif' ? 'صورة متحركة' : 'صورة جديدة')
    };
    const updated = [newItem, ...(formData.dashboardMediaList || [])];
    setFormData(prev => ({ ...prev, dashboardMediaList: updated }));
    setMediaUrl('');
    setMediaTitle('');
  };

  const handleDeleteMediaItem = (id: string) => {
    const updated = (formData.dashboardMediaList || []).filter(m => m.id !== id);
    setFormData(prev => ({ ...prev, dashboardMediaList: updated }));
  };

  return (
    <div className="fixed inset-0 z-[300] bg-black/80 backdrop-blur-xl flex items-center justify-center p-4 dir-rtl animate-in fade-in duration-300">
      <div className="bg-[#0b0f17] border border-indigo-500/30 rounded-[36px] max-w-3xl w-full max-h-[90vh] flex flex-col shadow-[0_0_80px_rgba(99,102,241,0.25)] overflow-hidden relative">
        
        {/* Header */}
        <div className="p-6 border-b border-indigo-500/20 bg-gradient-to-r from-indigo-950/40 via-purple-950/20 to-black flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-indigo-500/20 text-indigo-400 rounded-2xl border border-indigo-500/30 shadow-inner">
              <Key size={24} />
            </div>
            <div>
              <h2 className="text-xl font-black text-white tracking-wide flex items-center gap-2">
                البوابة السرية (Secret Portal) 🔒
              </h2>
              <p className="text-xs text-indigo-300/60 font-medium mt-0.5">
                لوحة التحكم الحصرية لتعديل الهوية البصرية والنصوص والنسخ الاحتياطي
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-white/50 hover:text-white rounded-xl hover:bg-white/10 transition-colors">
            <X size={20} />
          </button>
        </div>

        {/* Content Body */}
        {!isUnlocked ? (
          /* Passcode Verification Screen */
          <div className="p-10 flex flex-col items-center justify-center space-y-6 text-center">
            <div className="w-20 h-20 bg-indigo-500/10 border border-indigo-500/30 rounded-3xl flex items-center justify-center text-indigo-400 shadow-2xl">
              <Lock size={36} />
            </div>
            <div>
              <h3 className="text-2xl font-black text-white">إدخال رمز البوابة السرية</h3>
              <p className="text-xs text-white/50 mt-2">يرجى إدخال رمز الأمان المخصص للدخول إلى إعدادات البوابة</p>
            </div>

            <form onSubmit={handleVerifyPasscode} className="w-full max-w-sm space-y-4">
              <input
                type="password"
                value={passcode}
                onChange={(e) => setPasscode(e.target.value)}
                placeholder="أدخل رمز البوابة السرية..."
                className="w-full bg-white/5 border border-indigo-500/30 rounded-2xl p-4 text-center text-lg font-mono font-bold text-white placeholder:text-white/20 focus:outline-none focus:border-indigo-500 transition-all"
                autoFocus
              />

              {errorMsg && (
                <p className="text-xs text-rose-400 font-bold bg-rose-500/10 p-3 rounded-xl border border-rose-500/20">
                  {errorMsg}
                </p>
              )}

              <button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-black py-4 rounded-2xl text-xs uppercase tracking-widest shadow-lg shadow-indigo-500/30 transition-all active:scale-95"
              >
                فتح البوابة السرية 🔑
              </button>
            </form>
          </div>
        ) : (
          /* Main Editing Panel */
          <div className="flex-1 overflow-y-auto custom-scrollbar flex flex-col">
            {/* Navigation Tabs */}
            <div className="flex flex-wrap gap-2 p-4 bg-black/40 border-b border-indigo-500/15">
              <button
                onClick={() => setActiveTab('logo')}
                className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${activeTab === 'logo' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30' : 'text-white/60 hover:text-white hover:bg-white/5'}`}
              >
                <Image size={15} /> الشعار واللوجو
              </button>
              <button
                onClick={() => setActiveTab('mainImage')}
                className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${activeTab === 'mainImage' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30' : 'text-white/60 hover:text-white hover:bg-white/5'}`}
              >
                <Sliders size={15} /> الصورة الرئيسية والأبعاد
              </button>
              <button
                onClick={() => setActiveTab('copyright')}
                className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${activeTab === 'copyright' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30' : 'text-white/60 hover:text-white hover:bg-white/5'}`}
              >
                <Shield size={15} /> حقوق المطور والشارة
              </button>
              <button
                onClick={() => setActiveTab('texts')}
                className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${activeTab === 'texts' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30' : 'text-white/60 hover:text-white hover:bg-white/5'}`}
              >
                <Type size={15} /> نصوص لوحة الدخول
              </button>
              <button
                onClick={() => setActiveTab('emails')}
                className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${activeTab === 'emails' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30' : 'text-white/60 hover:text-white hover:bg-white/5'}`}
              >
                <Mail size={15} /> الإيميل والنسخ الاحتياطي
              </button>
              <button
                onClick={() => setActiveTab('media')}
                className={`px-4 py-2.5 rounded-xl text-xs font-black transition-all flex items-center gap-2 ${activeTab === 'media' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30' : 'text-white/60 hover:text-white hover:bg-white/5'}`}
              >
                <Film size={15} /> ميديا الداشبورد
              </button>
            </div>

            {/* Tab 1: Logo Settings */}
            {activeTab === 'logo' && (
              <div className="p-6 space-y-6">
                <div className="space-y-3">
                  <label className="block text-xs font-black text-white/80 uppercase">صورة الشعار العلوية (فوق تسجيل الدخول)</label>
                  <div className="flex flex-col sm:flex-row gap-4 items-center">
                    <div className="w-24 h-24 rounded-2xl border border-white/10 bg-white/5 flex items-center justify-center p-2 overflow-hidden shrink-0">
                      {formData.logoUrl ? (
                        <img src={formData.logoUrl} alt="Logo" className="max-h-full max-w-full object-contain" />
                      ) : (
                        <span className="text-xs text-white/30 font-bold">لا يوجد شعار</span>
                      )}
                    </div>
                    <div className="flex-1 space-y-3 w-full">
                      <input
                        type="text"
                        value={formData.logoUrl || ''}
                        onChange={(e) => setFormData({ ...formData, logoUrl: e.target.value })}
                        placeholder="رابط صورة الشعار..."
                        className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none"
                      />
                      <label className="inline-flex items-center gap-2 px-4 py-2.5 bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 rounded-xl text-xs font-black cursor-pointer transition-all border border-indigo-500/30">
                        <Upload size={14} /> اختيار صورة من الجهاز
                        <input type="file" accept="image/*" onChange={handleLogoUpload} className="hidden" />
                      </label>
                    </div>
                  </div>
                </div>

                <div className="space-y-3 pt-4 border-t border-white/10">
                  <label className="block text-xs font-black text-white/80 uppercase">ارتفاع الشعار (Height in pixels): {formData.logoHeight || 64}px</label>
                  <input
                    type="range"
                    min="32"
                    max="200"
                    value={formData.logoHeight || 64}
                    onChange={(e) => setFormData({ ...formData, logoHeight: parseInt(e.target.value) })}
                    className="w-full accent-indigo-500"
                  />
                </div>
              </div>
            )}

            {/* Tab 2: Main Image & Dimensions */}
            {activeTab === 'mainImage' && (
              <div className="p-6 space-y-6">
                <div className="space-y-3">
                  <label className="block text-xs font-black text-white/80 uppercase">الصورة الرئيسية (صورة الطائرة / الخلفية)</label>
                  <div className="aspect-[16/9] w-full rounded-2xl border border-white/10 overflow-hidden relative bg-black/50">
                    <img
                      src={formData.companyImage || 'https://images.unsplash.com/photo-1542296332-2e4473faf563'}
                      alt="Main"
                      className="w-full h-full"
                      style={{ objectFit: formData.mainImageObjectFit || 'cover' }}
                    />
                  </div>
                  <div className="flex gap-3">
                    <input
                      type="text"
                      value={formData.companyImage || ''}
                      onChange={(e) => setFormData({ ...formData, companyImage: e.target.value })}
                      placeholder="رابط الصورة الرئيسية..."
                      className="flex-1 bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none"
                    />
                    <label className="px-4 py-3 bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 rounded-xl text-xs font-black cursor-pointer transition-all border border-indigo-500/30 shrink-0 flex items-center gap-2">
                      <Upload size={14} /> رفع صورة
                      <input type="file" accept="image/*" onChange={handleMainImageUpload} className="hidden" />
                    </label>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-white/10">
                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">طريقة احتواء الصورة (Object Fit):</label>
                    <select
                      value={formData.mainImageObjectFit || 'cover'}
                      onChange={(e) => setFormData({ ...formData, mainImageObjectFit: e.target.value as any })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none"
                    >
                      <option value="cover" className="bg-black">محتوى كامل يغطي المساحة (Cover)</option>
                      <option value="contain" className="bg-black">احتواء بدون قص (Contain)</option>
                      <option value="fill" className="bg-black">تعبئة الهيكل (Fill)</option>
                    </select>
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">ارتفاع الصورة (Pixels): {formData.mainImageHeight || 720}px</label>
                    <input
                      type="number"
                      value={formData.mainImageHeight || 720}
                      onChange={(e) => setFormData({ ...formData, mainImageHeight: parseInt(e.target.value) || 720 })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Tab: Copyright Badge & Styling */}
            {activeTab === 'copyright' && (
              <div className="p-6 space-y-6">
                {/* Live Preview Box */}
                <div className="p-6 rounded-2xl bg-black/50 border border-indigo-500/30 flex flex-col items-center justify-center space-y-3">
                  <span className="text-[10px] font-black uppercase text-indigo-400 tracking-widest">معاينة فورية حية لشارة الحقوق (Live Preview)</span>
                  <div 
                    style={{ 
                      backgroundColor: formData.copyrightBgColor || 'rgba(15, 23, 42, 0.8)',
                      borderColor: formData.copyrightBorderColor || 'rgba(255, 255, 255, 0.2)',
                      borderRadius: formData.copyrightBorderRadius !== undefined ? `${formData.copyrightBorderRadius}px` : '9999px',
                      paddingLeft: formData.copyrightPaddingX !== undefined ? `${formData.copyrightPaddingX}px` : '24px',
                      paddingRight: formData.copyrightPaddingX !== undefined ? `${formData.copyrightPaddingX}px` : '24px',
                      paddingTop: formData.copyrightPaddingY !== undefined ? `${formData.copyrightPaddingY}px` : '12px',
                      paddingBottom: formData.copyrightPaddingY !== undefined ? `${formData.copyrightPaddingY}px` : '12px',
                      width: formData.copyrightWidth && formData.copyrightWidth !== 'auto' ? formData.copyrightWidth : 'auto',
                      height: formData.copyrightHeight && formData.copyrightHeight !== 'auto' ? formData.copyrightHeight : 'auto',
                    }}
                    className="border shadow-2xl flex items-center justify-center gap-4 transition-all duration-300 select-none"
                  >
                    <Shield size={16} className="text-orange-500 shrink-0" />
                    <div className="flex flex-col text-center">
                       <p 
                         style={{ 
                           fontSize: formData.copyrightFontSize ? `${formData.copyrightFontSize}px` : '12px',
                           color: formData.copyrightTextColor || '#ffffff',
                           fontFamily: formData.copyrightFontFamily || 'inherit',
                         }}
                         className={`${formData.copyrightFontWeight || 'font-black'} uppercase tracking-widest leading-none`}
                       >
                         {formData.copyrightName || 'Ali Ahmed Aneed'}
                       </p>
                       <p 
                         style={{ 
                           fontSize: formData.copyrightFontSize ? `${Math.max(8, formData.copyrightFontSize - 2)}px` : '10px',
                           color: formData.copyrightTextColor || '#ffffff',
                           fontFamily: formData.copyrightFontFamily || 'inherit',
                           opacity: 0.7
                         }}
                         className="font-bold uppercase tracking-widest mt-1.5"
                       >
                         {formData.copyrightRightsText || 'حقوق الطبع محفوظة للمطور'}
                       </p>
                    </div>
                  </div>
                </div>

                {/* Form Controls Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Name */}
                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">اسم المطور / صاحب الحقوق:</label>
                    <input
                      type="text"
                      value={formData.copyrightName || ''}
                      onChange={(e) => setFormData({ ...formData, copyrightName: e.target.value })}
                      placeholder="Ali Ahmed Aneed"
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none focus:border-indigo-500"
                    />
                  </div>

                  {/* Rights Text */}
                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">نص الحفظ / الحقوق:</label>
                    <input
                      type="text"
                      value={formData.copyrightRightsText || ''}
                      onChange={(e) => setFormData({ ...formData, copyrightRightsText: e.target.value })}
                      placeholder="حقوق الطبع محفوظة للمطور"
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none focus:border-indigo-500"
                    />
                  </div>

                  {/* Font Size */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs font-black text-white/80">
                      <span>حجم الخط (Font Size):</span>
                      <span className="text-indigo-400">{formData.copyrightFontSize || 12}px</span>
                    </div>
                    <input
                      type="range"
                      min="8"
                      max="32"
                      value={formData.copyrightFontSize || 12}
                      onChange={(e) => setFormData({ ...formData, copyrightFontSize: parseInt(e.target.value) })}
                      className="w-full accent-indigo-500 bg-white/10 h-2 rounded-lg cursor-pointer"
                    />
                  </div>

                  {/* Font Family */}
                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">نوع الخط (Font Family):</label>
                    <select
                      value={formData.copyrightFontFamily || ''}
                      onChange={(e) => setFormData({ ...formData, copyrightFontFamily: e.target.value })}
                      className="w-full bg-zinc-900 border border-white/10 rounded-xl p-3 text-xs text-white outline-none focus:border-indigo-500"
                    >
                      <option value="">افتراضي (Default)</option>
                      <option value="'Cairo', sans-serif">Cairo (القاهرة)</option>
                      <option value="'Tajawal', sans-serif">Tajawal (تجوال)</option>
                      <option value="'Alexandria', sans-serif">Alexandria (الإسكندرية)</option>
                      <option value="'IBM Plex Sans Arabic', sans-serif">IBM Plex Sans Arabic</option>
                      <option value="'Inter', sans-serif">Inter</option>
                      <option value="monospace">Monospace (خط برمجي)</option>
                      <option value="serif">Serif (كلاسيكي)</option>
                    </select>
                  </div>

                  {/* Font Weight */}
                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">سُمك الخط (Font Weight):</label>
                    <select
                      value={formData.copyrightFontWeight || 'font-black'}
                      onChange={(e) => setFormData({ ...formData, copyrightFontWeight: e.target.value })}
                      className="w-full bg-zinc-900 border border-white/10 rounded-xl p-3 text-xs text-white outline-none focus:border-indigo-500"
                    >
                      <option value="font-normal">عادي (Normal)</option>
                      <option value="font-medium">متوسط (Medium)</option>
                      <option value="font-semibold">شبه عريض (Semi-Bold)</option>
                      <option value="font-bold">عريض (Bold)</option>
                      <option value="font-black">أسود عريض جداً (Black Extra Bold)</option>
                    </select>
                  </div>

                  {/* Border Radius */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs font-black text-white/80">
                      <span>استدارة الحواف (Border Radius):</span>
                      <span className="text-indigo-400">{formData.copyrightBorderRadius ?? 24}px</span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="50"
                      value={formData.copyrightBorderRadius ?? 24}
                      onChange={(e) => setFormData({ ...formData, copyrightBorderRadius: parseInt(e.target.value) })}
                      className="w-full accent-indigo-500 bg-white/10 h-2 rounded-lg cursor-pointer"
                    />
                  </div>

                  {/* Padding X (Width) */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs font-black text-white/80">
                      <span>المسافة الأفقية / العرض الداخلي (Padding X):</span>
                      <span className="text-indigo-400">{formData.copyrightPaddingX ?? 24}px</span>
                    </div>
                    <input
                      type="range"
                      min="4"
                      max="60"
                      value={formData.copyrightPaddingX ?? 24}
                      onChange={(e) => setFormData({ ...formData, copyrightPaddingX: parseInt(e.target.value) })}
                      className="w-full accent-indigo-500 bg-white/10 h-2 rounded-lg cursor-pointer"
                    />
                  </div>

                  {/* Padding Y (Height) */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs font-black text-white/80">
                      <span>المسافة العمودية / الارتفاع الداخلي (Padding Y):</span>
                      <span className="text-indigo-400">{formData.copyrightPaddingY ?? 12}px</span>
                    </div>
                    <input
                      type="range"
                      min="2"
                      max="40"
                      value={formData.copyrightPaddingY ?? 12}
                      onChange={(e) => setFormData({ ...formData, copyrightPaddingY: parseInt(e.target.value) })}
                      className="w-full accent-indigo-500 bg-white/10 h-2 rounded-lg cursor-pointer"
                    />
                  </div>

                  {/* Custom Width */}
                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">عرض العلبة المخصص (Width):</label>
                    <input
                      type="text"
                      value={formData.copyrightWidth || ''}
                      onChange={(e) => setFormData({ ...formData, copyrightWidth: e.target.value })}
                      placeholder="تلقائي auto أو مثلاً 260px أو 100%"
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none focus:border-indigo-500"
                    />
                  </div>

                  {/* Custom Height */}
                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">ارتفاع العلبة المخصص (Height):</label>
                    <input
                      type="text"
                      value={formData.copyrightHeight || ''}
                      onChange={(e) => setFormData({ ...formData, copyrightHeight: e.target.value })}
                      placeholder="تلقائي auto أو مثلاً 50px أو 60px"
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none focus:border-indigo-500"
                    />
                  </div>

                  {/* Text Color */}
                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">لون النص (Text Color):</label>
                    <div className="flex gap-2">
                      <input
                        type="color"
                        value={formData.copyrightTextColor || '#ffffff'}
                        onChange={(e) => setFormData({ ...formData, copyrightTextColor: e.target.value })}
                        className="w-10 h-10 rounded-xl bg-transparent cursor-pointer border border-white/20 p-1"
                      />
                      <input
                        type="text"
                        value={formData.copyrightTextColor || ''}
                        onChange={(e) => setFormData({ ...formData, copyrightTextColor: e.target.value })}
                        placeholder="#ffffff"
                        className="flex-1 bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none focus:border-indigo-500 font-mono"
                      />
                    </div>
                  </div>

                  {/* Bg Color */}
                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">لون الخلفية (Background Color):</label>
                    <div className="flex gap-2">
                      <input
                        type="color"
                        value={formData.copyrightBgColor?.startsWith('#') ? formData.copyrightBgColor : '#0f172a'}
                        onChange={(e) => setFormData({ ...formData, copyrightBgColor: e.target.value })}
                        className="w-10 h-10 rounded-xl bg-transparent cursor-pointer border border-white/20 p-1"
                      />
                      <input
                        type="text"
                        value={formData.copyrightBgColor || ''}
                        onChange={(e) => setFormData({ ...formData, copyrightBgColor: e.target.value })}
                        placeholder="rgba(15, 23, 42, 0.8) أو #0f172a"
                        className="flex-1 bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none focus:border-indigo-500 font-mono"
                      />
                    </div>
                  </div>

                  {/* Border Color */}
                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">لون الإطار (Border Color):</label>
                    <div className="flex gap-2">
                      <input
                        type="color"
                        value={formData.copyrightBorderColor?.startsWith('#') ? formData.copyrightBorderColor : '#6366f1'}
                        onChange={(e) => setFormData({ ...formData, copyrightBorderColor: e.target.value })}
                        className="w-10 h-10 rounded-xl bg-transparent cursor-pointer border border-white/20 p-1"
                      />
                      <input
                        type="text"
                        value={formData.copyrightBorderColor || ''}
                        onChange={(e) => setFormData({ ...formData, copyrightBorderColor: e.target.value })}
                        placeholder="rgba(255, 255, 255, 0.2) أو #6366f1"
                        className="flex-1 bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none focus:border-indigo-500 font-mono"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Tab 3: Text Customization */}
            {activeTab === 'texts' && (
              <div className="p-6 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">اسم المطور / صاحبة الحقوق:</label>
                    <input
                      type="text"
                      value={formData.copyrightName || 'Ali Ahmed Aneed'}
                      onChange={(e) => setFormData({ ...formData, copyrightName: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">نص حفظ الحقوق:</label>
                    <input
                      type="text"
                      value={formData.copyrightRightsText || 'حقوق الطبع محفوظة للمطور'}
                      onChange={(e) => setFormData({ ...formData, copyrightRightsText: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">اسم الشركة / الموقع:</label>
                    <input
                      type="text"
                      value={formData.companyName || 'AIRLINK'}
                      onChange={(e) => setFormData({ ...formData, companyName: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">العنوان الفرعي بصفحة الدخول:</label>
                    <input
                      type="text"
                      value={formData.loginSubtitle || ''}
                      onChange={(e) => setFormData({ ...formData, loginSubtitle: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">نص زر الدخول (Login Button Text):</label>
                    <input
                      type="text"
                      value={formData.loginButtonText || ''}
                      onChange={(e) => setFormData({ ...formData, loginButtonText: e.target.value })}
                      placeholder="WELCOME TO AIRLINK"
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">عنوان المربع المباشر (Network Link):</label>
                    <input
                      type="text"
                      value={formData.loginWidgetTitle || 'Network Link'}
                      onChange={(e) => setFormData({ ...formData, loginWidgetTitle: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">مانشيت المربع المباشر (AIRLINK HQ):</label>
                    <input
                      type="text"
                      value={formData.loginWidgetHeadline || 'AIRLINK HQ'}
                      onChange={(e) => setFormData({ ...formData, loginWidgetHeadline: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">وصف المربع المباشر:</label>
                    <input
                      type="text"
                      value={formData.loginWidgetDesc || ''}
                      onChange={(e) => setFormData({ ...formData, loginWidgetDesc: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none"
                    />
                  </div>
                </div>

                <div className="pt-4 border-t border-white/10 space-y-4">
                  <h4 className="text-xs font-black text-indigo-400 uppercase">مؤشرات الأمان بأسفل الشاشة</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="space-y-1">
                      <label className="block text-[10px] font-bold text-white/60">المؤشر الأول:</label>
                      <input
                        type="text"
                        value={formData.loginMetric1Title || '24/7 System'}
                        onChange={(e) => setFormData({ ...formData, loginMetric1Title: e.target.value })}
                        className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="block text-[10px] font-bold text-white/60">المؤشر الثاني:</label>
                      <input
                        type="text"
                        value={formData.loginMetric2Title || 'Enterprise'}
                        onChange={(e) => setFormData({ ...formData, loginMetric2Title: e.target.value })}
                        className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white outline-none"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="block text-[10px] font-bold text-white/60">المؤشر الثالث:</label>
                      <input
                        type="text"
                        value={formData.loginMetric3Title || 'Real-time'}
                        onChange={(e) => setFormData({ ...formData, loginMetric3Title: e.target.value })}
                        className="w-full bg-white/5 border border-white/10 rounded-xl p-2.5 text-xs text-white outline-none"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Tab 4: Emails & Backup */}
            {activeTab === 'emails' && (
              <div className="p-6 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">إيميل استقبال الإشعارات:</label>
                    <input
                      type="email"
                      value={formData.notificationEmail || 'aloooshf9@gmail.com'}
                      onChange={(e) => setFormData({ ...formData, notificationEmail: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none"
                    />
                  </div>

                  <div className="space-y-2">
                    <label className="block text-xs font-black text-white/80">إيميل Google Drive للنسخ الاحتياطي:</label>
                    <input
                      type="email"
                      value={formData.googleDriveEmail || 'aloooshf9@gmail.com'}
                      onChange={(e) => setFormData({ ...formData, googleDriveEmail: e.target.value })}
                      className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-xs text-white outline-none"
                    />
                  </div>
                </div>

                <div className="p-5 bg-indigo-500/10 border border-indigo-500/20 rounded-2xl space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Cloud className="text-indigo-400" size={24} />
                      <div>
                        <h4 className="text-sm font-black text-white">النسخ الاحتياطي إلى Google Drive</h4>
                        <p className="text-xs text-white/50">أخذ نسخةاحتياطية فورية وتخزينها في حساب Google Drive الخاص بك</p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={handleGDriveSync}
                      disabled={isGDriveSyncing}
                      className="px-5 py-3 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-black shadow-lg shadow-indigo-600/30 transition-all active:scale-95 disabled:opacity-50"
                    >
                      {isGDriveSyncing ? 'جاري الرفع...' : 'رفع نسخة فورية الآن ☁️'}
                    </button>
                  </div>

                  {gdriveMsg && (
                    <div className="p-3 bg-black/40 rounded-xl text-xs font-bold text-indigo-300">
                      {gdriveMsg}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Tab 5: Dashboard Media */}
            {activeTab === 'media' && (
              <div className="p-6 space-y-6">
                <div className="p-4 bg-white/5 border border-white/10 rounded-2xl space-y-4">
                  <h4 className="text-xs font-black text-indigo-400 uppercase">إضافة فيديو أو صورة أو GIF جديد للداشبورد</h4>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <input
                      type="text"
                      value={mediaTitle}
                      onChange={(e) => setMediaTitle(e.target.value)}
                      placeholder="عنوان الميديا..."
                      className="bg-black/50 border border-white/10 rounded-xl p-3 text-xs text-white outline-none"
                    />
                    <input
                      type="text"
                      value={mediaUrl}
                      onChange={(e) => setMediaUrl(e.target.value)}
                      placeholder="رابط الميديا (YouTube / GIF / MP4 / Image)..."
                      className="bg-black/50 border border-white/10 rounded-xl p-3 text-xs text-white outline-none font-mono"
                    />
                    <select
                      value={mediaType}
                      onChange={(e) => setMediaType(e.target.value as any)}
                      className="bg-black/50 border border-white/10 rounded-xl p-3 text-xs text-white outline-none"
                    >
                      <option value="image">صورة (Image)</option>
                      <option value="gif">GIF متحرك</option>
                      <option value="video">فيديو (Video / YouTube)</option>
                    </select>
                  </div>
                  <button
                    type="button"
                    onClick={handleAddMediaItem}
                    className="px-5 py-3 bg-indigo-600 hover:bg-indigo-500 text-white font-black text-xs rounded-xl transition-all shadow-md"
                  >
                    + إضافة إلى الداشبورد
                  </button>
                </div>

                {/* Existing media list */}
                {formData.dashboardMediaList && formData.dashboardMediaList.length > 0 && (
                  <div className="space-y-3">
                    <h5 className="text-xs font-black text-white/70">الميديا المضافة حالياً ({formData.dashboardMediaList.length})</h5>
                    <div className="space-y-2 max-h-48 overflow-y-auto custom-scrollbar">
                      {formData.dashboardMediaList.map((item) => (
                        <div key={item.id} className="p-3 bg-black/40 border border-white/10 rounded-xl flex items-center justify-between text-xs">
                          <div className="flex items-center gap-3 truncate">
                            {item.type === 'video' ? <Video size={16} className="text-rose-400 shrink-0" /> : <Film size={16} className="text-indigo-400 shrink-0" />}
                            <span className="font-bold text-white truncate">{item.title}</span>
                            <span className="text-[10px] text-white/40 font-mono truncate">{item.url}</span>
                          </div>
                          <button
                            type="button"
                            onClick={() => handleDeleteMediaItem(item.id)}
                            className="p-1.5 text-rose-400 hover:bg-rose-500/20 rounded-lg transition-colors"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* Modal Footer */}
        {isUnlocked && (
          <div className="p-4 border-t border-indigo-500/20 bg-black/60 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-3 text-white/60 hover:text-white text-xs font-black transition-colors"
              >
                إغلاق
              </button>
              {saveSuccessMsg && (
                <span className="text-emerald-400 text-xs font-black animate-in fade-in">
                  {saveSuccessMsg}
                </span>
              )}
            </div>
            <button
              type="button"
              onClick={handleSaveSettings}
              className="px-8 py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black uppercase tracking-wider rounded-xl shadow-lg shadow-indigo-600/30 transition-all active:scale-95"
            >
              حفظ كافة التغييرات ✨
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

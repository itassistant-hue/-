import React, { useState, useEffect } from 'react';
import { 
  X, Download, Eye, ExternalLink, FileText, Film, Music, 
  ZoomIn, ZoomOut, RotateCw, Maximize2, Minimize2, Paperclip, Copy, Check
} from 'lucide-react';

export interface PreviewFileItem {
  name: string;
  data?: string;
  url?: string;
  type?: string;
  size?: number;
}

interface FilePreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  file: PreviewFileItem | null;
  lang?: 'ar' | 'en';
}

export function getFileTypeCategory(file: PreviewFileItem | null): 'image' | 'pdf' | 'video' | 'audio' | 'text' | 'office' | 'other' {
  if (!file) return 'other';
  const name = (file.name || '').toLowerCase();
  const mime = (file.type || '').toLowerCase();
  const src = (file.data || file.url || '');

  if (mime.startsWith('image/') || /\.(png|jpe?g|gif|webp|svg|bmp|ico)$/i.test(name) || src.startsWith('data:image/')) {
    return 'image';
  }
  if (mime.includes('pdf') || /\.pdf$/i.test(name) || src.startsWith('data:application/pdf')) {
    return 'pdf';
  }
  if (mime.startsWith('video/') || /\.(mp4|webm|ogg|mov)$/i.test(name) || src.startsWith('data:video/')) {
    return 'video';
  }
  if (mime.startsWith('audio/') || /\.(mp3|wav|ogg|m4a)$/i.test(name) || src.startsWith('data:audio/')) {
    return 'audio';
  }
  if (mime.startsWith('text/') || /\.(txt|json|csv|md|log|xml|html)$/i.test(name) || src.startsWith('data:text/')) {
    return 'text';
  }
  if (/\.(docx?|xlsx?|pptx?)$/i.test(name) || mime.includes('officedocument') || mime.includes('msword') || mime.includes('ms-excel')) {
    return 'office';
  }
  return 'other';
}

export const FilePreviewModal: React.FC<FilePreviewModalProps> = ({
  isOpen,
  onClose,
  file,
  lang = 'ar'
}) => {
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);
  const [textContent, setTextContent] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  useEffect(() => {
    setZoom(1);
    setRotation(0);
    setTextContent(null);
    setCopied(false);

    if (file && getFileTypeCategory(file) === 'text') {
      const src = file.data || file.url;
      if (src && src.startsWith('data:')) {
        try {
          const base64Part = src.split(',')[1];
          if (base64Part) {
            const binaryStr = atob(base64Part);
            const bytes = new Uint8Array(binaryStr.length);
            for (let i = 0; i < binaryStr.length; i++) {
              bytes[i] = binaryStr.charCodeAt(i);
            }
            const decoded = new TextDecoder('utf-8').decode(bytes);
            setTextContent(decoded);
          }
        } catch {
          setTextContent(null);
        }
      } else if (src && (src.startsWith('http') || src.startsWith('/'))) {
        fetch(src)
          .then(res => res.text())
          .then(text => setTextContent(text))
          .catch(() => setTextContent(null));
      }
    }
  }, [file]);

  if (!isOpen || !file) return null;

  const fileSrc = file.data || file.url || '';
  const fileCategory = getFileTypeCategory(file);
  const isAr = lang === 'ar';

  const handleDownload = () => {
    if (!fileSrc) return;
    try {
      const link = document.createElement('a');
      link.href = fileSrc;
      link.download = file.name || 'document';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch {
      // Graceful fallback
    }
  };

  const handleOpenNewTab = () => {
    if (!fileSrc) return;
    try {
      if (fileSrc.startsWith('data:')) {
        const win = window.open('', '_blank');
        if (win) {
          win.document.write(`
            <!DOCTYPE html>
            <html>
              <head><title>${file.name || 'Document'}</title></head>
              <body style="margin:0; background:#0f172a; display:flex; justify-content:center; align-items:center; height:100vh;">
                ${fileCategory === 'image' 
                  ? `<img src="${fileSrc}" style="max-width:100%; max-height:100vh; object-fit:contain;" />` 
                  : `<iframe src="${fileSrc}" style="width:100%; height:100vh; border:none;"></iframe>`}
              </body>
            </html>
          `);
          win.document.close();
        }
      } else {
        window.open(fileSrc, '_blank');
      }
    } catch {
      // Graceful fallback
    }
  };

  const handleCopyText = () => {
    if (textContent) {
      navigator.clipboard.writeText(textContent);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-[999999] flex items-center justify-center p-2 sm:p-4 md:p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-200 dir-rtl">
      <div 
        className={`relative w-full ${isFullscreen ? 'h-full max-w-none rounded-none' : 'max-w-5xl max-h-[92vh] rounded-3xl'} bg-zinc-950 border border-white/10 shadow-2xl flex flex-col overflow-hidden text-white transition-all duration-300`}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10 bg-zinc-900/90 backdrop-blur-md shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 shrink-0 shadow-inner">
              {fileCategory === 'image' && <Eye size={18} />}
              {fileCategory === 'pdf' && <FileText size={18} className="text-rose-400" />}
              {fileCategory === 'video' && <Film size={18} className="text-emerald-400" />}
              {fileCategory === 'audio' && <Music size={18} className="text-amber-400" />}
              {fileCategory === 'text' && <FileText size={18} className="text-cyan-400" />}
              {fileCategory === 'office' && <FileText size={18} className="text-blue-400" />}
              {fileCategory === 'other' && <Paperclip size={18} className="text-gray-400" />}
            </div>
            <div className="min-w-0">
              <h3 className="text-sm font-black text-white truncate max-w-[280px] sm:max-w-[450px]">
                {file.name}
              </h3>
              <p className="text-[10px] font-bold text-white/50 uppercase tracking-widest flex items-center gap-2">
                <span>{file.type || fileCategory.toUpperCase()}</span>
                {file.size && <span>• {(file.size / 1024).toFixed(1)} KB</span>}
              </p>
            </div>
          </div>

          {/* Action Toolbar */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Image Zoom Tools */}
            {fileCategory === 'image' && (
              <div className="hidden sm:flex items-center gap-1 bg-white/5 p-1 rounded-xl border border-white/10 ml-2">
                <button
                  onClick={() => setZoom(prev => Math.max(0.5, prev - 0.25))}
                  className="p-1.5 hover:bg-white/10 rounded-lg text-white/80 hover:text-white transition-colors"
                  title={isAr ? "تصغير" : "Zoom Out"}
                >
                  <ZoomOut size={15} />
                </button>
                <span className="text-[10px] font-mono px-1 text-indigo-400 font-bold">{Math.round(zoom * 100)}%</span>
                <button
                  onClick={() => setZoom(prev => Math.min(3, prev + 0.25))}
                  className="p-1.5 hover:bg-white/10 rounded-lg text-white/80 hover:text-white transition-colors"
                  title={isAr ? "تكبير" : "Zoom In"}
                >
                  <ZoomIn size={15} />
                </button>
                <button
                  onClick={() => setRotation(prev => (prev + 90) % 360)}
                  className="p-1.5 hover:bg-white/10 rounded-lg text-white/80 hover:text-white transition-colors border-r border-white/10 pr-1 pr-1.5"
                  title={isAr ? "تدوير" : "Rotate"}
                >
                  <RotateCw size={15} />
                </button>
              </div>
            )}

            {/* Fullscreen Toggle */}
            <button
              onClick={() => setIsFullscreen(!isFullscreen)}
              className="p-2 hover:bg-white/10 rounded-xl text-white/70 hover:text-white transition-colors hidden sm:block"
              title={isFullscreen ? (isAr ? "إنهاء ملء الشاشة" : "Exit Fullscreen") : (isAr ? "ملء الشاشة" : "Fullscreen")}
            >
              {isFullscreen ? <Minimize2 size={18} /> : <Maximize2 size={18} />}
            </button>

            {/* Open in New Tab */}
            <button
              onClick={handleOpenNewTab}
              className="px-3 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-xs font-bold text-white/80 hover:text-white transition-all flex items-center gap-1.5"
              title={isAr ? "فتح في نافذة جديدة" : "Open in new tab"}
            >
              <ExternalLink size={14} />
              <span className="hidden md:inline">{isAr ? "فتح بمستعرض" : "Open"}</span>
            </button>

            {/* Download Button */}
            <button
              onClick={handleDownload}
              className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 rounded-xl text-xs font-black text-white shadow-lg shadow-indigo-500/25 transition-all flex items-center gap-2 active:scale-95"
            >
              <Download size={14} />
              <span>{isAr ? "تحميل" : "Download"}</span>
            </button>

            {/* Close Modal */}
            <button
              onClick={onClose}
              className="p-2 hover:bg-rose-500/20 hover:text-rose-400 rounded-xl text-white/60 transition-colors ml-1"
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Modal Main Viewport */}
        <div className="flex-1 overflow-auto p-4 sm:p-6 bg-zinc-950/80 flex items-center justify-center min-h-[350px]">
          {/* IMAGE PREVIEW */}
          {fileCategory === 'image' && (
            <div className="relative w-full h-full flex items-center justify-center overflow-auto p-2">
              {fileSrc ? (
                <img
                  src={fileSrc}
                  alt={file.name}
                  style={{
                    transform: `scale(${zoom}) rotate(${rotation}deg)`,
                    transition: 'transform 0.2s ease-out'
                  }}
                  className="max-w-full max-h-[75vh] object-contain rounded-2xl shadow-2xl border border-white/10 select-none"
                />
              ) : (
                <div className="text-center text-white/40 text-xs">{isAr ? "تعذر تحميل الصورة" : "Image failed to load"}</div>
              )}
            </div>
          )}

          {/* PDF PREVIEW */}
          {fileCategory === 'pdf' && (
            <div className="w-full h-full min-h-[60vh] flex flex-col rounded-2xl overflow-hidden border border-white/10 bg-zinc-900">
              {fileSrc ? (
                <iframe
                  src={fileSrc}
                  title={file.name || 'PDF Document'}
                  className="w-full h-[70vh] rounded-2xl border-0"
                />
              ) : (
                <div className="flex flex-col items-center justify-center h-[50vh] text-center">
                  <FileText size={48} className="text-rose-400 mb-3" />
                  <p className="text-xs font-bold text-white/60">{isAr ? "لا يتوفر رابط للمستند" : "No PDF data source"}</p>
                </div>
              )}
            </div>
          )}

          {/* VIDEO PREVIEW */}
          {fileCategory === 'video' && (
            <div className="w-full h-full flex items-center justify-center">
              {fileSrc ? (
                <video
                  src={fileSrc}
                  controls
                  autoPlay
                  className="max-w-full max-h-[75vh] rounded-2xl shadow-2xl border border-white/10"
                />
              ) : (
                <div className="text-center text-white/40 text-xs">{isAr ? "تعذر تشغيل الفيديو" : "Video player error"}</div>
              )}
            </div>
          )}

          {/* AUDIO PREVIEW */}
          {fileCategory === 'audio' && (
            <div className="w-full max-w-md p-8 bg-zinc-900 border border-white/10 rounded-3xl text-center space-y-6 shadow-2xl">
              <div className="w-20 h-20 mx-auto rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shadow-inner">
                <Music size={36} />
              </div>
              <div>
                <h4 className="text-base font-black text-white truncate">{file.name}</h4>
                <p className="text-xs font-bold text-white/40 mt-1">{isAr ? "ملف صوتی" : "Audio File"}</p>
              </div>
              <audio src={fileSrc} controls className="w-full accent-indigo-500" />
            </div>
          )}

          {/* TEXT PREVIEW */}
          {fileCategory === 'text' && (
            <div className="w-full h-full min-h-[50vh] max-h-[70vh] flex flex-col bg-zinc-900 border border-white/10 rounded-2xl overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 bg-zinc-950 border-b border-white/10 text-xs font-bold text-white/60">
                <span>{isAr ? "محتوى المستند النصي" : "Text Document Content"}</span>
                {textContent && (
                  <button
                    onClick={handleCopyText}
                    className="flex items-center gap-1.5 px-3 py-1 bg-white/5 hover:bg-white/10 rounded-lg text-[10px] font-black text-indigo-400 transition-colors"
                  >
                    {copied ? <Check size={12} className="text-emerald-400" /> : <Copy size={12} />}
                    <span>{copied ? (isAr ? "تم النسخ!" : "Copied!") : (isAr ? "نسخ النص" : "Copy")}</span>
                  </button>
                )}
              </div>
              <div className="flex-1 p-5 overflow-auto font-mono text-xs text-emerald-400 leading-relaxed whitespace-pre-wrap dir-ltr text-left bg-zinc-950/90">
                {textContent !== null ? textContent : (fileSrc ? (isAr ? "جاري قراءة النص..." : "Loading text...") : (isAr ? "لا يوجد محتوى نصي" : "No text content"))}
              </div>
            </div>
          )}

          {/* OFFICE / OTHER DOCUMENTS PREVIEW CARD */}
          {(fileCategory === 'office' || fileCategory === 'other') && (
            <div className="w-full max-w-lg p-8 bg-zinc-900/90 border border-white/10 rounded-3xl text-center space-y-6 shadow-2xl my-auto">
              <div className="w-24 h-24 mx-auto rounded-3xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 shadow-2xl">
                <FileText size={48} />
              </div>

              <div className="space-y-2">
                <span className="px-3 py-1 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded-full text-[10px] font-black uppercase tracking-widest">
                  {file.type || (fileCategory === 'office' ? 'Office Document' : 'Attachment File')}
                </span>
                <h4 className="text-lg font-black text-white break-words px-2">{file.name}</h4>
                <p className="text-xs font-bold text-white/50">
                  {isAr ? "المعاينة التفاعلية متاحة بالكامل عبر التحميل أو الفتح المباشر" : "Interactive document preview ready"}
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                <button
                  onClick={handleOpenNewTab}
                  className="w-full sm:w-auto px-6 py-3.5 bg-white/10 hover:bg-white/15 border border-white/10 rounded-2xl text-xs font-black text-white transition-all flex items-center justify-center gap-2"
                >
                  <ExternalLink size={16} />
                  <span>{isAr ? "فتح بمستعرض مستقل" : "Open Document"}</span>
                </button>
                <button
                  onClick={handleDownload}
                  className="w-full sm:w-auto px-6 py-3.5 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 rounded-2xl text-xs font-black text-white shadow-xl shadow-indigo-500/30 transition-all flex items-center justify-center gap-2"
                >
                  <Download size={16} />
                  <span>{isAr ? "تحميل المستند" : "Download File"}</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

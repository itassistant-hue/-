import React, { useState } from 'react';
import { RequestStatus } from '../../types.ts';
import { TranslationType } from '../../translations.ts';
import { statusStyles } from '../../constants.ts';

export const Card = ({ children, className = '', ...props }: { children: React.ReactNode; className?: string; [key: string]: any }) => (
  <div className={`glass-pane rounded-[24px] ${className}`} {...props}>{children}</div>
);

export const StatusBadge = ({ status, t }: { status: RequestStatus; t: any }) => {
  const config = statusStyles[status];
  if (!config) return null;
  const Icon = config.icon;
  // Dynamic glow colors
  const glowStyles: Record<RequestStatus, string> = {
    pending: 'shadow-amber-500/10 border-amber-500/20',
    inProgress: 'shadow-blue-500/10 border-blue-500/20',
    quoted: 'shadow-indigo-500/10 border-indigo-500/20',
    approved: 'shadow-emerald-500/10 border-emerald-500/20',
    rejected: 'shadow-rose-500/10 border-rose-500/20',
    completed: 'shadow-emerald-500/10 border-emerald-500/20',
  };

  return (
    <span className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-[10px] font-black uppercase tracking-wider ${config.bg} ${config.text} border ${glowStyles[status]} shadow-lg backdrop-blur-md`}>
      <Icon size={12} strokeWidth={3} /> {t[status]}
    </span>
  );
};

export const Avatar = ({ name, url, className = "w-8 h-8 rounded-full" }: { name?: string; url?: string | null; className?: string }) => {
  const [hasError, setHasError] = useState(false);
  if (url && url.trim() !== '' && !hasError) {
    return (
      <img 
        src={url} 
        alt={name} 
        referrerPolicy="no-referrer"
        onError={() => setHasError(true)}
        className={`${className} object-cover border-2 border-white/20`} 
      />
    );
  }
  return (
    <div className={`${className} accent-gradient text-white flex items-center justify-center font-bold text-xs border-2 border-white/20`}>
      {name ? name.charAt(0).toUpperCase() : '?'}
    </div>
  );
};

export const AirlinkLogo = ({ className = "h-12" }: { className?: string }) => {
  return (
    <div className={`inline-flex items-center gap-4 ${className}`}>
       <div className="flex flex-col">
          <div className="flex h-10">
             <div className="bg-[#da4a26] w-10 h-10 flex items-center justify-center relative overflow-hidden">
                {/* Stylized 'a' swoosh */}
                <svg viewBox="0 0 100 100" className="absolute inset-x-0 bottom-0 w-full h-[80%] pointer-events-none">
                   <path d="M10,90 C10,30 50,10 90,40 T100,90" fill="none" stroke="white" strokeWidth="8" />
                </svg>
                <span className="text-white font-black text-sm relative z-10 self-start mt-1.5 ml-2">IR</span>
             </div>
             <div className="bg-[#5abebf] w-14 h-10 flex items-center justify-center">
                <span className="text-white font-black text-xl tracking-tighter">LINK</span>
             </div>
          </div>
          <span className="text-[#da4a26] text-[7px] font-black uppercase tracking-[0.2em] mt-1 text-center w-full">TRAVEL & TOURISM</span>
       </div>
       <div className="flex items-center">
         <span className="text-4xl font-black text-[#da4a26] tracking-tighter uppercase leading-none">AIRLINK</span>
       </div>
    </div>
  );
};

export const PriceDisplay = ({ amount, currency, defaultCurrency, exchangeRate = 1500, className = "" }: { amount: number; currency?: 'USD' | 'IQD'; defaultCurrency?: 'USD' | 'IQD'; exchangeRate?: number; className?: string }) => {
  const displayCurrency = defaultCurrency || 'USD';
  const sourceCurrency = currency || 'USD';
  
  let convertedAmount = amount;
  if (sourceCurrency !== displayCurrency) {
    if (sourceCurrency === 'USD' && displayCurrency === 'IQD') {
      convertedAmount = amount * exchangeRate;
    } else if (sourceCurrency === 'IQD' && displayCurrency === 'USD') {
      convertedAmount = amount / exchangeRate;
    }
  }

  const symbol = displayCurrency === 'USD' ? '$' : 'IQD';
  const formattedAmount = convertedAmount.toLocaleString(undefined, {
    minimumFractionDigits: displayCurrency === 'USD' ? 2 : 0,
    maximumFractionDigits: displayCurrency === 'USD' ? 2 : 0,
  });

  return (
    <span className={`font-mono ${className}`}>
      {displayCurrency === 'USD' ? symbol : ''}
      {formattedAmount}
      {displayCurrency === 'IQD' ? ` ${symbol}` : ''}
    </span>
  );
};

export const isVideoUrl = (url?: string): boolean => {
  if (!url) return false;
  const lower = url.toLowerCase();
  if (lower.startsWith('data:video/')) return true;
  if (lower.includes('.mp4') || lower.includes('.webm') || lower.includes('.ogg') || lower.includes('.mov') || lower.includes('.m4v') || lower.includes('.m3u8')) return true;
  if (lower.includes('youtube.com') || lower.includes('youtu.be') || lower.includes('vimeo.com')) return true;
  return false;
};

export const isYouTubeUrl = (url?: string): boolean => {
  if (!url) return false;
  const lower = url.toLowerCase();
  return lower.includes('youtube.com') || lower.includes('youtu.be');
};

export const MediaDisplay = ({ 
  url, 
  alt = 'Media', 
  className = "w-full h-full object-cover",
  autoPlay = true,
  loop = true,
  muted = true,
  controls = false
}: { 
  url?: string; 
  alt?: string; 
  className?: string; 
  autoPlay?: boolean;
  loop?: boolean;
  muted?: boolean;
  controls?: boolean;
}) => {
  if (!url || url.trim() === '') return null;

  if (isYouTubeUrl(url)) {
    let videoId = '';
    if (url.includes('youtu.be/')) {
      videoId = url.split('youtu.be/')[1]?.split('?')[0] || '';
    } else if (url.includes('watch?v=')) {
      videoId = url.split('watch?v=')[1]?.split('&')[0] || '';
    }
    if (videoId) {
      return (
        <iframe 
          src={`https://www.youtube.com/embed/${videoId}?autoplay=${autoPlay ? 1 : 0}&mute=${muted ? 1 : 0}&loop=${loop ? 1 : 0}&playlist=${videoId}&controls=${controls ? 1 : 0}`} 
          className={className} 
          allow="autoplay; encrypted-media"
          allowFullScreen 
          title={alt}
        />
      );
    }
  }

  if (isVideoUrl(url)) {
    return (
      <video 
        src={url} 
        autoPlay={autoPlay} 
        loop={loop} 
        muted={muted} 
        playsInline 
        controls={controls}
        className={className}
      />
    );
  }

  return (
    <img 
      src={url} 
      alt={alt} 
      referrerPolicy="no-referrer"
      onError={(e) => {
        // Prevent broken image loop
        const target = e.currentTarget;
        if (!target.dataset.failed) {
          target.dataset.failed = "true";
          target.src = "https://images.unsplash.com/photo-1542296332-2e4473faf563?q=80&w=2670&auto=format&fit=crop";
        }
      }}
      className={className}
    />
  );
};

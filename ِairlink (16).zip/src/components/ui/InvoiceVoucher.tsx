import React from 'react';
import { AirlinkLogo, PriceDisplay } from './Common.tsx';
import { ServiceRequest, AppSettings } from '../../types.ts';
import { Printer, Download, X } from 'lucide-react';

interface InvoiceVoucherProps {
  request: ServiceRequest;
  settings: AppSettings;
  t: any;
  onClose: () => void;
}

export const InvoiceVoucher = ({ request, settings, t, onClose }: InvoiceVoucherProps) => {
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-[100] flex justify-center p-4 bg-[#020617]/90 backdrop-blur-xl animate-in fade-in duration-300 overflow-y-auto">
      <div className="bg-white text-slate-900 w-full max-w-2xl rounded-[40px] shadow-2xl relative overflow-hidden flex flex-col h-fit my-10 min-h-[500px]">
        
        {/* Modal Controls */}
        <div className="absolute top-6 right-6 flex gap-3 no-print z-50">
           <button onClick={handlePrint} className="p-3 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-2xl transition-all shadow-sm" title="Print Invoice"><Printer size={20}/></button>
           <button onClick={onClose} className="p-3 bg-slate-900 text-white hover:bg-slate-800 rounded-2xl transition-all shadow-lg" title="Hide"><X size={20}/></button>
        </div>

        <div className="flex-1 overflow-y-auto p-12 printable-area print-target print:p-0">
          {/* Exact Image Match Structure */}
          <div className="flex justify-between items-start mb-6">
             <div className="flex flex-col">
                <div className="h-20 flex items-center">
                   {settings.logoUrl && settings.logoUrl.trim() !== '' ? (
                      <img src={settings.logoUrl} alt="Logo" style={{ height: '80px' }} className="object-contain" />
                   ) : (
                      <AirlinkLogo className="h-20" />
                   )}
                </div>
             </div>
             <div className="text-right">
                <p className="text-[10px] font-black text-[#64748b] uppercase tracking-[0.2em]">Reference Number</p>
                <p className="text-3xl font-black text-slate-900 mt-1">#{(request.id || '').toString().startsWith('REQ-') ? request.id : `REQ-${request.id}`}</p>
             </div>
          </div>

          <div className="flex justify-between items-end mb-10">
             <div>
                <h1 className="text-3xl font-black text-slate-900 leading-none uppercase tracking-tighter">Airlink</h1>
                <p className="text-[10px] font-black text-[#94a3b8] uppercase tracking-[0.3em] mt-2">Official Financial Document</p>
             </div>
             <div className="text-right">
                <p className="text-[10px] font-black text-[#64748b] uppercase tracking-[0.2em]">Date Issued</p>
                <p className="text-2xl font-black text-slate-700 mt-1">{request.date}</p>
             </div>
          </div>

          {/* Separation Line from Image */}
          <div className="w-full h-px bg-slate-100 mb-16"></div>

          <div className="grid grid-cols-2 gap-12 mb-24 px-12 py-14 bg-slate-50/50 rounded-[48px] border border-slate-100">
             <div className="space-y-6">
                <p className="text-[11px] font-black uppercase tracking-[0.2em] text-[#818cf8]">Billed To</p>
                <div className="space-y-2">
                  <p className="text-3xl font-black text-slate-900 tracking-tight leading-tight">{request.company}</p>
                  <p className="text-sm font-bold text-slate-400">Corporate Member • Premium Plan</p>
                </div>
             </div>
             <div className="space-y-6">
                <p className="text-[11px] font-black uppercase tracking-[0.2em] text-[#818cf8]">Service Category</p>
                <div className="space-y-2">
                  <p className="text-3xl font-black text-slate-900 uppercase tracking-tighter leading-none">{t[request.service] || request.service}</p>
                  <p className="text-sm font-bold text-slate-400 mt-2">Infrastructure Support</p>
                </div>
             </div>
          </div>

          <div className="mb-12 px-2">
            <div className="flex justify-between items-center mb-5 text-[10px] font-black uppercase tracking-[0.2em] text-[#94a3b8]">
               <span>Description</span>
               <span>Amount ({settings.defaultCurrency || 'USD'})</span>
            </div>
            <div className="w-full h-1.5 bg-slate-900 mb-12"></div>
            
            <div className="flex justify-between items-start mb-16">
               <div className="space-y-4">
                  <p className="text-2xl font-black text-slate-900 tracking-tight">Service Request: {(request.id || '').toString().startsWith('REQ-') ? request.id : `REQ-${request.id}`}</p>
                  <p className="text-base font-medium text-slate-500 max-w-lg leading-relaxed">{request.notes || 'Professional service fulfillment for corporate infrastructure.'}</p>
               </div>
               <div className="text-right">
                  <p className="text-6xl font-black text-slate-900 tracking-tighter leading-none">
                    <PriceDisplay amount={Number(request.selling) || 0} defaultCurrency={settings.defaultCurrency} exchangeRate={settings.exchangeRate} />
                  </p>
               </div>
            </div>

            <div className="w-full h-1.5 bg-slate-900 mb-16"></div>

            <div className="flex justify-end items-center gap-12">
               <p className="text-[11px] font-black uppercase tracking-[0.3em] text-[#94a3b8]">Total Investment</p>
               <p className="text-8xl font-black text-slate-900 tracking-tighter leading-none">
                 <PriceDisplay amount={Number(request.selling) || 0} defaultCurrency={settings.defaultCurrency} exchangeRate={settings.exchangeRate} />
               </p>
            </div>
          </div>

          <div className="mt-20 pt-8 border-t border-slate-200 flex justify-between items-end">
             <div className="text-[9px] font-bold uppercase tracking-[0.2em] text-slate-500 leading-relaxed">
                <span className="font-black text-slate-900">{settings.companyName || 'AIRLINK'} OFFICIAL DOCUMENT</span><br />
                ID: {Math.random().toString(36).substring(7).toUpperCase()} • ALL RIGHTS RESERVED
             </div>
             <div className="text-center flex flex-col items-center">
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-900 mb-2">ختم وتوقيع الشركة (Company Stamp & Signature)</p>
                {settings.companyStampUrl ? (
                   <img src={settings.companyStampUrl} alt="Company Stamp" className="h-24 w-24 object-contain rounded-full border border-slate-200 p-1 shadow-sm" />
                ) : (
                   <div className="h-20 w-28 rounded-2xl border-2 border-dashed border-slate-300 flex items-center justify-center text-[9px] font-bold text-slate-400 uppercase tracking-widest">
                      [ختم الشركة]
                   </div>
                )}
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

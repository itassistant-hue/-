import React, { useState } from 'react';
import { Shield, X, Check, Type, Palette, Sliders, Sparkles } from 'lucide-react';
import { AppSettings } from '../../types.ts';

interface CopyrightsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  onSave: (newSettings: Partial<AppSettings>) => void;
}

export const CopyrightsModal: React.FC<CopyrightsModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSave,
}) => {
  const [name, setName] = useState(settings.copyrightName || 'Ali Ahmed Aneed');
  const [rightsText, setRightsText] = useState(settings.copyrightRightsText || 'حقوق الطبع محفوظة للمطور');
  const [fontSize, setFontSize] = useState<number>(settings.copyrightFontSize || 11);
  const [textColor, setTextColor] = useState(settings.copyrightTextColor || '#ffffff');
  const [fontFamily, setFontFamily] = useState(settings.copyrightFontFamily || 'sans-serif');
  const [fontWeight, setFontWeight] = useState(settings.copyrightFontWeight || 'font-black');
  const [bgColor, setBgColor] = useState(settings.copyrightBgColor || 'rgba(15, 23, 42, 0.8)');

  if (!isOpen) return null;

  const handleSave = () => {
    onSave({
      copyrightName: name,
      copyrightRightsText: rightsText,
      copyrightFontSize: Number(fontSize),
      copyrightTextColor: textColor,
      copyrightFontFamily: fontFamily,
      copyrightFontWeight: fontWeight,
      copyrightBgColor: bgColor,
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-in fade-in duration-300">
      <div className="bg-[#0f172a] text-white border border-indigo-500/30 rounded-3xl max-w-xl w-full p-6 lg:p-8 shadow-[0_25px_60px_rgba(0,0,0,0.8)] relative overflow-hidden dir-rtl">
        {/* Glow accent */}
        <div className="absolute -top-20 -right-20 w-48 h-48 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />

        <div className="flex items-center justify-between pb-4 border-b border-white/10 mb-6">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
              <Shield size={22} />
            </div>
            <div>
              <h3 className="text-xl font-black text-white tracking-tight">تعديل حقوق الملكية والشعار</h3>
              <p className="text-xs text-white/50 font-medium">الوضع السري: تخصيص حقوق المطور بالكامل</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-white/50 hover:text-white hover:bg-white/10 rounded-xl transition-colors"
          >
            <X size={20} />
          </button>
        </div>

        {/* Live Preview Box */}
        <div className="mb-6 p-6 rounded-2xl border border-white/10 relative overflow-hidden bg-slate-900/80">
          <p className="text-[10px] font-black uppercase tracking-widest text-indigo-400 mb-3 flex items-center gap-2">
            <Sparkles size={12} /> معاينة مباشرة (Live Preview)
          </p>
          <div
            className="p-4 rounded-full border border-white/20 shadow-2xl flex items-center justify-between gap-4 max-w-md mx-auto transition-all"
            style={{ backgroundColor: bgColor }}
          >
            <div className="flex items-center gap-3">
              <Shield size={20} className="text-amber-400 shrink-0" />
              <div className="flex flex-col">
                <p
                  style={{
                    fontSize: `${fontSize}px`,
                    color: textColor,
                    fontFamily: fontFamily,
                  }}
                  className={`${fontWeight} uppercase tracking-widest leading-none`}
                >
                  {name || 'اسم المطور / الشركة'}
                </p>
                <p
                  style={{
                    fontSize: `${Math.max(8, fontSize - 2)}px`,
                    color: textColor,
                    opacity: 0.7,
                    fontFamily: fontFamily,
                  }}
                  className="font-bold uppercase tracking-widest mt-1"
                >
                  {rightsText || 'حقوق الطبع محفوظة'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="space-y-4 max-h-[50vh] overflow-y-auto pr-1 custom-scrollbar">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-white/80 mb-1.5 flex items-center gap-1.5">
                <Type size={14} className="text-indigo-400" /> الاسم / المطور
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full bg-slate-800/80 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-indigo-500 font-medium"
                placeholder="أدخل الاسم"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-white/80 mb-1.5 flex items-center gap-1.5">
                <Type size={14} className="text-indigo-400" /> نص الحقوق
              </label>
              <input
                type="text"
                value={rightsText}
                onChange={(e) => setRightsText(e.target.value)}
                className="w-full bg-slate-800/80 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-indigo-500 font-medium"
                placeholder="حقوق الطبع محفوظة..."
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-white/80 mb-1.5 flex items-center gap-1.5">
                <Sliders size={14} className="text-indigo-400" /> حجم الخط ({fontSize}px)
              </label>
              <input
                type="range"
                min="8"
                max="24"
                value={fontSize}
                onChange={(e) => setFontSize(Number(e.target.value))}
                className="w-full accent-indigo-500 h-2 bg-slate-800 rounded-lg cursor-pointer mt-2"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-white/80 mb-1.5 flex items-center gap-1.5">
                <Palette size={14} className="text-indigo-400" /> لون النص
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={textColor}
                  onChange={(e) => setTextColor(e.target.value)}
                  className="w-10 h-10 rounded-xl bg-transparent border border-white/20 cursor-pointer p-0.5"
                />
                <input
                  type="text"
                  value={textColor}
                  onChange={(e) => setTextColor(e.target.value)}
                  className="flex-1 bg-slate-800/80 border border-white/10 rounded-xl px-3 py-2 text-xs text-white uppercase font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-white/80 mb-1.5 flex items-center gap-1.5">
                <Palette size={14} className="text-indigo-400" /> لون الخلفية
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="color"
                  value={bgColor.startsWith('#') ? bgColor : '#0f172a'}
                  onChange={(e) => setBgColor(e.target.value)}
                  className="w-10 h-10 rounded-xl bg-transparent border border-white/20 cursor-pointer p-0.5"
                />
                <input
                  type="text"
                  value={bgColor}
                  onChange={(e) => setBgColor(e.target.value)}
                  className="flex-1 bg-slate-800/80 border border-white/10 rounded-xl px-3 py-2 text-xs text-white font-mono"
                  placeholder="rgba or hex"
                />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-white/80 mb-1.5">نوع الخط (Font Family)</label>
              <select
                value={fontFamily}
                onChange={(e) => setFontFamily(e.target.value)}
                className="w-full bg-slate-800/80 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-indigo-500 font-medium"
              >
                <option value="sans-serif">Default Sans (افتراضي)</option>
                <option value="Cairo, sans-serif">Cairo (القاهرة)</option>
                <option value="Tajawal, sans-serif">Tajawal (تجوال)</option>
                <option value="monospace">Monospace (برمجي)</option>
                <option value="serif">Serif (كلاسيكي)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-white/80 mb-1.5">سمك الخط (Font Weight)</label>
              <select
                value={fontWeight}
                onChange={(e) => setFontWeight(e.target.value)}
                className="w-full bg-slate-800/80 border border-white/10 rounded-xl px-4 py-2.5 text-sm text-white focus:outline-none focus:border-indigo-500 font-medium"
              >
                <option value="font-normal">عادي (Normal)</option>
                <option value="font-semibold">متوسط (Semibold)</option>
                <option value="font-bold">عريض (Bold)</option>
                <option value="font-black">عريض جداً (Black)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="mt-8 pt-4 border-t border-white/10 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl text-xs font-bold text-white/60 hover:text-white hover:bg-white/10 transition-colors"
          >
            إلغاء
          </button>
          <button
            type="button"
            onClick={handleSave}
            className="px-6 py-2.5 rounded-xl text-xs font-black bg-indigo-500 hover:bg-indigo-600 text-white shadow-lg shadow-indigo-500/30 flex items-center gap-2 transition-all active:scale-95"
          >
            <Check size={16} /> حفظ التعديلات
          </button>
        </div>
      </div>
    </div>
  );
};

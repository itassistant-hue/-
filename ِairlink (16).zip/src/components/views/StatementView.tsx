import React, { useState } from 'react';
import { Wallet, DollarSign, FileText, PlusCircle, Send, Lock, Download } from 'lucide-react';
import { UserRole, Transaction, AppSettings, ServiceRequest } from '../../types.ts';
import { Card, AirlinkLogo, PriceDisplay } from '../ui/Common.tsx';
import { InvoiceVoucher } from '../ui/InvoiceVoucher.tsx';
import { mockCompaniesList } from '../../mockData.ts';
import { generateId } from '../../App.tsx';

interface StatementViewProps {
  userRole: UserRole | null;
  t: any;
  lang: string;
  transactionsList: Transaction[];
  setTransactionsList: React.Dispatch<React.SetStateAction<Transaction[]>>;
  requestsList: ServiceRequest[];
  settings: AppSettings;
  currentUser: any;
}

export const StatementView = ({ userRole, t, lang, transactionsList, setTransactionsList, requestsList, settings, currentUser }: StatementViewProps) => {
  const [autoEmail, setAutoEmail] = useState(false);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [selectedInvoiceReq, setSelectedInvoiceReq] = useState<ServiceRequest | null>(null);
  const [adminSelectedCompany, setAdminSelectedCompany] = useState(userRole === 'client' ? currentUser?.company : '');
  const [startDate, setStartDate] = useState(new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().split('T')[0]);
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
  
  const showFinancials = userRole !== 'client' || settings.showFinancialsToClient;
  
  // Filter for date and company, and exclude costs (supplier transactions)
  const visibleTrxs = (userRole === 'client' 
    ? transactionsList.filter(tr => tr.company === currentUser?.company) 
    : (adminSelectedCompany ? transactionsList.filter(tr => tr.company === adminSelectedCompany) : transactionsList))
    .filter(tr => {
      // Surgical: Only show "Cash" (collected amounts/payments) and hide "Cost" (supplier transactions)
      if (tr.supplierId) return false; 
      
      if (!startDate && !endDate) return true;
      if (startDate && tr.date < startDate) return false;
      if (endDate && tr.date > endDate) return false;
      return true;
    });

  if (!showFinancials && userRole === 'client') {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center animate-in fade-in zoom-in duration-500">
        <div className="w-24 h-24 bg-[var(--card-bg)]/20 rounded-[40px] flex items-center justify-center text-rose-500 mb-8 border border-[var(--border-main)] shadow-2xl">
          <Lock size={40} />
        </div>
        <h2 className="text-3xl font-black text-[var(--text-main)] tracking-tighter uppercase mb-2">Access Restricted</h2>
        <p className="text-[var(--muted-text)] font-medium max-w-md mx-auto leading-relaxed">Financial tracking is currently restricted by the administrator. Please contact your account manager for detailed balance information.</p>
      </div>
    );
  }

  const currentBalanceUSD = visibleTrxs.filter(tr => tr.currency !== 'IQD').reduce((acc, trx) => trx.type === 'charge' ? acc + parseFloat(trx.amount.toString()) : acc - parseFloat(trx.amount.toString()), 0);
  const currentBalanceIQD = visibleTrxs.filter(tr => tr.currency === 'IQD').reduce((acc, trx) => trx.type === 'charge' ? acc + parseFloat(trx.amount.toString()) : acc - parseFloat(trx.amount.toString()), 0);
  
  const monthlyUsageUSD = visibleTrxs.filter(trx => trx.type === 'charge' && trx.date.startsWith('2026-04') && trx.currency !== 'IQD').reduce((acc, trx) => acc + parseFloat(trx.amount.toString()), 0);
  const lastPaymentTrx = visibleTrxs.find(trx => trx.type === 'payment');
  const lastPaymentDate = lastPaymentTrx ? lastPaymentTrx.date : 'N/A';

  const handlePaymentSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const amount = parseFloat((form.elements.namedItem('payAmount') as HTMLInputElement).value);
    const ref = (form.elements.namedItem('payRef') as HTMLInputElement).value;
    const currency = (form.elements.namedItem('payCurrency') as HTMLSelectElement).value as 'USD' | 'IQD';
    
    const newTrx: Transaction = { id: `TRX-${generateId()}`, date: new Date().toISOString().split('T')[0], company: adminSelectedCompany, service: 'Account Payment', desc: ref, amount: amount, type: 'payment', status: 'Cleared', currency };
    setTransactionsList(prev => [newTrx, ...prev]);
    alert(lang === 'ar' ? 'تم تسجيل الدفعة بنجاح! تم تقليل الرصيد.' : 'Payment recorded successfully! Balance reduced.');
    setShowPaymentForm(false);
  };

  const handlePrint = () => {
    const originalTitle = document.title;
    document.title = settings.companyName || 'B2B Portal'; // Temporary title for print to avoid "Google AI"
    window.print();
    document.title = originalTitle;
  };

  const handleExportExcel = () => {
    // Basic CSV Export for Excel
    const headers = ['Date', 'Service', 'Description', 'Amount', 'Type', 'Status'];
    const rows = visibleTrxs.map(trx => [
      trx.date,
      `"${trx.service}"`,
      `"${trx.desc}"`,
      trx.amount,
      trx.type,
      trx.status
    ]);
    
    const csvContent = "data:text/csv;charset=utf-8," 
      + headers.join(",") + "\n"
      + rows.map(e => e.join(",")).join("\n");
      
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Statement_${adminSelectedCompany}_${startDate}_to_${endDate}.csv`);
    document.body.appendChild(link);
    link.click();
    link.remove();
  };

  return (
    <div className={`space-y-10 animate-in fade-in duration-500 ${selectedInvoiceReq ? 'no-print' : 'print-target'}`}>
      {/* Print Only Header */}
      <div className="hidden print:flex justify-between items-end mb-12 pb-10 border-b-2 border-slate-200">
         <div className="flex items-center">
           {settings.logoUrl && settings.logoUrl.trim() !== '' ? (
             <img src={settings.logoUrl} alt="Logo" style={{ height: `100px`, maxWidth: '100%' }} className="object-contain" />
           ) : (
             <AirlinkLogo className="h-24" />
           )}
         </div>
         <div className="text-right">
            <h1 className="text-4xl font-black uppercase tracking-tighter text-slate-900 leading-none">{t.statement}</h1>
         </div>
      </div>

      <div className="flex flex-col lg:flex-row justify-between lg:items-end gap-6 no-print">
        <div>
          <h2 className="text-4xl font-black text-[var(--text-main)] tracking-tight">{t.statement}</h2>
          <p className="text-[var(--muted-text)] mt-2 font-medium">Financial overview and recent transactions.</p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          {userRole === 'admin' && (
            <div className="flex items-center gap-3 bg-[var(--card-bg)] p-2 rounded-xl border border-[var(--border-main)] shadow-sm">
              <span className="text-[10px] font-black uppercase text-[var(--muted-text)] px-2 tracking-widest">{t.selectCompanyStatement}</span>
              <select value={adminSelectedCompany} onChange={(e) => setAdminSelectedCompany(e.target.value)} className="bg-transparent border-none text-[var(--text-main)] text-xs font-bold rounded-lg focus:ring-0 block p-2 outline-none appearance-none">
                <option value="" className="bg-[var(--bg-main)]">All Companies</option>
                {mockCompaniesList.map(comp => <option key={comp.id} className="bg-[var(--bg-main)]" value={comp.name}>{comp.name}</option>)}
              </select>
            </div>
          )}
          <div className="flex flex-col sm:flex-row gap-4 items-end">
            <div className="flex flex-col gap-1">
              <div className="flex gap-2">
                <div className="flex items-center gap-3 bg-[var(--card-bg)] p-2.5 rounded-xl border-2 border-indigo-500/20 shadow-lg no-print">
                   <span className="text-[9px] font-black uppercase text-indigo-500 px-2 tracking-widest">{lang === 'ar' ? 'من' : 'From'}</span>
                   <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="bg-transparent border-none text-[var(--text-main)] text-xs font-black outline-none cursor-pointer" />
                </div>
                <div className="flex items-center gap-3 bg-[var(--card-bg)] p-2.5 rounded-xl border-2 border-indigo-500/20 shadow-lg no-print">
                   <span className="text-[9px] font-black uppercase text-indigo-500 px-2 tracking-widest">{lang === 'ar' ? 'إلى' : 'To'}</span>
                   <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="bg-transparent border-none text-[var(--text-main)] text-xs font-black outline-none cursor-pointer" />
                </div>
              </div>
              <p className="text-[8px] text-[var(--muted-text)] font-black uppercase tracking-widest ms-2 no-print">{lang === 'ar' ? 'حدد المدة للكشف' : 'Specify statement duration'}</p>
            </div>
            {userRole === 'admin' && <button onClick={() => setShowPaymentForm(!showPaymentForm)} className="flex items-center gap-3 bg-emerald-600 text-white px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-emerald-700 shadow-xl transition-all active:scale-95 no-print"><PlusCircle size={18} /> {t.addPayment}</button>}
            <div className="flex gap-2">
              <button onClick={handleExportExcel} className="flex items-center gap-3 bg-blue-600 text-white px-5 py-3 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-blue-700 shadow-xl transition-all active:scale-95 no-print">
                <Download size={18} /> Excel
              </button>
              <button onClick={handlePrint} className="flex items-center gap-3 bg-[var(--text-main)] text-[var(--bg-main)] border border-[var(--text-main)] px-7 py-3 rounded-xl text-xs font-black uppercase tracking-widest hover:brightness-110 shadow-xl transition-all">
                <FileText size={18} /> PDF
              </button>
            </div>
          </div>
        </div>
      </div>

      {showPaymentForm && userRole === 'admin' && (
        <Card className="p-8 border-emerald-500/30 border animate-in slide-in-from-top-4 no-print">
           <h3 className="text-lg font-black text-[var(--text-main)] mb-6 flex items-center gap-3 uppercase tracking-widest"><DollarSign size={20} className="text-emerald-500"/> {t.addPayment} - {adminSelectedCompany}</h3>
           <form onSubmit={handlePaymentSubmit} className="grid grid-cols-1 md:grid-cols-4 gap-6 items-end">
              <div><label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">{t.paymentAmount}</label><input name="payAmount" required type="number" className="bg-[var(--bg-main)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl block w-full p-4 focus:ring-2 focus:ring-indigo-500/50 shadow-sm" placeholder="2000" /></div>
              <div>
                 <label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">Currency</label>
                 <select name="payCurrency" className="bg-[var(--bg-main)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl block w-full p-4 focus:ring-2 focus:ring-indigo-500/50 shadow-sm appearance-none">
                    <option value="USD">USD ($)</option>
                    <option value="IQD">IQD</option>
                 </select>
              </div>
              <div><label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">{t.paymentRef}</label><input name="payRef" required type="text" className="bg-[var(--bg-main)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl block w-full p-4 focus:ring-2 focus:ring-indigo-500/50 shadow-sm" placeholder="Bank Transfer #1234" /></div>
              <button type="submit" className="w-full bg-[var(--text-main)] text-[var(--bg-main)] px-8 py-4 rounded-xl text-xs font-black uppercase tracking-widest hover:brightness-110 shadow-xl transition-all">{t.savePayment}</button>
           </form>
        </Card>
      )}

      {selectedInvoiceReq && (
        <InvoiceVoucher 
          request={selectedInvoiceReq} 
          settings={settings} 
          t={t} 
          onClose={() => setSelectedInvoiceReq(null)} 
        />
      )}

      <Card className="p-10 accent-gradient border-none text-white shadow-2xl relative overflow-hidden rounded-[40px]">
         <div className="absolute top-0 right-0 p-12 opacity-10"><Wallet size={160} /></div>
         <div className="relative z-10 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-8">
            <div>
             <p className="text-white/60 text-[10px] font-black mb-4 uppercase tracking-[0.3em]">{t.currentBalanceLabel}</p>
              <div className="space-y-2">
               {settings.defaultCurrency === 'IQD' ? (
                 <>
                   <h3 className="text-6xl font-black tracking-tighter font-mono">{currentBalanceIQD.toLocaleString()} IQD</h3>
                   {currentBalanceUSD !== 0 && (
                     <h4 className="text-2xl font-black tracking-tighter font-mono opacity-80">${currentBalanceUSD.toLocaleString(undefined, {minimumFractionDigits: 2})}</h4>
                   )}
                 </>
               ) : (
                 <>
                   <h3 className="text-6xl font-black tracking-tighter font-mono">${currentBalanceUSD.toLocaleString(undefined, {minimumFractionDigits: 2})}</h3>
                   {currentBalanceIQD !== 0 && (
                     <h4 className="text-2xl font-black tracking-tighter font-mono opacity-80">{currentBalanceIQD.toLocaleString()} IQD</h4>
                   )}
                 </>
               )}
             </div>
             <div className="flex flex-wrap gap-8 mt-8">
               <div className="glass-pane px-6 py-4 rounded-2xl border-white/10">
                 <p className="text-[9px] font-black text-white/40 uppercase tracking-[0.2em] mb-1">{t.monthlyUsageLabel}</p>
                 <PriceDisplay amount={monthlyUsageUSD} defaultCurrency={settings.defaultCurrency} exchangeRate={settings.exchangeRate} className="font-black text-2xl text-white" />
               </div>
               <div className="glass-pane px-6 py-4 rounded-2xl border-white/10"><p className="text-[9px] font-black text-white/40 uppercase tracking-[0.2em] mb-1">{t.lastPaymentLabel}</p><p className="font-black text-2xl text-emerald-400 font-mono">{lastPaymentDate}</p></div>
             </div>
           </div>
           {userRole === 'client' && (
             <div className="glass-pane p-6 rounded-[32px] border-white/10 flex items-center gap-6 shadow-2xl no-print">
               <div className="bg-white/10 p-4 rounded-full text-white/80"><Send size={24} /></div>
               <div><label htmlFor="autoEmail" className="text-sm font-black text-white block cursor-pointer uppercase tracking-widest">{t.autoMonthlyEmail}</label><p className="text-xs text-white/40 mt-1 font-medium">Receive an automatic PDF every 1st of the month.</p></div>
               <div className="ms-4"><input type="checkbox" id="autoEmail" checked={autoEmail} onChange={(e)=>setAutoEmail(e.target.checked)} className="w-8 h-8 text-indigo-500 bg-black/40 border-white/10 rounded-xl cursor-pointer focus:ring-indigo-500 transition-all" /></div>
             </div>
           )}
         </div>
         {/* Print header for PDF */}
         <div className="print-only absolute top-4 left-8 text-[10px] font-black uppercase tracking-widest opacity-30">Account Statement • {startDate} to {endDate} • {new Date().toLocaleDateString()}</div>
      </Card>

      <Card className="overflow-hidden !p-0 bg-[var(--card-bg)] border-[var(--border-main)]">
        <div className="p-8 border-b border-[var(--border-main)] flex justify-between items-center bg-[var(--bg-main)]">
          <h3 className="font-black text-[var(--text-main)] text-xl uppercase tracking-widest">{t.transactions}</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left rtl:text-right">
            <thead className="text-[10px] text-[var(--muted-text)] uppercase tracking-[0.2em] bg-[var(--bg-main)] border-b border-[var(--border-main)]">
              <tr><th className="px-8 py-6 font-black">{t.date}</th><th className="px-8 py-6 font-black">Description</th><th className="px-8 py-6 font-black text-right">Amount</th><th className="px-8 py-6 font-black text-center">Status</th><th className="px-8 py-6 font-black text-center no-print">Invoice</th></tr>
            </thead>
            <tbody className="divide-y divide-[var(--border-main)]">
              {visibleTrxs.map(trx => (
                <tr key={trx.id} className="hover:bg-[var(--bg-main)] transition-all group">
                  <td className="px-8 py-6 text-[var(--muted-text)] whitespace-nowrap font-bold text-xs">{trx.date}</td>
                  <td className="px-8 py-6"><p className="font-black text-[var(--text-main)] text-base tracking-tight">{trx.service}</p><p className="text-[10px] uppercase font-black text-[var(--muted-text)] mt-1 tracking-widest">{trx.desc}</p></td>
                  <td className={`px-8 py-6 text-right font-black text-2xl tracking-tighter font-mono ${trx.type === 'payment' ? 'text-emerald-500' : 'text-[var(--text-main)]'}`}>
                    {trx.type === 'payment' ? '−' : '+'}
                    <PriceDisplay amount={Math.abs(trx.amount)} currency={trx.currency} defaultCurrency={settings.defaultCurrency} exchangeRate={settings.exchangeRate} />
                  </td>
                  <td className="px-8 py-6 text-center"><span className={`inline-flex items-center px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest ${trx.status === 'Cleared' ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/10' : 'bg-[var(--border-main)] text-[var(--muted-text)] border border-[var(--border-main)]'}`}>{trx.status}</span></td>
                  <td className="px-8 py-6 text-center no-print">
                    <button 
                      onClick={() => {
                        const reqId = trx.service.split(' - ')[1] || trx.desc.match(/REQ-\d+/)?.[0];
                        const req = requestsList.find(r => r.id === reqId);
                        if (req) {
                          setSelectedInvoiceReq(req);
                        } else {
                          // Fallback: Create a temporary request object from transaction data if original request isn't found
                          setSelectedInvoiceReq({
                            id: trx.id,
                            company: trx.company,
                            service: trx.service as any,
                            date: trx.date,
                            status: 'completed',
                            desc: trx.desc,
                            cost: trx.amount,
                            sellingPrice: trx.amount,
                            profit: 0,
                            selling: trx.amount,
                            supplier: 'Auto-Billed',
                            notes: '',
                            details: {},
                            attachments: [],
                            chat: []
                          } as unknown as ServiceRequest);
                        }
                      }}
                      className="px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest bg-indigo-500 text-white hover:bg-indigo-600 transition-all shadow-lg shadow-indigo-500/20"
                    >
                      {lang === 'ar' ? 'عرض الفاتورة' : 'View Invoice'}
                    </button>
                    <span className="hidden print:inline-flex px-3 py-1 rounded-full text-[8px] font-black uppercase tracking-widest bg-emerald-500/10 text-emerald-500">
                      {trx.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

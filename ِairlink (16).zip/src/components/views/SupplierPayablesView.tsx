import React from 'react';
import { Briefcase, Building2, TrendingDown } from 'lucide-react';
import { ServiceRequest, AppSettings } from '../../types.ts';
import { Card, PriceDisplay, Avatar } from '../ui/Common.tsx';

interface SupplierPayablesViewProps {
  t: any;
  lang: string;
  isRTL: boolean;
  requestsList: ServiceRequest[];
  settings: AppSettings;
}

export const SupplierPayablesView = ({ t, lang, isRTL, requestsList, settings }: SupplierPayablesViewProps) => {
  // Only completed or approved requests
  const validReqs = requestsList.filter(r => r.status === 'completed' || r.status === 'approved');
  
  // Group by Supplier
  const supplierGroups = validReqs.reduce((acc: Record<string, { cost: number; requests: ServiceRequest[] }>, req) => {
    const supplierName = req.supplier || 'Unknown Supplier';
    if (!acc[supplierName]) {
      acc[supplierName] = { cost: 0, requests: [] };
    }
    acc[supplierName].cost += (Number(req.cost) || 0);
    acc[supplierName].requests.push(req);
    return acc;
  }, {});

  const sortedSuppliers = Object.entries(supplierGroups).sort((a, b) => b[1].cost - a[1].cost);
  const totalPayable = sortedSuppliers.reduce((acc, [_, data]) => acc + data.cost, 0);

  return (
    <div className="space-y-12 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row justify-between md:items-end gap-6 no-print">
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-indigo-500/10 text-indigo-500 border border-indigo-500/20 shadow-xl shadow-indigo-500/5">
              <Briefcase size={24} strokeWidth={2.5} />
            </div>
            <h2 className="text-4xl font-black text-[var(--text-main)] tracking-tight">{t.supplierPayables}</h2>
          </div>
          <p className="text-[10px] font-black uppercase text-rose-500 tracking-[0.2em] bg-rose-500/10 inline-block px-4 py-2 border border-rose-500/20 rounded-xl shadow-xl shadow-rose-500/5">
            {lang === 'ar' ? 'إجمالي المبالغ المستحقة للموردين (التكلفة فقط)' : 'Total Outstanding to Suppliers (Cost Only)'}
          </p>
        </div>
        
        <Card className="p-6 border-indigo-500/20 bg-indigo-500/5 min-w-[240px]">
          <div className="flex flex-col items-end">
            <p className="text-[10px] font-black text-[var(--muted-text)] uppercase tracking-widest mb-1">{lang === 'ar' ? 'إجمالي المستحقات' : 'Total Payables'}</p>
            <p className="text-3xl font-black text-indigo-500 tracking-tighter transition-all hover:scale-105">
              <PriceDisplay amount={totalPayable} defaultCurrency={settings.defaultCurrency} exchangeRate={settings.exchangeRate} />
            </p>
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1 space-y-4">
          <p className="text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.3em] px-2">{lang === 'ar' ? 'قائمة الموردين' : 'Supplier List'}</p>
          <div className="space-y-3">
            {sortedSuppliers.map(([name, data]) => (
              <Card key={name} className="p-5 border-[var(--border-main)] hover:border-indigo-500/40 transition-all group group relative overflow-hidden">
                <div className="absolute inset-y-0 left-0 w-1 bg-indigo-500/20 group-hover:bg-indigo-500 transition-colors"></div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Avatar name={name} className="w-10 h-10 rounded-xl" />
                    <div>
                      <h4 className="font-black text-[var(--text-main)] text-sm tracking-tight capitalize">{name}</h4>
                      <p className="text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-wider">{data.requests.length} {lang === 'ar' ? 'طلب' : 'Requests'}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-black text-indigo-500 text-lg tracking-tight">
                      <PriceDisplay amount={data.cost} defaultCurrency={settings.defaultCurrency} exchangeRate={settings.exchangeRate} />
                    </p>
                  </div>
                </div>
              </Card>
            ))}
            {sortedSuppliers.length === 0 && (
              <div className="p-12 text-center glass-pane rounded-[24px] border border-dashed border-[var(--border-main)]">
                <Building2 size={40} className="mx-auto text-[var(--muted-text)]/20 mb-4" />
                <p className="text-sm text-[var(--muted-text)] font-bold">{lang === 'ar' ? 'لا يوجد موردين حالياً' : 'No supplier data available yet'}</p>
              </div>
            )}
          </div>
        </div>

        <div className="lg:col-span-2">
           <Card className="overflow-hidden !p-0 border-[var(--border-main)] bg-[var(--card-bg)] shadow-2xl h-full flex flex-col">
              <div className="p-8 border-b border-[var(--border-main)] bg-[var(--bg-main)] flex items-center justify-between">
                <h3 className="font-black text-[var(--text-main)] text-xl uppercase tracking-widest">{lang === 'ar' ? 'تفصيل سجل التكلفة' : 'Cost Ledger Detail'}</h3>
                <TrendingDown size={20} className="text-rose-500" />
              </div>
              <div className="flex-1 overflow-x-auto overflow-y-auto max-h-[600px] custom-scrollbar">
                <table className="w-full text-sm text-left rtl:text-right sticky-header">
                  <thead className="text-[10px] text-[var(--muted-text)] uppercase bg-[var(--bg-main)] border-b border-[var(--border-main)] tracking-[0.2em] font-black sticky top-0 z-10">
                    <tr>
                      <th className="px-8 py-6">ID</th>
                      <th className="px-8 py-6">{lang === 'ar' ? 'المورد' : 'Supplier'}</th>
                      <th className="px-8 py-6">{lang === 'ar' ? 'الخدمة' : 'Service'}</th>
                      <th className="px-8 py-6">{lang === 'ar' ? 'التاريخ' : 'Date'}</th>
                      <th className="px-8 py-6 text-right">{lang === 'ar' ? 'التكلفة' : 'Cost'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[var(--border-main)]">
                    {validReqs.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map(req => (
                      <tr key={req.id} className="hover:bg-white/[0.02] transition-colors group">
                        <td className="px-8 py-6 font-black text-[var(--text-main)] text-[11px] tracking-widest">{req.id}</td>
                        <td className="px-8 py-6">
                           <div className="flex items-center gap-2">
                              <span className="font-bold text-[var(--text-main)]">{req.supplier || 'N/A'}</span>
                           </div>
                        </td>
                        <td className="px-8 py-6">
                           <span className="px-3 py-1 rounded-lg bg-white/5 border border-white/10 text-[10px] font-black uppercase tracking-widest text-[var(--muted-text)]">
                              {t[req.service] || req.service}
                           </span>
                        </td>
                        <td className="px-8 py-6 text-[10px] font-bold text-[var(--muted-text)]">{req.date}</td>
                        <td className="px-8 py-6 text-right font-black text-rose-500 tracking-tight">
                           <PriceDisplay amount={req.cost} defaultCurrency={settings.defaultCurrency} exchangeRate={settings.exchangeRate} />
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
           </Card>
        </div>
      </div>
    </div>
  );
};

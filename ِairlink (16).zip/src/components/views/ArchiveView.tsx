import React, { useState } from 'react';
import { Archive, Briefcase, ChevronRight, Search, Filter, Eye, Printer } from 'lucide-react';
import { Card, PriceDisplay } from '../ui/Common.tsx';
import { ServiceRequest, UserRole, AppSettings } from '../../types.ts';
import { InvoiceVoucher } from '../ui/InvoiceVoucher.tsx';

interface ArchiveViewProps {
  requestsList: ServiceRequest[];
  t: any;
  userRole: UserRole | null;
  currentUser: any;
  settings: AppSettings;
}

export const ArchiveView = ({ requestsList, t, userRole, currentUser, settings, lang }: any) => {
  const [selectedReq, setSelectedReq] = useState<ServiceRequest | null>(null);
  const [filter, setFilter] = useState('');

  const filteredRequests = requestsList.filter(req => {
    if (userRole === 'client') return req.company === currentUser?.company;
    const searchStr = `${req.id} ${req.company} ${req.service}`.toLowerCase();
    return searchStr.includes(filter.toLowerCase());
  });

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      {selectedReq && (
        <InvoiceVoucher 
          request={selectedReq}
          settings={settings}
          t={t}
          onClose={() => setSelectedReq(null)}
        />
      )}
      <div className="flex flex-col lg:flex-row justify-between lg:items-end gap-6">
        <div>
          <h2 className="text-4xl font-black text-[var(--text-main)] tracking-tight">{t.archive || 'System Archive'}</h2>
          <p className="text-[var(--muted-text)] mt-2 font-medium">Historical record of all portal activities and requests.</p>
        </div>
        
        <div className="flex bg-[var(--card-bg)] border border-[var(--border-main)] p-2 rounded-2xl shadow-sm">
           <div className="flex items-center gap-3 px-4 border-r border-[var(--border-main)]">
              <Search size={16} className="text-[var(--muted-text)]" />
              <input 
                type="text" 
                placeholder="Search archive..." 
                value={filter}
                onChange={(e) => setFilter(e.target.value)}
                className="bg-transparent border-none outline-none text-xs font-bold text-[var(--text-main)] w-32 placeholder:text-[var(--muted-text)]/40" 
              />
           </div>
           <button className="flex items-center gap-2 px-4 py-2 text-[var(--muted-text)] hover:text-[var(--text-main)] transition-colors">
              <Filter size={16} />
              <span className="text-[10px] font-black uppercase tracking-widest">{t.filter || 'Filter'}</span>
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
         <Card className="p-8 border-none bg-[var(--primary)]/5">
            <p className="text-[9px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-2">Total Archived</p>
            <h3 className="text-4xl font-black text-[var(--text-main)] tracking-tighter">{filteredRequests.length}</h3>
         </Card>
         <Card className="p-8 border-none bg-emerald-500/5">
            <p className="text-[9px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-2">Completed Tasks</p>
            <h3 className="text-4xl font-black text-emerald-500 tracking-tighter">{filteredRequests.filter(r => r.status === 'completed').length}</h3>
         </Card>
         <Card className="p-8 border-none bg-rose-500/5">
            <p className="text-[9px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-2">Rejected/Cancelled</p>
            <h3 className="text-4xl font-black text-rose-500 tracking-tighter">{filteredRequests.filter(r => r.status === 'rejected').length}</h3>
         </Card>
      </div>

      <Card className="overflow-hidden !p-0 border-[var(--border-main)] bg-[var(--card-bg)] shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left rtl:text-right">
            <thead className="text-[10px] text-[var(--muted-text)] uppercase tracking-[0.2em] bg-white/[0.03] border-b border-[var(--border-main)] font-black">
              <tr>
                <th className="px-8 py-6">Request ID</th>
                <th className="px-8 py-6">Date</th>
                <th className="px-8 py-6">Company</th>
                <th className="px-8 py-6">Service</th>
                {(userRole === 'admin' || userRole === 'staff') && <th className="px-8 py-6">{t.supplierLabel}</th>}
                <th className="px-8 py-6">Status</th>
                {(userRole === 'admin' || userRole === 'staff') && (
                  <>
                    <th className="px-8 py-6">Users</th>
                    <th className="px-8 py-6">Cost Price</th>
                    <th className="px-8 py-6">Selling Price</th>
                    <th className="px-8 py-6">Profit</th>
                  </>
                )}
                <th className="px-8 py-6 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border-main)]">
              {filteredRequests.map(req => (
                <tr key={req.id} className="hover:bg-white/[0.02] transition-all group">
                  <td className="px-8 py-6 font-black text-[var(--text-main)]">{req.id}</td>
                  <td className="px-8 py-6 text-[var(--muted-text)] font-bold text-xs">{req.date}</td>
                  <td className="px-8 py-6 text-[var(--text-main)] font-bold">{req.company}</td>
                  <td className="px-8 py-6">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-[var(--primary)]/10 text-[var(--primary)] rounded-lg"><Briefcase size={14}/></div>
                      <span className="text-[var(--text-main)] font-bold uppercase text-[10px] tracking-widest">{t[req.service]}</span>
                    </div>
                  </td>
                  {(userRole === 'admin' || userRole === 'staff') && (
                    <td className="px-8 py-6">
                      <span className={`text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-lg border w-fit ${req.supplier ? 'bg-indigo-500/5 text-indigo-400 border-indigo-500/10' : 'bg-white/5 text-white/20 border-white/5'}`}>
                         {req.supplier || '---'}
                      </span>
                    </td>
                  )}
                  <td className="px-8 py-6">
                    <span className={`px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${
                      req.status === 'completed' ? 'bg-emerald-500/10 text-emerald-500 border border-emerald-500/10' :
                      req.status === 'rejected' ? 'bg-rose-500/10 text-rose-500 border border-rose-500/10' :
                      'bg-indigo-500/10 text-indigo-400 border border-indigo-500/10'
                    }`}>
                      {t[req.status]}
                    </span>
                  </td>
                  {(userRole === 'admin' || userRole === 'staff') && (
                    <>
                      <td className="px-8 py-6 text-[var(--muted-text)] font-bold text-xs">{req.realSupplier || '-'}</td>
                      <td className="px-8 py-6 text-[var(--text-main)] font-mono font-black">
                        <PriceDisplay amount={req.cost || 0} defaultCurrency={settings.defaultCurrency} exchangeRate={settings.exchangeRate} />
                      </td>
                      <td className="px-8 py-6 text-emerald-500 font-mono font-black">
                        <PriceDisplay amount={req.selling || 0} defaultCurrency={settings.defaultCurrency} exchangeRate={settings.exchangeRate} />
                      </td>
                      <td className="px-8 py-6 text-indigo-500 font-mono font-black">
                        <PriceDisplay amount={(req.selling || 0) - (req.cost || 0)} defaultCurrency={settings.defaultCurrency} exchangeRate={settings.exchangeRate} />
                      </td>
                    </>
                  )}
                  <td className="px-8 py-6 text-right">
                    <div className="flex items-center justify-end gap-3">
                      <button 
                        onClick={() => setSelectedReq(req)}
                        className="flex items-center gap-2 px-4 py-2 bg-[var(--primary)]/10 text-[var(--primary)] hover:bg-[var(--primary)]/20 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all"
                      >
                        <Eye size={14}/> {lang === 'ar' ? 'معاينة' : 'Preview'}
                      </button>
                      <button 
                        onClick={() => {
                          setSelectedReq(req);
                          setTimeout(() => {
                            window.print();
                          }, 500);
                        }}
                        className="flex items-center gap-2 px-4 py-2 bg-indigo-500/10 text-indigo-500 hover:bg-indigo-500/20 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all"
                      >
                        <Printer size={14}/> {lang === 'ar' ? 'طباعة' : 'Print'}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

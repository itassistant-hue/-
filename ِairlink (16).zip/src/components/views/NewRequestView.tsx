import React, { useState } from 'react';
import { ChevronRight, UploadCloud, Globe, Plane, Hotel, ShieldCheck, Mail, MapPin, Calendar, Users as UsersIcon, FileText, LayoutList, Eye } from 'lucide-react';
import { UserRole, ServiceRequest } from '../../types.ts';
import { Card } from '../ui/Common.tsx';
import { FilePreviewModal, PreviewFileItem } from '../modals/FilePreviewModal.tsx';
import { generateId } from '../../App.tsx';

interface NewRequestViewProps {
  userRole: UserRole | null;
  t: any;
  lang: string;
  isRTL: boolean;
  requestsList: ServiceRequest[];
  setRequestsList: React.Dispatch<React.SetStateAction<ServiceRequest[]>>;
  setCurrentView: (view: string) => void;
  currentUser: any;
  addNotification: (text: string, type?: any, description?: string, relatedId?: string, targetRole?: UserRole, targetEmail?: string) => void;
  addLog?: (action: string, details: string) => void;
}

export const NewRequestView = ({ userRole, t, lang, isRTL, requestsList, setRequestsList, setCurrentView, currentUser, addNotification, addLog }: NewRequestViewProps) => {
  const [serviceType, setServiceType] = useState<string>('flight');
  const [emailNotify, setEmailNotify] = useState(true);
  const [tempAttachments, setTempAttachments] = useState<any[]>([]);
  const [previewFile, setPreviewFile] = useState<PreviewFileItem | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const files = Array.from(e.target.files);
      (files as File[]).forEach(file => {
        const reader = new FileReader();
        const fileName = file.name;
        reader.onloadend = () => {
          setTempAttachments(prev => [...prev, { name: fileName, data: reader.result as string } as any]);
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const removeAttachment = (idx: number) => {
    setTempAttachments(prev => prev.filter((_, i) => i !== idx));
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const formData = new FormData(form);
    const details: any = {};
    
    for (let [key, value] of formData.entries()) {
       if (['notes', 'notificationEmail'].includes(key)) continue;
       if (value) details[key] = value.toString();
    }

    const notesText = (form.elements.namedItem('notes') as HTMLTextAreaElement)?.value || '';
    const notifEmail = (form.elements.namedItem('notificationEmail') as HTMLInputElement)?.value || '';
    const subType = (form.elements.namedItem('requestSubType') as HTMLSelectElement)?.value || 'new';

    const newReq: ServiceRequest = {
      id: generateId('REQ'),
      company: userRole === 'client' ? currentUser?.company || 'Unknown' : 'Airlink Admin',
      service: serviceType as any,
      status: 'pending',
      date: new Date().toISOString().split('T')[0],
      cost: 0, 
      selling: 0, 
      supplier: '',
      details: details,
      notes: notesText + (notifEmail ? `\n(Notify Email: ${notifEmail})` : ''),
      assignedTo: 'Unassigned', 
      attachments: tempAttachments, 
      chat: [], 
      offers: [], 
      selectedOfferId: null,
      requestSubType: subType as any,
      createdBy: currentUser?.email
    };

    setRequestsList([newReq, ...requestsList]);
    addNotification(`${t.notifNewRequest} - ${newReq.company}`, 'new_request', `${lang === 'ar' ? 'طلب جديد برقم' : 'New request ID'}: #${newReq.id.slice(-5)}`, newReq.id, 'admin');
    if (addLog) addLog('New Request', `Request ${newReq.id} created by ${currentUser?.email} for service ${newReq.service}.`);
    
    // Trigger immediate database sync to employee view
    setTimeout(() => {
      window.dispatchEvent(new CustomEvent('force-immediate-save'));
    }, 50);

    alert(lang === 'ar' ? 'تم تقديم الطلب بنجاح!' : 'Request Submitted Successfully!');
    setCurrentView('requests');
  };

  const SectionTitle = ({ icon: Icon, title }: { icon: any, title: string }) => (
    <div className="flex items-center gap-3 mb-6">
      <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-500 border border-indigo-500/20">
        <Icon size={18} />
      </div>
      <h3 className="text-[11px] font-black uppercase tracking-[0.25em] text-[var(--muted-text)]">{title}</h3>
    </div>
  );

  return (
    <div className="max-w-5xl mx-auto space-y-12 animate-in fade-in slide-in-from-bottom-8 duration-700 pb-20">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
        <div className="space-y-2">
          <h2 className="text-5xl font-black text-[var(--text-main)] tracking-tighter leading-none">{t.createRequestTitle}</h2>
          <p className="text-[var(--muted-text)] font-bold text-sm tracking-tight opacity-70">
            {lang === 'ar' ? 'قم بتعبئة التفاصيل أدناه لتقديم طلب خدمة جديد.' : 'Precision-fill the details below to submit a new service request.'}
          </p>
        </div>
        <div className="flex items-center gap-2 px-6 py-3 bg-[var(--card-bg)] border border-[var(--border-main)] rounded-2xl shadow-xl">
           <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></div>
           <span className="text-[10px] font-black uppercase tracking-widest text-indigo-500">{lang === 'ar' ? 'جلسة نشطة' : 'Active Session'}</span>
        </div>
      </div>

      <form className="space-y-8" onSubmit={handleSubmit}>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* Left Column: Core Selection */}
          <div className="lg:col-span-4 space-y-8">
            <Card className="p-8 border-[var(--border-main)] bg-[var(--card-bg)] shadow-2xl space-y-8 h-fit">
              <div>
                <SectionTitle icon={LayoutList} title={lang === 'ar' ? 'نوع الخدمة' : 'Service Logic'} />
                <div className="space-y-3">
                  {[
                    { id: 'flight', icon: Plane, label: t.flight },
                    { id: 'hotel', icon: Hotel, label: t.hotel },
                    { id: 'visa', icon: ShieldCheck, label: t.visa },
                    { id: 'insurance', icon: ShieldCheck, label: t.insurance },
                    { id: 'other', icon: Globe, label: t.other }
                  ].map(option => (
                    <button 
                      key={option.id}
                      type="button" 
                      onClick={() => setServiceType(option.id)}
                      className={`w-full flex items-center justify-between p-4 rounded-xl border transition-all duration-300 group ${serviceType === option.id ? 'bg-indigo-500 border-indigo-400 text-white shadow-lg shadow-indigo-500/20' : 'bg-[var(--bg-main)] border-[var(--border-main)] text-[var(--muted-text)] hover:border-indigo-500/40 hover:text-[var(--text-main)]'}`}
                    >
                      <div className="flex items-center gap-3">
                        <option.icon size={18} className={serviceType === option.id ? 'text-white' : 'group-hover:text-indigo-500 transition-colors'} />
                        <span className="text-sm font-black tracking-tight uppercase">{option.label}</span>
                      </div>
                      {serviceType === option.id && <ChevronRight size={16} className={isRTL ? 'rotate-180' : ''} />}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <SectionTitle icon={Globe} title={lang === 'ar' ? 'العملة المفضلة' : 'Currency Context'} />
                <div className="relative group">
                  <select name="currency" className="appearance-none bg-[var(--bg-main)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl focus:ring-2 focus:ring-indigo-500/50 block w-full p-4 pr-12 transition-all hover:bg-[var(--card-bg)] font-bold group-hover:border-indigo-500/30">
                    <option value="USD">USD ($) - US Dollar</option>
                    <option value="IQD">IQD (ع.د) - Iraqi Dinar</option>
                  </select>
                  <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-5 text-[var(--muted-text)] group-hover:text-indigo-500 transition-colors"><ChevronRight size={18} className="rotate-90" /></div>
                </div>
              </div>

              <div>
                <SectionTitle icon={LayoutList} title={lang === 'ar' ? 'طبيعة الطلب' : 'Request Flow'} />
                <div className="relative group">
                  <select name="requestSubType" className="appearance-none bg-[var(--bg-main)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl focus:ring-2 focus:ring-indigo-500/50 block w-full p-4 pr-12 transition-all hover:bg-[var(--card-bg)] font-bold group-hover:border-indigo-500/30">
                    <option value="new">{t.subTypeNew}</option>
                    <option value="reissue">{t.subTypeReissue}</option>
                    <option value="change">{t.subTypeChange}</option>
                    <option value="cancellation">{t.subTypeCancellation}</option>
                  </select>
                  <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-5 text-[var(--muted-text)] group-hover:text-indigo-500 transition-colors"><ChevronRight size={18} className="rotate-90" /></div>
                </div>
              </div>
            </Card>
          </div>

          {/* Right Column: Dynamic Form Content */}
          <div className="lg:col-span-8 space-y-8">
            <Card className="p-10 border-[var(--border-main)] bg-[var(--card-bg)] shadow-2xl relative overflow-hidden">
               {/* Abstract accent shape */}
               <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none" />
               
               <div className="relative z-10 space-y-10">
                  <div>
                    <SectionTitle icon={Plane} title={lang === 'ar' ? 'بيانات المسار والوجهة' : 'Logistics & Itinerary'} />
                    
                    {serviceType === 'flight' && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                        <div className="space-y-2">
                          <label className="flex items-center gap-2 text-[9px] font-black text-[var(--muted-text)] uppercase tracking-widest px-1"><MapPin size={12}/> {t.from}</label>
                          <input name="from" type="text" placeholder="Origin City/Airport" className="w-full bg-[var(--bg-main)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 transition-all font-bold placeholder:opacity-30" required/>
                        </div>
                        <div className="space-y-2">
                          <label className="flex items-center gap-2 text-[9px] font-black text-[var(--muted-text)] uppercase tracking-widest px-1"><MapPin size={12}/> {t.to}</label>
                          <input name="to" type="text" placeholder="Destination City/Airport" className="w-full bg-[var(--bg-main)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 transition-all font-bold placeholder:opacity-30" required/>
                        </div>
                        <div className="space-y-2">
                          <label className="flex items-center gap-2 text-[9px] font-black text-[var(--muted-text)] uppercase tracking-widest px-1"><Calendar size={12}/> {t.departureDate}</label>
                          <input name="departureDate" type="date" className="w-full bg-[var(--bg-main)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 transition-all font-bold" required/>
                        </div>
                        <div className="space-y-2">
                          <label className="flex items-center gap-2 text-[9px] font-black text-[var(--muted-text)] uppercase tracking-widest px-1"><Calendar size={12}/> {t.returnDate}</label>
                          <input name="returnDate" type="date" className="w-full bg-[var(--bg-main)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 transition-all font-bold blur-[0.5px] hover:blur-0 grayscale-[0.5] hover:grayscale-0" />
                        </div>
                        <div className="md:col-span-2 space-y-2">
                          <label className="flex items-center gap-2 text-[9px] font-black text-[var(--muted-text)] uppercase tracking-widest px-1"><UsersIcon size={12}/> {t.passengers}</label>
                          <input name="passengers" type="number" min="1" placeholder="Number of Passengers" className="w-full bg-[var(--bg-main)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 transition-all font-bold" required/>
                        </div>
                      </div>
                    )}

                    {serviceType === 'hotel' && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                        <div className="space-y-2">
                           <label className="flex items-center gap-2 text-[9px] font-black text-[var(--muted-text)] uppercase tracking-widest px-1"><MapPin size={12}/> {t.city}</label>
                           <input name="city" type="text" className="w-full bg-[var(--bg-main)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 transition-all font-bold shadow-sm" required/>
                        </div>
                        <div className="space-y-2">
                           <label className="flex items-center gap-2 text-[9px] font-black text-[var(--muted-text)] uppercase tracking-widest px-1"><Hotel size={12}/> {t.rooms}</label>
                           <input name="rooms" type="number" min="1" className="w-full bg-[var(--bg-main)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 transition-all font-bold shadow-sm" required/>
                        </div>
                        <div className="space-y-2">
                           <label className="flex items-center gap-2 text-[9px] font-black text-[var(--muted-text)] uppercase tracking-widest px-1"><Calendar size={12}/> {t.checkIn}</label>
                           <input name="checkIn" type="date" className="w-full bg-[var(--bg-main)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 transition-all font-bold shadow-sm" required/>
                        </div>
                        <div className="space-y-2">
                           <label className="flex items-center gap-2 text-[9px] font-black text-[var(--muted-text)] uppercase tracking-widest px-1"><Calendar size={12}/> {t.checkOut}</label>
                           <input name="checkOut" type="date" className="w-full bg-[var(--bg-main)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 transition-all font-bold shadow-sm" required/>
                        </div>
                      </div>
                    )}

                    {serviceType === 'visa' && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                        <div className="space-y-2">
                           <label className="flex items-center gap-2 text-[9px] font-black text-[var(--muted-text)] uppercase tracking-widest px-1"><Globe size={12}/> {t.to} (Country)</label>
                           <input name="to" type="text" className="w-full bg-[var(--bg-main)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 transition-all font-bold shadow-sm" required/>
                        </div>
                        <div className="space-y-2">
                           <label className="flex items-center gap-2 text-[9px] font-black text-[var(--muted-text)] uppercase tracking-widest px-1"><UsersIcon size={12}/> {t.nationality}</label>
                           <input name="nationality" type="text" className="w-full bg-[var(--bg-main)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 transition-all font-bold shadow-sm" required/>
                        </div>
                        <div className="md:col-span-2 space-y-2">
                           <label className="flex items-center gap-2 text-[9px] font-black text-[var(--muted-text)] uppercase tracking-widest px-1"><ShieldCheck size={12}/> {t.visaType}</label>
                           <input name="visaType" type="text" placeholder="Tourist, Business, Umrah..." className="w-full bg-[var(--bg-main)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 transition-all font-bold shadow-sm" required/>
                        </div>
                      </div>
                    )}

                    {serviceType === 'insurance' && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                        <div className="space-y-2">
                           <label className="flex items-center gap-2 text-[9px] font-black text-[var(--muted-text)] uppercase tracking-widest px-1"><Calendar size={12}/> {t.dob}</label>
                           <input name="dob" type="date" className="w-full bg-[var(--bg-main)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 transition-all font-bold shadow-sm" required/>
                        </div>
                        <div className="space-y-2">
                           <label className="flex items-center gap-2 text-[9px] font-black text-[var(--muted-text)] uppercase tracking-widest px-1"><ShieldCheck size={12}/> {t.coverage}</label>
                           <input name="coverage" type="text" placeholder="Worldwide, Schengen, regional..." className="w-full bg-[var(--bg-main)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 transition-all font-bold shadow-sm" required/>
                        </div>
                      </div>
                    )}

                    {serviceType === 'other' && <div className="p-6 bg-indigo-500/5 border border-indigo-500/20 rounded-2xl text-xs font-bold text-indigo-500 italic uppercase tracking-wider">{lang === 'ar' ? 'يرجى كتابة تفاصيل طلبك بالكامل في قسم الملاحظات أدناه.' : 'Please define the full scope of your unique request in the comprehensive notes section below.'}</div>}
                  </div>

                  <div>
                    <SectionTitle icon={FileText} title={lang === 'ar' ? 'ملاحظات إضافية' : 'Contextual Notes & Clarifications'} />
                    <textarea name="notes" rows={4} className="block p-5 w-full text-sm text-[var(--text-main)] bg-[var(--bg-main)] rounded-2xl border border-[var(--border-main)] focus:ring-2 focus:ring-indigo-500/50 shadow-sm resize-none transition-all hover:bg-[var(--bg-main)] border-dashed font-medium placeholder:opacity-30" placeholder="Passenger full names, passport numbers, seating preferences, hotel star rating, special assistance..."></textarea>
                  </div>

                  <div>
                    <SectionTitle icon={UploadCloud} title={lang === 'ar' ? 'المرفقات والوثائق' : 'Attachments & Documentation'} />
                    <div className="space-y-4">
                        <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-[var(--border-main)] border-dashed rounded-3xl cursor-pointer bg-[var(--bg-main)]/50 hover:bg-[var(--bg-main)] hover:border-indigo-500/40 transition-all group">
                            <div className="flex flex-col items-center justify-center pt-5 pb-6">
                                <UploadCloud className="w-8 h-8 text-[var(--muted-text)] group-hover:text-indigo-500 group-hover:scale-110 transition-all mb-3" />
                                <p className="text-[10px] text-[var(--muted-text)] font-black uppercase tracking-widest leading-none"><span className="text-indigo-500">Inject Files</span> or Drag & Drop Here</p>
                            </div>
                            <input type="file" className="hidden" multiple onChange={handleFileChange} />
                        </label>
                        
                        {tempAttachments.length > 0 && (
                           <div className="flex flex-wrap gap-2 pt-2">
                              {tempAttachments.map((file: any, idx) => (
                                <div key={idx} className="bg-white/5 text-[var(--text-main)] px-3.5 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest flex items-center gap-2.5 border border-[var(--border-main)] animate-in zoom-in-95">
                                   <div 
                                     onClick={() => setPreviewFile({ name: file.name, data: file.data, type: file.type })} 
                                     className="flex items-center gap-2 cursor-pointer hover:text-indigo-400 transition-colors"
                                     title={lang === 'ar' ? 'معاينة المستند' : 'Preview Document'}
                                   >
                                     <Eye size={12} className="text-indigo-400" />
                                     <span className="truncate max-w-[140px]">{file.name || `Asset ${idx + 1}`}</span>
                                   </div>
                                   <button type="button" onClick={() => removeAttachment(idx)} className="text-rose-500 hover:scale-125 transition-transform font-black px-1" title={lang === 'ar' ? 'حذف' : 'Remove'}>×</button>
                                </div>
                              ))}
                           </div>
                        )}
                    </div>
                  </div>

                  <div className="pt-6 border-t border-[var(--border-main)]">
                    <div className="flex flex-col gap-4 bg-[var(--bg-main)]/30 p-6 rounded-3xl border border-[var(--border-main)]">
                       <div className="flex items-center gap-4">
                         <div className="relative inline-block w-12 h-6 transition duration-200 ease-in">
                            <input type="checkbox" checked={emailNotify} onChange={(e)=>setEmailNotify(e.target.checked)} id="toggle-email" className="absolute w-6 h-6 bg-white border-4 border-gray-300 rounded-full appearance-none cursor-pointer checked:bg-indigo-500 checked:right-0 right-6 transition-all duration-300" />
                            <label htmlFor="toggle-email" className="block h-6 overflow-hidden bg-gray-300 rounded-full cursor-pointer transition-colors duration-300"></label>
                         </div>
                         <label htmlFor="toggle-email" className="text-[10px] font-black text-[var(--text-main)] uppercase tracking-[0.2em] select-none cursor-pointer">{t.emailNotify}</label>
                       </div>
                       
                       {emailNotify && (
                         <div className="animate-in slide-in-from-top-2 flex flex-col gap-2">
                           <label className="text-[9px] font-black text-[var(--muted-text)] uppercase tracking-widest px-1">{t.officialEmail}</label>
                           <div className="relative">
                              <input type="email" name="notificationEmail" required className="w-full bg-[var(--bg-main)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl block p-4 pl-12 focus:ring-2 focus:ring-indigo-500/50 shadow-sm transition-all font-bold" placeholder="your@email.com" defaultValue={userRole === 'client' ? 'info@rabanalsafina.com' : ''} />
                              <Mail size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-[var(--muted-text)]" />
                           </div>
                         </div>
                       )}
                    </div>
                  </div>

                  <div className="pt-6 flex justify-end gap-4">
                    <button type="button" onClick={() => setCurrentView('requests')} className="px-8 py-4 rounded-xl text-[10px] font-black uppercase tracking-[0.3em] text-[var(--muted-text)] hover:text-[var(--text-main)] transition-colors">
                      {lang === 'ar' ? 'إلغاء' : 'Discard'}
                    </button>
                    <button type="submit" className="bg-indigo-500 text-white font-black rounded-xl text-[10px] px-12 py-4 shadow-2xl shadow-indigo-500/30 hover:scale-105 active:scale-95 transition-all uppercase tracking-[0.4em] hover:brightness-110">
                      {t.submit}
                    </button>
                  </div>
               </div>
            </Card>
          </div>

        </div>
      </form>

      <FilePreviewModal 
        isOpen={!!previewFile} 
        onClose={() => setPreviewFile(null)} 
        file={previewFile} 
        lang={lang === 'ar' ? 'ar' : 'en'} 
      />
    </div>
  );
};

import React, { useState, useEffect } from 'react';
import { Settings as SettingsIcon, Image, Palette, Megaphone, Database, Download, Calendar, ShieldCheck, Upload, X, Terminal, Globe, UserCheck, Briefcase, Trash2, MessageSquare, Shield, Sparkles, RefreshCw, FileUp, HardDrive, Check, Type, Sliders, Cloud, CloudDownload, CloudUpload, CheckCircle2 } from 'lucide-react';
import { Card, AirlinkLogo, MediaDisplay } from '../ui/Common.tsx';
import { AppSettings, ServiceRequest, Transaction, UserRole, User } from '../../types.ts';
import { optimizeImage } from '../../utils/imageOptimizer.ts';
import { processMediaFile } from '../../utils/mediaHelper.ts';
import { extractDominantColor } from '../../utils/colorExtractor.ts';
import { getApiUrl } from '../../utils/api.ts';
import { 
  getStoredGDriveToken, 
  requestGDriveToken, 
  clearGDriveToken, 
  uploadBackupToGoogleDrive, 
  listGoogleDriveBackups, 
  restoreBackupFromGoogleDrive,
  getStoredGoogleClientId,
  saveGoogleClientId
} from '../../utils/googleDriveBackup.ts';

interface SettingsViewProps {
  t: any;
  lang: string;
  settings: AppSettings;
  setSettings: (s: AppSettings) => void;
  requestsList: ServiceRequest[];
  transactionsList: Transaction[];
  userRole: UserRole | null;
  currentUser: User | null;
  setCurrentUser: React.Dispatch<React.SetStateAction<User | null>>;
  usersList: User[];
  setUsersList: React.Dispatch<React.SetStateAction<User[]>>;
  companiesList: any[];
  suppliersList: any[];
  notifications: any[];
  isDevMode?: boolean;
  handleResetSystem?: () => void;
}

export const SettingsView = ({ t, lang, settings, setSettings, requestsList, transactionsList, userRole, currentUser, setCurrentUser, usersList, setUsersList, companiesList, suppliersList, notifications, isDevMode, handleResetSystem }: SettingsViewProps) => {
  const [activeTab, setActiveTab] = useState<'general' | 'theme' | 'aboutDev' | 'publicInfo' | 'account'>('account');
  const [formData, setFormData] = useState<AppSettings>({
    ...settings,
    primaryColor: settings.primaryColor || '#0ea5e9',
    secondaryColor: settings.secondaryColor || '#f59e0b',
    backupSchedule: settings.backupSchedule || 'none',
    adOpacity: settings.adOpacity ?? 0.6,
    loginLayout: settings.loginLayout || 'center',
    logoHeight: settings.logoHeight || 64
  });
  const [isUploading, setIsUploading] = useState<string | null>(null);
  const [serverBackups, setServerBackups] = useState<any[]>([]);
  const [isLoadingBackups, setIsLoadingBackups] = useState(false);

  const [gdriveToken, setGdriveToken] = useState<string | null>(getStoredGDriveToken());
  const [gdriveBackups, setGdriveBackups] = useState<any[]>([]);
  const [isGDriveLoading, setIsGDriveLoading] = useState(false);
  const [gdriveMsg, setGdriveMsg] = useState<string | null>(null);
  const [customClientId, setCustomClientId] = useState<string>(getStoredGoogleClientId());

  useEffect(() => {
    fetchServerBackups();
    if (gdriveToken) {
      loadGDriveBackups(gdriveToken);
    }
  }, []);

  const loadGDriveBackups = async (token?: string) => {
    const activeToken = token || gdriveToken;
    if (!activeToken) return;
    setIsGDriveLoading(true);
    try {
      const files = await listGoogleDriveBackups(activeToken);
      setGdriveBackups(files);
    } catch (err) {
      console.error('GDrive error:', err);
    } finally {
      setIsGDriveLoading(false);
    }
  };

  const handleConnectGDrive = () => {
    setGdriveMsg(null);
    if (customClientId) {
      saveGoogleClientId(customClientId);
    }
    requestGDriveToken(
      (token) => {
        setGdriveToken(token);
        setGdriveMsg('✅ تم الربط بحساب Google Drive بنجاح!');
        loadGDriveBackups(token);
      },
      (err) => {
        console.warn('GDrive OAuth error:', err);
        const errStr = typeof err === 'string' ? err : JSON.stringify(err);
        if (errStr.includes('invalid_client') || errStr.includes('401')) {
          setGdriveMsg('⚠️ تنبيه: يلزم إدخال معرف العميل (Google Client ID) الخاص بك من Google Cloud Console للربط، أو استخدم خيار التنزيل والاسترجاع المباشر للنسخ الاحتياطية أدناه.');
        } else {
          setGdriveMsg('⚠️ فشل الربط بـ Google Drive: ' + (errStr || 'يرجى التحقق من الإعدادات'));
        }
      },
      customClientId
    );
  };

  const handleManualGDriveBackup = async () => {
    if (!gdriveToken) {
      handleConnectGDrive();
      return;
    }
    setIsGDriveLoading(true);
    const payload = {
      users: usersList,
      requests: requestsList,
      transactions: transactionsList,
      companies: companiesList,
      suppliers: suppliersList,
      settings: formData,
      notifications: notifications
    };
    const res = await uploadBackupToGoogleDrive(payload, gdriveToken);
    setIsGDriveLoading(false);
    if (res.success) {
      alert(`تم رفع النسخة الاحتياطية (${res.fileName}) إلى Google Drive بنجاح!`);
      loadGDriveBackups(gdriveToken);
    } else {
      alert('خطأ: ' + res.error);
    }
  };

  const handleRestoreGDrivePoint = async (fileId: string, fileName: string) => {
    if (!window.confirm(`هل أنت متأكد من استرجاع كافة بيانات النظام من نقطة الاسترجاع (${fileName}) من Google Drive؟`)) return;
    try {
      setIsGDriveLoading(true);
      const data = await restoreBackupFromGoogleDrive(fileId, gdriveToken || undefined);
      if (data) {
        const res = await fetch(getApiUrl('/api/backups/restore'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ data })
        });
        const resData = await res.json();
        if (resData.success) {
          alert('تمت استعادة البيانات بنجاح من Google Drive! جاري إعادة التحميل...');
          window.location.reload();
        } else {
          alert('فشلت استعادة البيانات.');
        }
      }
    } catch (err: any) {
      alert('خطأ في استرجاع النسخة الاحتياطية: ' + err.message);
    } finally {
      setIsGDriveLoading(false);
    }
  };

  const fetchServerBackups = async () => {
    setIsLoadingBackups(true);
    try {
      const res = await fetch(getApiUrl('/api/backups'));
      const data = await res.json();
      if (data.backups) {
        setServerBackups(data.backups);
      }
    } catch (err) {
      console.error('Failed to fetch server backups:', err);
    } finally {
      setIsLoadingBackups(false);
    }
  };

  const handleCreateServerBackup = async () => {
    try {
      const res = await fetch(getApiUrl('/api/backups/create'), { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        alert(lang === 'ar' ? 'تم إنشاء نسخة احتياطية آمنة على السيرفر بنجاح!' : 'Server backup created successfully!');
        fetchServerBackups();
      } else {
        alert(lang === 'ar' ? 'فشل إنشاء النسخة الاحتياطية' : 'Failed to create backup');
      }
    } catch (err: any) {
      alert((lang === 'ar' ? 'خطأ أثناء الاتصال بالخادم: ' : 'Server connection error: ') + err.message);
    }
  };

  const handleRestoreFromFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const content = event.target?.result as string;
        const parsed = JSON.parse(content);
        if (!parsed || typeof parsed !== 'object') {
          alert(lang === 'ar' ? 'ملف النسخة الاحتياطية غير صالح' : 'Invalid backup JSON file');
          return;
        }
        if (window.confirm(lang === 'ar' ? 'هل أنت متأكد من استرجاع كافة البيانات من هذا الملف؟ سيتم استبدال البيانات الحالية!' : 'Are you sure you want to restore all system data from this backup file?')) {
          const res = await fetch(getApiUrl('/api/backups/restore'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ data: parsed })
          });
          const data = await res.json();
          if (data.success) {
            alert(lang === 'ar' ? 'تمت استعادة البيانات بنجاح! جاري إعادة التحميل...' : 'Database restored successfully! Reloading...');
            window.location.reload();
          } else {
            alert(lang === 'ar' ? 'فشلت عملية الاستعادة' : 'Restore failed');
          }
        }
      } catch (err: any) {
        alert((lang === 'ar' ? 'خطأ في قراءة الملف: ' : 'Error reading backup file: ') + err.message);
      }
    };
    reader.readAsText(file);
  };

  const toggleAutoLogoBg = async (enabled: boolean) => {
    let color = formData.extractedLogoColor;
    if (enabled && formData.logoUrl) {
      color = await extractDominantColor(formData.logoUrl);
    }
    setFormData(prev => ({
      ...prev,
      autoAdaptLogoBg: enabled,
      extractedLogoColor: color || prev.extractedLogoColor,
      primaryColor: enabled && color ? color : prev.primaryColor
    }));
  };

  const [profileData, setProfileData] = useState({
    name: currentUser?.name || '',
    email: currentUser?.email || '',
    avatar: currentUser?.avatar || null
  });

  const canEditDev = currentUser?.email.toLowerCase() === 'ali.aneed';

  const handleProfileImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const optimized = await optimizeImage(file, 300, 300, 0.8);
        setProfileData(prev => ({ ...prev, avatar: optimized }));
      } catch (err) {
        console.error("Failed to optimize profile image:", err);
      }
    }
  };

  const saveProfile = () => {
    if (!currentUser) return;
    const updatedUser = { ...currentUser, ...profileData };
    const updatedUsers = usersList.map(u => u.email === currentUser.email ? updatedUser : u);
    setUsersList(updatedUsers);
    setCurrentUser(updatedUser);
    alert('Profile Updated successfully!');
  };

  const deleteMyAccount = () => {
    if (window.confirm('WARNING: Are you sure you want to delete your account? This action is irreversible.')) {
      if (!currentUser) return;
      const updatedUsers = usersList.filter(u => u.email !== currentUser.email);
      setUsersList(updatedUsers);
      alert('Account Deleted. Logging out...');
      window.location.reload();
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, field: keyof AppSettings) => {
    const file = e.target.files?.[0];
    if (file) {
      setIsUploading(field);
      try {
        let mediaData: string;
        if (file.type.startsWith('video/') || file.type === 'image/gif' || file.name.toLowerCase().endsWith('.gif')) {
          mediaData = await processMediaFile(file);
        } else {
          let mw = 800, mh = 800, q = 0.7;
          if (field === 'logoUrl') { mw = 400; mh = 400; q = 0.8; }
          if (field === 'backgroundImageUrl' || field === 'loginBgUrl' || field === 'companyImage') { mw = 1200; mh = 800; q = 0.6; }
          mediaData = await optimizeImage(file, mw, mh, q);
        }

        if (field === 'logoUrl') {
          const domColor = await extractDominantColor(mediaData);
          setFormData(prev => ({
            ...prev,
            logoUrl: mediaData,
            extractedLogoColor: domColor,
            primaryColor: prev.autoAdaptLogoBg ? domColor : prev.primaryColor
          }));
        } else {
          setFormData(prev => ({ ...prev, [field]: mediaData }));
        }
      } catch (err) {
        console.error("Failed to process media file upload:", err);
      } finally {
        setIsUploading(null);
      }
    }
  };

  const handleAdUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      try {
        const optimized = await optimizeImage(file, 800, 600, 0.6);
        const newAds = [...(formData.ads || []), optimized];
        setFormData(prev => ({ ...prev, ads: newAds }));
      } catch (err) {
        console.error("Failed to optimize ad image:", err);
      }
    }
  };

  const removeAd = (index: number) => {
    const newAds = (formData.ads || []).filter((_, i) => i !== index);
    setFormData(prev => ({ ...prev, ads: newAds }));
  };

  const exportBackup = () => {
    const fullData = {
      users: usersList,
      requests: requestsList,
      transactions: transactionsList,
      companies: companiesList,
      suppliers: suppliersList,
      notifications: notifications,
      settings: settings,
      exportDate: new Date().toISOString(),
      systemVersion: 'v4.2 PRO',
      createdBy: 'Ali Ahmed Aneed'
    };
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(fullData));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href",     dataStr);
    downloadAnchorNode.setAttribute("download", `AIRLINK_SYSTEM_MIGRATION_${new Date().toLocaleDateString().replace(/\//g, '-')}.json`);
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
    alert('System backup file generated! You can use this file to move the entire portal to another server.');
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSettings(formData);
    alert(t.settingsSaved);
  };

  const SecurityNotice = () => (
    <div className="bg-rose-500/10 border border-rose-500/20 p-4 rounded-2xl flex items-center gap-4 mb-6">
      <div className="p-2 bg-rose-500/20 text-rose-500 rounded-lg"><ShieldCheck size={18}/></div>
      <div>
        <h4 className="text-xs font-black text-white/90 uppercase tracking-widest">{t.adminActions || 'ADMIN SECURITY'}</h4>
        <p className="text-[10px] text-white/40 mt-0.5 leading-relaxed">Only authorized administrators can modify these system-wide settings. All changes are logged.</p>
      </div>
    </div>
  );

  return (
    <div className="space-y-10 animate-in fade-in duration-500 selection:bg-indigo-500/30">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-4xl font-black text-[var(--text-main)] tracking-tight">{t.settings}</h2>
          <p className="text-[var(--muted-text)] mt-2 font-medium">{t.siteSettingsDesc}</p>
        </div>
      </div>

      <div className="flex flex-wrap gap-4 border-b border-[var(--border-main)] pb-6">
         <button onClick={() => setActiveTab('account')} className={`flex items-center gap-3 px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'account' ? 'bg-[var(--text-main)] text-[var(--bg-main)] shadow-xl ring-4 ring-[var(--text-main)]/10' : 'text-[var(--muted-text)] hover:text-[var(--text-main)] hover:bg-[var(--card-bg)]'}`}>
            <UserCheck size={16}/> {t.myAccount || 'My Account'}
         </button>
         <button onClick={() => setActiveTab('general')} className={`flex items-center gap-3 px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'general' ? 'bg-[var(--text-main)] text-[var(--bg-main)] shadow-xl ring-4 ring-[var(--text-main)]/10' : 'text-[var(--muted-text)] hover:text-[var(--text-main)] hover:bg-[var(--card-bg)]'}`}>
            <SettingsIcon size={16}/> {t.general}
         </button>
         <button onClick={() => setActiveTab('theme')} className={`flex items-center gap-3 px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'theme' ? 'bg-[var(--text-main)] text-[var(--bg-main)] shadow-xl ring-4 ring-[var(--text-main)]/10' : 'text-[var(--muted-text)] hover:text-[var(--text-main)] hover:bg-[var(--card-bg)]'}`}>
            <Palette size={16}/> {t.themeConfiguration}
         </button>
         <button onClick={() => setActiveTab('publicInfo')} className={`flex items-center gap-3 px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'publicInfo' ? 'bg-[var(--text-main)] text-[var(--bg-main)] shadow-xl ring-4 ring-[var(--text-main)]/10' : 'text-[var(--muted-text)] hover:text-[var(--text-main)] hover:bg-[var(--card-bg)]'}`}>
            <Globe size={16}/> {t.aboutUs}
         </button>
         <button onClick={() => setActiveTab('aboutDev')} className={`flex items-center gap-3 px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest transition-all ${activeTab === 'aboutDev' ? 'bg-[var(--text-main)] text-[var(--bg-main)] shadow-xl ring-4 ring-[var(--text-main)]/10' : 'text-[var(--muted-text)] hover:text-[var(--text-main)] hover:bg-[var(--card-bg)]'}`}>
            <Terminal size={16}/> {t.aboutDeveloper}
         </button>
      </div>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-3 gap-8 pb-12">
        <div className="lg:col-span-2 space-y-8">
          <SecurityNotice />
          
          {activeTab === 'account' && (
            <div className="space-y-8 animate-in slide-in-from-left-4">
              <Card className="p-10 space-y-10 border-[var(--border-main)]">
                 <div className="flex flex-col items-center gap-6 pb-6 border-b border-[var(--border-main)]">
                    <div className="relative group">
                      <div className="w-32 h-32 rounded-[40px] overflow-hidden border-4 border-[var(--border-main)] shadow-2xl relative">
                         {profileData.avatar ? (
                           <img src={profileData.avatar && profileData.avatar.trim() !== '' ? profileData.avatar : undefined} alt="Avatar" className="w-full h-full object-cover" />
                         ) : (
                           <div className="w-full h-full accent-gradient flex items-center justify-center text-white text-4xl font-black">{profileData.name.charAt(0)}</div>
                         )}
                         <label className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center cursor-pointer text-white">
                            <Upload size={24} />
                            <span className="text-[8px] font-black uppercase tracking-widest mt-2">Change Photo</span>
                            <input type="file" className="hidden" accept="image/*" onChange={handleProfileImageUpload} />
                         </label>
                      </div>
                      {canEditDev && (
                        <label className="absolute -bottom-2 -right-2 bg-indigo-500 text-white p-2.5 rounded-2xl shadow-xl border-4 border-[var(--bg-main)] hover:scale-110 transition-all cursor-pointer">
                           <SettingsIcon size={16} />
                           <input type="file" className="hidden" accept="image/*" onChange={handleProfileImageUpload} />
                        </label>
                      )}
                    </div>
                   <div className="text-center">
                      <h4 className="text-2xl font-black text-[var(--text-main)] tracking-tight">{profileData.name}</h4>
                      <p className="text-[10px] text-[var(--muted-text)] font-black uppercase tracking-widest mt-1">{userRole} Account • Verified Access</p>
                   </div>
                 </div>

                 <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="space-y-3">
                      <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">Profile Name</label>
                      <input type="text" value={profileData.name} onChange={e => setProfileData({...profileData, name: e.target.value})} className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all" />
                    </div>
                    <div className="space-y-3">
                      <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">Registered Email</label>
                      <input type="email" value={profileData.email} onChange={e => setProfileData({...profileData, email: e.target.value})} className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all" />
                    </div>
                 </div>

                 <div className="pt-6 border-t border-[var(--border-main)] flex justify-between items-center">
                    <button type="button" onClick={saveProfile} className="bg-indigo-500 hover:bg-indigo-600 text-white px-8 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all active:scale-95 shadow-xl shadow-indigo-500/20">Save Profile Changes</button>
                    <button type="button" onClick={deleteMyAccount} className="text-rose-500 hover:text-rose-400 text-[10px] font-black uppercase tracking-widest flex items-center gap-2 px-4 py-2 hover:bg-rose-500/10 rounded-xl transition-all"><Trash2 size={14} /> {t.deleteAccount || 'Delete Account'}</button>
                 </div>
              </Card>
            </div>
          )}

           {activeTab === 'general' && (
            <div className="space-y-8 animate-in slide-in-from-left-4 dir-rtl">
               {/* Full Database Backup & Recovery Section */}
              <Card className="p-8 space-y-8 border-indigo-500/20 bg-indigo-500/5">
                <div className="flex items-center justify-between border-b border-[var(--border-main)] pb-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 bg-indigo-500/20 text-indigo-400 rounded-xl"><Database size={24}/></div>
                    <div>
                      <h3 className="text-xl font-bold text-[var(--text-main)] tracking-tight">النسخ الاحتياطي واستعادة قاعدة البيانات</h3>
                      <p className="text-xs text-[var(--muted-text)] mt-1 font-medium">حفظ أمان تام لكافة البيانات والطلبات والشركات والماليات لمنع أي فقدان للمعلومات</p>
                    </div>
                  </div>
                  <button type="button" onClick={fetchServerBackups} className="p-2.5 text-indigo-400 hover:bg-indigo-500/10 rounded-xl transition-colors flex items-center gap-2 text-xs font-bold">
                    <RefreshCw size={16} className={isLoadingBackups ? 'animate-spin' : ''} /> تحديث السجل
                  </button>
                </div>

                {/* Main Action Buttons */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="space-y-3">
                    <label className="block text-xs font-black text-[var(--muted-text)] uppercase tracking-wider">تحميل نسخة فورية (JSON)</label>
                    <button type="button" onClick={exportBackup} className="w-full flex items-center justify-center gap-3 bg-indigo-500 hover:bg-indigo-600 text-white p-4 rounded-2xl transition-all shadow-lg shadow-indigo-500/20 active:scale-95 font-bold text-xs">
                      <Download size={18} />
                      <span>تحميل نسخة احتياطية مباشرة</span>
                    </button>
                  </div>

                  <div className="space-y-3">
                    <label className="block text-xs font-black text-[var(--muted-text)] uppercase tracking-wider">إنشاء نسخة على السيرفر</label>
                    <button type="button" onClick={handleCreateServerBackup} className="w-full flex items-center justify-center gap-3 bg-emerald-600 hover:bg-emerald-700 text-white p-4 rounded-2xl transition-all shadow-lg shadow-emerald-500/20 active:scale-95 font-bold text-xs">
                      <HardDrive size={18} />
                      <span>حفظ نسخة آمنة بالسيرفر</span>
                    </button>
                  </div>

                  <div className="space-y-3">
                    <label className="block text-xs font-black text-[var(--muted-text)] uppercase tracking-wider">استرجاع نسخة من ملف</label>
                    <label className="w-full flex items-center justify-center gap-3 bg-[var(--card-bg)] border-2 border-dashed border-indigo-500/40 hover:border-indigo-500 text-[var(--text-main)] p-4 rounded-2xl transition-all cursor-pointer font-bold text-xs">
                      <FileUp size={18} className="text-amber-400" />
                      <span>رفع واسترجاع نسخة احتياطية</span>
                      <input type="file" accept=".json" onChange={handleRestoreFromFile} className="hidden" />
                    </label>
                  </div>
                </div>

                {/* Auto Backup Configuration */}
                <div className="p-6 bg-[var(--card-bg)]/40 rounded-2xl border border-indigo-500/20 space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-indigo-500/20 text-indigo-400 rounded-xl">
                        <Sparkles size={20} />
                      </div>
                      <div>
                        <span className="text-sm font-black text-[var(--text-main)] block">النسخ الاحتياطي التلقائي (Auto Backup)</span>
                        <span className="text-xs text-[var(--muted-text)] font-medium">يقوم النظام بإنشاء وتحديث نسخ احتياطية دورية أوتوماتيكياً في الخلفية</span>
                      </div>
                    </div>

                    <label className="relative inline-flex items-center cursor-pointer">
                      <input 
                        type="checkbox" 
                        checked={formData.autoBackupEnabled ?? true} 
                        onChange={e => setFormData({...formData, autoBackupEnabled: e.target.checked})}
                        className="sr-only peer"
                      />
                      <div className="w-14 h-8 bg-[var(--border-main)] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[4px] after:left-[4px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-indigo-500"></div>
                    </label>
                  </div>

                  {formData.autoBackupEnabled !== false && (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-[var(--border-main)]">
                      <div>
                        <label className="block text-xs font-bold text-[var(--muted-text)] mb-2">جدولة التكرار التلقائي</label>
                        <select 
                          value={formData.backupSchedule || 'daily'} 
                          onChange={e => setFormData({...formData, backupSchedule: e.target.value as any})}
                          className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-3.5 text-sm text-[var(--text-main)] outline-none"
                        >
                          <option value="daily">نسخ احتياطي يومي (كل 24 ساعة)</option>
                          <option value="weekly">نسخ احتياطي أسبوعي (كل 7 أيام)</option>
                          <option value="monthly">نسخ احتياطي شهري (كل 30 يوم)</option>
                        </select>
                      </div>

                      <div className="flex flex-col justify-end">
                        <p className="text-xs text-[var(--muted-text)] font-medium leading-relaxed bg-indigo-500/10 p-3.5 rounded-xl border border-indigo-500/20">
                          🛡️ النسخ التلقائي مفعل ويتم الاحتفاظ بآخر 100 نسخة احتياطية آمنة في السيرفر مع خيار الاسترجاع الفوري بأي وقت.
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Google Drive Integration & Auto-Backup */}
                <div className="p-6 bg-[var(--card-bg)]/60 rounded-2xl border border-blue-500/30 space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex items-center gap-4">
                      <div className="p-3.5 bg-blue-500/20 text-blue-400 rounded-xl shadow-inner">
                        <Cloud size={26} />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-base font-black text-[var(--text-main)] block">نظام النسخ الاحتياطي السحابي (Google Drive Auto-Backup)</span>
                          {gdriveToken && (
                            <span className="inline-flex items-center gap-1 text-[10px] font-black px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                              <CheckCircle2 size={12} /> متصل بـ Drive
                            </span>
                          )}
                        </div>
                        <span className="text-xs text-[var(--muted-text)] font-medium mt-1 block">
                          حفظ أوتوماتيكي ومستمر لكافة التغييرات والطلبات بالحساب الشخصي على Google Drive في مجلد آمن وتحديد نقاط الاسترجاع
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      {!gdriveToken ? (
                        <button
                          type="button"
                          onClick={handleConnectGDrive}
                          className="px-5 py-3 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs rounded-xl shadow-lg shadow-blue-500/20 transition-all flex items-center gap-2 active:scale-95"
                        >
                          <Cloud size={16} /> ربط Google Drive
                        </button>
                      ) : (
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={handleManualGDriveBackup}
                            disabled={isGDriveLoading}
                            className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-black text-xs rounded-xl shadow-md transition-all flex items-center gap-2 active:scale-95 disabled:opacity-50"
                          >
                            <CloudUpload size={16} /> {isGDriveLoading ? 'جاري الرفع...' : 'رفع نسخة فورية لـ Drive'}
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              clearGDriveToken();
                              setGdriveToken(null);
                              setGdriveBackups([]);
                            }}
                            className="p-2.5 text-rose-400 hover:bg-rose-500/10 rounded-xl transition-all"
                            title="إلغاء الربط"
                          >
                            <X size={16} />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Emails Configuration */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4 border-t border-[var(--border-main)]">
                    <div className="space-y-2">
                      <label className="block text-xs font-bold text-[var(--text-main)]">
                        إيميل Google Drive المخصص للنسخ الاحتياطي:
                      </label>
                      <input 
                        type="email" 
                        value={formData.googleDriveEmail || 'aloooshf9@gmail.com'} 
                        onChange={(e) => setFormData({...formData, googleDriveEmail: e.target.value})} 
                        placeholder="aloooshf9@gmail.com"
                        className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-3 text-xs text-[var(--text-main)] outline-none focus:ring-1 focus:ring-blue-500"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="block text-xs font-bold text-[var(--text-main)]">
                        إيميل استقبال الإشعارات في الموقع:
                      </label>
                      <input 
                        type="email" 
                        value={formData.notificationEmail || 'aloooshf9@gmail.com'} 
                        onChange={(e) => setFormData({...formData, notificationEmail: e.target.value})} 
                        placeholder="aloooshf9@gmail.com"
                        className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-3 text-xs text-[var(--text-main)] outline-none focus:ring-1 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  {/* Client ID Setting Field */}
                  <div className="p-4 bg-[var(--bg-main)]/80 rounded-xl border border-[var(--border-main)] space-y-2">
                    <label className="block text-[11px] font-bold text-[var(--text-main)]">
                      معرف عميل جوجل (Google OAuth Client ID) - اختياري للمشاريع الخاصة:
                    </label>
                    <div className="flex gap-2">
                      <input 
                        type="text" 
                        value={customClientId} 
                        onChange={(e) => setCustomClientId(e.target.value)} 
                        placeholder="ضع هنا xxxxx.apps.googleusercontent.com الخاص بك..."
                        className="flex-1 bg-[var(--input-bg)] border border-[var(--border-main)] rounded-lg p-2.5 text-xs text-[var(--text-main)] font-mono outline-none focus:ring-1 focus:ring-blue-500"
                      />
                      <button
                        type="button"
                        onClick={() => saveGoogleClientId(customClientId)}
                        className="px-3 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-lg transition-all"
                      >
                        حفظ المعرف
                      </button>
                    </div>
                    <p className="text-[10px] text-[var(--muted-text)]">
                      ملاحظة: إذا ظهر خطأ invalid_client، يمكنك استخدام خيار الرفع والتحميل المباشر بأسفل الصفحة برفع ملفات JSON، أو وضع Client ID المرخص لموقعك.
                    </p>
                  </div>

                  {gdriveMsg && (
                    <div className={`p-3.5 rounded-xl text-xs font-bold ${gdriveMsg.includes('✅') ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/30' : 'bg-amber-500/10 text-amber-400 border border-amber-500/30'}`}>
                      {gdriveMsg}
                    </div>
                  )}

                  {/* Google Drive Restore Points */}
                  {gdriveToken && (
                    <div className="pt-4 border-t border-[var(--border-main)] space-y-3">
                      <div className="flex justify-between items-center">
                        <h5 className="text-xs font-black uppercase text-[var(--text-main)] tracking-wider flex items-center gap-2">
                          <CloudDownload size={14} className="text-blue-400" /> نقاط الاسترجاع المحفوظة بـ Google Drive ({gdriveBackups.length})
                        </h5>
                        <button
                          type="button"
                          onClick={() => loadGDriveBackups()}
                          className="text-[10px] text-blue-400 hover:underline flex items-center gap-1 font-bold"
                        >
                          <RefreshCw size={12} className={isGDriveLoading ? 'animate-spin' : ''} /> تحديث القائمة
                        </button>
                      </div>

                      {gdriveBackups.length === 0 ? (
                        <p className="text-xs text-[var(--muted-text)] font-medium italic p-3 bg-[var(--bg-main)] rounded-xl border border-[var(--border-main)] text-center">
                          لم يتم العثور على نسخ احتياطية سابقة في المجلد. اضغط على "رفع نسخة فورية لـ Drive" للبدء.
                        </p>
                      ) : (
                        <div className="max-h-48 overflow-y-auto space-y-2 custom-scrollbar pr-1">
                          {gdriveBackups.map((file) => (
                            <div key={file.id} className="flex items-center justify-between p-3 rounded-xl bg-[var(--bg-main)] border border-[var(--border-main)] hover:border-blue-500/30 transition-all text-xs">
                              <div className="flex items-center gap-3">
                                <Cloud size={16} className="text-blue-400 shrink-0" />
                                <div>
                                  <p className="font-bold text-[var(--text-main)] font-mono dir-ltr">{file.name}</p>
                                  <p className="text-[10px] text-[var(--muted-text)] mt-0.5">
                                    {new Date(file.createdTime).toLocaleString('ar-EG')}
                                  </p>
                                </div>
                              </div>
                              <button
                                type="button"
                                onClick={() => handleRestoreGDrivePoint(file.id, file.name)}
                                className="px-3 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 rounded-lg font-bold text-[11px] transition-colors flex items-center gap-1"
                              >
                                <RefreshCw size={12} /> استرجاع هذه النقطة
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Server Backups List */}
                {serverBackups.length > 0 && (
                  <div className="space-y-4 pt-4 border-t border-[var(--border-main)]">
                    <h4 className="text-sm font-black text-[var(--text-main)] uppercase tracking-wider flex items-center gap-2">
                      <HardDrive size={16} className="text-indigo-400" /> سجل النسخ الاحتياطية المحفوظة بالسيرفر ({serverBackups.length})
                    </h4>
                    <div className="max-h-60 overflow-y-auto space-y-2.5 custom-scrollbar pr-1">
                      {serverBackups.map((bk, i) => (
                        <div key={i} className="flex items-center justify-between p-3.5 rounded-xl bg-[var(--card-bg)]/60 border border-[var(--border-main)] hover:border-indigo-500/30 transition-all text-xs">
                          <div className="flex items-center gap-3">
                            <Database size={16} className="text-indigo-400 shrink-0" />
                            <div>
                              <p className="font-bold text-[var(--text-main)] font-mono dir-ltr text-right">{bk.filename}</p>
                              <p className="text-[10px] text-[var(--muted-text)] mt-0.5">
                                {new Date(bk.mtime).toLocaleString('ar-EG')} • {(bk.size / 1024).toFixed(1)} KB
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <a 
                              href={getApiUrl(`/api/backups/download/${bk.filename}`)}
                              download
                              className="px-3 py-1.5 bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-400 rounded-lg font-bold text-[11px] transition-colors flex items-center gap-1"
                            >
                              <Download size={12} /> تحميل
                            </a>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Smart Chat Backup */}
                <div className="pt-6 border-t border-[var(--border-main)]/50">
                   <label className="flex items-center justify-between p-5 bg-indigo-500/5 hover:bg-indigo-500/10 border border-indigo-500/20 rounded-2xl cursor-pointer transition-all group">
                     <div className="flex items-center gap-4">
                       <div className="p-3 bg-indigo-500 text-white rounded-xl shadow-lg shadow-indigo-500/20 group-hover:scale-110 transition-transform">
                         <MessageSquare size={20} />
                       </div>
                       <div className="flex flex-col">
                         <span className="text-sm font-black uppercase tracking-widest text-[var(--text-main)]">
                           {lang === 'ar' ? 'نظام أرشفة الدردشة الذكي' : 'Smart Chat Archiving System'}
                         </span>
                         <span className="text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-wider mt-0.5">
                           {lang === 'ar' ? 'تحميل نسخة تلقائية عند إرسال "END CHAT"' : 'Automatic download triggered by "END CHAT" command'}
                         </span>
                       </div>
                     </div>
                     <div className="relative inline-flex items-center cursor-pointer">
                       <input 
                         type="checkbox" 
                         checked={formData.chatBackupEnabled} 
                         onChange={e => setFormData({...formData, chatBackupEnabled: e.target.checked})}
                         className="sr-only peer"
                       />
                       <div className="w-14 h-8 bg-[var(--border-main)] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[4px] after:left-[4px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-indigo-500"></div>
                     </div>
                   </label>
                </div>
              </Card>

              {/* Visual Identity Section */}
              <Card className="p-8 space-y-8 border-[var(--border-main)]">
                <div className="flex items-center gap-4 border-b border-[var(--border-main)] pb-6">
                  <div className="p-3 bg-[var(--card-bg)]/20 rounded-xl text-indigo-400"><Image size={24}/></div>
                  <h3 className="text-xl font-bold text-[var(--text-main)] tracking-tight">الهوية البصرية والشعار</h3>
                </div>

                {/* Logo Auto-Adaptation Toggle Switch */}
                <div className="p-5 bg-gradient-to-r from-indigo-500/10 via-purple-500/10 to-pink-500/10 rounded-2xl border border-indigo-500/30 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-xl bg-indigo-500 text-white shadow-lg shadow-indigo-500/30">
                      <Sparkles size={20} />
                    </div>
                    <div>
                      <h4 className="text-sm font-black text-[var(--text-main)]">تنسيق الخلفية أوتوماتيكياً مع لون الشعار</h4>
                      <p className="text-xs text-[var(--muted-text)] font-medium mt-0.5">
                        عند تفعيل الخيار، يقوم النظام بتعديل خلفية وألوان النظام تلقائياً لتتنسق وتتطابق بدقة مع ألوان الشعار المرفوع.
                      </p>
                    </div>
                  </div>

                  <label className="relative inline-flex items-center cursor-pointer shrink-0 mr-4">
                    <input 
                      type="checkbox" 
                      checked={formData.autoAdaptLogoBg ?? false} 
                      onChange={e => toggleAutoLogoBg(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-14 h-8 bg-[var(--border-main)] peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[4px] after:left-[4px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-6 after:w-6 after:transition-all peer-checked:bg-indigo-500"></div>
                  </label>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">{t.companyLogo}</label>
                    <div className="flex gap-3">
                      <input type="text" value={formData.logoUrl} onChange={e => setFormData({...formData, logoUrl: e.target.value})} className="flex-1 bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all" />
                      <label className="p-4 bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl text-[var(--muted-text)] cursor-pointer hover:bg-[var(--card-bg)] transition-all flex items-center justify-center aspect-square"><Upload size={18} /><input type="file" className="hidden" accept="image/*" onChange={e => handleFileUpload(e, 'logoUrl')} /></label>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">ختم وتوقيع الشركة الرسمي (Company Stamp / Seal)</label>
                    <div className="flex gap-3">
                      <input type="text" placeholder="رابط صورة الختم أو ملف..." value={formData.companyStampUrl || ''} onChange={e => setFormData({...formData, companyStampUrl: e.target.value})} className="flex-1 bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all" />
                      <label className="p-4 bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl text-[var(--muted-text)] cursor-pointer hover:bg-[var(--card-bg)] transition-all flex items-center justify-center aspect-square" title="رفع صورة الختم"><Upload size={18} /><input type="file" className="hidden" accept="image/*" onChange={async (e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          try {
                            const opt = await optimizeImage(file, 400, 400, 0.85);
                            setFormData(prev => ({ ...prev, companyStampUrl: opt }));
                          } catch (err) {
                            console.error("Stamp optimization failed", err);
                          }
                        }
                      }} /></label>
                    </div>
                    {formData.companyStampUrl && (
                      <div className="flex items-center gap-3 pt-1">
                        <img src={formData.companyStampUrl} alt="Stamp Preview" className="h-12 w-12 object-contain rounded-xl border border-[var(--border-main)] bg-white p-1" />
                        <span className="text-[10px] font-bold text-emerald-400">معاينه ختم الشركة الحالي جاهز للطباعة الفورية</span>
                        <button type="button" onClick={() => setFormData({...formData, companyStampUrl: ''})} className="text-[10px] text-rose-400 hover:underline ms-auto font-bold">حذف الختم</button>
                      </div>
                    )}
                  </div>
                  {userRole?.toLowerCase() === 'admin' && (
                    <div className="space-y-3">
                      <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">
                        {t.lang === 'ar' ? 'بنر الداشبورد الرئيسي (فيديو / صورة / GIF)' : 'Dashboard Banner Media (Video/GIF/Image)'}
                      </label>
                      <div className="flex gap-3">
                        <input type="text" value={formData.companyImage} onChange={e => setFormData({...formData, companyImage: e.target.value})} className="flex-1 bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all" placeholder="Enter video/GIF/image URL or upload file..." />
                        <label className="p-4 bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl text-[var(--muted-text)] cursor-pointer hover:bg-[var(--card-bg)] transition-all flex items-center justify-center aspect-square shadow-sm"><Upload size={18} /><input type="file" className="hidden" accept="image/*,video/*" onChange={e => handleFileUpload(e, 'companyImage')} /></label>
                      </div>
                      {formData.companyImage && formData.companyImage.trim() !== '' && (
                        <div className="relative h-20 w-36 rounded-xl overflow-hidden border border-[var(--border-main)] shadow-sm mt-1">
                          <MediaDisplay url={formData.companyImage} alt="Dashboard Banner Preview" className="w-full h-full object-cover" />
                        </div>
                      )}
                    </div>
                  )}
                  <div className="space-y-3">
                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">{t.logoHeight}</label>
                    <input type="range" min="40" max="250" value={formData.logoHeight} onChange={e => setFormData({...formData, logoHeight: parseInt(e.target.value)})} className="w-full accent-indigo-500 bg-[var(--border-main)] h-2 rounded-lg appearance-none cursor-pointer" />
                    <div className="flex justify-between text-[8px] font-bold text-[var(--muted-text)] uppercase tracking-widest"><span>40px</span><span>{formData.logoHeight}px</span><span>250px</span></div>
                  </div>
                  <div className="space-y-3">
                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">Login Logo Size</label>
                    <input type="range" min="40" max="300" value={formData.loginLogoHeight || 64} onChange={e => setFormData({...formData, loginLogoHeight: parseInt(e.target.value)})} className="w-full accent-emerald-500 bg-[var(--border-main)] h-2 rounded-lg appearance-none cursor-pointer" />
                    <div className="flex justify-between text-[8px] font-bold text-[var(--muted-text)] uppercase tracking-widest"><span>40px</span><span>{formData.loginLogoHeight || 64}px</span><span>300px</span></div>
                  </div>
                   <div className="space-y-3">
                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">{t.systemCurrency || 'Default System Currency'}</label>
                    <select value={formData.defaultCurrency || 'USD'} onChange={e => setFormData({...formData, defaultCurrency: e.target.value as any})} className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] outline-none">
                      <option value="USD">US Dollar ($)</option>
                      <option value="IQD">Iraqi Dinar (IQD)</option>
                    </select>
                  </div>
                  <div className="space-y-3">
                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">{t.exchangeRate || 'System Exchange Rate'}</label>
                    <input type="number" value={formData.exchangeRate || 1500} onChange={e => setFormData({...formData, exchangeRate: parseFloat(e.target.value)})} className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] outline-none" placeholder="1500" />
                  </div>
                  <div className="space-y-3">
                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">{t.siteBackground}</label>
                    <div className="flex gap-3">
                      <input type="text" value={formData.backgroundImageUrl} onChange={e => setFormData({...formData, backgroundImageUrl: e.target.value})} className="flex-1 bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all" />
                      <label className="p-4 bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl text-[var(--muted-text)] cursor-pointer hover:bg-[var(--card-bg)] transition-all flex items-center justify-center aspect-square"><Upload size={18} /><input type="file" className="hidden" accept="image/*" onChange={e => handleFileUpload(e, 'backgroundImageUrl')} /></label>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">
                      {t.loginBgUrl} {t.lang === 'ar' ? '(فيديو / صورة / GIF)' : '(Video/GIF/Image)'}
                    </label>
                    <div className="flex gap-3">
                      <input type="text" value={formData.loginBgUrl || ''} onChange={e => setFormData({...formData, loginBgUrl: e.target.value})} className="flex-1 bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all" placeholder="Enter video/GIF/image URL or upload file..." />
                      <label className="p-4 bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl text-[var(--muted-text)] cursor-pointer hover:bg-[var(--card-bg)] transition-all flex items-center justify-center aspect-square shadow-sm"><Upload size={18} /><input type="file" className="hidden" accept="image/*,video/*" onChange={e => handleFileUpload(e, 'loginBgUrl')} /></label>
                    </div>
                    {formData.loginBgUrl && formData.loginBgUrl.trim() !== '' && (
                      <div className="relative h-20 w-36 rounded-xl overflow-hidden border border-[var(--border-main)] shadow-sm mt-1">
                        <MediaDisplay url={formData.loginBgUrl} alt="Login Background Preview" className="w-full h-full object-cover" />
                      </div>
                    )}
                  </div>
                  <div className="space-y-3">
                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">Login Page Title</label>
                    <input type="text" value={formData.loginTitle || ''} onChange={e => setFormData({...formData, loginTitle: e.target.value})} className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all" placeholder="e.g. Welcome to Airlink" />
                  </div>
                  <div className="space-y-3 md:col-span-2">
                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">Login Page Subtitle</label>
                    <input type="text" value={formData.loginSubtitle || ''} onChange={e => setFormData({...formData, loginSubtitle: e.target.value})} className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all" placeholder="e.g. Exclusive B2B Travel Management Portal" />
                  </div>
                   <div className="space-y-3">
                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">{t.loginLayout}</label>
                    <div className="flex gap-4">
                       <button type="button" onClick={() => setFormData({...formData, loginLayout: 'center'})} className={`flex-1 p-4 rounded-xl border transition-all text-[10px] font-black uppercase tracking-widest ${formData.loginLayout === 'center' ? 'bg-indigo-500 border-indigo-500 text-white' : 'bg-[var(--input-bg)] border-[var(--border-main)] text-[var(--muted-text)] hover:border-[var(--muted-text)]/30'}`}>{t.loginCenter}</button>
                       <button type="button" onClick={() => setFormData({...formData, loginLayout: 'right'})} className={`flex-1 p-4 rounded-xl border transition-all text-[10px] font-black uppercase tracking-widest ${formData.loginLayout === 'right' ? 'bg-indigo-500 border-indigo-500 text-white' : 'bg-[var(--input-bg)] border-[var(--border-main)] text-[var(--muted-text)] hover:border-[var(--muted-text)]/30'}`}>{t.loginRight}</button>
                    </div>
                  </div>
                </div>
              </Card>

              {/* Ads Section */}
              <Card className="p-8 space-y-8 border-[var(--border-main)]">
                <div className="flex items-center gap-4 border-b border-[var(--border-main)] pb-6">
                  <div className="p-3 bg-[var(--card-bg)]/20 rounded-xl text-amber-400"><Megaphone size={24}/></div>
                  <h3 className="text-xl font-bold text-[var(--text-main)] tracking-tight">Dashboard Ads</h3>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-4">
                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">{t.adText}</label>
                    <textarea value={formData.adText || ''} onChange={e => setFormData({...formData, adText: e.target.value})} className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all h-24 resize-none" />
                  </div>
                  <div className="space-y-4">
                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] font-mono">{t.adOpacity} ({formData.adOpacity})</label>
                    <input type="range" min="0" max="1" step="0.1" value={formData.adOpacity} onChange={e => setFormData({...formData, adOpacity: parseFloat(e.target.value)})} className="w-full accent-amber-500 bg-[var(--border-main)] h-2 rounded-lg appearance-none cursor-pointer" />
                    <div className="flex justify-between text-[8px] font-bold text-[var(--muted-text)] uppercase tracking-widest"><span>Invisible (0)</span><span>Opaque (1.0)</span></div>
                  </div>
                </div>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                  {(formData.ads || []).filter(ad => ad && ad.trim() !== '').map((ad, idx) => (
                    <div key={idx} className="relative aspect-video rounded-xl overflow-hidden border border-[var(--border-main)] group">
                      <img src={ad} alt={`Ad ${idx}`} className="w-full h-full object-cover" />
                      <button type="button" onClick={() => removeAd(idx)} className="absolute top-2 right-2 p-1.5 bg-rose-500 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"><X size={14} /></button>
                    </div>
                  ))}
                  <label className="aspect-video border-2 border-dashed border-[var(--border-main)] rounded-xl flex flex-col items-center justify-center text-[var(--muted-text)] hover:text-[var(--text-main)] hover:border-[var(--muted-text)]/20 cursor-pointer transition-all">
                    <Upload size={24} /><span className="text-[10px] font-black uppercase tracking-widest mt-2">{t.upload}</span>
                    <input type="file" className="hidden" accept="image/*" onChange={handleAdUpload} />
                  </label>
                </div>
              </Card>
            </div>
          )}

          {activeTab === 'theme' && (
            <div className="space-y-8 animate-in slide-in-from-left-4">
              <Card className="p-8 space-y-8 border-[var(--border-main)]">
                <div className="flex items-center gap-4 border-b border-[var(--border-main)] pb-6">
                  <div className="p-3 bg-[var(--card-bg)]/20 rounded-xl text-emerald-400"><Palette size={24}/></div>
                  <h3 className="text-xl font-bold text-[var(--text-main)] tracking-tight">{t.themeConfiguration}</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">{t.sitePrimaryColor}</label>
                    <div className="flex gap-4 items-center">
                      <input type="color" value={formData.primaryColor || '#6366f1'} onChange={e => setFormData({...formData, primaryColor: e.target.value})} className="h-12 w-12 bg-transparent border-none cursor-pointer" />
                      <input type="text" value={formData.primaryColor || '#6366f1'} onChange={e => setFormData({...formData, primaryColor: e.target.value})} className="flex-1 bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-[10px] font-black uppercase tracking-widest text-[var(--text-main)] outline-none font-mono" />
                    </div>
                  </div>
                  <div className="space-y-3">
                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">{t.siteSecondaryColor}</label>
                    <div className="flex gap-4 items-center">
                      <input type="color" value={formData.secondaryColor || '#4f46e5'} onChange={e => setFormData({...formData, secondaryColor: e.target.value})} className="h-12 w-12 bg-transparent border-none cursor-pointer" />
                      <input type="text" value={formData.secondaryColor || '#4f46e5'} onChange={e => setFormData({...formData, secondaryColor: e.target.value})} className="flex-1 bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-[10px] font-black uppercase tracking-widest text-[var(--text-main)] outline-none font-mono" />
                    </div>
                  </div>
                  <div className="md:col-span-2 space-y-3">
                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">{t.footerText}</label>
                    <input type="text" value={formData.footerText} onChange={e => setFormData({...formData, footerText: e.target.value})} className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] outline-none" />
                  </div>
                </div>
              </Card>
            </div>
          )}

          {activeTab === 'publicInfo' && (
            <div className="space-y-8 animate-in slide-in-from-left-4">
              <Card className="p-8 space-y-8 border-indigo-500/20 bg-indigo-500/5">
                <div className="flex items-center gap-4 border-b border-[var(--border-main)] pb-6">
                  <div className="p-3 bg-indigo-500/20 text-indigo-400 rounded-xl"><Globe size={24}/></div>
                  <h3 className="text-xl font-bold text-[var(--text-main)] tracking-tight">{t.aboutUs} Content</h3>
                </div>
                <div className="space-y-4">
                  <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">Public Site Description / About Us Page</label>
                  <textarea disabled={!canEditDev} value={formData.aboutContent || ''} onChange={e => setFormData({...formData, aboutContent: e.target.value})} rows={12} className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-6 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 outline-none transition-all resize-none leading-loose font-medium disabled:opacity-50" placeholder="Enter the content that will be visible to all users in the About Us section..." />
                </div>
              </Card>
            </div>
          )}

          {activeTab === 'aboutDev' && (
            <div className="space-y-8 animate-in slide-in-from-left-4">
              <Card className="p-8 space-y-8 border-indigo-500/20 bg-indigo-500/5">
                <div className="flex items-center gap-4 border-b border-[var(--border-main)] pb-6">
                  <div className="p-3 bg-indigo-500/20 text-indigo-400 rounded-xl"><Terminal size={24}/></div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-[var(--text-main)] tracking-tight">{t.aboutDeveloper}</h3>
                    <p className="text-[var(--muted-text)] text-xs font-medium">Official technical records and creator information</p>
                  </div>
                  {canEditDev && (
                    <div className="flex items-center gap-2 bg-emerald-500/20 text-emerald-400 px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest animate-pulse">
                      <UserCheck size={14}/> {t.developerAccess}
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <div>
                      <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-3">{t.devName} (AR)</label>
                      <input type="text" disabled={!canEditDev} value={formData.devInfo?.nameAr} onChange={e => setFormData({...formData, devInfo: {...formData.devInfo!, nameAr: e.target.value}})} className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] outline-none disabled:opacity-50 font-bold" />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-3">{t.devDept} (AR)</label>
                      <input type="text" disabled={!canEditDev} value={formData.devInfo?.deptAr} onChange={e => setFormData({...formData, devInfo: {...formData.devInfo!, deptAr: e.target.value}})} className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] outline-none disabled:opacity-50 font-bold" />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-3">{t.devDescription} (AR)</label>
                      <textarea disabled={!canEditDev} value={formData.devInfo?.descriptionAr} onChange={e => setFormData({...formData, devInfo: {...formData.devInfo!, descriptionAr: e.target.value}})} rows={4} className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] outline-none disabled:opacity-50 resize-none font-bold" />
                    </div>
                  </div>
                  <div className="space-y-6">
                    <div>
                      <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-3">{t.devName} (EN)</label>
                      <input type="text" disabled={!canEditDev} value={formData.devInfo?.nameEn} onChange={e => setFormData({...formData, devInfo: {...formData.devInfo!, nameEn: e.target.value}})} className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] outline-none disabled:opacity-50 font-bold" />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-3">{t.devDept} (EN)</label>
                      <input type="text" disabled={!canEditDev} value={formData.devInfo?.deptEn} onChange={e => setFormData({...formData, devInfo: {...formData.devInfo!, deptEn: e.target.value}})} className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] outline-none disabled:opacity-50 font-bold" />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-3">{t.devDescription} (EN)</label>
                      <textarea disabled={!canEditDev} value={formData.devInfo?.descriptionEn} onChange={e => setFormData({...formData, devInfo: {...formData.devInfo!, descriptionEn: e.target.value}})} rows={4} className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] outline-none disabled:opacity-50 resize-none font-bold" />
                    </div>
                  </div>
                </div>
                   {!canEditDev && (
                  <div className="flex items-center gap-6 p-8 bg-indigo-500/10 border border-[var(--border-main)] rounded-[40px] shadow-2xl overflow-hidden relative group">
                     <div className="absolute top-0 right-0 p-8 opacity-5 transform group-hover:scale-110 transition-transform"><Terminal size={120} /></div>
                     <div className="w-24 h-24 rounded-[32px] accent-gradient text-white flex items-center justify-center p-6 shadow-2xl border border-white/20"><Globe size={60} className="animate-[pulse_4s_infinite]" /></div>
                     <div className="relative z-10 flex-1">
                        <p className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.3em] mb-2">Authenticated System Creator</p>
                        <h4 className="text-3xl font-black text-[var(--text-main)] tracking-tight leading-none mb-3">{lang === 'ar' ? formData.devInfo?.nameAr : formData.devInfo?.nameEn}</h4>
                        <div className="flex gap-4 text-[var(--muted-text)] text-[10px] font-black uppercase tracking-widest items-center">
                           <span className="flex items-center gap-2"><Briefcase size={12}/> {lang === 'ar' ? formData.devInfo?.deptAr : formData.devInfo?.deptEn}</span>
                           <span className="w-1.5 h-1.5 rounded-full bg-white/10" />
                           <span>Enterprise Portal v4.5</span>
                        </div>
                     </div>
                  </div>
                )}

                {canEditDev && isDevMode && handleResetSystem && (
                  <div className="pt-10 border-t border-rose-500/20 mt-10">
                    <div className="bg-rose-500/5 border border-rose-500/20 p-8 rounded-[40px] space-y-6">
                      <div className="flex items-center gap-4">
                        <div className="p-3 bg-rose-500 text-white rounded-2xl shadow-lg shadow-rose-500/20">
                          <Trash2 size={24} />
                        </div>
                        <div>
                          <h4 className="text-xl font-black text-rose-500 tracking-tight uppercase">System Zeroing</h4>
                          <p className="text-[10px] text-rose-500/60 font-medium uppercase tracking-[0.2em] mt-1">Dangerous Operation • Developer Command</p>
                        </div>
                      </div>
                      <p className="text-xs text-rose-500/70 leading-relaxed font-medium">This will completely wipe all user requests, financial transactions, activity logs, and system notifications. The portal will be returned to a factory-fresh state for delivery to the client.</p>
                      <button 
                        type="button" 
                        onClick={handleResetSystem}
                        className="w-full bg-rose-500 hover:bg-rose-600 text-white py-5 rounded-[24px] text-xs font-black uppercase tracking-[0.3em] transition-all active:scale-95 shadow-xl shadow-rose-500/20 flex items-center justify-center gap-4 group"
                      >
                        <Terminal size={18} className="group-hover:rotate-12 transition-transform" />
                        Execute Factory Reset (WIPE ALL DATA)
                      </button>
                    </div>
                  </div>
                )}
              </Card>
            </div>
          )}
        </div>

        <div className="space-y-8">
          <Card className="p-8 glass-pane border-indigo-500/30 bg-indigo-500/10 shadow-[0_20px_40px_rgba(99,102,241,0.1)]">
             <div className="flex flex-col items-center text-center space-y-6">
                <div className="w-20 h-20 bg-[var(--text-main)] p-4 rounded-3xl shadow-2xl flex items-center justify-center">
                   {formData.logoUrl && formData.logoUrl.trim() !== '' ? (
                      <img src={formData.logoUrl} alt="Logo" className="max-h-full object-contain" />
                   ) : (
                      <AirlinkLogo className="max-h-full max-w-full text-[var(--bg-main)]" />
                   )}
                </div>
                <div>
                   <h4 className="text-xl font-black text-[var(--text-main)] tracking-tight">Configuration Status</h4>
                   <p className="text-[var(--muted-text)] text-xs mt-2 leading-relaxed">Changes to identity or theme will be applied across the entire portal instantly.</p>
                </div>
                <button type="submit" className="w-full accent-gradient text-white py-4 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] shadow-xl shadow-indigo-500/20 active:scale-95 transition-all">
                  {t.saveSettings}
                </button>
             </div>
          </Card>
        </div>
      </form>
    </div>
  );
};

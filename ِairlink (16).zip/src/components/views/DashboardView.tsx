import React, { useState } from 'react';
import { Wallet, Clock, CheckCircle, MoreVertical, Megaphone, Video, Image as ImageIcon, Film, Plus, Trash2, Play, Upload, X } from 'lucide-react';
import { UserRole, ServiceRequest, Transaction, AppSettings, DashboardMediaItem } from '../../types.ts';
import { Card, StatusBadge, PriceDisplay, MediaDisplay } from '../ui/Common.tsx';
import { serviceIcons } from '../../constants.ts';
import { optimizeImage } from '../../utils/imageOptimizer.ts';
import { processMediaFile } from '../../utils/mediaHelper.ts';
import { savePortalSettings } from '../../utils/mediaStorage.ts';

interface DashboardViewProps {
  userRole: UserRole | null;
  t: any;
  lang: 'en' | 'ar';
  requestsList: ServiceRequest[];
  transactionsList: Transaction[];
  setCurrentView: (view: string) => void;
  settings: AppSettings;
  setSettings?: (s: AppSettings) => void;
  currentUser: any;
  setRequestFilter: (filter: string | null) => void;
  setSelectedReqId: (id: string | null) => void;
  logs?: any[];
}

export const DashboardView = ({ userRole, t, lang, requestsList, transactionsList, setCurrentView, settings, setSettings, currentUser, setRequestFilter, setSelectedReqId, logs = [] }: DashboardViewProps) => {
  const [showMediaModal, setShowMediaModal] = useState(false);
  const [newMediaType, setNewMediaType] = useState<'video' | 'image' | 'gif'>('image');
  const [newMediaUrl, setNewMediaUrl] = useState('');
  const [newMediaTitle, setNewMediaTitle] = useState('');
  const [newMediaDesc, setNewMediaDesc] = useState('');

  // Client Data Isolation
  const visibleReqs = userRole === 'client' ? requestsList.filter(r => r.company === currentUser?.company) : requestsList;
  const visibleTrxs = userRole === 'client' ? transactionsList.filter(tx => tx.company === currentUser?.company) : transactionsList;

  const pendingCount = visibleReqs.filter(r => r.status === 'pending' || r.status === 'inProgress').length;
  const completedCount = visibleReqs.filter(r => r.status === 'completed' || r.status === 'approved').length;
  const currentBalance = visibleTrxs.reduce((acc, trx) => trx.type === 'charge' ? acc + parseFloat(trx.amount.toString()) : acc - parseFloat(trx.amount.toString()), 0);
  
  // Total Cash = Total Selling Price of all valid requests (No cost involved)
  const totalCash = visibleReqs
    .filter(r => r.status === 'completed' || r.status === 'approved')
    .reduce((acc, req) => acc + (Number(req.selling) || 0), 0);
    
  const totalPayables = (userRole === 'admin' || userRole === 'staff') 
    ? visibleReqs
        .filter(r => r.status === 'completed' || r.status === 'approved')
        .reduce((acc, req) => acc + (Number(req.cost) || 0), 0)
    : 0;

  const showFinancials = userRole !== 'client' || settings.showFinancialsToClient;

  const handleFileUploadMedia = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (userRole === 'client') return;
    const file = e.target.files?.[0];
    if (file) {
      if (file.type.startsWith('video/')) {
        // Create object URL or reader for video
        const reader = new FileReader();
        reader.onloadend = () => {
          setNewMediaUrl(reader.result as string);
          setNewMediaType('video');
        };
        reader.readAsDataURL(file);
      } else {
        try {
          const optimized = await optimizeImage(file, 1200, 800, 0.7);
          setNewMediaUrl(optimized);
          if (file.type === 'image/gif' || file.name.endsWith('.gif')) {
            setNewMediaType('gif');
          } else {
            setNewMediaType('image');
          }
        } catch (err) {
          console.error('Failed to optimize uploaded media:', err);
        }
      }
    }
  };

  const handleAddMedia = () => {
    if (userRole === 'client') return;
    if (!newMediaUrl) {
      alert(lang === 'ar' ? 'يرجى إدخال رابط أو اختيار ملف الميديا' : 'Please provide a URL or upload a media file');
      return;
    }
    const newItem: DashboardMediaItem = {
      id: `MEDIA-${Date.now()}`,
      type: newMediaType,
      url: newMediaUrl,
      title: newMediaTitle || (newMediaType === 'video' ? 'فيديو توضيحي' : newMediaType === 'gif' ? 'صورة متحركة' : 'صورة جديدة'),
      description: newMediaDesc
    };

    if (setSettings) {
      const existing = settings.dashboardMediaList || [];
      setSettings({
        ...settings,
        dashboardMediaList: [newItem, ...existing]
      });
    }

    setNewMediaUrl('');
    setNewMediaTitle('');
    setNewMediaDesc('');
    setShowMediaModal(false);
  };

  const handleDeleteMedia = (id: string) => {
    if (setSettings && settings.dashboardMediaList) {
      setSettings({
        ...settings,
        dashboardMediaList: settings.dashboardMediaList.filter(m => m.id !== id)
      });
    }
  };

  const renderEmbedVideo = (url: string) => {
    if (url.includes('youtube.com') || url.includes('youtu.be')) {
      let videoId = '';
      if (url.includes('youtu.be/')) {
        videoId = url.split('youtu.be/')[1]?.split('?')[0] || '';
      } else if (url.includes('watch?v=')) {
        videoId = url.split('watch?v=')[1]?.split('&')[0] || '';
      }
      if (videoId) {
        return (
          <iframe 
            src={`https://www.youtube.com/embed/${videoId}`} 
            className="w-full h-full rounded-[24px]" 
            allowFullScreen 
            title="Dashboard Video"
          />
        );
      }
    }
    return (
      <video src={url} controls className="w-full h-full object-cover rounded-[24px]" />
    );
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-4xl font-black text-[var(--text-main)] tracking-tight">{t.dashboard}</h2>
          <p className="text-[var(--muted-text)] mt-2 font-medium">{userRole === 'admin' ? t.companyOverview : `Welcome back to ${settings.companyName} Portal`}</p>
        </div>
        
        {/* Add Media Button */}
        {setSettings && userRole !== 'client' && (
          <button
            onClick={() => setShowMediaModal(true)}
            className="flex items-center gap-3 bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3.5 rounded-2xl text-xs font-black uppercase tracking-wider shadow-lg shadow-indigo-500/20 active:scale-95 transition-all"
          >
            <Plus size={18} />
            <span>{lang === 'ar' ? 'إضافة فيديو / صورة / GIF' : 'Add Video / Image / GIF'}</span>
          </button>
        )}
      </div>

      {/* Dashboard Media Gallery (Videos, Images, GIFs) */}
      {settings.dashboardMediaList && settings.dashboardMediaList.length > 0 && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-indigo-500/10 text-indigo-500 rounded-xl">
                <Film size={20} />
              </div>
              <h3 className="text-base font-black text-[var(--text-main)] uppercase tracking-wider">
                {lang === 'ar' ? 'المحتوى المرئي والوسائط (فيديو / صور / GIF)' : 'Media Gallery (Videos, Images, GIFs)'}
              </h3>
            </div>
            <span className="text-xs text-[var(--muted-text)] font-bold">
              {settings.dashboardMediaList.length} {lang === 'ar' ? 'وسائط مضافة' : 'Items'}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {settings.dashboardMediaList.map((media) => (
              <div key={media.id} className="relative rounded-[32px] overflow-hidden border border-[var(--border-main)] bg-[var(--card-bg)] shadow-2xl group">
                <div className="aspect-[16/9] w-full relative bg-black/40 overflow-hidden flex items-center justify-center">
                  {media.type === 'video' ? (
                    renderEmbedVideo(media.url)
                  ) : (
                    <img 
                      src={media.url} 
                      alt={media.title || 'Media'} 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" 
                    />
                  )}
                  {media.type === 'gif' && (
                    <span className="absolute top-4 right-4 bg-indigo-600 text-white text-[9px] font-black px-2.5 py-1 rounded-full uppercase tracking-widest shadow-md">
                      GIF
                    </span>
                  )}
                  {media.type === 'video' && (
                    <span className="absolute top-4 right-4 bg-rose-600 text-white text-[9px] font-black px-2.5 py-1 rounded-full uppercase tracking-widest shadow-md flex items-center gap-1">
                      <Video size={12} /> VIDEO
                    </span>
                  )}
                  {media.type === 'image' && (
                    <span className="absolute top-4 right-4 bg-emerald-600 text-white text-[9px] font-black px-2.5 py-1 rounded-full uppercase tracking-widest shadow-md flex items-center gap-1">
                      <ImageIcon size={12} /> IMAGE
                    </span>
                  )}
                </div>

                <div className="p-5 flex items-center justify-between bg-[var(--card-bg)]">
                  <div>
                    <h4 className="text-sm font-black text-[var(--text-main)] truncate">{media.title}</h4>
                    {media.description && (
                      <p className="text-xs text-[var(--muted-text)] mt-1 font-medium line-clamp-1">{media.description}</p>
                    )}
                  </div>

                  {setSettings && (userRole === 'admin' || currentUser?.email?.includes('ali')) && (
                    <button
                      onClick={() => handleDeleteMedia(media.id)}
                      className="p-2 text-rose-400 hover:bg-rose-500/10 rounded-xl transition-all"
                      title="حذف"
                    >
                      <Trash2 size={16} />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Media Add Modal */}
      {showMediaModal && userRole !== 'client' && (
        <div className="fixed inset-0 z-[200] bg-black/70 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[var(--card-bg)] border border-[var(--border-main)] rounded-[32px] p-8 max-w-lg w-full space-y-6 shadow-2xl relative animate-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-[var(--border-main)] pb-4">
              <h3 className="text-lg font-black text-[var(--text-main)] uppercase tracking-wider flex items-center gap-3">
                <Film size={20} className="text-indigo-500" />
                {lang === 'ar' ? 'إضافة ميديا للداشبورد' : 'Add Dashboard Media'}
              </h3>
              <button onClick={() => setShowMediaModal(false)} className="text-[var(--muted-text)] hover:text-[var(--text-main)]">
                <X size={20} />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-black text-[var(--muted-text)] uppercase tracking-wider mb-2">
                  {lang === 'ar' ? 'نوع الميديا' : 'Media Type'}
                </label>
                <div className="grid grid-cols-3 gap-3">
                  <button
                    type="button"
                    onClick={() => setNewMediaType('image')}
                    className={`py-3 rounded-xl text-xs font-black uppercase tracking-wider border transition-all flex items-center justify-center gap-2 ${newMediaType === 'image' ? 'bg-indigo-600 text-white border-indigo-500' : 'bg-[var(--input-bg)] border-[var(--border-main)] text-[var(--muted-text)]'}`}
                  >
                    <ImageIcon size={16} /> صورة
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewMediaType('gif')}
                    className={`py-3 rounded-xl text-xs font-black uppercase tracking-wider border transition-all flex items-center justify-center gap-2 ${newMediaType === 'gif' ? 'bg-indigo-600 text-white border-indigo-500' : 'bg-[var(--input-bg)] border-[var(--border-main)] text-[var(--muted-text)]'}`}
                  >
                    <Film size={16} /> GIF متحرك
                  </button>
                  <button
                    type="button"
                    onClick={() => setNewMediaType('video')}
                    className={`py-3 rounded-xl text-xs font-black uppercase tracking-wider border transition-all flex items-center justify-center gap-2 ${newMediaType === 'video' ? 'bg-indigo-600 text-white border-indigo-500' : 'bg-[var(--input-bg)] border-[var(--border-main)] text-[var(--muted-text)]'}`}
                  >
                    <Video size={16} /> فيديو
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-black text-[var(--muted-text)] uppercase tracking-wider mb-2">
                  {lang === 'ar' ? 'عنوان الميديا' : 'Title'}
                </label>
                <input
                  type="text"
                  value={newMediaTitle}
                  onChange={(e) => setNewMediaTitle(e.target.value)}
                  placeholder={lang === 'ar' ? 'مثال: عرض الميزات الرئيسية' : 'e.g. Hero Overview Video'}
                  className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-3.5 text-sm text-[var(--text-main)] outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-black text-[var(--muted-text)] uppercase tracking-wider mb-2">
                  {lang === 'ar' ? 'رابط الميديا (YouTube / MP4 / GIF / صورة)' : 'Media URL'}
                </label>
                <input
                  type="text"
                  value={newMediaUrl}
                  onChange={(e) => setNewMediaUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-3.5 text-sm text-[var(--text-main)] outline-none font-mono text-xs"
                />
              </div>

              <div className="relative border-2 border-dashed border-[var(--border-main)] hover:border-indigo-500 p-4 rounded-2xl text-center cursor-pointer transition-all">
                <Upload size={24} className="mx-auto text-indigo-500 mb-1" />
                <span className="text-xs font-bold text-[var(--text-main)] block">
                  {lang === 'ar' ? 'أو ارفع ملف من جهازك مباشرة' : 'Or upload file directly'}
                </span>
                <input type="file" accept="image/*,video/*" onChange={handleFileUploadMedia} className="absolute inset-0 opacity-0 cursor-pointer" />
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t border-[var(--border-main)]">
              <button
                type="button"
                onClick={() => setShowMediaModal(false)}
                className="px-5 py-3 rounded-xl text-xs font-black text-[var(--muted-text)] hover:bg-[var(--input-bg)]"
              >
                {lang === 'ar' ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handleAddMedia}
                className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black uppercase tracking-wider shadow-lg shadow-indigo-500/20"
              >
                {lang === 'ar' ? 'إضافة للداشبورد' : 'Add to Dashboard'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Advertisements Section */}
      {((settings.ads && settings.ads.length > 0) || settings.adText) && (
        <div className="space-y-6">
          <div className="flex flex-col gap-1">
             <div className="flex items-center gap-3">
                <div className="p-2 bg-amber-500/10 text-amber-500 rounded-lg"><Megaphone size={16}/></div>
                <h3 className="text-sm font-black text-[var(--muted-text)] uppercase tracking-widest">{t.advertisements || 'Promotions'}</h3>
             </div>
             {settings.adText && (
               <p className="ms-11 text-sm text-[var(--muted-text)] font-medium leading-relaxed max-w-2xl">{settings.adText}</p>
             )}
          </div>
          
          {settings.ads && settings.ads.filter(ad => ad && ad.trim() !== '').length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {settings.ads.filter(ad => ad && ad.trim() !== '').map((ad, idx) => (
                <div key={idx} className="relative aspect-[16/9] rounded-[40px] overflow-hidden border border-[var(--border-main)] group shadow-2xl bg-[var(--card-bg)]">
                   <img src={ad} alt={`Ad ${idx}`} className="w-full h-full object-cover transform transition-transform duration-700 group-hover:scale-110" />
                   <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-6">
                      <p className="text-[10px] font-black text-white uppercase tracking-[0.2em] mb-2">{settings.companyName} Exclusive</p>
                      <div className="h-0.5 w-12 bg-white/50 rounded-full"></div>
                   </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {settings.companyImage && settings.companyImage.trim() !== '' ? (
        <div className="relative h-64 rounded-[40px] overflow-hidden shadow-2xl border border-[var(--border-main)] group">
          <MediaDisplay url={settings.companyImage} alt="Company Hero" className="w-full h-full object-cover transform transition-transform duration-1000 group-hover:scale-105" />
          <div className="absolute inset-0 bg-gradient-to-t from-[var(--bg-main)] via-transparent to-transparent opacity-60 pointer-events-none"></div>
          <div className="absolute bottom-8 left-8 right-8 flex items-end justify-between gap-4">
             <div className="bg-black/40 backdrop-blur-3xl p-6 sm:p-8 rounded-[32px] border border-white/10 inline-block shadow-2xl" style={{ opacity: settings.adOpacity ?? 0.9 }}>
                <h3 className="text-xl sm:text-2xl font-black text-white tracking-tight leading-tight">{settings.adText || 'Precision in Motion'}</h3>
                <p className="text-white/60 text-[10px] font-black uppercase tracking-[0.3em] mt-2">{t.loginSubtitle || 'Your trusted travel infrastructure partner'}</p>
                <div className="h-1 w-12 bg-orange-500 mt-3 rounded-full"></div>
             </div>

             {/* Admin Banner Change Action (Admin Only) */}
             {userRole === 'admin' && setSettings && (
               <label className="bg-black/70 hover:bg-black/90 backdrop-blur-md text-white px-4 py-3 rounded-2xl border border-white/20 cursor-pointer transition-all flex items-center gap-2 text-xs font-black uppercase tracking-wider shadow-xl group active:scale-95 shrink-0 z-20">
                 <Upload size={16} className="text-indigo-400 group-hover:scale-110 transition-transform" />
                 <span>{lang === 'ar' ? 'تعديل بنر الداشبورد (فيديو / صورة / GIF)' : 'Change Banner (Video/GIF/Image)'}</span>
                 <input 
                   type="file" 
                   className="hidden" 
                   accept="image/*,video/*" 
                   onChange={async (e) => {
                     const file = e.target.files?.[0];
                     if (file) {
                       try {
                         const mediaData = await processMediaFile(file);
                         const updated = { ...settings, companyImage: mediaData };
                         setSettings(updated);
                         savePortalSettings(updated);
                       } catch (err) {
                         console.error("Failed to upload banner media:", err);
                       }
                     }
                   }} 
                 />
               </label>
             )}
          </div>
        </div>
      ) : (
        /* Empty Banner Placeholder for Admin */
        userRole === 'admin' && setSettings && (
          <div className="p-8 border-2 border-dashed border-[var(--border-main)] hover:border-indigo-500/50 rounded-[32px] text-center bg-[var(--card-bg)]/50 transition-all">
            <div className="max-w-md mx-auto space-y-3">
              <div className="p-3 bg-indigo-500/10 text-indigo-500 rounded-2xl w-fit mx-auto">
                <Film size={24} />
              </div>
              <h4 className="text-sm font-black text-[var(--text-main)] uppercase tracking-wider">
                {lang === 'ar' ? 'بنر الداشبورد (فيديو / صورة / GIF)' : 'Dashboard Banner Media'}
              </h4>
              <p className="text-xs text-[var(--muted-text)]">
                {lang === 'ar' ? 'يمكنك كأدمن إضافة فيديو أو صورة متحركة (GIF) أو صورة لبنر الداشبورد الرئيسي' : 'Upload a video, animated GIF, or image as the main dashboard hero banner.'}
              </p>
              <label className="inline-flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-3 rounded-2xl text-xs font-black uppercase tracking-wider cursor-pointer shadow-lg shadow-indigo-500/20 active:scale-95 transition-all mt-2">
                <Upload size={16} />
                <span>{lang === 'ar' ? 'رفع فيديو / صورة متحركة GIF' : 'Upload Media Banner'}</span>
                <input 
                  type="file" 
                  className="hidden" 
                  accept="image/*,video/*" 
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      try {
                        const mediaData = await processMediaFile(file);
                        const updated = { ...settings, companyImage: mediaData };
                        setSettings(updated);
                        savePortalSettings(updated);
                      } catch (err) {
                        console.error("Failed to upload banner media:", err);
                      }
                    }
                  }} 
                />
              </label>
            </div>
          </div>
        )
      )}

      <div className={`grid grid-cols-1 ${showFinancials ? 'md:grid-cols-3' : 'md:grid-cols-2'} gap-8`}>
        {showFinancials && (
          <Card 
            onClick={() => setCurrentView('statement')}
            className="p-6 relative overflow-hidden group border-[var(--border-main)] cursor-pointer hover:shadow-2xl transition-all active:scale-95"
          >
            <div className="absolute top-0 right-0 p-4 opacity-5 transform group-hover:scale-110 transition-transform"><Wallet size={80} className="text-[var(--text-main)]" /></div>
            <div className="relative z-10">
              <p className="text-[10px] font-bold text-[var(--muted-text)] mb-2 uppercase tracking-widest">
                {userRole === 'client' ? t.totalBalance : (userRole === 'staff' ? t.receivablesCount : (userRole === 'viewer' ? t.totalRequests : t.totalReceivableCash))}
              </p>
              <h3 className="text-4xl font-black text-[var(--text-main)] mb-2 tracking-tighter">
                {userRole === 'staff' || userRole === 'viewer' ? visibleReqs.length : <PriceDisplay amount={userRole === 'admin' ? totalCash : currentBalance} defaultCurrency={settings.defaultCurrency} exchangeRate={settings.exchangeRate} />}
              </h3>
              <div className="w-12 h-1 accent-gradient rounded-full"></div>
            </div>
          </Card>
        )}
        <Card 
          onClick={() => {
            setRequestFilter('active');
            setCurrentView(userRole === 'admin' || userRole === 'staff' || userRole === 'viewer' ? 'allRequests' : 'requests');
          }}
          className="p-6 relative overflow-hidden group border-[var(--border-main)] cursor-pointer hover:shadow-2xl transition-all active:scale-95"
        >
          <div className="absolute top-0 right-0 p-4 opacity-5 transform group-hover:scale-110 transition-transform"><Clock size={80} className="text-[var(--text-main)]" /></div>
          <div className="relative z-10">
            <p className="text-[10px] font-bold text-[var(--muted-text)] mb-2 uppercase tracking-widest">{t.pendingRequests}</p>
            <h3 className="text-4xl font-black text-[var(--text-main)] mb-2 tracking-tighter">{pendingCount}</h3>
            <div className="w-12 h-1 bg-amber-500 rounded-full"></div>
          </div>
        </Card>
        <Card 
          onClick={() => {
            setRequestFilter('completed');
            setCurrentView(userRole === 'admin' || userRole === 'staff' || userRole === 'viewer' ? 'allRequests' : 'requests');
          }}
          className="p-6 relative overflow-hidden group border-[var(--border-main)] cursor-pointer hover:shadow-2xl transition-all active:scale-95"
        >
           <div className="absolute top-0 right-0 p-4 opacity-5 transform group-hover:scale-110 transition-transform"><CheckCircle size={80} className="text-[var(--text-main)]" /></div>
          <div className="relative z-10">
            <p className="text-[10px] font-bold text-[var(--muted-text)] mb-2 uppercase tracking-widest">{t.completedRequests}</p>
            <h3 className="text-4xl font-black text-[var(--text-main)] mb-2 tracking-tighter">{completedCount}</h3>
            <div className="w-12 h-1 bg-emerald-500 rounded-full"></div>
          </div>
        </Card>
      </div>

      {(userRole === 'admin' || userRole === 'staff') && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
           <Card 
            className="p-6 relative overflow-hidden group border-rose-500/20 bg-rose-500/5 transition-all shadow-lg"
          >
            <div className="absolute top-0 right-0 p-4 opacity-5 transform group-hover:scale-110 transition-transform"><Wallet size={80} className="text-rose-500" /></div>
            <div className="relative z-10">
              <p className="text-[10px] font-bold text-rose-500 mb-2 uppercase tracking-widest">
                {lang === 'ar' ? 'إجمالي مستحقات الموردين' : 'Total Supplier Payables (Costs)'}
              </p>
              <h3 className="text-4xl font-black text-rose-600 mb-2 tracking-tighter">
                <PriceDisplay amount={totalPayables} defaultCurrency={settings.defaultCurrency} exchangeRate={settings.exchangeRate} />
              </h3>
              <div className="w-12 h-1 bg-rose-500 rounded-full"></div>
              <p className="text-[10px] text-rose-500/60 font-bold mt-2 uppercase tracking-widest">{lang === 'ar' ? 'إجمالي التكاليف فقط' : 'Total Costs Only'}</p>
            </div>
          </Card>
        </div>
      )}

      <Card className="overflow-hidden border-[var(--border-main)]">
        <div className="p-6 border-b border-[var(--border-main)] flex justify-between items-center bg-[var(--card-bg)]">
          <h3 className="font-black text-[var(--text-main)] text-lg uppercase tracking-widest">{t.recentActivity}</h3>
          <button onClick={() => setCurrentView(userRole === 'admin' ? 'allRequests' : 'requests')} className="text-xs text-indigo-500 font-black uppercase tracking-widest hover:underline transition-all">View All</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left rtl:text-right text-[var(--muted-text)]">
            <thead className="text-[10px] text-[var(--muted-text)] opacity-60 uppercase bg-[var(--bg-main)] border-b border-[var(--border-main)] font-black">
              <tr>
                <th className="px-6 py-4 tracking-widest">{t.date}</th>
                {(userRole === 'admin' || userRole === 'staff' || userRole === 'viewer') && <th className="px-6 py-4 tracking-widest">Company</th>}
                <th className="px-6 py-4 tracking-widest">{t.service}</th>
                <th className="px-6 py-4 tracking-widest">{t.status}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border-main)]">
              {visibleReqs.slice(0, 5).map(req => {
                const SIcon = serviceIcons[req.service] || MoreVertical;
                return (
                   <tr 
                     key={req.id} 
                     className="hover:bg-[var(--card-bg)] transition-colors cursor-pointer group"
                     onClick={() => {
                        // User requested to see the "list, not the request" from dashboard
                        setSelectedReqId(null); 
                        setCurrentView(userRole === 'admin' || userRole === 'staff' || userRole === 'viewer' ? 'allRequests' : 'requests');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                     }}
                   >
                     <td className="px-6 py-4 whitespace-nowrap text-[var(--muted-text)] font-black text-[10px] tracking-widest group-hover:text-[var(--text-main)] transition-colors">{req.id.slice(-8)}</td>
                     <td className="px-6 py-4 whitespace-nowrap text-[var(--muted-text)] font-bold text-xs">{req.date}</td>
                     {(userRole === 'admin' || userRole === 'staff' || userRole === 'viewer') && <td className="px-6 py-4 font-black text-[var(--text-main)]">{req.company}</td>}
                     <td className="px-6 py-4">
                       <div className="flex items-center gap-2">
                         <div className="p-1.5 bg-[var(--primary)]/10 rounded-md text-[var(--primary)]"><SIcon size={16}/></div>
                         <span className="font-bold text-[var(--text-main)] uppercase text-[10px] tracking-widest">{t[req.service]}</span>
                       </div>
                     </td>
                     <td className="px-6 py-4"><StatusBadge status={req.status} t={t} /></td>
                   </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      {userRole === 'admin' && (
        <Card className="overflow-hidden border border-amber-500/20 bg-amber-500/[0.02]">
          <div className="p-6 border-b border-amber-500/10 flex justify-between items-center">
            <div className="flex items-center gap-3">
               <div className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></div>
               <h3 className="font-black text-[var(--text-main)] text-lg uppercase tracking-widest">
                  {lang === 'ar' ? 'سجل أحداث النظام' : 'System Activity Log'}
               </h3>
            </div>
            <span className="text-[10px] font-black text-amber-500/60 uppercase tracking-widest">Monitoring Mode v4.2</span>
          </div>
          <div className="max-h-[300px] overflow-y-auto">
             <div className="p-0">
                {logs.length === 0 ? (
                  <div className="p-10 text-center text-sm text-[var(--muted-text)] italic">No recent activities recorded.</div>
                ) : (
                  <div className="divide-y divide-[var(--border-main)]">
                    {logs.map((log: any) => (
                      <div key={log.id} className="p-4 flex gap-4 items-start hover:bg-amber-500/[0.03] transition-colors group">
                        <div className="w-1 h-10 bg-amber-500/20 group-hover:bg-amber-500 rounded-full transition-colors flex-shrink-0 mt-1"></div>
                        <div className="flex-1 space-y-1">
                          <div className="flex justify-between items-center">
                            <span className="text-xs font-black text-[var(--text-main)] uppercase tracking-wider">{log.action}</span>
                            <span className="text-[10px] text-[var(--muted-text)] font-medium">{new Date(log.timestamp).toLocaleString(lang === 'ar' ? 'ar-EG' : 'en-US')}</span>
                          </div>
                          <p className="text-xs text-[var(--muted-text)] leading-relaxed">{log.details}</p>
                          <div className="flex items-center gap-2 pt-1">
                             <div className="w-1.5 h-1.5 rounded-full bg-emerald-500"></div>
                             <span className="text-[9px] font-black text-[var(--text-main)] opacity-60 uppercase tracking-tighter">{log.user}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
             </div>
          </div>
        </Card>
      )}
    </div>
  );
};

import React from 'react';
import { TrendingUp } from 'lucide-react';
import { ServiceRequest, AppSettings } from '../../types.ts';
import { Card, PriceDisplay } from '../ui/Common.tsx';

interface AdminFinancialsViewProps {
  t: any;
  lang: string;
  isRTL: boolean;
  requestsList: ServiceRequest[];
  settings: AppSettings;
}

export const AdminFinancialsView = ({ t, lang, isRTL, requestsList, settings }: AdminFinancialsViewProps) => {
  const validReqs = requestsList.filter(r => r.status === 'completed' || r.status === 'approved');
  
  const totalSelling = validReqs.reduce((acc, req) => acc + (Number(req.selling) || 0), 0);
  const totalCost = validReqs.reduce((acc, req) => acc + (Number(req.cost) || 0), 0);
  const totalProfit = totalSelling - totalCost;

  const groupBy = (keyFn: (r: ServiceRequest) => string): [string, number][] => {
    const grouped = validReqs.reduce((acc: Record<string, number>, req) => {
      const key = keyFn(req);
      if(!key) return acc;
      const profit = (Number(req.selling) || 0) - (Number(req.cost) || 0);
      acc[key] = (acc[key] || 0) + profit;
      return acc;
    }, {});
    const entries = Object.entries(grouped) as [string, number][];
    return entries.sort((a, b) => b[1] - a[1]);
  };

  const profitByClient = groupBy(r => r.company);
  const profitByService = groupBy(r => t[r.service]);
  const profitByDay = groupBy(r => r.date);
  const profitByMonth = groupBy(r => r.date.substring(0, 7)); 

  return (
    <div className="space-y-12 animate-in fade-in duration-500 print-target">
      <div className="flex flex-col md:flex-row justify-between md:items-end gap-6 no-print">
        <div>
          <h2 className="text-4xl font-black text-[var(--text-main)] tracking-tight">{t.financials}</h2>
          <p className="text-[10px] font-black uppercase text-amber-500 tracking-[0.2em] mt-3 bg-amber-500/10 inline-block px-4 py-2 border border-amber-500/20 rounded-xl shadow-xl shadow-amber-500/5">Strictly Confidential - Admin View Only</p>
        </div>
        <div className="flex items-center gap-4">
            <button 
              onClick={() => window.print()}
              className="flex items-center gap-2 bg-[var(--card-bg)] text-[var(--text-main)] border border-[var(--border-main)] px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-[var(--bg-main)] transition-all shadow-lg"
            >
              <TrendingUp size={16} /> {lang === 'ar' ? 'طباعة التقارير' : 'Print Reports'}
            </button>
            <div className="flex items-center gap-3 bg-[var(--card-bg)] p-4 rounded-2xl border border-[var(--border-main)] shadow-sm">
                <span className="text-[var(--muted-text)] font-black uppercase tracking-widest text-[10px]">Real-time Analytics</span>
            </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <Card className="p-8 border-[var(--border-main)] bg-[var(--card-bg)] relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-1 h-full bg-indigo-500 shadow-[0_0_20px_rgba(99,102,241,0.5)]"></div>
          <p className="text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-3">{t.totalSales}</p>
          <p className="text-4xl font-black text-[var(--text-main)] tracking-tighter group-hover:scale-105 transition-transform duration-500">
            <PriceDisplay amount={totalSelling} defaultCurrency={settings.defaultCurrency} exchangeRate={settings.exchangeRate} />
          </p>
          <div className="absolute -right-8 -bottom-8 w-24 h-24 bg-indigo-500/5 rounded-full blur-3xl"></div>
        </Card>
        <Card className="p-8 border-[var(--border-main)] bg-[var(--card-bg)] relative overflow-hidden group">
          <div className="absolute top-0 left-0 w-1 h-full bg-rose-500 shadow-[0_0_20px_rgba(244,63,94,0.5)]"></div>
          <p className="text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-3">{t.totalCosts}</p>
          <p className="text-4xl font-black text-[var(--text-main)] tracking-tighter group-hover:scale-105 transition-transform duration-500">
            <PriceDisplay amount={totalCost} defaultCurrency={settings.defaultCurrency} exchangeRate={settings.exchangeRate} />
          </p>
          <div className="absolute -right-8 -bottom-8 w-24 h-24 bg-rose-500/5 rounded-full blur-3xl"></div>
        </Card>
        <Card className="p-8 border-none bg-[var(--primary)] shadow-xl relative overflow-hidden group">
          <p className="text-[10px] font-black text-white/60 uppercase tracking-[0.2em] mb-3">{t.netProfit}</p>
          <p className="text-4xl font-black text-white tracking-tighter group-hover:scale-105 transition-transform duration-500">
            <PriceDisplay amount={totalProfit} defaultCurrency={settings.defaultCurrency} exchangeRate={settings.exchangeRate} />
          </p>
          <div className="absolute -right-10 -bottom-10 w-32 h-32 bg-white/20 rounded-full blur-3xl group-hover:scale-150 transition-transform duration-700"></div>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
        <Card className="p-8 border-[var(--border-main)] bg-[var(--card-bg)] hover:bg-[var(--bg-main)] transition-all group">
          <h3 className="text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-6 border-b border-[var(--border-main)] pb-4">{t.profitByDay}</h3>
          <div className="space-y-4 max-h-56 overflow-y-auto custom-scrollbar pr-2">
              {profitByDay.map(([date, profit]) => (
                <div key={date} className="flex justify-between items-center group/item hover:bg-white/[0.02] p-2.5 rounded-xl transition-all border border-transparent hover:border-white/5">
                  <span className="text-[11px] font-bold text-[var(--muted-text)] group-hover/item:text-[var(--text-main)] transition-colors">{date}</span>
                  <span className="font-black text-emerald-500 text-sm tracking-tight leading-none">${profit.toLocaleString()}</span>
                </div>
              ))}
             {profitByDay.length === 0 && <p className="text-xs text-[var(--muted-text)]/40 font-medium italic">No data available.</p>}
          </div>
        </Card>
        <Card className="p-8 border-[var(--border-main)] bg-[var(--card-bg)] hover:bg-[var(--bg-main)] transition-all group">
          <h3 className="text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-6 border-b border-[var(--border-main)] pb-4">{t.profitByMonth}</h3>
          <div className="space-y-4 max-h-56 overflow-y-auto custom-scrollbar pr-2">
              {profitByMonth.map(([month, profit]) => (
                <div key={month} className="flex justify-between items-center group/item hover:bg-white/[0.02] p-2.5 rounded-xl transition-all border border-transparent hover:border-white/5">
                  <span className="text-[11px] font-bold text-[var(--muted-text)] group-hover/item:text-[var(--text-main)] transition-colors">{month}</span>
                  <span className="font-black text-emerald-500 text-sm tracking-tight leading-none">${profit.toLocaleString()}</span>
                </div>
              ))}
             {profitByMonth.length === 0 && <p className="text-xs text-[var(--muted-text)]/40 font-medium italic">No data available.</p>}
          </div>
        </Card>
        <Card className="p-8 border-[var(--border-main)] bg-[var(--card-bg)] hover:bg-[var(--bg-main)] transition-all group">
          <h3 className="text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-6 border-b border-[var(--border-main)] pb-4">{t.byClient}</h3>
          <div className="space-y-4 max-h-56 overflow-y-auto custom-scrollbar pr-2">
              {profitByClient.map(([client, profit]) => (
                <div key={client} className="flex justify-between items-center group/item hover:bg-white/[0.02] p-2.5 rounded-xl transition-all border border-transparent hover:border-white/5">
                  <span className="text-[11px] font-bold text-[var(--muted-text)] group-hover/item:text-[var(--text-main)] transition-colors truncate max-w-[120px]" title={client}>{client}</span>
                  <span className="font-black text-emerald-500 text-sm tracking-tight leading-none">${profit.toLocaleString()}</span>
                </div>
              ))}
             {profitByClient.length === 0 && <p className="text-xs text-[var(--muted-text)]/40 font-medium italic">No data available.</p>}
          </div>
        </Card>
        <Card className="p-8 border-[var(--border-main)] bg-[var(--card-bg)] hover:bg-[var(--bg-main)] transition-all group">
          <h3 className="text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-6 border-b border-[var(--border-main)] pb-4">{t.byService}</h3>
          <div className="space-y-4 max-h-56 overflow-y-auto custom-scrollbar pr-2">
              {profitByService.map(([service, profit]) => (
                <div key={service} className="flex justify-between items-center group/item hover:bg-white/[0.02] p-2.5 rounded-xl transition-all border border-transparent hover:border-white/5">
                  <span className="text-[11px] font-bold text-[var(--muted-text)] group-hover/item:text-[var(--text-main)] transition-colors truncate max-w-[120px]" title={service}>{service}</span>
                  <span className="font-black text-emerald-500 text-sm tracking-tight leading-none">${profit.toLocaleString()}</span>
                </div>
              ))}
             {profitByService.length === 0 && <p className="text-xs text-[var(--muted-text)]/40 font-medium italic">No data available.</p>}
          </div>
        </Card>
      </div>

      <Card className="overflow-hidden !p-0 border-[var(--border-main)] bg-[var(--card-bg)] shadow-2xl">
        <div className="p-8 border-b border-[var(--border-main)] bg-[var(--bg-main)]">
          <h3 className="font-black text-[var(--text-main)] text-xl uppercase tracking-widest">Detailed Profit Ledger</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left rtl:text-right">
            <thead className="text-[10px] text-[var(--muted-text)] uppercase bg-[var(--bg-main)] border-b border-[var(--border-main)] tracking-[0.2em] font-black">
              <tr>
                <th className="px-8 py-6">Ref ID</th>
                <th className="px-8 py-6">Company</th>
                <th className="px-8 py-6">{t.supplier}</th>
                <th className="px-8 py-6 text-right">{t.cost}</th>
                <th className="px-8 py-6 text-right">{t.selling}</th>
                <th className="px-8 py-6 text-right text-emerald-500">Profit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border-main)]">
              {validReqs.map(req => {
                const profit = (Number(req.selling) || 0) - (Number(req.cost) || 0);
                return (
                  <tr key={req.id} className="hover:bg-[var(--bg-main)] transition-all group">
                    <td className="px-8 py-6 font-black text-[var(--text-main)] tracking-tight">{req.id}</td>
                    <td className="px-8 py-6 font-bold text-[var(--muted-text)]">{req.company}</td>
                    <td className="px-8 py-6 text-[var(--muted-text)]/60 font-bold text-[11px] uppercase tracking-widest">{req.supplier || '-'}</td>
                    <td className="px-8 py-6 text-right text-rose-500 font-black tracking-tight underline decoration-rose-500/30 underline-offset-4">${(Number(req.cost) || 0).toLocaleString()}</td>
                    <td className="px-8 py-6 text-right text-indigo-500 font-black tracking-tight underline decoration-indigo-500/30 underline-offset-4">${(Number(req.selling) || 0).toLocaleString()}</td>
                    <td className="px-8 py-6 text-right">
                        <span className="font-black text-white bg-emerald-500 px-4 py-1.5 rounded-lg shadow-xl shadow-emerald-500/20 tracking-tight">
                            ${profit.toLocaleString()}
                        </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
};

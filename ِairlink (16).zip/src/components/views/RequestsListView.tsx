import React, { useState, useEffect } from 'react';
import { 
  ChevronRight, ChevronLeft, MoreVertical, Star, CheckCircle, 
  Check, XCircle, FileSignature, Building, PlusCircle, Globe,
  UploadCloud, Send, Paperclip, CheckSquare, Trash2, Eye,
  AlertCircle, ThumbsUp, ThumbsDown, CheckCheck, FileText, Copy
} from 'lucide-react';
import { UserRole, ServiceRequest, Transaction, Offer, AppSettings, Supplier } from '../../types.ts';
import { Card, StatusBadge, AirlinkLogo, PriceDisplay } from '../ui/Common.tsx';
import { InvoiceVoucher } from '../ui/InvoiceVoucher.tsx';
import { FilePreviewModal, PreviewFileItem } from '../modals/FilePreviewModal.tsx';
import { serviceIcons } from '../../constants.ts';
import { generateId } from '../../App.tsx';

interface RequestsListViewProps {
  userRole: UserRole | null;
  t: any;
  lang: string;
  isRTL: boolean;
  requestsList: ServiceRequest[];
  setRequestsList: React.Dispatch<React.SetStateAction<ServiceRequest[]>>;
  transactionsList: Transaction[];
  setTransactionsList: React.Dispatch<React.SetStateAction<Transaction[]>>;
  currentUser: any;
  settings: AppSettings;
  addNotification: (text: string, type?: any, description?: string, relatedId?: string, targetRole?: UserRole, targetEmail?: string) => void;
  requestFilter?: string | null;
  setRequestFilter?: (filter: string | null) => void;
  selectedReqId: string | null;
  setSelectedReqId: (id: string | null) => void;
  suppliersList: Supplier[];
  setSuppliersList: React.Dispatch<React.SetStateAction<Supplier[]>>;
  addLog?: (action: string, details: string) => void;
}

export const RequestsListView = ({ 
  userRole, t, lang, isRTL, requestsList, setRequestsList, transactionsList, setTransactionsList, 
  currentUser, settings, addNotification, requestFilter, setRequestFilter,
  selectedReqId, setSelectedReqId, suppliersList, setSuppliersList, addLog
}: RequestsListViewProps) => {
  const [filterCompany, setFilterCompany] = useState(t.allCompanies);
  const [filterStatus, setFilterStatus] = useState(requestFilter || t.allStatuses);
  const [filterService, setFilterService] = useState(t.allServices);
  const [chatMsg, setChatMsg] = useState('');
  const [chatFileToUpload, setChatFileToUpload] = useState<{name: string, data: string, type: string} | null>(null);
  const [previewFile, setPreviewFile] = useState<PreviewFileItem | null>(null);

  const handlePrint = () => { window.print(); };

  const [confirmingOfferId, setConfirmingOfferId] = useState<string | null>(null);
  const [confirmAction, setConfirmAction] = useState<'approve' | 'reject' | null>(null);

  useEffect(() => {
    if (requestFilter) {
      setFilterStatus(requestFilter);
      if (setRequestFilter) setRequestFilter(null);
    }
  }, [requestFilter]);
  
  const [isEditingReq, setIsEditingReq] = useState(false);
  const [editReqData, setEditReqData] = useState<any>({});
  const [offerSupplier, setOfferSupplier] = useState('');
  const [offerRealSupplier, setOfferRealSupplier] = useState('');
  const [offerRoute, setOfferRoute] = useState('');
  const [offerCurrency, setOfferCurrency] = useState<'USD' | 'IQD'>('USD');
  const [offerCost, setOfferCost] = useState('');
  const [offerSelling, setOfferSelling] = useState('');
  const [offerDetails, setOfferDetails] = useState('');
  const [offerFlightNumber, setOfferFlightNumber] = useState('');
  const [offerAirline, setOfferAirline] = useState('');
  const [offerCabinClass, setOfferCabinClass] = useState('Economy');
  const [offerBaggage, setOfferBaggage] = useState('');
  const [offerTransit, setOfferTransit] = useState('');
  const [offerRefundable, setOfferRefundable] = useState(false);
  const [offerHotelName, setOfferHotelName] = useState('');
  const [offerStarRating, setOfferStarRating] = useState('');
  const [offerRoomType, setOfferRoomType] = useState('');
  const [offerBoardBasis, setOfferBoardBasis] = useState('');
  const [offerDepartureDate, setOfferDepartureDate] = useState('');
  const [offerReturnDate, setOfferReturnDate] = useState('');
  const [offerSupplierCosts, setOfferSupplierCosts] = useState<{id: string, name: string, cost: number}[]>([]);
  const [tempSupplierName, setTempSupplierName] = useState('');
  const [tempSupplierCost, setTempSupplierCost] = useState('');
  const [showInvoice, setShowInvoice] = useState(false);
  const [copyFeedback, setCopyFeedback] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    if (!text) return;
    
    const performFeedback = () => {
      setCopyFeedback(id);
      setTimeout(() => setCopyFeedback(null), 2000);
    };

    // Try Clipboard API first
    if (navigator.clipboard && window.isSecureContext) {
      navigator.clipboard.writeText(text)
        .then(performFeedback)
        .catch(() => fallbackCopy(text, id, performFeedback));
    } else {
      fallbackCopy(text, id, performFeedback);
    }
  };

  const fallbackCopy = (text: string, id: string, callback: () => void) => {
    try {
      const textArea = document.createElement("textarea");
      textArea.value = text;
      textArea.style.position = "fixed";
      textArea.style.left = "-9999px";
      textArea.style.top = "0";
      document.body.appendChild(textArea);
      textArea.focus();
      textArea.select();
      const successful = document.execCommand('copy');
      document.body.removeChild(textArea);
      if (successful) callback();
    } catch (err) {
      console.error('Copy fallback failed', err);
    }
  };

  const selectedReq = requestsList.find(r => r.id === selectedReqId);

  useEffect(() => {
    if (selectedReq) {
       setOfferSupplier(''); setOfferCost(''); setOfferSelling(''); setOfferDetails('');
       setOfferFlightNumber(''); setOfferAirline(''); setOfferCabinClass('Economy');
       setOfferBaggage(''); setOfferTransit(''); setOfferRefundable(false);
       setOfferHotelName(''); setOfferStarRating(''); setOfferRoomType(''); setOfferBoardBasis('');
       setOfferDepartureDate(''); setOfferReturnDate('');
       setOfferSupplierCosts([]); setTempSupplierName(''); setTempSupplierCost('');
       setIsEditingReq(false);
    }
  }, [selectedReqId]);

  const updateReqStatus = (id: string, newStatus: any) => {
    const targetReq = requestsList.find(r => r.id === id);
    setRequestsList(prev => prev.map(req => req.id === id ? { ...req, status: newStatus } : req));
    
    if (targetReq) {
      addNotification(
        `${lang === 'ar' ? 'تحديث حالة الطلب' : 'Request Status Updated'} - #${id?.slice(-5)}`,
        'status',
        `${lang === 'ar' ? 'تم تغيير حالة الطلب إلى: ' : 'Status changed to: '}${t[newStatus]}`,
        id || undefined,
        'client',
        targetReq.createdBy
      );
      if (addLog) addLog('Status Update', `Request ${id} status changed to ${newStatus} by ${currentUser?.email}.`);
    }

    // Surgical Addition: Trigger immediate background sync for faster status propagation
    window.dispatchEvent(new CustomEvent('force-immediate-save'));

    if (newStatus === 'approved') {
      const req = requestsList.find(r => r.id === id);
      const alreadyBilled = transactionsList.some(tr => tr.desc.includes(req?.id || ''));
      if (req && req.selling > 0 && !alreadyBilled) {
         const newTrx: Transaction = {
            id: `TRX-${generateId()}`, 
            date: new Date().toISOString().split('T')[0],
            company: req.company,
            service: `${t[req.service]} - ${req.id}`, 
            desc: `System Auto-Charge (Booking Confirmed - ${req.id})`,
            amount: req.selling, 
            currency: 'USD',
            type: 'charge', 
            status: 'Completed'
         };
         setTransactionsList(prev => [newTrx, ...prev]);
      }
    }
  };

  const handleAssignStaff = (id: string, staffName: string) => {
    setRequestsList(prev => prev.map(req => req.id === id ? { ...req, assignedTo: staffName } : req));
    window.dispatchEvent(new CustomEvent('force-immediate-save'));
  };

  const downloadChatBackup = (request: ServiceRequest) => {
    if (!request.chat || request.chat.length === 0) return;
    const content = `CHAT LOG - REQUEST #${request.id}\nCompany: ${request.company}\nService: ${request.service}\nDate: ${new Date().toLocaleString()}\n-----------------------------------\n\n` + 
      request.chat.map(msg => `[${msg.sender.toUpperCase()}] : ${msg.text}`).join('\n');
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Chat_Backup_${request.company}_${request.id.slice(-5)}_${new Date().toISOString().split('T')[0]}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const handleSendChat = () => {
    if ((!chatMsg.trim() && !chatFileToUpload) || !selectedReqId || selectedReq?.chatClosed) return;

    // Support command-based closure as well
    if (chatMsg.trim().toUpperCase() === 'END CHAT' && (userRole === 'admin' || userRole === 'staff')) {
      handleEndChat();
      setChatMsg('');
      setChatFileToUpload(null);
      return;
    }

    const targetRole: UserRole = userRole === 'client' ? 'staff' : 'client';
    const targetEmail = userRole === 'client' ? undefined : selectedReq?.createdBy;
    
    const newMsg = { 
      id: `MSG-${generateId()}`,
      sender: userRole || 'system', 
      text: chatMsg, 
      read: false,
      file: chatFileToUpload || undefined
    };

    setRequestsList(prev => prev.map(req => req.id === selectedReqId ? { ...req, chat: [...req.chat, newMsg] } : req));
    
    addNotification(
      `${lang === 'ar' ? 'رسالة جديدة' : 'New Message'} - #${selectedReqId?.slice(-5)}`,
      'message',
      chatFileToUpload ? (lang === 'ar' ? 'أرسل ملفاً: ' : 'Sent a file: ') + chatFileToUpload.name : (chatMsg.length > 40 ? chatMsg.slice(0, 40) + '...' : chatMsg),
      selectedReqId || undefined,
      targetRole,
      targetEmail
    );
    
    if (addLog) addLog('Chat Message', `New message on Request ${selectedReqId} from ${userRole}.`);
    
    // Surgical Addition: Trigger immediate background sync for chat messages
    window.dispatchEvent(new CustomEvent('force-immediate-save'));

    setChatMsg('');
    setChatFileToUpload(null);
  };

  React.useEffect(() => {
    if (selectedReqId && selectedReq && selectedReq.chat) {
      const hasUnread = selectedReq.chat.some(msg => msg.sender !== userRole && !msg.read);
      if (hasUnread) {
        setRequestsList(prev => prev.map(req => {
          if (req.id === selectedReqId) {
            const updatedChat = req.chat.map(msg => 
              msg.sender !== userRole ? { ...msg, read: true } : msg
            );
            return { ...req, chat: updatedChat };
          }
          return req;
        }));
      }
    }
  }, [selectedReqId, userRole, selectedReq?.chat?.length]);

  const handleEndChat = () => {
    if (!selectedReqId || !window.confirm(lang === 'ar' ? 'هل أنت متأكد من إنهاء المحادثة؟' : 'Are you sure you want to end the chat?')) return;
    
    setRequestsList(prev => prev.map(req => 
      req.id === selectedReqId ? { 
        ...req, 
        chatClosed: true,
        chat: [...req.chat, { id: `MSG-${generateId()}`, sender: 'system', text: lang === 'ar' ? 'تم إنهاء المحادثة' : 'Chat has been ended', read: true }]
      } : req
    ));

    if (settings.chatBackupEnabled && selectedReq) {
      downloadChatBackup({ ...selectedReq, chatClosed: true });
    }

    addNotification(
      `${lang === 'ar' ? 'تم إنهاء المحادثة' : 'Chat Ended'} - #${selectedReqId.slice(-5)}`,
      'info',
      lang === 'ar' ? 'المحادثة مغلقة الآن' : 'This chat session is now closed',
      selectedReqId
    );

    window.dispatchEvent(new CustomEvent('force-immediate-save'));
  };

  const startEditingRequest = () => { if(selectedReq) { setEditReqData({ ...selectedReq }); setIsEditingReq(true); } };
  const saveEditingRequest = () => { 
    setRequestsList(prev => prev.map(r => r.id === selectedReq?.id ? { ...r, ...editReqData } : r)); 
    setIsEditingReq(false); 
    window.dispatchEvent(new CustomEvent('force-immediate-save'));
  };

  const addSupplierToOffer = () => {
    if (!tempSupplierName || !tempSupplierCost) return;
    setOfferSupplierCosts([...offerSupplierCosts, { id: generateId() as string, name: tempSupplierName, cost: parseFloat(tempSupplierCost) }]);
    setTempSupplierName('');
    setTempSupplierCost('');
  };

  const removeSupplierFromOffer = (id: string) => {
    setOfferSupplierCosts(offerSupplierCosts.filter(s => s.id !== id));
  };

  const handleAddOffer = (e?: React.FormEvent) => {
     e?.preventDefault();
     if (!offerSelling) {
         alert(t.fillRequiredOffers);
         return;
     }

     const totalCost = offerSupplierCosts.length > 0 
        ? offerSupplierCosts.reduce((sum, s) => sum + s.cost, 0)
        : (parseFloat(offerCost) || 0);

     const mainSupplierName = offerSupplierCosts.length > 0 
        ? offerSupplierCosts[0].name 
        : (offerSupplier || 'Multiple Providers');

     const newOffer: Offer = { 
       id: generateId() as any, 
       supplier: mainSupplierName, 
       realSupplier: offerRealSupplier, 
       supplierCosts: offerSupplierCosts.length > 0 ? offerSupplierCosts : undefined,
       route: offerRoute,
       currency: offerCurrency,
       cost: totalCost, 
       selling: parseFloat(offerSelling) || 0, 
       details: offerDetails,
       createdBy: currentUser?.email,
       status: 'pending',
       flightNumber: offerFlightNumber,
       airline: offerAirline,
       cabinClass: offerCabinClass,
       baggageAllowance: offerBaggage,
       transitInfo: offerTransit,
       isRefundable: offerRefundable,
       departureDate: offerDepartureDate,
       returnDate: offerReturnDate,
       hotelName: offerHotelName,
       starRating: offerStarRating,
       roomType: offerRoomType,
       boardBasis: offerBoardBasis
     } as any;

     // Auto-assign the staff member who creates the offer
     setRequestsList(prev => prev.map(req => req.id === selectedReqId ? { 
       ...req, 
       offers: [...(req.offers || []), newOffer],
       assignedTo: currentUser?.name || currentUser?.email || req.assignedTo
     } : req));

     setOfferSupplier(''); setOfferRealSupplier(''); setOfferRoute(''); setOfferCost(''); setOfferSelling(''); setOfferDetails('');
     setOfferFlightNumber(''); setOfferAirline(''); setOfferCabinClass('Economy');
     setOfferBaggage(''); setOfferTransit(''); setOfferRefundable(false);
     setOfferHotelName(''); setOfferStarRating(''); setOfferRoomType(''); setOfferBoardBasis('');
     setOfferDepartureDate(''); setOfferReturnDate('');
     setOfferSupplierCosts([]);

     // Smart Notification for Staff
     addNotification(
       `${lang === 'ar' ? 'عرض جديد مضاف' : 'New Offer Added'}`,
       'info',
       `${lang === 'ar' ? 'تمت إضافة خيار سعر بقيمة ' : 'New offer option added: '}${offerSelling} ${offerCurrency}`,
       selectedReqId || undefined,
       'staff'
     );

     window.dispatchEvent(new CustomEvent('force-immediate-save'));
  };

  const handleSendOffersToClient = () => {
     setRequestsList(prev => prev.map(req => req.id === selectedReqId ? { ...req, status: 'quoted' } : req));
     
     // Smart Notification for Client
     addNotification(
       `${t.notifNewOffer}`, 
       'offer_received', 
       `${lang === 'ar' ? 'عروض جديدة لطلبك رقم ' : 'New offers ready for your request #'}${selectedReqId?.slice(-5)}`, 
       selectedReqId || undefined, 
       'client',
       selectedReq?.createdBy
     );

     // Smart Notification for Staff
     addNotification(
       `${t.notifOfferSentStaff}`, 
       'status_update', 
       `${lang === 'ar' ? 'تم إرسال العروض للطلب رقم ' : 'Offers sent for request #'}${selectedReqId?.slice(-5)}`, 
       selectedReqId || undefined, 
       'staff'
     );

     window.dispatchEvent(new CustomEvent('force-immediate-save'));
     
     alert(t.offersSentMsg);
  };

  const handleApproveOfferByClient = (offer: Offer) => {
     if(!selectedReqId) return;
     setRequestsList(prev => prev.map(req => req.id === selectedReqId ? { 
       ...req, 
       status: 'approved', 
       selectedOfferId: offer.id, 
       cost: offer.cost, 
       selling: offer.selling, 
       supplier: offer.supplier,
       realSupplier: (offer as any).realSupplier,
       route: (offer as any).route,
       offers: (req.offers || []).map(o => o.id === offer.id ? { ...o, status: 'approved' } : { ...o, status: 'pending' })
     } : req));
     addNotification(`${t.notifOfferApproved}`, 'offer_approved', `${lang === 'ar' ? 'تمت الموافقة' : 'Approved'}`, selectedReqId || undefined, 'admin');
     const alreadyBilled = transactionsList.some(tr => tr.desc.includes(selectedReqId));
     
     // 1. Transaction for Client (Selling Price)
     if (offer.selling > 0 && !alreadyBilled) {
         setTransactionsList(prev => [{ 
           id: `TRX-${generateId()}`, 
           date: new Date().toISOString().split('T')[0], 
           company: selectedReq?.company || 'Company', 
           service: `${t[selectedReq?.service || 'other']} - ${selectedReqId}`, 
           desc: `System Auto-Charge (Booking Approved - ${offer.supplier})`, 
           amount: offer.selling, 
           currency: (offer as any).currency || 'USD',
           type: 'charge', 
           status: 'Completed' 
         }, ...prev]);
     }

     // 2. Transaction for Supplier (Cost Price) - AUTO POSTING
     const items = (offer as any).supplierCosts || ((offer as any).realSupplier ? [{ name: (offer as any).realSupplier, cost: offer.cost }] : []);
     
     items.forEach((sc: any) => {
       if (sc.name && sc.cost > 0) {
          const supplierTrx: Transaction = {
            id: `TRX-${generateId()}`,
            date: new Date().toISOString().split('T')[0],
            company: sc.name,
            service: `Cost for ${selectedReqId}`,
            desc: `Booking Auto-Post: ${selectedReq?.company} - ${offer.supplier}`,
            amount: sc.cost,
            currency: (offer as any).currency || 'USD',
            type: 'charge',
            status: 'Completed',
            supplierId: sc.name
          };
          setTransactionsList(prev => [supplierTrx, ...prev]);
          const curr = (offer as any).currency || 'USD';
          setSuppliersList(prev => prev.map(s => s.name === sc.name ? { 
            ...s, 
            balanceUSD: curr === 'USD' ? (s.balanceUSD || 0) + sc.cost : (s.balanceUSD || 0),
            balanceIQD: curr === 'IQD' ? (s.balanceIQD || 0) + sc.cost : (s.balanceIQD || 0)
          } : s));
       }
     });

     window.dispatchEvent(new CustomEvent('force-immediate-save'));
  };

  const handleRejectOfferByClient = (offer: Offer) => {
    if(!selectedReqId) return;
    setRequestsList(prev => prev.map(req => req.id === selectedReqId ? { 
      ...req, 
      offers: (req.offers || []).map(o => o.id === offer.id ? { ...o, status: 'rejected' } : o)
    } : req));
    addNotification(
      `${t.notifOfferRejected}`,
      'offer_rejected',
      `${lang === 'ar' ? 'تم رفض العرض للطلب رقم ' : 'Offer rejected for request #'} ${selectedReqId?.slice(-5)} (${selectedReq?.company})`,
      selectedReqId || undefined,
      'admin'
    );
    window.dispatchEvent(new CustomEvent('force-immediate-save'));
  };

  const handleDeleteOffer = (offerId: string) => {
    if (!window.confirm(t.confirmDeleteOffer || 'Are you sure you want to delete this offer?')) return;
    setRequestsList(prev => prev.map(req => req.id === selectedReqId ? { ...req, offers: (req.offers || []).filter(o => o.id !== offerId) } : req));
    window.dispatchEvent(new CustomEvent('force-immediate-save'));
  };

  const handleDeleteRequest = (e: React.MouseEvent, reqId: string) => {
    e.stopPropagation();
    const reqToDelete = requestsList.find(r => r.id === reqId);
    const msg = lang === 'ar' 
      ? `هل أنت تأكد من حذف الطلب رقم ${reqId} بشكل نهائي؟` 
      : `Are you sure you want to permanently delete request #${reqId}?`;
    if (window.confirm(msg)) {
      window.dispatchEvent(new CustomEvent('item-deleted', { detail: { id: reqId } }));
      setRequestsList(prev => prev.filter(r => r.id !== reqId));
      if (selectedReqId === reqId) setSelectedReqId(null);
      if (reqToDelete && addLog) {
        addLog(
          lang === 'ar' ? 'حذف طلب' : 'Delete Request',
          `${lang === 'ar' ? 'تم حذف الطلب رقم' : 'Deleted request #'} ${reqId} (${reqToDelete.company})`
        );
      }
      if (addNotification) {
        addNotification(
          lang === 'ar' ? 'تم حذف طلب' : 'Request Deleted',
          `${lang === 'ar' ? 'تم حذف الطلب رقم' : 'Request #'} ${reqId} ${lang === 'ar' ? 'بواسطة مدير النظام' : 'by Admin'}`,
          'request_deleted',
          reqId,
          'admin'
        );
      }
      window.dispatchEvent(new CustomEvent('force-immediate-save'));
    }
  };

  const handleEditOffer = (offer: Offer) => {
     setOfferSupplier(offer.supplier);
     setOfferCost(offer.cost.toString());
     setOfferSelling(offer.selling.toString());
     setOfferDetails(offer.details);
     setRequestsList(prev => prev.map(req => req.id === selectedReqId ? { ...req, offers: (req.offers || []).filter(o => o.id !== offer.id) } : req));
     window.dispatchEvent(new CustomEvent('force-immediate-save'));
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && selectedReqId) {
      const files = Array.from(e.target.files);
      (files as File[]).forEach(file => {
        const reader = new FileReader();
        const fileName = file.name;
        reader.onloadend = () => {
          setRequestsList(prev => prev.map(req => 
            req.id === selectedReqId ? { ...req, attachments: [...(req.attachments || []), { name: fileName, data: reader.result as string, type: file.type } as any] } : req
          ));
          window.dispatchEvent(new CustomEvent('force-immediate-save'));
        };
        reader.readAsDataURL(file);
      });
    }
  };

  const downloadAttachment = (file: any) => {
    const link = document.createElement('a');
    if (typeof file === 'string') {
      alert(lang === 'ar' ? 'هذا الملف بنسق قديم ولا يمكن تحميله.' : 'This file is in an old format and cannot be downloaded.');
      return;
    }
    link.href = file.data;
    link.download = file.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleRejectAllOffers = () => {
    if (!window.confirm(t.confirmRejectOffers || 'Are you sure you want to reject these offers?')) return;
    setRequestsList(prev => prev.map(req => req.id === selectedReqId ? { ...req, status: 'rejected' } : req));
    window.dispatchEvent(new CustomEvent('force-immediate-save'));
  };

  const DetailItem = ({ label, value }: { label: any; value?: any; [key: string]: any }) => {
    if (!value) return null;
    return (
      <div className="bg-[var(--card-bg)]/30 border border-[var(--border-main)] p-5 rounded-2xl transition-all hover:bg-[var(--card-bg)]/60 group/item">
        <p className="text-[9px] font-black text-[var(--muted-text)] uppercase tracking-[0.1em] group-hover/item:text-[var(--text-main)] transition-colors">{label}</p>
        <p className="font-bold text-[var(--text-main)] text-base mt-1.5 tracking-tight">{value}</p>
      </div>
    );
  };

  const filteredRequests = requestsList.filter(req => {
    if (userRole === 'client') return req.company === currentUser?.company;
    
    // Status matching logic
    let statusMatch = filterStatus === t.allStatuses || req.status === filterStatus;
    
    // Handle 'active' special filter
    if (filterStatus === 'active') {
       statusMatch = req.status === 'pending' || req.status === 'inProgress' || req.status === 'quoted' || req.status === 'approved';
    }
    
    return (filterCompany === t.allCompanies || req.company === filterCompany) && 
           statusMatch && 
           (filterService === t.allServices || req.service === filterService);
  });

  if (selectedReq) {
    const SIcon = serviceIcons[selectedReq.service] || MoreVertical;
    const isViewer = userRole === 'viewer';
    const hasApprovedOffer = (selectedReq.offers || []).some(o => o.status === 'approved');
    const hasRejectedOffer = (selectedReq.offers || []).some(o => o.status === 'rejected');

    return (
      <div className="space-y-6 animate-in slide-in-from-right-4 duration-300 RequestsListView-Detailed print-target">
        {/* Print Only Header */}
        <div className="hidden print:flex justify-between items-end mb-12 pb-10 border-b-2 border-slate-200">
           <div className="flex items-center">
             {settings.logoUrl && settings.logoUrl.trim() !== '' ? (
               <img src={settings.logoUrl} alt="Logo" style={{ height: `100px`, maxWidth: '100%' }} className="object-contain" />
             ) : (
               <AirlinkLogo className="h-24" />
             )}
           </div>
           <div className="text-right">
              <h1 className="text-4xl font-black uppercase tracking-tighter text-slate-900 leading-none">{t.requestDetails || 'Request Details'}</h1>
           </div>
        </div>

        <div className="flex justify-between items-center no-print">
          <div className="flex items-center gap-4">
            <button onClick={() => setSelectedReqId(null)} className="flex items-center text-[var(--muted-text)] hover:text-[var(--text-main)] font-bold gap-2 glass-pane px-6 py-2.5 rounded-xl border border-[var(--border-main)] w-fit transition-all hover:bg-[var(--card-bg)]">
               {isRTL ? <ChevronRight size={18}/> : <ChevronLeft size={18}/>} Back to list
            </button>
            <button 
              onClick={handlePrint}
              className="flex items-center gap-2 bg-[var(--card-bg)] text-[var(--text-main)] border border-[var(--border-main)] px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-[var(--bg-main)] transition-all shadow-sm"
            >
              <FileText size={16} /> {lang === 'ar' ? 'طباعة الطلب' : 'Print Request'}
            </button>
            {userRole === 'admin' && (
              <button 
                onClick={(e) => handleDeleteRequest(e, selectedReq.id)}
                className="flex items-center gap-2 bg-rose-500/10 text-rose-500 border border-rose-500/20 hover:bg-rose-500/20 px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all shadow-sm"
              >
                <Trash2 size={16} /> {lang === 'ar' ? 'حذف الطلب' : 'Delete Request'}
              </button>
            )}
          </div>
          <button 
            onClick={() => setShowInvoice(true)}
            className="flex items-center gap-2 bg-[var(--primary)] text-white px-6 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest hover:brightness-110 shadow-lg transition-all"
          >
            <FileSignature size={16} /> {t.invoice || 'Invoice'}
          </button>
        </div>
        
        {showInvoice && (
          <InvoiceVoucher 
            request={selectedReq} 
            settings={settings} 
            t={t} 
            onClose={() => setShowInvoice(false)} 
          />
        )}
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-8">
            <Card className="p-8 bg-[var(--card-bg)] border-[var(--border-main)]">
              <div className="flex flex-col md:flex-row justify-between md:items-start mb-8 gap-6 border-b border-[var(--border-main)] pb-8">
                <div className="flex items-center gap-6">
                  <div className="w-16 h-16 accent-gradient text-white rounded-[20px] flex items-center justify-center border-2 border-white/20"><SIcon size={32} /></div>
                  <div>
                    <h3 className="text-3xl font-black text-[var(--text-main)] tracking-tight">{selectedReq.id}</h3>
                    <p className="text-[var(--muted-text)] font-bold uppercase text-xs tracking-widest mt-1">
                      {t[selectedReq.service]} • {selectedReq.date}
                      {selectedReq.requestSubType && (
                        <span className="ml-2 px-2 py-0.5 bg-[var(--primary)]/10 text-[var(--primary)] rounded text-[10px] border border-[var(--primary)]/20">
                          {selectedReq.requestSubType === 'reissue' ? t.subTypeReissue : 
                           selectedReq.requestSubType === 'change' ? t.subTypeChange : 
                           selectedReq.requestSubType === 'cancellation' ? t.subTypeCancellation : 
                           t.subTypeNew}
                        </span>
                      )}
                    </p>
                    {(userRole === 'admin' || userRole === 'staff') && (hasApprovedOffer || hasRejectedOffer) && (
                      <div className="mt-4 flex flex-wrap gap-2">
                         {hasApprovedOffer && (
                           <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-emerald-400 text-[10px] font-black uppercase tracking-widest animate-pulse">
                             <ThumbsUp size={12}/> {t.offerApprovedNotify || 'Offer Approved'}
                           </div>
                         )}
                         {hasRejectedOffer && (
                           <div className="flex items-center gap-2 px-3 py-1.5 bg-rose-500/10 border border-rose-500/20 rounded-lg text-rose-400 text-[10px] font-black uppercase tracking-widest">
                             <ThumbsDown size={12}/> {t.offerRejectedNotify || 'Offer Rejected'}
                           </div>
                         )}
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex flex-col items-end gap-3">
                  <StatusBadge status={selectedReq.status} t={t} />
                  {(userRole === 'admin' || userRole === 'staff') && !isEditingReq && !isViewer && (
                    <button onClick={startEditingRequest} className="text-[10px] bg-[var(--card-bg)] hover:bg-[var(--bg-main)] text-[var(--muted-text)] hover:text-[var(--text-main)] px-4 py-2 rounded-xl font-black border border-[var(--border-main)] uppercase tracking-widest transition-all">{t.editRequest}</button>
                  )}
                </div>
              </div>
              
              <div className="space-y-8">
                {isEditingReq ? (
                   <div className="bg-[var(--bg-main)] border border-[var(--border-main)] p-8 rounded-[24px] space-y-6 text-[var(--text-main)]">
                      <h4 className="text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-4">{t.editRequest}</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="md:col-span-2">
                          <label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">{t.serviceType}</label>
                          <select value={editReqData.service} onChange={e => setEditReqData({...editReqData, service: e.target.value})} className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 appearance-none">
                             <option value="flight">{t.flight}</option><option value="hotel">{t.hotel}</option><option value="visa">{t.visa}</option><option value="insurance">{t.insurance}</option><option value="other">{t.other}</option>
                          </select>
                        </div>
                        <div className="md:col-span-2">
                          <label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">{t.notes}</label>
                          <textarea rows={5} value={editReqData.notes} onChange={e => setEditReqData({...editReqData, notes: e.target.value})} className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm text-[var(--text-main)] focus:ring-2 focus:ring-indigo-500/50 resize-none"></textarea>
                        </div>
                      </div>
                      <div className="flex gap-4 pt-4">
                        <button onClick={saveEditingRequest} className="bg-[var(--text-main)] text-[var(--bg-main)] px-8 py-3 rounded-xl text-xs font-black uppercase tracking-widest hover:brightness-110 transition-all">{t.saveChanges}</button>
                        <button onClick={() => setIsEditingReq(false)} className="bg-[var(--card-bg)] border border-[var(--border-main)] text-[var(--muted-text)] px-8 py-3 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-[var(--bg-main)] transition-all">{t.cancel}</button>
                      </div>
                   </div>
                 ) : (
                    <div className="space-y-8">
                    {selectedReq.status === 'quoted' && (
                      <div className="mb-8 animate-in slide-in-from-top-4 duration-700">
                        {hasApprovedOffer ? (
                          <div className="bg-emerald-500/10 border-2 border-emerald-500/20 rounded-[32px] p-6 flex flex-col md:flex-row items-center justify-between gap-6">
                             <div className="flex items-center gap-5">
                               <div className="w-16 h-16 bg-emerald-500 rounded-3xl flex items-center justify-center text-white shadow-[0_10px_20px_rgba(16,185,129,0.4)] animate-pulse">
                                 <CheckCheck size={32} strokeWidth={3} />
                               </div>
                               <div>
                                 <p className="text-emerald-500 font-black text-xs uppercase tracking-[0.3em] mb-1">{lang === 'ar' ? 'تم اعتماد العرض بنجاح' : 'OFFER OFFICIALLY APPROVED'}</p>
                                 <p className="text-[var(--text-main)] text-lg font-black tracking-tight">{lang === 'ar' ? 'يمكنك الآن متابعة حالة الطلب في القائمة الرئيسية.' : 'The selected offer has been synchronized to our logistics team.'}</p>
                               </div>
                             </div>
                          </div>
                        ) : hasRejectedOffer ? (
                          <div className="bg-rose-500/10 border-2 border-rose-500/20 rounded-[32px] p-6 flex flex-col md:flex-row items-center justify-between gap-6">
                             <div className="flex items-center gap-5">
                               <div className="w-16 h-16 bg-rose-500 rounded-3xl flex items-center justify-center text-white shadow-[0_10px_20px_rgba(244,63,94,0.4)]">
                                 <XCircle size={32} strokeWidth={3} />
                               </div>
                               <div>
                                 <p className="text-rose-500 font-black text-xs uppercase tracking-[0.3em] mb-1">{lang === 'ar' ? 'تم رفض العروض' : 'OFFERS REJECTED'}</p>
                                 <p className="text-[var(--text-main)] text-lg font-black tracking-tight">{lang === 'ar' ? 'بانتظار تحديث العروض من قبل الإدارة' : 'Awaiting new quotations from the operations team.'}</p>
                               </div>
                             </div>
                          </div>
                        ) : (
                          <div className="bg-amber-500/10 border-2 border-amber-500/20 rounded-[32px] p-6 flex flex-col md:flex-row items-center justify-between gap-6 shadow-xl ring-4 ring-amber-500/5">
                             <div className="flex items-center gap-5">
                               <div className="w-16 h-16 bg-amber-500 rounded-3xl flex items-center justify-center text-white shadow-[0_10px_20px_rgba(245,158,11,0.4)] animate-bounce">
                                 <Star size={32} fill="currentColor" />
                               </div>
                               <div>
                                 <p className="text-amber-500 font-black text-xs uppercase tracking-[0.3em] mb-1">{lang === 'ar' ? 'عرض سعر جديد متاح!' : 'NEW QUOTATION AVAILABLE'}</p>
                                 <p className="text-[var(--text-main)] text-lg font-black tracking-tight">{lang === 'ar' ? 'يرجى مراجعة العروض أدناه واختيار الأنسب لك.' : 'Review the pricing options below and select your preferred route.'}</p>
                               </div>
                             </div>
                             {userRole === 'client' && (
                               <div className="px-10 py-4 bg-amber-500 text-white rounded-[20px] text-[11px] font-black uppercase tracking-widest animate-pulse shadow-xl shadow-amber-500/30">
                                 {lang === 'ar' ? 'اتخاذ قرار' : 'ACTION REQUIRED'}
                               </div>
                             )}
                          </div>
                        )}
                      </div>
                    )}

                    {selectedReq.details && (userRole === 'admin' || userRole === 'staff' || userRole === 'client' || userRole === 'viewer') && (
                      <div className="mb-10">
                        <h4 className="text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-4">{t.requestDetails}</h4>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                          {selectedReq.service === 'flight' && (
                            <>
                              <DetailItem label={t.from} value={selectedReq.details.from} />
                              <DetailItem label={t.to} value={selectedReq.details.to} />
                              <DetailItem label={t.departureDate} value={selectedReq.details.departureDate} />
                              <DetailItem label={t.returnDate} value={selectedReq.details.returnDate} />
                            </>
                          )}
                          {selectedReq.service === 'hotel' && (
                            <>
                              <DetailItem label={t.city} value={selectedReq.details.city} />
                              <DetailItem label={t.rooms} value={selectedReq.details.rooms} />
                              <DetailItem label={t.checkIn} value={selectedReq.details.checkIn} />
                              <DetailItem label={t.checkOut} value={selectedReq.details.checkOut} />
                            </>
                          )}
                          {selectedReq.service === 'visa' && (
                            <>
                              <DetailItem label={t.to} value={selectedReq.details.to} />
                              <DetailItem label={t.nationality} value={selectedReq.details.nationality} />
                              <DetailItem label={t.visaType} value={selectedReq.details.visaType} />
                            </>
                          )}
                          {selectedReq.service === 'insurance' && (
                            <>
                              <DetailItem label={t.dob} value={selectedReq.details.dob} />
                              <DetailItem label={t.coverage} value={selectedReq.details.coverage} />
                            </>
                          )}
                        </div>
                      </div>
                    )}
                    <h4 className="text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-4">{t.notes}</h4>
                    <div className="bg-[var(--bg-main)] border border-[var(--border-main)] p-6 rounded-[24px] text-[var(--muted-text)] leading-relaxed font-medium text-sm whitespace-pre-wrap">{selectedReq.notes}</div>

                    {selectedReq.attachments && selectedReq.attachments.length > 0 && (
                      <div className="mt-8">
                        <h4 className="text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-4">{t.attachments}</h4>
                        <div className="flex flex-wrap gap-3">
                             {selectedReq.attachments.map((file: any, idx) => {
                               const isStandard = typeof file === 'object' && file !== null && 'data' in file;
                               const fileName = isStandard ? file.name : (typeof file === 'string' ? file : `File ${idx+1}`);
                               const fileData = isStandard ? file.data : (typeof file === 'string' ? file : undefined);
                               const fileType = isStandard ? file.type : undefined;

                               return (
                                 <div 
                                   key={idx} 
                                   className={`flex items-center gap-3 px-4 py-2.5 rounded-xl text-xs font-bold transition-all shadow-sm border ${isStandard ? 'bg-[var(--card-bg)] border-[var(--border-main)] text-[var(--text-main)] hover:border-[var(--primary)]' : 'bg-rose-500/5 border-rose-500/10 text-rose-500/60'}`}
                                 >
                                   <div 
                                     onClick={() => setPreviewFile({ name: fileName, data: fileData, type: fileType })}
                                     className="flex items-center gap-2 cursor-pointer hover:text-indigo-400 transition-colors"
                                     title={lang === 'ar' ? 'انقر للمعاينة المباشرة' : 'Click to preview'}
                                   >
                                     <Paperclip size={14} className={isStandard ? 'text-indigo-400' : 'text-rose-400'}/>
                                     <span className="truncate max-w-[180px] font-black uppercase tracking-widest">{fileName}</span>
                                   </div>

                                   <div className="flex items-center gap-1 border-r border-[var(--border-main)] pr-2 pr-2">
                                     <button
                                       type="button"
                                       onClick={() => setPreviewFile({ name: fileName, data: fileData, type: fileType })}
                                       className="p-1.5 hover:bg-indigo-500/10 hover:text-indigo-400 rounded-lg text-[var(--muted-text)] transition-colors flex items-center gap-1 text-[10px] font-black"
                                       title={lang === 'ar' ? 'معاينة الملف' : 'Preview File'}
                                     >
                                       <Eye size={13} />
                                       <span className="hidden sm:inline">{lang === 'ar' ? 'معاينة' : 'Preview'}</span>
                                     </button>

                                     <button
                                       type="button"
                                       onClick={() => downloadAttachment(file)}
                                       className="p-1.5 hover:bg-emerald-500/10 hover:text-emerald-400 rounded-lg text-[var(--muted-text)] transition-colors flex items-center gap-1 text-[10px] font-black"
                                       title={lang === 'ar' ? 'تحميل الملف' : 'Download File'}
                                     >
                                       <UploadCloud size={13} className="rotate-180" />
                                       <span className="hidden sm:inline">{lang === 'ar' ? 'تحميل' : 'Download'}</span>
                                     </button>
                                   </div>
                                 </div>
                               );
                             })}
                        </div>
                      </div>
                    )}

                    {selectedReq.offers && selectedReq.offers.length > 0 && (
                      <div id="offers-section" className="mt-16 border-t-2 border-[var(--border-main)] pt-16 scroll-mt-20">
                         <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
                            <div className="flex items-center gap-6">
                               <div className="w-16 h-16 bg-amber-500/10 border border-amber-500/20 rounded-[24px] flex items-center justify-center text-amber-500 shadow-2xl"><Star size={32} fill="currentColor"/></div>
                               <div>
                                  <h4 className="text-3xl font-black text-[var(--text-main)] uppercase tracking-tight">{t.availableOffers || 'Available Offers'}</h4>
                                  <p className="text-[10px] font-black text-[var(--muted-text)] uppercase tracking-widest mt-1.5 opacity-60">{lang === 'ar' ? 'عروض حصرية مقدمة لكم' : 'EXCLUSIVE QUOTATIONS FOR YOUR REVIEW'}</p>
                               </div>
                            </div>
                         </div>
                         <div className="grid grid-cols-1 gap-12">
                           {selectedReq.offers.map(offer => {
                             const isOfferApproved = offer.status === 'approved';
                             const isOfferRejected = offer.status === 'rejected';
                             const isOtherRejected = hasApprovedOffer && !isOfferApproved;
                             const isNew = !offer.status && selectedReq.status === 'quoted';

                              return (
                                <div key={offer.id} className={`group/offer relative flex flex-col p-10 rounded-[48px] border-2 transition-all duration-700 overflow-hidden ${isOfferApproved ? 'border-emerald-500 bg-emerald-500/[0.05] shadow-2xl ring-4 ring-emerald-500/10 scale-[1.02]' : (isOfferRejected || isOtherRejected) ? (userRole === 'client' ? 'border-rose-500/10 bg-rose-500/[0.02] opacity-40 grayscale-[0.8]' : 'border-[var(--border-main)] bg-[var(--card-bg)]/30 opacity-70 saturate-[0.5]') : 'border-[var(--border-main)] bg-[var(--card-bg)]/60 hover:border-amber-500/40 hover:bg-[var(--card-bg)] hover:shadow-2xl hover:-translate-y-2'}`}>
                                  {/* Background Decorative Element */}
                                  <div className="absolute -right-20 -top-20 w-64 h-64 bg-gradient-to-br from-white/5 to-transparent rounded-full blur-3xl group-hover/offer:scale-150 transition-transform duration-1000"></div>

                                  {isOfferApproved ? (
                                    <div className="relative z-10 flex flex-col h-full animate-in zoom-in-95 duration-500">
                                      <div className="absolute top-0 right-0 bg-emerald-500 text-white w-24 h-24 rounded-bl-[50px] flex items-center justify-center shadow-xl overflow-hidden">
                                        <div className="absolute inset-0 bg-white/20 animate-pulse"></div>
                                        <CheckCheck size={48} strokeWidth={4} className="relative z-10" />
                                      </div>
                                      <div className="mb-10">
                                        <div className="flex items-center gap-3 mb-4">
                                          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></div>
                                          <p className="text-[12px] font-black uppercase tracking-[0.5em] text-emerald-500">Provider</p>
                                          <span className="px-4 py-1.5 bg-emerald-500/20 text-emerald-500 text-[10px] font-black rounded-full border border-emerald-500/30 uppercase tracking-[0.2em]">{lang === 'ar' ? 'العرض المعتمد' : 'SELECTED OFFER'}</span>
                                        </div>
                                        <h5 className="text-5xl font-black text-emerald-600 tracking-tighter drop-shadow-sm">{offer.supplier}</h5>
                                      </div>
                                      
                                      {/* Detailed Breakdown for Approved Offer */}
                                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10 overflow-hidden rounded-[32px] border border-emerald-500/20 bg-white/5 p-6 backdrop-blur-sm">
                                          {offer.flightNumber && (
                                            <div className="p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl">
                                              <p className="text-[9px] font-black text-emerald-500 uppercase tracking-widest mb-1">Flight No</p>
                                              <p className="text-sm font-black text-emerald-900 dark:text-emerald-300">{offer.flightNumber}</p>
                                            </div>
                                          )}
                                          {offer.airline && (
                                            <div className="p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl">
                                              <p className="text-[9px] font-black text-emerald-500 uppercase tracking-widest mb-1">Airline</p>
                                              <p className="text-sm font-black text-emerald-900 dark:text-emerald-300">{offer.airline}</p>
                                            </div>
                                          )}
                                          {offer.cabinClass && (
                                            <div className="p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl">
                                              <p className="text-[9px] font-black text-emerald-500 uppercase tracking-widest mb-1">Cabin</p>
                                              <p className="text-sm font-black text-emerald-900 dark:text-emerald-300">{offer.cabinClass}</p>
                                            </div>
                                          )}
                                          {offer.baggageAllowance && (
                                            <div className="p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl">
                                              <p className="text-[9px] font-black text-emerald-500 uppercase tracking-widest mb-1">Baggage</p>
                                              <p className="text-sm font-black text-emerald-900 dark:text-emerald-300">{offer.baggageAllowance}</p>
                                            </div>
                                          )}
                                          {offer.hotelName && (
                                            <div className="col-span-2 p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl">
                                              <p className="text-[9px] font-black text-emerald-500 uppercase tracking-widest mb-1">Hotel Configuration</p>
                                              <p className="text-sm font-black text-emerald-900 dark:text-emerald-300">{offer.hotelName} ({offer.starRating} Stars)</p>
                                            </div>
                                          )}
                                          {offer.roomType && (
                                            <div className="p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl">
                                              <p className="text-[9px] font-black text-emerald-500 uppercase tracking-widest mb-1">Room</p>
                                              <p className="text-sm font-black text-emerald-900 dark:text-emerald-300">{offer.roomType}</p>
                                            </div>
                                          )}
                                          {offer.boardBasis && (
                                            <div className="p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl">
                                              <p className="text-[9px] font-black text-emerald-500 uppercase tracking-widest mb-1">Board</p>
                                              <p className="text-sm font-black text-emerald-900 dark:text-emerald-300">{offer.boardBasis}</p>
                                            </div>
                                          )}
                                       </div>
                                      <div className="flex-1 mb-10 p-10 rounded-[40px] text-[18px] leading-relaxed bg-emerald-500/5 text-emerald-900 dark:text-emerald-300 font-bold border-2 border-emerald-500/10 shadow-inner relative overflow-hidden group/details">
                                        <div className="absolute -right-4 -bottom-4 opacity-[0.03] rotate-12 group-hover/details:rotate-0 transition-transform duration-1000">
                                          <Building size={160} />
                                        </div>
                                        <button 
                                          onClick={() => handleCopy(offer.route ? `${offer.route}\n\n${offer.details}` : offer.details, offer.id)}
                                          className="absolute top-6 right-6 p-3 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-600 rounded-2xl transition-all border border-emerald-500/20 group/copy z-30"
                                        >
                                          {copyFeedback === offer.id ? (
                                             <div className="flex items-center gap-2 px-2">
                                                <Check size={14} strokeWidth={3} />
                                                <span className="text-[10px] font-black uppercase tracking-widest">Copied</span>
                                             </div>
                                          ) : (
                                             <Copy size={18} className="group-hover/copy:scale-110 transition-transform" />
                                          )}
                                        </button>
                                        <div className="relative z-10 pr-10 whitespace-pre-wrap">
                                          {offer.route && (
                                            <div className="mb-4 pb-4 border-b border-emerald-500/20">
                                              <p className="text-[10px] font-black text-emerald-500 uppercase tracking-[0.2em] mb-1">{lang === 'ar' ? 'المسار' : 'ROUTE'}</p>
                                              <p className="text-xl font-black text-emerald-950 dark:text-emerald-200">{offer.route}</p>
                                            </div>
                                          )}
                                          {offer.details}
                                        </div>
                                      </div>
                              <div className="flex items-end justify-between mt-auto">
                                        <div className="flex flex-col gap-3">
                                          <p className="text-[11px] font-black uppercase tracking-[0.4em] text-emerald-500/40">{lang === 'ar' ? 'القيمة الإجمالية' : 'TOTAL CONTRACT VALUE'}</p>
                                          <div className="flex items-baseline gap-3">
                                            <PriceDisplay amount={offer.selling} currency={offer.currency} defaultCurrency={offer.currency} exchangeRate={settings.exchangeRate} className="text-8xl font-black text-emerald-500 tracking-tighter" />
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  ) : (isOfferRejected || isOtherRejected) ? (
                                    <div className="relative z-10 opacity-30 flex flex-col h-full">
                                      <div className="absolute top-0 right-0 p-8 text-rose-500/20"><XCircle size={64} strokeWidth={1} /></div>
                                      <div className="mb-10">
                                        <p className="text-[10px] font-black uppercase tracking-[0.5em] mb-4 opacity-30">Provider Name</p>
                                        <h5 className="text-3xl font-black opacity-30 tracking-tight">{offer.supplier}</h5>
                                      </div>
                                      <div className="flex-1 mb-10 p-8 rounded-[32px] text-sm font-medium border border-dashed border-rose-500/10 line-through italic text-rose-500/40 bg-rose-500/5 whitespace-pre-wrap">
                                        {offer.route && <div className="mb-2 uppercase border-b border-rose-500/10 pb-2">{offer.route}</div>}
                                        {offer.details}
                                      </div>
                                      <div className="flex items-end justify-between mt-auto">
                                        <div><div className="flex items-baseline gap-2 font-mono line-through text-rose-500/20"><PriceDisplay amount={offer.selling} currency={offer.currency} defaultCurrency={offer.currency} exchangeRate={settings.exchangeRate} className="text-5xl font-black" /></div></div>
                                      </div>
                                    </div>
                                  ) : (
                                    <div className="relative z-10 flex flex-col h-full">
                                      <div className="mb-10">
                                        <div className="flex items-center gap-3 mb-4">
                                          <div className="w-1.5 h-1.5 rounded-full bg-amber-500"></div>
                                          <p className="text-[11px] font-black uppercase tracking-[0.4em] text-[var(--muted-text)]">Provider</p>
                                        </div>
                                        <h5 className="text-4xl font-black text-[var(--text-main)] group-hover/offer:text-amber-500 transition-colors tracking-tight">{offer.supplier}</h5>
                                      </div>
                                      
                                      {/* Detailed Breakdown */}
                                      <div className="grid grid-cols-2 gap-4 mb-6">
                                        {offer.flightNumber && (
                                          <div className="p-3 bg-white/5 rounded-2xl border border-white/5">
                                            <p className="text-[8px] font-black text-amber-500/60 uppercase tracking-widest">Flight No</p>
                                            <p className="text-xs font-bold text-white/90">{offer.flightNumber}</p>
                                          </div>
                                        )}
                                        {offer.airline && (
                                          <div className="p-3 bg-white/5 rounded-2xl border border-white/5">
                                            <p className="text-[8px] font-black text-amber-500/60 uppercase tracking-widest">Airline</p>
                                            <p className="text-xs font-bold text-white/90">{offer.airline}</p>
                                          </div>
                                        )}
                                        {offer.cabinClass && (
                                          <div className="p-3 bg-white/5 rounded-2xl border border-white/5">
                                            <p className="text-[8px] font-black text-amber-500/60 uppercase tracking-widest">Cabin</p>
                                            <p className="text-xs font-bold text-white/90">{offer.cabinClass}</p>
                                          </div>
                                        )}
                                        {offer.baggageAllowance && (
                                          <div className="p-3 bg-white/5 rounded-2xl border border-white/5">
                                            <p className="text-[8px] font-black text-amber-500/60 uppercase tracking-widest">Baggage</p>
                                            <p className="text-xs font-bold text-white/90">{offer.baggageAllowance}</p>
                                          </div>
                                        )}
                                        {offer.hotelName && (
                                          <div className="col-span-2 p-3 bg-white/5 rounded-2xl border border-white/5">
                                            <p className="text-[8px] font-black text-amber-500/60 uppercase tracking-widest">Hotel</p>
                                            <p className="text-xs font-bold text-white/90">{offer.hotelName} ({offer.starRating} Stars)</p>
                                          </div>
                                        )}
                                        {offer.roomType && (
                                          <div className="p-3 bg-white/5 rounded-2xl border border-white/5">
                                            <p className="text-[8px] font-black text-amber-500/60 uppercase tracking-widest">Room</p>
                                            <p className="text-xs font-bold text-white/90">{offer.roomType}</p>
                                          </div>
                                        )}
                                        {offer.boardBasis && (
                                          <div className="p-3 bg-white/5 rounded-2xl border border-white/5">
                                            <p className="text-[8px] font-black text-amber-500/60 uppercase tracking-widest">Board</p>
                                            <p className="text-xs font-bold text-white/90">{offer.boardBasis}</p>
                                          </div>
                                        )}
                                        {offer.transitInfo && (
                                          <div className="col-span-2 p-3 bg-white/5 rounded-2xl border border-white/5">
                                            <p className="text-[8px] font-black text-amber-500/60 uppercase tracking-widest">Transit / Notes</p>
                                            <p className="text-xs font-bold text-white/90">{offer.transitInfo}</p>
                                          </div>
                                        )}
                                      </div>

                                      <div className="flex-1 mb-10 p-10 rounded-[40px] text-[17px] leading-relaxed bg-[var(--card-bg)] text-[var(--text-main)] font-semibold border border-[var(--border-main)] shadow-[0_20px_40px_rgba(0,0,0,0.1)] group-hover/offer:shadow-[0_30px_60px_rgba(0,0,0,0.15)] transition-all relative overflow-hidden group/inner">
                                        <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover/inner:opacity-100 transition-opacity"></div>
                                        <button 
                                          onClick={() => handleCopy(offer.route ? `${offer.route}\n\n${offer.details}` : offer.details, offer.id)}
                                          className="absolute top-6 right-6 p-3 bg-white/5 hover:bg-white/10 text-[var(--muted-text)] hover:text-indigo-500 rounded-2xl transition-all border border-white/10 group/copy z-30"
                                        >
                                          {copyFeedback === offer.id ? (
                                             <div className="flex items-center gap-2 px-2 text-emerald-500">
                                                <Check size={14} strokeWidth={3} />
                                                <span className="text-[10px] font-black uppercase tracking-widest">Copied</span>
                                             </div>
                                          ) : (
                                             <Copy size={18} className="group-hover/copy:scale-110 transition-transform" />
                                          )}
                                        </button>
                                        <div className="relative z-10 pr-10 whitespace-pre-wrap">
                                          {offer.route && (
                                            <div className="mb-4 pb-4 border-b border-white/5">
                                              <p className="text-[10px] font-black text-amber-500 uppercase tracking-[0.2em] mb-1">{lang === 'ar' ? 'المسار' : 'ROUTE'}</p>
                                              <p className="text-xl font-black text-[var(--text-main)] group-hover/offer:text-amber-500 transition-colors uppercase">{offer.route}</p>
                                            </div>
                                          )}
                                          {offer.details}
                                        </div>
                                      </div>
                                      <div className="flex items-end justify-between mt-auto flex-wrap gap-8">
                                        <div className="flex flex-col gap-3">
                                          <p className="text-[11px] font-black uppercase tracking-[0.5em] text-[var(--muted-text)] opacity-60">{lang === 'ar' ? 'عرض السعر' : 'QUOTED PRICE'}</p>
                                          <div className="flex items-baseline gap-3 font-mono group-hover/offer:scale-105 transition-transform origin-left">
                                            <PriceDisplay amount={offer.selling} currency={offer.currency} defaultCurrency={offer.currency} exchangeRate={settings.exchangeRate} className="text-7xl font-black text-[var(--text-main)] group-hover/offer:text-amber-500 transition-colors tracking-tighter" />
                                          </div>
                                          
                                          {(userRole === 'admin' || userRole === 'staff') && (
                                            <div className="flex flex-col gap-3 mt-6 p-5 bg-[var(--bg-main)]/40 rounded-3xl border border-[var(--border-main)]">
                                              <div className="flex items-center justify-between mb-2">
                                                 <p className="text-[9px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">Supplier Breakdown</p>
                                                 <div className="flex items-center gap-1.5 text-[9px] font-black text-emerald-500 bg-emerald-500/10 px-3 py-1 rounded-full uppercase tracking-widest">
                                                    Net Profit: ${offer.selling - offer.cost}
                                                 </div>
                                              </div>
                                              
                                              {offer.supplierCosts && offer.supplierCosts.length > 0 ? (
                                                 <div className="space-y-1.5">
                                                    {offer.supplierCosts.map((sc, idx) => (
                                                       <div key={idx} className="flex justify-between items-center bg-[var(--card-bg)]/60 px-4 py-2 rounded-xl border border-[var(--border-main)]">
                                                          <div className="flex items-center gap-2">
                                                             <Building size={10} className="text-indigo-500" />
                                                             <span className="text-[9px] font-black text-[var(--text-main)] uppercase truncate max-w-[120px]">{sc.name}</span>
                                                          </div>
                                                          <span className="text-[10px] font-mono font-black text-[var(--text-main)]">${sc.cost}</span>
                                                       </div>
                                                    ))}
                                                 </div>
                                              ) : (
                                                 <div className="flex items-center justify-between bg-[var(--card-bg)]/60 px-4 py-2 rounded-xl border border-[var(--border-main)]">
                                                    <div className="flex items-center gap-2">
                                                       <Building size={10} className="text-secondary" />
                                                       <span className="text-[10px] font-black text-[var(--text-main)] uppercase">{offer.realSupplier || 'Standard'}</span>
                                                    </div>
                                                    <span className="text-[10px] font-mono font-black text-[var(--text-main)]">${offer.cost}</span>
                                                 </div>
                                              )}
                                            </div>
                                          )}
                                        </div>

                                         {((selectedReq.status === 'quoted' || selectedReq.status === 'inProgress' || selectedReq.status === 'pending') && !hasApprovedOffer && !isOfferRejected && (userRole === 'client' || userRole === 'admin' || userRole === 'staff')) && (
                                           <div className="flex flex-col sm:flex-row gap-5 mt-4 self-center sm:self-end">
                                             {confirmingOfferId === offer.id ? (
                                               <div className="flex flex-col gap-4 bg-[var(--card-bg)] p-6 rounded-[34px] border-2 border-amber-500/30 animate-in zoom-in-95 duration-300">
                                                 <p className="text-xs font-black text-amber-500 uppercase tracking-widest text-center">
                                                   {confirmAction === 'approve' 
                                                     ? (lang === 'ar' ? 'هل أنت متأكد من قبول العرض؟' : 'CONFIRM APPROVAL?')
                                                     : (lang === 'ar' ? 'هل أنت متأكد من رفض العرض؟' : 'CONFIRM REJECTION?')
                                                   }
                                                 </p>
                                                 <div className="flex gap-3">
                                                   <button 
                                                     onClick={(e) => {
                                                       e.stopPropagation();
                                                       if (confirmAction === 'approve') handleApproveOfferByClient(offer);
                                                       else handleRejectOfferByClient(offer);
                                                       setConfirmingOfferId(null);
                                                       setConfirmAction(null);
                                                     }}
                                                     className="flex-1 bg-emerald-500 text-white px-8 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:brightness-110 active:scale-95 transition-all"
                                                   >
                                                     {lang === 'ar' ? 'نعم' : 'YES'}
                                                   </button>
                                                   <button 
                                                     onClick={(e) => {
                                                       e.stopPropagation();
                                                       setConfirmingOfferId(null);
                                                       setConfirmAction(null);
                                                     }}
                                                     className="flex-1 bg-[var(--bg-main)] text-[var(--muted-text)] px-8 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-[var(--border-main)] hover:text-[var(--text-main)] active:scale-95 transition-all"
                                                   >
                                                     {lang === 'ar' ? 'تراجع' : 'NO'}
                                                   </button>
                                                 </div>
                                               </div>
                                             ) : (
                                               <>
                                                 <button 
                                                   onClick={(e) => { 
                                                     e.stopPropagation(); 
                                                     setConfirmingOfferId(offer.id);
                                                     setConfirmAction('approve');
                                                   }} 
                                                   className="relative overflow-hidden bg-gradient-to-br from-emerald-500 to-emerald-700 text-white px-12 py-6 rounded-[34px] text-[13px] font-black uppercase tracking-[0.3em] hover:scale-[1.08] active:scale-[0.92] shadow-[0_20px_40px_-5px_rgba(16,185,129,0.35)] transition-all flex items-center justify-center gap-4 group/btn ring-4 ring-emerald-500/0 hover:ring-emerald-500/20"
                                                 >
                                                   <div className="absolute inset-0 bg-white/20 -translate-x-full group-hover/btn:translate-x-full transition-transform duration-1000 skew-x-12"></div>
                                                   <CheckCheck size={26} className="group-hover/btn:rotate-[360deg] transition-transform duration-700" strokeWidth={3}/> 
                                                   {t.approve || 'Approve'}
                                                 </button>
                                                 
                                                 <button 
                                                   onClick={(e) => { 
                                                     e.stopPropagation(); 
                                                     setConfirmingOfferId(offer.id);
                                                     setConfirmAction('reject');
                                                   }} 
                                                   className="bg-white/5 hover:bg-rose-500/15 border-[3px] border-rose-500/20 text-rose-500 px-10 py-6 rounded-[34px] text-[13px] font-black uppercase tracking-[0.3em] transition-all flex items-center justify-center gap-4 hover:border-rose-500/60 hover:scale-[1.05] group/btn-r active:scale-[0.95]"
                                                 >
                                                   <XCircle size={24} className="group-hover/btn-r:scale-125 transition-transform" strokeWidth={3}/> 
                                                   {t.reject || 'Reject'}
                                                 </button>
                                               </>
                                             )}
                                           </div>
                                         )}
                                      </div>
                                    </div>
                                  )}
                                </div>
                              );
                           })}
                         </div>
                      </div>
                    )}

                    {(userRole === 'admin' || userRole === 'staff') && !isViewer && (
                      <div className="bg-[var(--card-bg)] p-8 rounded-[32px] border border-[var(--border-main)] space-y-8 mt-16">
                         <div>
                           <h4 className="text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-6 border-b border-[var(--border-main)] pb-4">Workflow Management</h4>
                           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                              <div><label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">{t.assignedStaff || 'Assigned Staff'}</label>
                                 <div className="w-full bg-[var(--input-bg)]/50 border border-[var(--border-main)] rounded-xl p-4 text-sm font-black text-indigo-400 flex items-center gap-3">
                                   <div className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"></div>
                                   {selectedReq.assignedTo || 'System Auto-Assign'}
                                 </div></div>
                              <div><label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">{t.updateStatus}</label><select value={selectedReq.status} onChange={(e) => updateReqStatus(selectedReq.id, e.target.value)} className="w-full bg-[var(--input-bg)] border border-[var(--border-main)] rounded-xl p-4 text-sm focus:ring-2 focus:ring-indigo-500/50 appearance-none"><option value="pending">{t.pending}</option><option value="inProgress">{t.inProgress}</option><option value="quoted">{t.quoted}</option><option value="approved">{t.approved}</option><option value="rejected">{t.rejected}</option><option value="completed">{t.completed}</option></select></div>
                           </div>
                         </div>
                         <div className="space-y-8">
                           <h4 className="text-[11px] font-black text-[var(--muted-text)] uppercase tracking-[0.3em] mb-6 flex items-center gap-4">
                             <div className="p-2.5 rounded-xl bg-indigo-500/10 text-indigo-500 border border-indigo-500/20 shadow-xl shadow-indigo-500/5">
                               <FileSignature size={18}/>
                             </div>
                             Quotation & Offers System
                           </h4>
                           
                           <div className="space-y-4 mb-10">
                             {(selectedReq.offers || []).map((offer, idx) => (
                               <div key={idx} className="flex items-center justify-between p-6 bg-[var(--bg-main)]/50 rounded-2xl border border-[var(--border-main)] backdrop-blur-sm group/os shadow-sm hover:shadow-lg hover:border-indigo-500/30 transition-all">
                                 <div className="flex-1">
                                   <div className="flex items-center gap-3">
                                     <span className="text-[10px] font-black text-indigo-500 uppercase tracking-widest bg-indigo-500/10 px-3 py-1 rounded-full border border-indigo-500/20">Offer {idx+1}</span>
                                     <p className="text-sm font-black text-[var(--text-main)] uppercase tracking-tight">{offer.supplier}</p>
                                   </div>
                                   <div className="mt-3 flex flex-wrap gap-2">
                                     {offer.flightNumber && <span className="text-[8px] font-black bg-white/5 px-2 py-0.5 rounded border border-white/5 opacity-60">FLT: {offer.flightNumber}</span>}
                                     {offer.airline && <span className="text-[8px] font-black bg-white/5 px-2 py-0.5 rounded border border-white/5 opacity-60">{offer.airline}</span>}
                                     {offer.hotelName && <span className="text-[8px] font-black bg-white/5 px-2 py-0.5 rounded border border-white/5 opacity-60">HTL: {offer.hotelName}</span>}
                                     {offer.route && <span className="text-[8px] font-black bg-indigo-500/10 text-indigo-400 px-2 py-0.5 rounded border border-indigo-500/10 uppercase">{offer.route}</span>}
                                   </div>
                                   <p className="text-xs text-[var(--muted-text)] mt-2 font-medium opacity-70 leading-relaxed italic whitespace-pre-wrap">{offer.details}</p>
                                 </div>
                                 <div className="flex items-center gap-8">
                                   <div className="text-right">
                                      <PriceDisplay amount={offer.selling} currency={offer.currency} defaultCurrency={offer.currency} exchangeRate={settings.exchangeRate} className="text-lg font-black text-[var(--text-main)] tracking-tighter"/>
                                      <p className="text-[8px] font-black text-[var(--muted-text)] uppercase tracking-widest mt-0.5 opacity-40">{lang === 'ar' ? 'قيمة العقد' : 'Contract Value'}</p>
                                   </div>
                                   <button onClick={() => handleDeleteOffer(offer.id)} className="p-3 text-[var(--muted-text)] hover:text-rose-500 hover:bg-rose-500/10 rounded-xl transition-all"><Trash2 size={18}/></button>
                                 </div>
                               </div>
                             ))}
                           </div>
                           <div className="bg-[#050b1e]/30 p-10 rounded-[44px] border border-white/5 space-y-10 shadow-3xl relative overflow-hidden">
                               <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 blur-[100px] rounded-full pointer-events-none" />
                               
                               <div className="grid grid-cols-1 md:grid-cols-12 gap-8 relative z-10">
                                  {/* ROW 1: SUPPLIER, COST, SELLING */}
                                  <div className="md:col-span-12 items-center gap-10 flex border-b border-white/5 pb-10 mb-2">
                                     <div className="flex-1 space-y-4">
                                         <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.3em] px-1">Supplier / Vendor</label>
                                         <div className="flex gap-4 group">
                                             <div className="relative flex-1">
                                               <select value={tempSupplierName} onChange={e => setTempSupplierName(e.target.value)} className="w-full bg-[#0a0f25] border border-white/5 rounded-[24px] p-7 text-sm appearance-none outline-none focus:ring-2 focus:ring-indigo-500/40 hover:border-white/10 transition-all font-bold text-[var(--text-main)]">
                                                  <option value="">Select Vendor</option>
                                                  {suppliersList.map(sup => <option key={sup.id} value={sup.name}>{sup.name}</option>)}
                                               </select>
                                               <div className="pointer-events-none absolute right-6 top-1/2 -translate-y-1/2 text-white/20"><ChevronRight size={18} className="rotate-90"/></div>
                                             </div>
                                             <div className="relative w-48">
                                               <input type="number" placeholder="Cost" value={tempSupplierCost} onChange={e => setTempSupplierCost(e.target.value)} className="w-full bg-[#0a0f25] border border-white/5 rounded-[24px] p-7 text-sm font-mono outline-none focus:ring-2 focus:ring-indigo-500/40 font-bold placeholder:opacity-20 text-emerald-400" />
                                             </div>
                                             <button type="button" onClick={addSupplierToOffer} className="bg-white/5 border border-white/10 text-white px-10 rounded-[24px] hover:bg-white/10 active:scale-95 transition-all flex items-center justify-center gap-3 font-black text-[10px] uppercase tracking-[0.2em] shadow-sm"><PlusCircle size={22}/> Add Vendor</button>
                                         </div>
                                         
                                         {offerSupplierCosts.length > 0 && (
                                              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
                                                  {offerSupplierCosts.map(sc => (
                                                      <div key={sc.id} className="flex justify-between items-center bg-white/5 p-4 rounded-2xl border border-white/10 group/sc">
                                                          <div className="flex items-center gap-3">
                                                             <Building size={12} className="text-indigo-400 opacity-60" />
                                                             <span className="text-[10px] font-black uppercase truncate max-w-[80px] text-white/80">{sc.name}</span>
                                                          </div>
                                                          <div className="flex items-center gap-3">
                                                              <span className="text-[11px] font-mono font-black text-emerald-400">${sc.cost}</span>
                                                              <button type="button" onClick={() => removeSupplierFromOffer(sc.id)} className="text-white/20 hover:text-rose-500 transition-colors"><Trash2 size={14}/></button>
                                                          </div>
                                                      </div>
                                                  ))}
                                              </div>
                                         )}
                                     </div>
                                  </div>

                                  <div className="md:col-span-6 space-y-4">
                                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.3em] px-1">Cost Price</label>
                                    <div className="relative">
                                      <input 
                                        type="number" 
                                        value={offerSupplierCosts.length > 0 ? offerSupplierCosts.reduce((sum, s) => sum + s.cost, 0) : offerCost} 
                                        onChange={e => setOfferCost(e.target.value)} 
                                        disabled={offerSupplierCosts.length > 0}
                                        className={`w-full bg-[#101730] border border-white/5 rounded-[32px] p-8 text-[32px] font-mono outline-none focus:ring-4 focus:ring-indigo-500/10 transition-all font-black shadow-inner ${offerSupplierCosts.length > 0 ? 'text-amber-500/30 cursor-not-allowed' : 'text-amber-500'}`} 
                                        placeholder="0.00"
                                      />
                                      <div className="absolute right-8 top-1/2 -translate-y-1/2 flex flex-col items-end">
                                        <span className="text-[12px] font-black text-white/10 uppercase tracking-[0.4em]">{offerCurrency}</span>
                                      </div>
                                    </div>
                                  </div>

                                  <div className="md:col-span-6 space-y-4">
                                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.3em] px-1">Selling Price</label>
                                    <div className="relative">
                                      <input type="number" value={offerSelling} onChange={e => setOfferSelling(e.target.value)} placeholder="0.00" className="w-full bg-[#101730] border border-white/5 rounded-[32px] p-8 text-[32px] font-mono outline-none focus:ring-4 focus:ring-emerald-500/10 transition-all font-black text-emerald-500 shadow-inner" />
                                      <div className="absolute right-8 top-1/2 -translate-y-1/2 text-white/10">
                                        <span className="text-[12px] font-black uppercase tracking-[0.4em]">{offerCurrency}</span>
                                      </div>
                                    </div>
                                  </div>

                                  {/* ROW 2: AIRLINE, CURRENCY, ROUTE */}
                                  <div className="md:col-span-4 space-y-4">
                                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.3em] px-1">Airline</label>
                                    <input type="text" value={offerAirline} onChange={e => setOfferAirline(e.target.value)} placeholder="Iraqi Airways" className="w-full bg-[#0a0f25] border border-white/5 rounded-[24px] p-7 text-sm font-bold text-[var(--text-main)] outline-none focus:ring-2 focus:ring-indigo-500/40 hover:border-white/10 transition-all placeholder:opacity-20 shadow-sm" />
                                  </div>

                                  <div className="md:col-span-4 space-y-4">
                                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.3em] px-1">Currency</label>
                                    <div className="relative">
                                      <select value={offerCurrency} onChange={e => setOfferCurrency(e.target.value as any)} className="w-full bg-[#0a0f25] border border-white/5 rounded-[24px] p-7 text-sm appearance-none outline-none focus:ring-2 focus:ring-indigo-500/40 hover:border-white/10 transition-all font-bold text-[var(--text-main)] shadow-sm">
                                         <option value="USD">USD ($)</option>
                                         <option value="IQD">IQD (ع.د)</option>
                                      </select>
                                      <div className="pointer-events-none absolute right-6 top-1/2 -translate-y-1/2 text-white/20"><ChevronRight size={18} className="rotate-90"/></div>
                                    </div>
                                  </div>

                                  <div className="md:col-span-12 space-y-4">
                                    <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.3em] px-1">{lang === 'ar' ? 'الروت / تفاصيل الرحلة الأساسية' : 'Route / Primary flight details'}</label>
                                    <textarea 
                                      value={offerRoute} 
                                      onChange={e => setOfferRoute(e.target.value)} 
                                      placeholder={lang === 'ar' ? 'أدخل الروت أو تفاصيل العرض هنا...' : 'e.g. BGW-DXB-IST'} 
                                      rows={2}
                                      className="w-full bg-[#0a0f25] border border-white/5 rounded-[24px] p-7 text-sm outline-none focus:ring-2 focus:ring-indigo-500/40 hover:border-white/10 transition-all font-bold text-[var(--text-main)] placeholder:opacity-20 shadow-sm resize-none"
                                    ></textarea>
                                  </div>

                                  {/* ROW 3: FLIGHT DETAILS */}
                                  {selectedReq.service === 'flight' && (
                                    <>
                                      {/* Flight Number Hidden */}
                                      {false && (
                                        <div className="md:col-span-3 space-y-4">
                                          <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.3em] px-1">Flight Number</label>
                                          <input type="text" value={offerFlightNumber} onChange={e => setOfferFlightNumber(e.target.value)} placeholder="IA-123" className="w-full bg-[#101730] border border-white/5 rounded-[24px] p-7 text-sm font-black text-[var(--text-main)] outline-none focus:ring-2 focus:ring-indigo-500/10 shadow-sm" />
                                        </div>
                                      )}
                                      <div className="md:col-span-3 space-y-4">
                                        <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.3em] px-1">Cabin Class</label>
                                        <div className="relative">
                                          <select value={offerCabinClass} onChange={e => setOfferCabinClass(e.target.value)} className="w-full bg-[#101730] border border-white/5 rounded-[24px] p-7 text-sm font-black text-[var(--text-main)] outline-none focus:ring-2 focus:ring-indigo-500/10 appearance-none shadow-sm">
                                            <option value="Economy">Economy</option>
                                            <option value="Premium Economy">Premium Economy</option>
                                            <option value="Business">Business</option>
                                            <option value="First Class">First Class</option>
                                          </select>
                                          <div className="pointer-events-none absolute right-6 top-1/2 -translate-y-1/2 text-white/20"><ChevronRight size={18} className="rotate-90"/></div>
                                        </div>
                                      </div>
                                      <div className="md:col-span-3 space-y-4">
                                        <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.3em] px-1">Baggage (kg)</label>
                                        <input type="text" value={offerBaggage} onChange={e => setOfferBaggage(e.target.value)} placeholder="30kg + 7kg" className="w-full bg-[#101730] border border-white/5 rounded-[24px] p-7 text-sm font-black text-[var(--text-main)] outline-none focus:ring-2 focus:ring-indigo-500/10 shadow-sm" />
                                      </div>
                                      <div className="md:col-span-3 space-y-4">
                                        <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.3em] px-1">Transit / Stops</label>
                                        <input type="text" value={offerTransit} onChange={e => setOfferTransit(e.target.value)} placeholder="Direct Flight" className="w-full bg-[#101730] border border-white/5 rounded-[24px] p-7 text-sm font-black text-[var(--text-main)] outline-none focus:ring-2 focus:ring-indigo-500/10 shadow-sm" />
                                      </div>
                                      {/* Departure & Return Dates Hidden */}
                                      {false && (
                                        <>
                                          <div className="md:col-span-3 space-y-4">
                                            <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.3em] px-1">{lang === 'ar' ? 'تاريخ الذهاب' : 'Departure Date'}</label>
                                            <input type="date" value={offerDepartureDate} onChange={e => setOfferDepartureDate(e.target.value)} className="w-full bg-[#101730] border border-white/5 rounded-[24px] p-7 text-sm font-black text-[var(--text-main)] outline-none focus:ring-2 focus:ring-indigo-500/10 shadow-sm" />
                                          </div>
                                          <div className="md:col-span-3 space-y-4">
                                            <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.3em] px-1">{lang === 'ar' ? 'تاريخ العودة' : 'Return Date'}</label>
                                            <input type="date" value={offerReturnDate} onChange={e => setOfferReturnDate(e.target.value)} className="w-full bg-[#101730] border border-white/5 rounded-[24px] p-7 text-sm font-black text-[var(--text-main)] outline-none focus:ring-2 focus:ring-indigo-500/10 shadow-sm" />
                                          </div>
                                        </>
                                      )}
                                      <div className="md:col-span-12 flex items-center gap-6 pt-4">
                                        {/* Refundable Ticket Hidden */}
                                        {false && (
                                          <label className="flex items-center gap-6 cursor-pointer group bg-white/5 p-6 rounded-[32px] border border-white/10 hover:bg-white/10 transition-all select-none">
                                            <div className="relative flex items-center justify-center">
                                              <input type="checkbox" checked={offerRefundable} onChange={e => setOfferRefundable(e.target.checked)} className="peer w-8 h-8 rounded-xl bg-[#0a0f25] border-white/10 text-indigo-500 focus:ring-0 focus:ring-offset-0 appearance-none" />
                                              <div className="absolute inset-0 bg-indigo-500/20 scale-0 peer-checked:scale-100 rounded-xl transition-transform duration-200" />
                                              <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-white scale-0 transition-transform duration-200 ${offerRefundable ? 'scale-100' : 'scale-0'}`}>
                                                <CheckCheck size={16} />
                                              </div>
                                            </div>
                                            <span className="text-[11px] font-black text-white/40 uppercase tracking-[0.3em] group-hover:text-white transition-colors">Refundable Ticket</span>
                                          </label>
                                        )}
                                      </div>
                                    </>
                                  )}

                                  {selectedReq.service === 'hotel' && (
                                    <>
                                      <div className="md:col-span-6 space-y-4">
                                        <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.3em] px-1">Hotel Name</label>
                                        <input type="text" value={offerHotelName} onChange={e => setOfferHotelName(e.target.value)} placeholder="Sheraton Grand BGW" className="w-full bg-[#0a0f25] border border-white/5 rounded-[24px] p-7 text-sm font-black text-[var(--text-main)] outline-none focus:ring-2 focus:ring-indigo-500/40" />
                                      </div>
                                      <div className="md:col-span-3 space-y-4">
                                        <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.3em] px-1">Stars</label>
                                        <div className="relative">
                                          <select value={offerStarRating} onChange={e => setOfferStarRating(e.target.value)} className="w-full bg-[#0a0f25] border border-white/5 rounded-[24px] p-7 text-sm font-black text-[var(--text-main)] outline-none focus:ring-2 focus:ring-indigo-500/40 appearance-none">
                                            <option value="">Select</option>
                                            <option value="5">5 Stars</option>
                                            <option value="4">4 Stars</option>
                                            <option value="3">3 Stars</option>
                                            <option value="2">2 Stars</option>
                                          </select>
                                          <div className="pointer-events-none absolute right-6 top-1/2 -translate-y-1/2 text-white/20"><ChevronRight size={18} className="rotate-90"/></div>
                                        </div>
                                      </div>
                                      <div className="md:col-span-3 space-y-4">
                                        <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.3em] px-1">Room Type</label>
                                        <input type="text" value={offerRoomType} onChange={e => setOfferRoomType(e.target.value)} placeholder="Double / Suite" className="w-full bg-[#0a0f25] border border-white/5 rounded-[24px] p-7 text-sm font-black text-[var(--text-main)] outline-none focus:ring-2 focus:ring-indigo-500/40" />
                                      </div>
                                      <div className="md:col-span-3 space-y-4">
                                        <label className="block text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.3em] px-1">Board Basis</label>
                                        <div className="relative">
                                          <select value={offerBoardBasis} onChange={e => setOfferBoardBasis(e.target.value)} className="w-full bg-[#0a0f25] border border-white/5 rounded-[24px] p-7 text-sm font-black text-[var(--text-main)] outline-none focus:ring-2 focus:ring-indigo-500/40 appearance-none">
                                            <option value="Room Only">Room Only</option>
                                            <option value="BB - Breakfast">BB - Breakfast</option>
                                            <option value="HB - Half Board">HB - Half Board</option>
                                            <option value="FB - Full Board">FB - Full Board</option>
                                            <option value="AI - All Inclusive">AI - All Inclusive</option>
                                          </select>
                                          <div className="pointer-events-none absolute right-6 top-1/2 -translate-y-1/2 text-white/20"><ChevronRight size={18} className="rotate-90"/></div>
                                        </div>
                                      </div>
                                    </>
                                  )}

                                  {/* OFFER DETAILS (FULL WIDTH AT BOTTOM) */}
                                  <div className="md:col-span-12 space-y-3">
                                    <label className="block text-[9px] font-black text-[var(--muted-text)] uppercase tracking-[0.3em] px-1">{lang === 'ar' ? 'ملاحظات إضافية / تفاصيل ثانوية' : 'Additional Notes / Secondary Details'}</label>
                                    <textarea value={offerDetails} onChange={e => setOfferDetails(e.target.value)} rows={4} className="w-full bg-[#0a0f25] border border-white/5 rounded-[32px] p-6 text-sm outline-none focus:ring-2 focus:ring-indigo-500/40 hover:border-white/10 transition-all font-medium text-white/90 resize-none shadow-inner" placeholder="Provide a detailed description of what is included in this particular offer..."></textarea>
                                  </div>
                              </div>
                              
                              <div className="flex justify-end pt-4 relative z-10">
                                <button 
                                  onClick={handleAddOffer} 
                                  className="relative group bg-indigo-500/10 border border-indigo-500/20 p-[1px] rounded-2xl hover:scale-105 active:scale-95 transition-all duration-300"
                                >
                                  <div className="bg-[#0a0f25] rounded-[14px] px-12 py-5 flex items-center gap-4 group-hover:bg-transparent transition-colors">
                                    <PlusCircle size={22} className="text-white group-hover:scale-110 transition-transform"/> 
                                    <span className="text-[13px] font-black text-white uppercase tracking-[0.4em] drop-shadow-md">Add Offer</span>
                                  </div>
                                </button>
                              </div>
                           </div>
                           <div className="mt-8 pt-8 border-t border-[var(--border-main)] flex gap-4">
                              <button onClick={handleSendOffersToClient} className="flex-1 bg-[var(--text-main)] text-[var(--bg-main)] py-4 rounded-xl text-xs font-black uppercase tracking-widest hover:brightness-110 shadow-xl transition-all">{t.sendOffers}</button>
                              <label className="cursor-pointer bg-[var(--card-bg)] border border-[var(--border-main)] text-[var(--text-main)] px-8 py-4 rounded-xl text-xs font-black uppercase tracking-widest flex items-center gap-3"><UploadCloud size={18}/> {t.attachFile} <input type="file" className="hidden" multiple onChange={handleFileChange} /></label>
                           </div>
                         </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </Card>
          </div>

          <Card className="flex flex-col h-[700px] !p-0 overflow-hidden bg-[var(--card-bg)] border-[var(--border-main)]">
            <div className="p-6 border-b border-[var(--border-main)] flex items-center justify-between">
              <h3 className="font-bold text-[var(--text-main)] flex items-center gap-3 tracking-tight">
                <div className={`w-2.5 h-2.5 rounded-full ${selectedReq.chatClosed ? 'bg-rose-500' : 'bg-emerald-500 animate-pulse'}`}></div>
                {t.internalChat}
                {selectedReq.chatClosed && <span className="text-[10px] font-black text-rose-500 uppercase tracking-widest ml-2 px-2 py-0.5 bg-rose-500/10 rounded-lg border border-rose-500/20">{lang === 'ar' ? 'مغلقة' : 'CLOSED'}</span>}
              </h3>
              {(userRole === 'admin' || userRole === 'staff') && !selectedReq.chatClosed && (
                <button 
                  onClick={handleEndChat}
                  className="text-[10px] font-black text-rose-400 hover:text-rose-500 uppercase tracking-widest px-3 py-1.5 bg-rose-500/5 hover:bg-rose-500/10 rounded-lg border border-rose-500/10 transition-all flex items-center gap-2"
                >
                  <XCircle size={14}/> {lang === 'ar' ? 'إنهاء المحادثة' : 'End Chat'}
                </button>
              )}
            </div>
            <div className="flex-1 p-6 overflow-y-auto space-y-6">
              {selectedReq.chat.map((msg, idx) => {
                const isMe = msg.sender === userRole;
                const isSystem = msg.sender === 'system';
                if (isSystem) {
                  return (
                    <div key={idx} className="flex justify-center py-2">
                      <div className="px-4 py-1.5 bg-[var(--bg-main)] border border-[var(--border-main)] rounded-full text-[10px] font-black text-[var(--muted-text)] uppercase tracking-widest">{msg.text}</div>
                    </div>
                  );
                }
                return (
                  <div key={idx} className={`flex flex-col ${isMe ? (isRTL ? 'items-start' : 'items-end') : (isRTL ? 'items-end' : 'items-start')}`}>
                    <div className={`max-w-[85%] p-5 rounded-[24px] text-sm font-medium leading-relaxed shadow-xl ${isMe ? 'accent-gradient text-white rounded-br-none' : 'bg-[var(--bg-main)] text-[var(--text-main)] border border-[var(--border-main)] rounded-bl-none'}`}>
                      {msg.text && <p className={msg.file ? 'mb-4' : ''}>{msg.text}</p>}
                      {msg.file && (
                        <div className="space-y-3">
                          {msg.file.type.startsWith('image/') && msg.file.data && msg.file.data.trim() !== '' ? (
                            <div className="relative group/chatimg cursor-pointer" onClick={() => setPreviewFile({ name: msg.file!.name, data: msg.file!.data, type: msg.file!.type })}>
                              <img src={msg.file.data} alt={msg.file.name} className="max-w-full rounded-xl border border-white/10 shadow-lg" />
                              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover/chatimg:opacity-100 transition-opacity rounded-xl flex items-center justify-center gap-2">
                                <span className="px-3 py-1.5 bg-indigo-600/90 text-white text-[10px] font-black rounded-lg flex items-center gap-1.5 shadow-lg">
                                  <Eye size={13} /> {lang === 'ar' ? 'معاينة الصورة' : 'Preview Image'}
                                </span>
                              </div>
                            </div>
                          ) : (
                            <div 
                              onClick={() => setPreviewFile({ name: msg.file!.name, data: msg.file!.data, type: msg.file!.type })}
                              className="p-4 bg-black/10 rounded-xl border border-white/5 flex items-center gap-3 cursor-pointer hover:bg-black/20 transition-all"
                            >
                              <FileText size={18} className="text-indigo-400 shrink-0" />
                              <span className="text-[10px] font-black uppercase tracking-widest truncate">{msg.file.name}</span>
                            </div>
                          )}

                          <div className="flex items-center gap-2 pt-1">
                            <button
                              type="button"
                              onClick={() => setPreviewFile({ name: msg.file!.name, data: msg.file!.data, type: msg.file!.type })}
                              className={`flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest px-3 py-1.5 rounded-lg transition-all ${isMe ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-[var(--bg-main)] hover:brightness-95 text-[var(--text-main)] border border-[var(--border-main)]'}`}
                            >
                              <Eye size={12} /> {lang === 'ar' ? 'معاينة' : 'Preview'}
                            </button>

                            <button 
                              type="button"
                              onClick={() => {
                                const link = document.createElement('a');
                                link.href = msg.file!.data;
                                link.download = msg.file!.name;
                                link.click();
                              }}
                              className={`flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest px-3 py-1.5 rounded-lg transition-all ${isMe ? 'bg-white/10 hover:bg-white/20 text-white' : 'bg-[var(--bg-main)] hover:brightness-95 text-[var(--text-main)] border border-[var(--border-main)]'}`}
                            >
                              <UploadCloud size={12} className="rotate-180" /> {lang === 'ar' ? 'تحميل' : 'Download'}
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                    {isMe && <div className="flex items-center gap-1.5 mt-1 px-2 opacity-50">{msg.read ? <CheckCheck size={10} className="text-emerald-400" /> : <Check size={10} />} <span className="text-[9px] font-black uppercase tracking-widest">{msg.read ? t.readStatus : t.unreadStatus}</span></div>}
                  </div>
                );
              })}
            </div>
            {!isViewer && !selectedReq.chatClosed ? (
              <div className="p-6 border-t border-[var(--border-main)] flex flex-col gap-4">
                {chatFileToUpload && (
                   <div className="flex items-center justify-between p-3 bg-indigo-500/10 border border-indigo-500/20 rounded-xl">
                      <div className="flex items-center gap-3">
                         <Paperclip size={14} className="text-indigo-500" />
                         <span className="text-[10px] font-black text-indigo-500 uppercase tracking-widest truncate max-w-[200px]">{chatFileToUpload.name}</span>
                      </div>
                      <button onClick={() => setChatFileToUpload(null)} className="text-rose-500 hover:scale-110 transition-transform"><XCircle size={14} /></button>
                   </div>
                )}
                <div className="flex gap-3">
                  <label className="bg-[var(--bg-main)] text-[var(--muted-text)] p-4 rounded-2xl hover:text-[var(--text-main)] border border-[var(--border-main)] cursor-pointer transition-all active:scale-90">
                    <Paperclip size={20} />
                    <input 
                      type="file" 
                      className="hidden" 
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                           const reader = new FileReader();
                           reader.onloadend = () => {
                              setChatFileToUpload({ name: file.name, type: file.type, data: reader.result as string });
                           };
                           reader.readAsDataURL(file);
                        }
                      }} 
                    />
                  </label>
                  <input type="text" value={chatMsg} onChange={e => setChatMsg(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSendChat()} placeholder={t.typeMessage} className="flex-1 bg-[var(--bg-main)] border border-[var(--border-main)] rounded-2xl px-5 py-4 text-sm focus:ring-2 focus:ring-indigo-500/50 outline-none" />
                  <button onClick={handleSendChat} className="bg-[var(--text-main)] text-[var(--bg-main)] p-4 rounded-2xl hover:brightness-110 active:scale-90 transition-all">
                    <Send size={20} className={isRTL ? 'rotate-180' : ''}/>
                  </button>
                </div>
              </div>
            ) : selectedReq.chatClosed && (
              <div className="p-8 border-t border-[var(--border-main)] bg-[var(--bg-main)]/50 text-center">
                <p className="text-xs font-black text-[var(--muted-text)] uppercase tracking-[0.2em]">{lang === 'ar' ? 'هذه المحادثة مغلقة ولا يمكن إرسال رسائل' : 'THIS CHAT IS CLOSED. NO FURTHER MESSAGES CAN BE SENT.'}</p>
              </div>
            )}
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 no-print">
        <div><h2 className="text-4xl font-black text-[var(--text-main)] tracking-tight">{(userRole === 'admin' || userRole === 'staff' || userRole === 'viewer') ? t.allRequests : t.requests}</h2><p className="text-[var(--muted-text)] mt-2 font-medium">Manage and track your service requests in real-time.</p></div>
        <button onClick={handlePrint} className="flex items-center gap-2 bg-[var(--card-bg)] text-[var(--text-main)] border border-[var(--border-main)] px-6 py-2.5 rounded-xl text-xs font-black uppercase tracking-widest hover:bg-[var(--bg-main)] transition-all shadow-lg"><FileText size={16} /> {lang === 'ar' ? 'طباعة' : 'Print'}</button>
      </div>

      <Card className="overflow-hidden !p-0">
        {(userRole === 'admin' || userRole === 'staff' || userRole === 'viewer') && (
          <div className="p-6 border-b border-[var(--border-main)] bg-[var(--bg-main)] flex flex-col md:flex-row gap-6">
            <div className="flex-1"><select value={filterCompany} onChange={(e) => setFilterCompany(e.target.value)} className="w-full bg-[var(--card-bg)] border border-[var(--border-main)] text-xs font-bold uppercase tracking-widest rounded-xl p-4 focus:ring-2 focus:ring-indigo-500/50 appearance-none"><option value={t.allCompanies}>{t.allCompanies}</option><option value="Raban Al-Safina">Raban Al-Safina</option><option value="Ur Energy">Ur Energy</option><option value="Dijla Tech">Dijla Tech</option></select></div>
            <div className="flex-1"><select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className="w-full bg-[var(--card-bg)] border border-[var(--border-main)] text-xs font-bold uppercase tracking-widest rounded-xl p-4 focus:ring-2 focus:ring-indigo-500/50 appearance-none">
              <option value={t.allStatuses}>{t.allStatuses}</option>
              <option value="active">{t.activeRequests || 'Active Requests'}</option>
              <option value="pending">{t.pending}</option>
              <option value="inProgress">{t.inProgress}</option>
              <option value="quoted">{t.quoted}</option>
              <option value="approved">{t.approved}</option>
              <option value="rejected">{t.rejected}</option>
              <option value="completed">{t.completed}</option>
            </select></div>
            <div className="flex-1"><select value={filterService} onChange={(e) => setFilterService(e.target.value)} className="w-full bg-[var(--card-bg)] border border-[var(--border-main)] text-xs font-bold uppercase tracking-widest rounded-xl p-4 focus:ring-2 focus:ring-indigo-500/50 appearance-none"><option value={t.allServices}>{t.allServices}</option><option value="flight">{t.flight}</option><option value="hotel">{t.hotel}</option><option value="visa">{t.visa}</option></select></div>
          </div>
        )}
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left rtl:text-right">
            <thead className="text-[10px] text-[var(--muted-text)] uppercase tracking-[0.2em] bg-[var(--bg-main)] border-b border-[var(--border-main)]">
              <tr>
                <th className="px-8 py-6 font-black">ID / Ref</th>
                <th className="px-8 py-6 font-black">{t.date}</th>
                {(userRole === 'admin' || userRole === 'staff' || userRole === 'viewer') && <th className="px-8 py-6 font-black">Company</th>}
                {(userRole === 'admin' || userRole === 'staff' || userRole === 'viewer') && <th className="px-8 py-6 font-black">Assigned</th>}
                {(userRole === 'admin' || userRole === 'staff' || userRole === 'viewer') && <th className="px-8 py-6 font-black">{t.supplierLabel}</th>}
                <th className="px-8 py-6 font-black">{t.service}</th>
                <th className="px-8 py-6 font-black">{t.status}</th>
                <th className="px-8 py-6 font-black text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[var(--border-main)]">
              {filteredRequests.map(req => {
                const SIcon = serviceIcons[req.service] || MoreVertical;
                const hasApproved = (req.offers || []).some(o => o.status === 'approved');
                const hasRejected = (req.offers || []).some(o => o.status === 'rejected');
                return (
                  <tr key={req.id} className="hover:bg-[var(--bg-main)] transition-all group cursor-pointer" onClick={() => {
                    setSelectedReqId(req.id);
                    // Standard surgical addition: Scroll to top of detail view
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}>
                    <td className="px-8 py-6 font-black text-[var(--text-main)] text-base"><div className="flex items-center gap-3">{req.id}{(hasApproved || hasRejected) && <div className="flex gap-1.5 ml-2">{hasApproved && <div className="w-3 h-3 rounded-full bg-emerald-500 shadow-lg animate-pulse" />} {hasRejected && <div className="w-3 h-3 rounded-full bg-rose-500 shadow-lg" />}</div>}</div></td>
                    <td className="px-8 py-6 text-[var(--muted-text)] font-bold text-xs">{req.date}</td>
                    {(userRole === 'admin' || userRole === 'staff' || userRole === 'viewer') && <td className="px-8 py-6 font-bold text-[var(--text-main)]"><div className="flex items-center gap-3"><div className="w-8 h-8 rounded-xl accent-gradient text-white flex items-center justify-center text-xs font-black shadow-lg">{req.company.charAt(0)}</div>{req.company}</div></td>}
                    {(userRole === 'admin' || userRole === 'staff' || userRole === 'viewer') && <td className="px-8 py-6 text-[var(--muted-text)] text-[10px] font-black uppercase tracking-widest">{req.assignedTo || '---'}</td>}
                    {(userRole === 'admin' || userRole === 'staff' || userRole === 'viewer') && (
                      <td className="px-8 py-6">
                        <div className="flex flex-col">
                           <span className={`text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-lg border w-fit ${req.supplier ? 'bg-indigo-500/5 text-indigo-400 border-indigo-500/10' : 'bg-white/5 text-white/20 border-white/5'}`}>
                              {req.supplier || '---'}
                           </span>
                           {req.selectedOfferId && (
                             <span className="text-[8px] font-bold text-indigo-500/30 uppercase tracking-[0.2em] mt-1 ml-1 leading-none italic">Verified & Assigned</span>
                           )}
                        </div>
                      </td>
                    )}
                    <td className="px-8 py-6"><div className="flex items-center gap-3"><div className="p-2 bg-[var(--primary)]/10 rounded-xl text-[var(--primary)]"><SIcon size={18}/></div><span className="font-bold text-[var(--text-main)]">{t[req.service]}</span></div></td>
                    <td className="px-8 py-6"><StatusBadge status={req.status} t={t} /></td>
                    <td className="px-8 py-6 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button className="text-[9px] font-black uppercase tracking-[0.2em] text-[var(--muted-text)] group-hover:text-[var(--text-main)] glass-pane px-5 py-2.5 rounded-xl border-[var(--border-main)] transition-all">Details</button>
                        {userRole === 'admin' && (
                          <button 
                            onClick={(e) => handleDeleteRequest(e, req.id)}
                            title={lang === 'ar' ? 'حذف الطلب' : 'Delete Request'}
                            className="p-2.5 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-500 border border-rose-500/20 transition-all hover:scale-105 active:scale-95"
                          >
                            <Trash2 size={15} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>

      <FilePreviewModal 
        isOpen={!!previewFile} 
        onClose={() => setPreviewFile(null)} 
        file={previewFile} 
        lang={lang === 'ar' ? 'ar' : 'en'} 
      />
    </div>
  );
};

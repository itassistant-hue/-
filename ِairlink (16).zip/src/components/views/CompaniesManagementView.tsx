import React, { useState } from 'react';
import { 
  PlusCircle, Users, ShieldAlert, Camera, Building, 
  ChevronRight, ChevronLeft, CheckCircle, Trash2, Eye 
} from 'lucide-react';
import { Company, User, Supplier, AppSettings } from '../../types.ts';
import { Card, Avatar } from '../ui/Common.tsx';
import { mockCompaniesList, mockUsers } from '../../mockData.ts';
import { generateId } from '../../App.tsx';

interface CompaniesManagementViewProps {
  t: any;
  lang: string;
  isRTL: boolean;
  usersList: User[];
  setUsersList: React.Dispatch<React.SetStateAction<User[]>>;
  companiesList: Company[];
  setCompaniesList: React.Dispatch<React.SetStateAction<Company[]>>;
  suppliersList: Supplier[];
  setSuppliersList: React.Dispatch<React.SetStateAction<Supplier[]>>;
  initialTab?: 'users' | 'companies' | 'suppliers';
}

export const CompaniesManagementView = ({ 
  t, lang, isRTL, usersList, setUsersList, companiesList, setCompaniesList, 
  suppliersList, setSuppliersList, settings, initialTab = 'users' 
}: CompaniesManagementViewProps & { settings: AppSettings }) => {
  const [activeTab, setActiveTab] = useState<'users' | 'companies' | 'suppliers'>(initialTab);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [newUser, setNewUser] = useState<any>({ name: '', email: '', password: '', role: 'client', company: '', avatar: null });
  const [editingCompanyId, setEditingCompanyId] = useState<string | null>(null);
  const [newCompany, setNewCompany] = useState<any>({ name: '', industry: '', contactPerson: '', phone: '', address: '', creditLimit: '', logo: null });
  const [editingSupplierId, setEditingSupplierId] = useState<string | null>(null);
  const [newSupplier, setNewSupplier] = useState<any>({ name: '', type: 'airline', contactPerson: '', phone: '', balanceUSD: 0, balanceIQD: 0 });
  const [selectedCompanyProfile, setSelectedCompanyProfile] = useState<Company | null>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, type: 'user' | 'company') => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const imageUrl = reader.result as string;
        if (type === 'user') setNewUser({ ...newUser, avatar: imageUrl });
        if (type === 'company') setNewCompany({ ...newCompany, logo: imageUrl });
      };
      reader.readAsDataURL(e.target.files[0]);
    }
  };

  const triggerSync = () => {
    setTimeout(() => {
      window.dispatchEvent(new CustomEvent('save-trigger-now'));
    }, 50);
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingUserId) {
      setUsersList(usersList.map(u => u.id === editingUserId ? { ...newUser, id: editingUserId } : u));
      setEditingUserId(null);
    } else {
      const newId = `USR-${generateId()}`;
      setUsersList([{ ...newUser, id: newId }, ...usersList]);
    }
    triggerSync();
    alert(t.userAdded);
    setNewUser({ name: '', email: '', password: '', role: 'client', company: '', avatar: null });
  };

  const editUser = (user: User) => {
    setEditingUserId(user.id);
    setNewUser({ name: user.name, email: user.email, password: '', role: user.role, company: user.company, avatar: user.avatar });
    window.scrollTo(0,0);
  };

  const deleteUser = (id: string) => {
    const confirmation = window.confirm(t.confirmDelete || 'Are you sure you want to delete this user?');
    if(confirmation) {
      window.dispatchEvent(new CustomEvent('item-deleted', { detail: { id } }));
      setUsersList(prev => prev.filter(u => u.id !== id));
      triggerSync();
    }
  };

  const handleSaveCompany = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingCompanyId) {
      setCompaniesList(companiesList.map(c => c.id === editingCompanyId ? { ...newCompany, id: editingCompanyId, status: c.status } : c));
      setEditingCompanyId(null);
    } else {
      const newId = `COM-${generateId()}`;
      setCompaniesList([{ ...newCompany, id: newId, status: 'Active' }, ...companiesList]);
    }
    triggerSync();
    alert(t.companyAdded);
    setNewCompany({ name: '', industry: '', contactPerson: '', phone: '', address: '', creditLimit: '', logo: null });
  };

  const editCompany = (comp: Company) => {
    setEditingCompanyId(comp.id);
    setNewCompany({ name: comp.name, industry: comp.industry, contactPerson: comp.contactPerson, phone: comp.phone, address: comp.address, creditLimit: comp.creditLimit, logo: comp.logo });
    window.scrollTo(0,0);
  };

  const deleteCompany = (id: string) => {
    if(window.confirm(t.confirmDelete)) {
      window.dispatchEvent(new CustomEvent('item-deleted', { detail: { id } }));
      setCompaniesList(companiesList.filter(c => c.id !== id));
      setSelectedCompanyProfile(null);
      triggerSync();
    }
  };

  const handleSaveSupplier = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingSupplierId) {
      setSuppliersList(suppliersList.map(s => s.id === editingSupplierId ? { ...newSupplier, id: editingSupplierId } : s));
      setEditingSupplierId(null);
    } else {
      const newId = `SUP-${generateId()}`;
      setSuppliersList([{ ...newSupplier, id: newId }, ...suppliersList]);
    }
    triggerSync();
    alert("Supplier saved successfully");
    setNewSupplier({ name: '', type: 'airline', contactPerson: '', phone: '', balanceUSD: 0, balanceIQD: 0 });
  };

  const editSupplier = (sup: Supplier) => {
    setEditingSupplierId(sup.id);
    setNewSupplier({ ...sup });
    window.scrollTo(0,0);
  };

  const deleteSupplier = (id: string) => {
    if(window.confirm(t.confirmDelete)) {
      window.dispatchEvent(new CustomEvent('item-deleted', { detail: { id } }));
      setSuppliersList(suppliersList.filter(s => s.id !== id));
      triggerSync();
    }
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row justify-between md:items-end gap-6">
        <div>
          <h3 className="text-4xl font-black text-[var(--text-main)] tracking-tight">{t.usersManagement}</h3>
          <p className="text-[var(--muted-text)] mt-2 font-medium">Manage system access for staff and client companies.</p>
        </div>
        <div className="flex glass-pane p-1.5 rounded-2xl w-fit border-[var(--border-main)] shadow-xl">
          <button onClick={() => {setActiveTab('users'); setSelectedCompanyProfile(null);}} className={`px-8 py-3 font-black text-xs rounded-xl transition-all duration-500 uppercase tracking-widest ${activeTab === 'users' ? 'bg-[var(--primary)] text-white shadow-2xl scale-[1.02]' : 'text-[var(--muted-text)] hover:text-[var(--text-main)]'}`}>{t.usersTab}</button>
          <button onClick={() => {setActiveTab('companies'); setSelectedCompanyProfile(null);}} className={`px-8 py-3 font-black text-xs rounded-xl transition-all duration-500 uppercase tracking-widest ${activeTab === 'companies' ? 'bg-[var(--primary)] text-white shadow-2xl scale-[1.02]' : 'text-[var(--muted-text)] hover:text-[var(--text-main)]'}`}>{t.companiesProfiles}</button>
          <button onClick={() => {setActiveTab('suppliers'); setSelectedCompanyProfile(null);}} className={`px-8 py-3 font-black text-xs rounded-xl transition-all duration-500 uppercase tracking-widest ${activeTab === 'suppliers' ? 'bg-[var(--primary)] text-white shadow-2xl scale-[1.02]' : 'text-[var(--muted-text)] hover:text-[var(--text-main)]'}`}>Users (Suppliers)</button>
        </div>
      </div>

      {activeTab === 'users' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10 animate-in slide-in-from-left-4">
          <div className="lg:col-span-1">
            <Card className="p-8 sticky top-24 border-[var(--border-main)]">
              <div className="flex justify-between items-center mb-8 border-b border-[var(--border-main)] pb-4">
                <h3 className="font-black text-[var(--text-main)] flex items-center gap-3 uppercase tracking-widest text-sm"><PlusCircle size={20} className="text-[var(--primary)]" />{editingUserId ? t.updateUser : t.addUser}</h3>
                {editingUserId && <button onClick={() => {setEditingUserId(null); setNewUser({ name: '', email: '', password: '', role: 'client', company: '', avatar: null });}} className="text-[10px] font-black uppercase text-rose-500 hover:text-rose-400 tracking-widest transition-colors">Cancel</button>}
              </div>

              <form onSubmit={handleSaveUser} className="space-y-6">
                <div className="flex flex-col items-center mb-6">
                  <div className="relative group">
                    <Avatar name={newUser.name} url={newUser.avatar} className="w-24 h-24 rounded-[32px] text-3xl shadow-2xl border-2 border-[var(--border-main)] accent-gradient text-white" />
                    <label className="absolute -bottom-2 -right-2 bg-[var(--text-main)] text-[var(--bg-main)] p-2.5 rounded-xl cursor-pointer hover:scale-110 shadow-2xl transition-all">
                      <Camera size={18} />
                      <input type="file" className="hidden" accept="image/*" onChange={(e) => handleImageUpload(e, 'user')} />
                    </label>
                  </div>
                </div>

                <div><label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">{t.fullName}</label><input required type="text" value={newUser.name} onChange={e => setNewUser({...newUser, name: e.target.value})} className="bg-[var(--input-bg)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl focus:ring-2 focus:ring-indigo-500/50 block w-full p-4 transition-all hover:bg-[var(--card-bg)]" placeholder="John Doe" /></div>
                <div><label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">{t.email}</label><input required type="email" value={newUser.email} onChange={e => setNewUser({...newUser, email: e.target.value})} className="bg-[var(--input-bg)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl focus:ring-2 focus:ring-indigo-500/50 block w-full p-4 transition-all hover:bg-[var(--card-bg)]" placeholder="john@example.com" /></div>
                <div><label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">{t.password}</label><input required={!editingUserId} type="password" value={newUser.password} onChange={e => setNewUser({...newUser, password: e.target.value})} className="bg-[var(--input-bg)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl focus:ring-2 focus:ring-indigo-500/50 block w-full p-4 transition-all hover:bg-[var(--card-bg)]" placeholder={editingUserId ? "••••••••" : "Create password"} /></div>
                <div>
                  <label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">{t.accountPermissions}</label>
                  <select 
                    required 
                    value={newUser.role} 
                    onChange={e => setNewUser({...newUser, role: e.target.value, company: (e.target.value === 'client' || e.target.value === 'viewer') ? newUser.company : '-'})} 
                    className="bg-[var(--input-bg)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl focus:ring-2 focus:ring-indigo-500/50 block w-full p-4 transition-all hover:bg-[var(--card-bg)] appearance-none"
                  >
                    <optgroup label={t.fullAccess} className="bg-[var(--bg-main)]">
                       <option value="admin">{t.adminRole}</option>
                    </optgroup>
                    <optgroup label={t.standardAccess} className="bg-[var(--bg-main)]">
                       <option value="staff">{t.staffRole}</option>
                    </optgroup>
                    <optgroup label={t.limitedAccess} className="bg-[var(--bg-main)]">
                       <option value="client">{t.clientRole}</option>
                    </optgroup>
                    <optgroup label={t.readOnlyAccess} className="bg-[var(--bg-main)]">
                       <option value="viewer">{t.viewerRole}</option>
                    </optgroup>
                  </select>
                  
                  <div className="mt-4 text-[10px] text-[var(--muted-text)] font-medium bg-[var(--card-bg)] p-4 rounded-2xl border border-[var(--border-main)] leading-relaxed">
                     <span className="text-[var(--primary)] font-black uppercase tracking-widest block mb-1">{t.selectPermissions}:</span>
                     {newUser.role === 'admin' ? t.adminPermDesc : newUser.role === 'staff' ? t.staffPermDesc : newUser.role === 'client' ? t.clientPermDesc : t.viewerPermDesc}
                  </div>
                </div>
                
                {newUser.role === 'client' && (
                  <div className="animate-in slide-in-from-top-2">
                    <label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">{t.selectCompany}</label>
                    <select required value={newUser.company} onChange={e => setNewUser({...newUser, company: e.target.value})} className="bg-[var(--input-bg)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl focus:ring-2 focus:ring-indigo-500/50 block w-full p-4 appearance-none">
                      <option className="bg-[var(--bg-main)]" value="">-- {t.selectCompany} --</option>
                      {companiesList.map(comp => <option key={comp.id} className="bg-[var(--bg-main)]" value={comp.name}>{comp.name}</option>)}
                    </select>
                  </div>
                )}
                
                <button type="submit" className="w-full mt-6 bg-[var(--text-main)] text-[var(--bg-main)] px-8 py-4 rounded-xl text-xs font-black uppercase tracking-widest shadow-xl transition-all hover:bg-[var(--text-main)]/90 active:scale-95 flex items-center justify-center gap-3">
                  {t.saveUser}
                  <ShieldAlert size={14} className="opacity-20" />
                </button>
              </form>
            </Card>
          </div>

          <div className="lg:col-span-2">
            <Card className="overflow-hidden !p-0">
              <div className="p-8 border-b border-[var(--border-main)] bg-[var(--card-bg)]/50"><h3 className="font-black text-[var(--text-main)] text-xl uppercase tracking-widest">System Users</h3></div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left rtl:text-right">
                  <thead className="text-[10px] text-[var(--muted-text)] uppercase bg-[var(--card-bg)]/30 border-b border-[var(--border-main)] tracking-[0.2em]">
                    <tr><th className="px-8 py-6 font-black">{t.fullName}</th><th className="px-8 py-6 font-black">{t.role}</th><th className="px-8 py-6 font-black">Company</th><th className="px-8 py-6 font-black text-center">{t.actions}</th></tr>
                  </thead>
                  <tbody className="divide-y divide-[var(--border-main)]">
                    {usersList.filter(u => u.email.toLowerCase() !== 'ali.aneed').map(usr => (
                      <tr key={usr.id} className="hover:bg-[var(--card-bg)]/40 transition-all group">
                        <td className="px-8 py-6">
                          <div className="flex items-center gap-4">
                            <Avatar name={usr.name} url={usr.avatar} className="w-10 h-10 rounded-xl accent-gradient text-white border-[var(--border-main)]" />
                            <div><p className="font-black text-[var(--text-main)] text-base tracking-tight">{usr.name}</p><p className="text-xs text-[var(--muted-text)] font-medium">{usr.email}</p></div>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <span className={`inline-flex items-center px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest border ${usr.role === 'admin' ? 'bg-rose-500/10 text-rose-400 border-rose-500/20' : usr.role === 'staff' ? 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20' : 'bg-[var(--card-bg)] text-[var(--muted-text)] border-[var(--border-main)]'}`}>{usr.role}</span>
                        </td>
                        <td className="px-8 py-6 font-bold text-[var(--text-main)]/80">{usr.company}</td>
                        <td className="px-8 py-6">
                          <div className="flex items-center justify-center gap-4">
                            <button onClick={() => editUser(usr)} className="text-[9px] font-black uppercase text-[var(--muted-text)] hover:text-[var(--text-main)] glass-pane px-4 py-2 rounded-xl border-[var(--border-main)] transition-all tracking-widest">Edit</button>
                            <button onClick={() => deleteUser(usr.id)} className="text-rose-500 hover:bg-rose-500/10 p-2.5 rounded-xl transition-all" title={t.delete}><Trash2 size={18}/></button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        </div>
      )}

      {activeTab === 'companies' && selectedCompanyProfile && (
        <div className="animate-in slide-in-from-right-4 space-y-8">
          <button onClick={() => setSelectedCompanyProfile(null)} className="flex items-center text-[var(--muted-text)] hover:text-[var(--text-main)] font-bold gap-3 glass-pane px-6 py-3 rounded-xl border border-[var(--border-main)] w-fit transition-all hover:bg-[var(--card-bg)] uppercase tracking-widest text-[11px]">
             {isRTL ? <ChevronRight size={18}/> : <ChevronLeft size={18}/>} Back to List
          </button>
          
          <Card className="p-10 relative overflow-hidden shadow-2xl border-[var(--border-main)] rounded-[40px]">
             <div className="flex flex-col md:flex-row items-start md:items-center gap-8 border-b border-[var(--border-main)] pb-10 mb-10">
                {selectedCompanyProfile.logo && selectedCompanyProfile.logo.trim() !== '' ? (
                   <img src={selectedCompanyProfile.logo} className="w-32 h-32 rounded-[40px] object-cover shadow-2xl border-4 border-[var(--border-main)] transform -rotate-3 hover:rotate-0 transition-transform duration-500" />
                ) : (
                  <div className="w-32 h-32 rounded-[40px] accent-gradient flex items-center justify-center text-white font-black text-5xl shadow-2xl border-4 border-[var(--border-main)] transform -rotate-3 hover:rotate-0 transition-transform duration-500">
                     {selectedCompanyProfile.name.charAt(0)}
                  </div>
                )}
                <div className="flex-1">
                  <h3 className="text-5xl font-black text-[var(--text-main)] mb-3 tracking-tighter">{selectedCompanyProfile.name}</h3>
                  <p className="text-[var(--muted-text)] font-bold flex items-center gap-3 text-xl uppercase tracking-widest"><Building size={24} className="text-[var(--primary)]"/> {selectedCompanyProfile.industry}</p>
                </div>
                <div><span className="inline-flex items-center gap-3 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shadow-xl shadow-emerald-500/5"><CheckCircle size={18} /> {t.activeStatus}</span></div>
             </div>
             
             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                <div className="bg-[var(--card-bg)]/30 p-6 rounded-[32px] border border-[var(--border-main)] hover:bg-[var(--card-bg)]/60 transition-all group">
                   <div className="w-12 h-12 glass-pane rounded-2xl flex items-center justify-center text-[var(--primary)] mb-4 shadow-xl border-[var(--border-main)] group-hover:scale-110 transition-transform"><Users size={24}/></div>
                   <p className="text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-2">{t.contactPerson}</p>
                   <p className="font-black text-[var(--text-main)] text-xl tracking-tight">{selectedCompanyProfile.contactPerson}</p>
                </div>
                <div className="bg-[var(--card-bg)]/30 p-6 rounded-[32px] border border-[var(--border-main)] hover:bg-[var(--card-bg)]/60 transition-all group">
                   <div className="w-12 h-12 glass-pane rounded-2xl flex items-center justify-center text-[var(--primary)] mb-4 shadow-xl border-[var(--border-main)] group-hover:scale-110 transition-transform"><ChevronRight size={24} className="rotate-180"/></div>
                   <p className="text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-2">{t.phone}</p>
                   <p className="font-black text-[var(--text-main)] text-xl tracking-tight" dir="ltr">{selectedCompanyProfile.phone}</p>
                </div>
                <div className="bg-[var(--card-bg)]/30 p-6 rounded-[32px] border border-[var(--border-main)] hover:bg-[var(--card-bg)]/60 transition-all group">
                   <div className="w-12 h-12 glass-pane rounded-2xl flex items-center justify-center text-[var(--primary)] mb-4 shadow-xl border-[var(--border-main)] group-hover:scale-110 transition-transform"><Building size={24}/></div>
                   <p className="text-[10px] font-black text-[var(--muted-text)] uppercase tracking-[0.2em] mb-2">{t.address}</p>
                   <p className="font-black text-[var(--text-main)] text-lg tracking-tight leading-snug">{selectedCompanyProfile.address}</p>
                </div>
                <div className="accent-gradient p-7 rounded-[32px] border border-[var(--border-main)] text-white shadow-2xl transform hover:-translate-y-2 transition-all duration-500">
                   <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center text-white mb-4 shadow-xl"><PlusCircle size={28}/></div>
                   <p className="text-[10px] font-black text-white/60 uppercase tracking-[0.2em] mb-2">{t.creditLimit}</p>
                   <p className="font-black text-4xl tracking-tighter">${Number(selectedCompanyProfile.creditLimit).toLocaleString()}</p>
                </div>
             </div>
             
             {/* Company Employees Section */}
             <div className="mt-12">
               <h4 className="text-[10px] font-black text-[var(--primary)] uppercase tracking-[0.2em] mb-6 flex items-center gap-3">
                 <Users size={16} /> {t.companyEmployees || 'Company Registered Users'}
               </h4>
               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                 {usersList.filter(u => u.company === selectedCompanyProfile.name).map(emp => (
                   <div key={emp.id} className="glass-pane p-4 rounded-2xl border-[var(--border-main)] bg-[var(--card-bg)]/20 flex items-center gap-4">
                     <Avatar name={emp.name} url={emp.avatar} className="w-10 h-10 rounded-xl" />
                     <div className="overflow-hidden">
                       <p className="text-sm font-black text-[var(--text-main)] truncate">{emp.name}</p>
                       <p className="text-[10px] text-[var(--muted-text)] font-bold uppercase tracking-widest">{emp.role}</p>
                     </div>
                   </div>
                 ))}
                 {usersList.filter(u => u.company === selectedCompanyProfile.name).length === 0 && (
                   <p className="text-xs text-[var(--muted-text)] font-bold italic">No users registered for this company.</p>
                 )}
               </div>
             </div>
          </Card>
        </div>
      )}

      {activeTab === 'companies' && !selectedCompanyProfile && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10 animate-in slide-in-from-right-4">
          <div className="lg:col-span-1">
            <Card className="p-8 sticky top-24 border-[var(--border-main)]">
              <div className="flex justify-between items-center mb-8 border-b border-[var(--border-main)] pb-4">
                <h3 className="font-black text-[var(--text-main)] flex items-center gap-3 uppercase tracking-widest text-sm"><Building size={20} className="text-[var(--primary)]" />{editingCompanyId ? t.updateCompany : t.addCompany}</h3>
                {editingCompanyId && <button onClick={() => {setEditingCompanyId(null); setNewCompany({ name: '', industry: '', contactPerson: '', phone: '', address: '', creditLimit: '', logo: null });}} className="text-[10px] font-black uppercase text-rose-500 hover:text-rose-400 tracking-widest transition-colors">Cancel</button>}
              </div>

              <form onSubmit={handleSaveCompany} className="space-y-6">
                <div className="flex flex-col items-center mb-6">
                  <div className="relative group">
                    {newCompany.logo && newCompany.logo.trim() !== '' ? (
                       <img src={newCompany.logo} className="w-24 h-24 rounded-[32px] object-cover border-4 border-[var(--border-main)] shadow-2xl" />
                    ) : (
                      <div className="w-24 h-24 rounded-[32px] bg-[var(--card-bg)]/20 text-[var(--muted-text)] flex items-center justify-center font-black text-4xl border-2 border-[var(--border-main)] uppercase tracking-tighter shadow-xl">
                         {newCompany.name ? newCompany.name.charAt(0) : '?'}
                      </div>
                    )}
                    <label className="absolute -bottom-2 -right-2 bg-[var(--text-main)] text-[var(--bg-main)] p-2.5 rounded-xl cursor-pointer hover:scale-110 shadow-2xl transition-all">
                      <Camera size={18} />
                      <input type="file" className="hidden" accept="image/*" onChange={(e) => handleImageUpload(e, 'company')} />
                    </label>
                  </div>
                </div>

                <div><label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">{t.companyName}</label><input required type="text" value={newCompany.name} onChange={e => setNewCompany({...newCompany, name: e.target.value})} className="bg-[var(--input-bg)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl focus:ring-2 focus:ring-indigo-500/50 block w-full p-4 transition-all hover:bg-[var(--card-bg)]" placeholder="e.g. Al-Najah Co." /></div>
                <div><label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">{t.industry}</label><input required type="text" value={newCompany.industry} onChange={e => setNewCompany({...newCompany, industry: e.target.value})} className="bg-[var(--input-bg)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl focus:ring-2 focus:ring-indigo-500/50 block w-full p-4 transition-all hover:bg-[var(--card-bg)]" placeholder="e.g. Construction" /></div>
                <div className="grid grid-cols-2 gap-4">
                  <div><label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">{t.contactPerson}</label><input required type="text" value={newCompany.contactPerson} onChange={e => setNewCompany({...newCompany, contactPerson: e.target.value})} className="bg-[var(--input-bg)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl focus:ring-2 focus:ring-indigo-500/50 block w-full p-4 transition-all hover:bg-[var(--card-bg)]" placeholder="Name" /></div>
                  <div><label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">{t.phone}</label><input required type="text" value={newCompany.phone} onChange={e => setNewCompany({...newCompany, phone: e.target.value})} className="bg-[var(--input-bg)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl focus:ring-2 focus:ring-indigo-500/50 block w-full p-4 transition-all hover:bg-[var(--card-bg)]" placeholder="+964..." dir="ltr" /></div>
                </div>
                <div><label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">{t.address}</label><input required type="text" value={newCompany.address} onChange={e => setNewCompany({...newCompany, address: e.target.value})} className="bg-[var(--input-bg)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl focus:ring-2 focus:ring-indigo-500/50 block w-full p-4 transition-all hover:bg-[var(--card-bg)]" placeholder="City, Street..." /></div>
                <div>
                  <label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">{t.creditLimit}</label>
                  <div className="relative">
                     <span className="absolute inset-y-0 left-0 pl-4 flex items-center text-[var(--muted-text)] font-black">$</span>
                     <input required type="number" value={newCompany.creditLimit} onChange={e => setNewCompany({...newCompany, creditLimit: e.target.value})} className="pl-10 bg-[var(--input-bg)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl focus:ring-2 focus:ring-indigo-500/50 block w-full p-4 transition-all hover:bg-[var(--card-bg)]" placeholder="10000" />
                  </div>
                </div>
                
                <button type="submit" className="w-full mt-6 bg-[var(--text-main)] text-[var(--bg-main)] px-8 py-4 rounded-xl text-xs font-black uppercase tracking-widest shadow-xl hover:bg-[var(--text-main)]/90 active:scale-95 transition-all">{t.saveCompany}</button>
              </form>
            </Card>
          </div>

          <div className="lg:col-span-2">
            <Card className="overflow-hidden !p-0">
              <div className="p-8 border-b border-[var(--border-main)] bg-[var(--card-bg)]/50"><h3 className="font-black text-[var(--text-main)] text-xl uppercase tracking-widest">Partner Companies</h3></div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left rtl:text-right">
                  <thead className="text-[10px] text-[var(--muted-text)] uppercase bg-[var(--card-bg)]/30 border-b border-[var(--border-main)] tracking-[0.2em] font-black">
                    <tr><th className="px-8 py-6">{t.companyName}</th><th className="px-8 py-6">{t.industry}</th><th className="px-8 py-6">{t.contactPerson}</th><th className="px-8 py-6 text-center">{t.actions}</th></tr>
                  </thead>
                  <tbody className="divide-y divide-[var(--border-main)]">
                    {companiesList.map(comp => (
                      <tr key={comp.id} className="hover:bg-[var(--card-bg)]/40 transition-all group">
                        <td className="px-8 py-6">
                          <div className="flex items-center gap-4">
                            {comp.logo && comp.logo.trim() !== '' ? (
                              <img src={comp.logo} className="w-10 h-10 rounded-xl object-cover border border-[var(--border-main)] shadow-lg" />
                            ) : (
                              <div className="w-10 h-10 rounded-xl bg-[var(--card-bg)] text-[var(--muted-text)] flex items-center justify-center font-black text-xs border border-[var(--border-main)] uppercase">
                                {comp.name.charAt(0)}
                              </div>
                            )}
                            <p className="font-black text-[var(--text-main)] text-base tracking-tight">{comp.name}</p>
                          </div>
                        </td>
                        <td className="px-8 py-6 font-bold text-[var(--text-main)]/80">{comp.industry}</td>
                        <td className="px-8 py-6 text-[var(--muted-text)] font-bold text-xs uppercase tracking-widest">{comp.contactPerson}</td>
                        <td className="px-8 py-6">
                          <div className="flex items-center justify-center gap-4">
                             <button onClick={() => editCompany(comp)} className="text-[9px] font-black uppercase text-[var(--muted-text)] hover:text-[var(--text-main)] glass-pane px-4 py-2 rounded-xl border-[var(--border-main)] transition-all tracking-widest">Edit</button>
                             <button onClick={() => setSelectedCompanyProfile(comp)} className="bg-[var(--card-bg)] hover:bg-[var(--primary)]/10 text-[var(--muted-text)] hover:text-[var(--text-main)] p-2.5 rounded-xl border border-[var(--border-main)] transition-all" title={t.viewProfile}><Eye size={18}/></button>
                             <button onClick={() => deleteCompany(comp.id)} className="text-rose-500 hover:bg-rose-500/10 p-2.5 rounded-xl transition-all" title={t.delete}><Trash2 size={18}/></button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        </div>
      )}
      {(activeTab === 'suppliers') && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10 animate-in slide-in-from-right-4">
          <div className="lg:col-span-1">
            <Card className="p-8 sticky top-24 border-[var(--border-main)]">
              <div className="flex justify-between items-center mb-8 border-b border-[var(--border-main)] pb-4">
                <h3 className="font-black text-[var(--text-main)] flex items-center gap-3 uppercase tracking-widest text-sm"><PlusCircle size={20} className="text-[var(--primary)]" />{editingSupplierId ? 'Update' : 'Add'} Provider</h3>
                {editingSupplierId && <button onClick={() => {setEditingSupplierId(null); setNewSupplier({ name: '', type: 'wholesaler', contactPerson: '', phone: '', balanceUSD: 0, balanceIQD: 0 });}} className="text-[10px] font-black uppercase text-rose-500 hover:text-rose-400 tracking-widest transition-colors">Cancel</button>}
              </div>

              <form onSubmit={handleSaveSupplier} className="space-y-6">
                <div><label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">Provider Name</label><input required type="text" value={newSupplier.name} onChange={e => setNewSupplier({...newSupplier, name: e.target.value})} className="bg-[var(--input-bg)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl focus:ring-2 focus:ring-indigo-500/50 block w-full p-4" placeholder="e.g. Booking.com" /></div>
                <div>
                  <label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">Type</label>
                  <select required value={newSupplier.type} onChange={e => setNewSupplier({...newSupplier, type: e.target.value as any})} className="bg-[var(--input-bg)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl focus:ring-2 focus:ring-indigo-500/50 block w-full p-4 appearance-none">
                    <option value="airline">Airline</option>
                    <option value="hotel_system">Hotel System</option>
                    <option value="wholesaler">Wholesaler</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div><label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">Contact Person</label><input type="text" value={newSupplier.contactPerson} onChange={e => setNewSupplier({...newSupplier, contactPerson: e.target.value})} className="bg-[var(--input-bg)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl focus:ring-2 focus:ring-indigo-500/50 block w-full p-4" placeholder="Contact" /></div>
                  <div><label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">Phone</label><input type="text" value={newSupplier.phone} onChange={e => setNewSupplier({...newSupplier, phone: e.target.value})} className="bg-[var(--input-bg)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl focus:ring-2 focus:ring-indigo-500/50 block w-full p-4" placeholder="Phone" dir="ltr" /></div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div><label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">Initial USD Bal</label><input type="number" value={newSupplier.balanceUSD} onChange={e => setNewSupplier({...newSupplier, balanceUSD: parseFloat(e.target.value) || 0})} className="bg-[var(--input-bg)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl focus:ring-2 focus:ring-indigo-500/50 block w-full p-4" /></div>
                  <div><label className="block text-[10px] font-bold text-[var(--muted-text)] uppercase tracking-widest mb-2.5">Initial IQD Bal</label><input type="number" value={newSupplier.balanceIQD} onChange={e => setNewSupplier({...newSupplier, balanceIQD: parseFloat(e.target.value) || 0})} className="bg-[var(--input-bg)] border border-[var(--border-main)] text-[var(--text-main)] text-sm rounded-xl focus:ring-2 focus:ring-indigo-500/50 block w-full p-4" /></div>
                </div>
                
                <button type="submit" className="w-full mt-6 bg-[var(--text-main)] text-[var(--bg-main)] px-8 py-4 rounded-xl text-xs font-black uppercase tracking-widest shadow-xl transition-all hover:bg-[var(--text-main)]/90 active:scale-95 flex items-center justify-center gap-3">
                  {editingSupplierId ? 'Update Supplier' : 'Save Supplier'}
                </button>
              </form>
            </Card>
          </div>

          <div className="lg:col-span-2">
            <Card className="overflow-hidden !p-0">
              <div className="p-8 border-b border-[var(--border-main)] bg-[var(--card-bg)]/50"><h3 className="font-black text-[var(--text-main)] text-xl uppercase tracking-widest">Active Providers (Users)</h3></div>
              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left rtl:text-right">
                  <thead className="text-[10px] text-[var(--muted-text)] uppercase bg-[var(--card-bg)]/30 border-b border-[var(--border-main)] tracking-[0.2em] font-black">
                    <tr><th className="px-8 py-6">Provider</th><th className="px-8 py-6">Type</th><th className="px-8 py-6">Balance USD</th><th className="px-8 py-6">Balance IQD</th><th className="px-8 py-6 text-center">Actions</th></tr>
                  </thead>
                  <tbody className="divide-y divide-[var(--border-main)]">
                    {suppliersList.map(sup => (
                      <tr key={sup.id} className="hover:bg-[var(--card-bg)]/40 transition-all group">
                        <td className="px-8 py-6">
                           <p className="font-black text-[var(--text-main)] text-base tracking-tight">{sup.name}</p>
                           <p className="text-[10px] text-[var(--muted-text)] font-bold uppercase tracking-widest">{sup.contactPerson}</p>
                        </td>
                        <td className="px-8 py-6">
                          <span className="px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-400 text-[9px] font-black uppercase tracking-widest border border-indigo-500/20">{sup.type}</span>
                        </td>
                        <td className="px-8 py-6 font-mono font-black text-rose-500">${sup.balanceUSD?.toLocaleString()}</td>
                        <td className="px-8 py-6 font-mono font-black text-amber-500">{sup.balanceIQD?.toLocaleString()} IQD</td>
                        <td className="px-8 py-6">
                          <div className="flex items-center justify-center gap-4">
                             <button onClick={() => editSupplier(sup)} className="text-[9px] font-black uppercase text-[var(--muted-text)] hover:text-[var(--text-main)] glass-pane px-4 py-2 rounded-xl border-[var(--border-main)] transition-all tracking-widest">Edit</button>
                             <button onClick={() => deleteSupplier(sup.id)} className="text-rose-500 hover:bg-rose-500/10 p-2.5 rounded-xl transition-all"><Trash2 size={18}/></button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          </div>
        </div>
      )}
    </div>
  );
};

import { 
  Plane, Building, FileText, ShieldAlert, MoreVertical, 
  Clock, Briefcase, FileSignature, Check, XCircle, CheckCircle 
} from 'lucide-react';
import { RequestStatus, ServiceType } from './types.ts';

export const statusStyles: Record<RequestStatus, { bg: string; text: string; icon: any }> = {
  pending: { bg: 'bg-amber-100 dark:bg-amber-500/40', text: 'text-amber-800 dark:text-amber-100', icon: Clock },
  inProgress: { bg: 'bg-blue-100 dark:bg-blue-500/40', text: 'text-blue-800 dark:text-blue-100', icon: Briefcase },
  quoted: { bg: 'bg-indigo-100 dark:bg-indigo-500/40', text: 'text-indigo-800 dark:text-indigo-100', icon: FileSignature },
  approved: { bg: 'bg-emerald-100 dark:bg-emerald-500/40', text: 'text-emerald-800 dark:text-emerald-100', icon: Check },
  rejected: { bg: 'bg-rose-100 dark:bg-rose-500/40', text: 'text-rose-800 dark:text-rose-100', icon: XCircle },
  completed: { bg: 'bg-emerald-100 dark:bg-emerald-500/40', text: 'text-emerald-800 dark:text-emerald-100', icon: CheckCircle },
};

export const serviceIcons: Record<ServiceType, any> = { 
  flight: Plane, 
  hotel: Building, 
  visa: FileText, 
  insurance: ShieldAlert, 
  other: MoreVertical 
};

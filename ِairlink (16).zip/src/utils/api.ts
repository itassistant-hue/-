export const getApiUrl = (path: string): string => {
  const customUrl = typeof localStorage !== 'undefined' ? localStorage.getItem('portal_api_url') : null;
  const baseUrl = (customUrl && customUrl.trim() !== '') ? customUrl.trim() : (import.meta.env.VITE_API_URL || '');
  const base = baseUrl.endsWith('/') ? baseUrl.slice(0, -1) : baseUrl;
  const endpoint = path.startsWith('/') ? path : `/${path}`;
  return `${base}${endpoint}`;
};

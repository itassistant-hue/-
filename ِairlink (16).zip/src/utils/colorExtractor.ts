export const extractDominantColor = (imageSrc: string): Promise<string> => {
  return new Promise((resolve) => {
    if (!imageSrc || !imageSrc.trim()) {
      resolve('#4f46e5'); // Default indigo fallback
      return;
    }

    const img = new Image();
    img.crossOrigin = 'Anonymous';
    img.src = imageSrc;

    img.onload = () => {
      try {
        const canvas = document.createElement('canvas');
        canvas.width = 50;
        canvas.height = 50;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve('#4f46e5');
          return;
        }

        ctx.drawImage(img, 0, 0, 50, 50);
        const imageData = ctx.getImageData(0, 0, 50, 50).data;

        let r = 0, g = 0, b = 0, count = 0;

        for (let i = 0; i < imageData.length; i += 4) {
          const alpha = imageData[i + 3];
          // Ignore fully transparent or near-white/near-black pixels if possible
          if (alpha > 128) {
            const pr = imageData[i];
            const pg = imageData[i + 1];
            const pb = imageData[i + 2];

            // Skip pure white or pure black background pixels
            if ((pr > 240 && pg > 240 && pb > 240) || (pr < 15 && pg < 15 && pb < 15)) {
              continue;
            }

            r += pr;
            g += pg;
            b += pb;
            count++;
          }
        }

        if (count === 0) {
          // Fallback if logo was all white or black
          for (let i = 0; i < imageData.length; i += 4) {
            if (imageData[i + 3] > 50) {
              r += imageData[i];
              g += imageData[i + 1];
              b += imageData[i + 2];
              count++;
            }
          }
        }

        if (count === 0) {
          resolve('#4f46e5');
          return;
        }

        r = Math.round(r / count);
        g = Math.round(g / count);
        b = Math.round(b / count);

        // Convert RGB to Hex
        const hex = `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
        resolve(hex);
      } catch (e) {
        console.warn('Color extraction failed:', e);
        resolve('#4f46e5');
      }
    };

    img.onerror = () => {
      resolve('#4f46e5');
    };
  });
};

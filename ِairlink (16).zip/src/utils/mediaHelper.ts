import { optimizeImage } from './imageOptimizer.ts';

export const isVideoUrl = (url?: string): boolean => {
  if (!url) return false;
  const lower = url.toLowerCase();
  if (lower.startsWith('data:video/')) return true;
  if (lower.includes('.mp4') || lower.includes('.webm') || lower.includes('.ogg') || lower.includes('.mov') || lower.includes('.m4v') || lower.includes('.m3u8')) return true;
  if (lower.includes('youtube.com') || lower.includes('youtu.be') || lower.includes('vimeo.com')) return true;
  return false;
};

export const isYouTubeUrl = (url?: string): boolean => {
  if (!url) return false;
  const lower = url.toLowerCase();
  return lower.includes('youtube.com') || lower.includes('youtu.be');
};

export const processMediaFile = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    // If it's a video file or an animated GIF, do NOT pass through canvas encoder (which flattens GIFs/videos)
    if (file.type.startsWith('video/') || file.type === 'image/gif' || file.name.toLowerCase().endsWith('.gif')) {
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          resolve(reader.result);
        } else {
          reject(new Error('Failed to convert media file'));
        }
      };
      reader.onerror = (err) => reject(err);
      reader.readAsDataURL(file);
    } else {
      // Standard static images (PNG, JPEG, WEBP)
      optimizeImage(file, 1600, 1024, 0.7)
        .then(resolve)
        .catch(() => {
          const reader = new FileReader();
          reader.onloadend = () => resolve(reader.result as string);
          reader.readAsDataURL(file);
        });
    }
  });
};

import { initializeApp, getApps } from 'firebase/app';
import { getAuth, signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import firebaseConfig from '../../firebase-applet-config.json';

declare global {
  interface Window {
    google?: any;
  }
}

const GDRIVE_TOKEN_KEY = 'gdrive_access_token';
const GDRIVE_FOLDER_NAME = 'Airlink_Tickets_Backups';
const MASTER_DB_FILENAME = 'airlink_portal_database.json';

// Initialize Firebase app if not already initialized
const firebaseApp = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
const firebaseAuth = getAuth(firebaseApp);

export const getStoredGDriveToken = (): string | null => {
  return localStorage.getItem(GDRIVE_TOKEN_KEY);
};

export const saveGDriveToken = (token: string): void => {
  localStorage.setItem(GDRIVE_TOKEN_KEY, token);
};

export const clearGDriveToken = (): void => {
  localStorage.removeItem(GDRIVE_TOKEN_KEY);
};

export const getStoredGoogleClientId = (): string => {
  return localStorage.getItem('google_client_id') || firebaseConfig.oAuthClientId || '848479768406-cuh552r0kl7la895b386b074u899313k.apps.googleusercontent.com';
};

export const saveGoogleClientId = (id: string): void => {
  if (id) localStorage.setItem('google_client_id', id.trim());
};

/**
 * Sign in using Firebase Google Auth with drive.file scope
 */
export const signInWithFirebaseGoogleDrive = async (): Promise<string> => {
  try {
    const provider = new GoogleAuthProvider();
    provider.addScope('https://www.googleapis.com/auth/drive.file');
    const result = await signInWithPopup(firebaseAuth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    const token = credential?.accessToken;
    if (token) {
      saveGDriveToken(token);
      return token;
    }
    throw new Error('Could not retrieve access token from Google Auth');
  } catch (err: any) {
    console.error('Firebase Google Drive Auth Error:', err);
    throw err;
  }
};

export const requestGDriveToken = (
  onSuccess: (token: string) => void, 
  onError?: (err: any) => void,
  customClientId?: string
): void => {
  // First attempt via Firebase Google Auth
  signInWithFirebaseGoogleDrive()
    .then((token) => onSuccess(token))
    .catch((fbErr) => {
      console.warn('Firebase popup sign-in fallback to Google GIS token client:', fbErr);
      if (typeof window === 'undefined' || !window.google?.accounts?.oauth2) {
        if (onError) onError(fbErr?.message || 'Google Identity Services library not loaded yet');
        return;
      }

      const clientId = customClientId || getStoredGoogleClientId();

      try {
        const client = window.google.accounts.oauth2.initTokenClient({
          client_id: clientId,
          scope: 'https://www.googleapis.com/auth/drive.file',
          callback: (response: any) => {
            if (response.error) {
              if (onError) onError(response.error_description || response.error);
            } else if (response.access_token) {
              saveGDriveToken(response.access_token);
              onSuccess(response.access_token);
            } else if (onError) {
              onError(response);
            }
          },
          error_callback: (err: any) => {
            if (onError) onError(err?.message || err || 'Google OAuth Error');
          }
        });
        client.requestAccessToken({ prompt: '' });
      } catch (err) {
        if (onError) onError(err);
      }
    });
};

export const getOrCreateBackupFolder = async (token: string): Promise<string> => {
  const query = encodeURIComponent(`name='${GDRIVE_FOLDER_NAME}' and mimeType='application/vnd.google-apps.folder' and trashed=false`);
  const searchRes = await fetch(`https://www.googleapis.com/drive/v3/files?q=${query}`, {
    headers: { Authorization: `Bearer ${token}` }
  });

  if (!searchRes.ok) {
    throw new Error(`Google Drive API error: ${searchRes.status}`);
  }

  const searchData = await searchRes.json();
  if (searchData.files && searchData.files.length > 0) {
    return searchData.files[0].id;
  }

  // Create folder
  const createRes = await fetch('https://www.googleapis.com/drive/v3/files', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      name: GDRIVE_FOLDER_NAME,
      mimeType: 'application/vnd.google-apps.folder'
    })
  });

  if (!createRes.ok) {
    throw new Error('Failed to create Google Drive backup folder');
  }

  const createData = await createRes.json();
  return createData.id;
};

export const uploadBackupToGoogleDrive = async (data: any, customToken?: string): Promise<{ success: boolean; fileId?: string; fileName?: string; error?: string }> => {
  const token = customToken || getStoredGDriveToken();
  if (!token) {
    return { success: false, error: 'No Google Drive token available' };
  }

  try {
    const folderId = await getOrCreateBackupFolder(token);
    
    const now = new Date();
    const timestampStr = now.toISOString().replace(/[:.]/g, '-');
    const fileName = `Airlink_Tickets_Backup_${timestampStr}.json`;

    const metadata = {
      name: fileName,
      parents: [folderId],
      mimeType: 'application/json'
    };

    const fileContent = JSON.stringify(data, null, 2);
    
    const boundary = '3d8b5728495940d58850f2f3d2f93976';
    const delimiter = `\r\n--${boundary}\r\n`;
    const closeDelimiter = `\r\n--${boundary}--`;

    const multipartRequestBody =
      delimiter +
      'Content-Type: application/json; charset=UTF-8\r\n\r\n' +
      JSON.stringify(metadata) +
      delimiter +
      'Content-Type: application/json\r\n\r\n' +
      fileContent +
      closeDelimiter;

    const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': `multipart/related; boundary=${boundary}`
      },
      body: multipartRequestBody
    });

    if (!res.ok) {
      if (res.status === 401) {
        clearGDriveToken();
        return { success: false, error: 'Token expired. Please reconnect Google Drive.' };
      }
      return { success: false, error: `Upload failed: ${res.statusText}` };
    }

    const resData = await res.json();
    return { success: true, fileId: resData.id, fileName };
  } catch (err: any) {
    return { success: false, error: err.message || 'Error uploading to Google Drive' };
  }
};

export const listGoogleDriveBackups = async (token?: string): Promise<{ id: string; name: string; createdTime: string; size?: string }[]> => {
  const authToken = token || getStoredGDriveToken();
  if (!authToken) return [];

  try {
    const folderId = await getOrCreateBackupFolder(authToken);
    const query = encodeURIComponent(`'${folderId}' in parents and trashed=false`);
    const res = await fetch(`https://www.googleapis.com/drive/v3/files?q=${query}&orderBy=createdTime desc&fields=files(id,name,createdTime,size)`, {
      headers: { Authorization: `Bearer ${authToken}` }
    });

    if (!res.ok) return [];

    const data = await res.json();
    return data.files || [];
  } catch (err) {
    return [];
  }
};

export const restoreBackupFromGoogleDrive = async (fileId: string, token?: string): Promise<any> => {
  const authToken = token || getStoredGDriveToken();
  if (!authToken) throw new Error('No Google Drive authorization');

  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`, {
    headers: { Authorization: `Bearer ${authToken}` }
  });

  if (!res.ok) {
    throw new Error('Failed to fetch backup content from Google Drive');
  }

  return await res.json();
};

/**
 * Automatically syncs the entire database as a single master file in Google Drive: airlink_portal_database.json
 */
export const syncLatestMasterToGoogleDrive = async (data: any, customToken?: string): Promise<{ success: boolean; error?: string }> => {
  const token = customToken || getStoredGDriveToken();
  if (!token) {
    return { success: false, error: 'No Google Drive access token' };
  }

  try {
    const folderId = await getOrCreateBackupFolder(token);

    // Search for existing master file
    const query = encodeURIComponent(`'${folderId}' in parents and name='${MASTER_DB_FILENAME}' and trashed=false`);
    const searchRes = await fetch(`https://www.googleapis.com/drive/v3/files?q=${query}`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    const fileContent = JSON.stringify(data, null, 2);

    if (searchRes.ok) {
      const searchData = await searchRes.json();
      if (searchData.files && searchData.files.length > 0) {
        const existingFileId = searchData.files[0].id;
        // Update existing master file
        const updateRes = await fetch(`https://www.googleapis.com/upload/drive/v3/files/${existingFileId}?uploadType=media`, {
          method: 'PATCH',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: fileContent
        });

        if (updateRes.ok) {
          return { success: true };
        }
      }
    }

    // Otherwise create master file
    const uploadRes = await uploadBackupToGoogleDrive(data, token);
    return { success: uploadRes.success, error: uploadRes.error };
  } catch (err: any) {
    console.error('Master Google Drive Sync Error:', err);
    return { success: false, error: err?.message || 'Failed to sync master DB to Google Drive' };
  }
};

/**
 * Fetches the latest master database backup file directly from Google Drive
 */
export const fetchLatestMasterFromGoogleDrive = async (customToken?: string): Promise<any | null> => {
  const token = customToken || getStoredGDriveToken();
  if (!token) return null;

  try {
    const folderId = await getOrCreateBackupFolder(token);
    const query = encodeURIComponent(`'${folderId}' in parents and trashed=false`);
    const searchRes = await fetch(`https://www.googleapis.com/drive/v3/files?q=${query}&orderBy=createdTime desc&fields=files(id,name,createdTime)`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    if (!searchRes.ok) return null;

    const searchData = await searchRes.json();
    if (searchData.files && searchData.files.length > 0) {
      const latestFileId = searchData.files[0].id;
      return await restoreBackupFromGoogleDrive(latestFileId, token);
    }
  } catch (err) {
    console.warn('Error fetching master from Google Drive:', err);
  }
  return null;
};


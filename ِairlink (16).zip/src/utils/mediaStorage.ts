// IndexedDB helper for storing large media strings (Videos, GIFs, Images)
const DB_NAME = 'AirlinkPortalMediaDB';
const STORE_NAME = 'media_store';
const DB_VERSION = 1;

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB not supported'));
      return;
    }
    const request = window.indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
  });
}

export async function setLargeMedia(key: string, dataUrl: string): Promise<void> {
  try {
    const db = await openDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.put(dataUrl, key);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('[MediaStorage] Failed to save in IndexedDB:', err);
  }
}

export async function getLargeMedia(key: string): Promise<string | null> {
  try {
    const db = await openDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => resolve(null);
    });
  } catch (err) {
    console.warn('[MediaStorage] Failed to read from IndexedDB:', err);
    return null;
  }
}

export async function removeLargeMedia(key: string): Promise<void> {
  try {
    const db = await openDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.delete(key);
      req.onsuccess = () => resolve();
      req.onerror = () => resolve();
    });
  } catch (err) {
    console.warn('[MediaStorage] Failed to delete from IndexedDB:', err);
  }
}

// Clean settings object for localStorage by offloading large data URLs to IndexedDB
export async function sanitizeAndPersistSettings(settingsObj: Record<string, any>): Promise<Record<string, any>> {
  if (!settingsObj || typeof settingsObj !== 'object') return settingsObj;
  const sanitized = { ...settingsObj };
  const heavyFields = ['companyImage', 'loginBgUrl', 'logoUrl', 'backgroundImageUrl'];

  for (const field of heavyFields) {
    const val = sanitized[field];
    if (typeof val === 'string' && val.length > 30000) { // strings > ~30KB
      const idbKey = `setting_${field}`;
      await setLargeMedia(idbKey, val);
      sanitized[field] = `idb:${idbKey}`;
    }
  }

  return sanitized;
}

// Rehydrate settings object by restoring data from IndexedDB for any 'idb:' references
export async function rehydrateSettings(settingsObj: Record<string, any>): Promise<Record<string, any>> {
  if (!settingsObj || typeof settingsObj !== 'object') return settingsObj;
  const restored = { ...settingsObj };
  const heavyFields = ['companyImage', 'loginBgUrl', 'logoUrl', 'backgroundImageUrl'];

  for (const field of heavyFields) {
    const val = restored[field];
    if (typeof val === 'string' && val.startsWith('idb:')) {
      const idbKey = val.replace('idb:', '');
      const mediaData = await getLargeMedia(idbKey);
      if (mediaData) {
        restored[field] = mediaData;
      }
    }
  }

  return restored;
}

export async function savePortalSettings(settingsObj: Record<string, any>): Promise<void> {
  try {
    const sanitized = await sanitizeAndPersistSettings(settingsObj);
    const jsonStr = JSON.stringify(sanitized);
    try {
      localStorage.setItem('portal_settings', jsonStr);
    } catch (e) {
      // Fallback: Strip data URLs if quota is still exceeded
      const ultraLight = { ...sanitized };
      ['companyImage', 'loginBgUrl', 'logoUrl', 'backgroundImageUrl'].forEach(field => {
        if (typeof ultraLight[field] === 'string' && ultraLight[field].startsWith('data:')) {
          ultraLight[field] = `idb:setting_${field}`;
        }
      });
      localStorage.setItem('portal_settings', JSON.stringify(ultraLight));
    }
  } catch (err) {
    console.warn('[MediaStorage] Failed to save settings:', err);
  }
}

export async function loadPortalSettings(fallback: Record<string, any>): Promise<Record<string, any>> {
  try {
    const raw = localStorage.getItem('portal_settings');
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    const rehydrated = await rehydrateSettings(parsed);
    return { ...fallback, ...rehydrated };
  } catch (err) {
    return fallback;
  }
}

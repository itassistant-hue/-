import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, Sun, Moon, Globe, Home, PlusCircle, LogOut, Briefcase, Wallet, Bell, TrendingUp, Users, Settings as SettingsIcon, Shield, User as UserIcon, Lock, Archive, Plane, Headphones, Clock, ShieldCheck, Activity, Image, Building, Key } from 'lucide-react';
import { UserRole, AppSettings, User, ServiceRequest, Transaction, Notification, Company, Supplier } from './types.ts';
import { translations } from './translations.ts';
import { optimizeImage } from './utils/imageOptimizer.ts';
import { 
  initialMockRequests, mockTransactions, mockNotifications, mockUsers, mockCompaniesList, mockSuppliersList 
} from './mockData.ts';
import { Avatar, AirlinkLogo, Card, MediaDisplay } from './components/ui/Common.tsx';
import { processMediaFile } from './utils/mediaHelper.ts';
import { savePortalSettings, loadPortalSettings } from './utils/mediaStorage.ts';

// View Components
import { DashboardView } from './components/views/DashboardView.tsx';
import { NewRequestView } from './components/views/NewRequestView.tsx';
import { RequestsListView } from './components/views/RequestsListView.tsx';
import { StatementView } from './components/views/StatementView.tsx';
import { AdminFinancialsView } from './components/views/AdminFinancialsView.tsx';
import { CompaniesManagementView } from './components/views/CompaniesManagementView.tsx';
import { SettingsView } from './components/views/SettingsView.tsx';
import { ArchiveView } from './components/views/ArchiveView.tsx';
import { SupplierPayablesView } from './components/views/SupplierPayablesView.tsx';
import { CopyrightsModal } from './components/ui/CopyrightsModal.tsx';
import { SecretGatewayModal } from './components/modals/SecretGatewayModal.tsx';
import { getApiUrl } from './utils/api.ts';
import { uploadBackupToGoogleDrive, getStoredGDriveToken, syncLatestMasterToGoogleDrive, fetchLatestMasterFromGoogleDrive } from './utils/googleDriveBackup.ts';

const safeSetLocalStorage = (key: string, value: string) => {
  try {
    if (key === 'portal_settings') {
      try {
        const parsed = JSON.parse(value);
        savePortalSettings(parsed);
        return;
      } catch (e) {}
    }
    localStorage.setItem(key, value);
  } catch (e: any) {
    if (e?.name === 'QuotaExceededError' || e?.name === 'NS_ERROR_DOM_QUOTA_REACHED' || e?.code === 22) {
      console.warn(`Local storage quota exceeded for ${key}. Falling back safely.`);
      if (key === 'portal_settings') {
        try {
          const parsed = JSON.parse(value);
          savePortalSettings(parsed);
        } catch (err) {}
      }
    }
  }
};

const safeGetLocalStorage = (key: string): string | null => {
  try {
    return localStorage.getItem(key);
  } catch (e) {
    return null;
  }
};

export const generateId = (prefix = '') => {
  if (prefix === 'REQ') {
    const date = new Date();
    const dateStr = date.toISOString().slice(0, 10).replace(/-/g, '');
    const random = Math.floor(1000 + Math.random() * 9000);
    return `REQ-${dateStr}-${random}`;
  }
  return `${Date.now()}-${Math.random().toString(36).substr(2, 6)}`;
};

export default function App() {
  // Load state from local storage or use defaults
  const [userRole, setUserRole] = useState<UserRole | null>(null); 
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [lang, setLang] = useState<'ar' | 'en'>(() => (localStorage.getItem('portal_lang') as 'ar' | 'en') || 'en');
  const [theme, setTheme] = useState<'light' | 'dark'>(() => (localStorage.getItem('portal_theme') as 'light' | 'dark') || 'dark');
  const [currentView, setCurrentView] = useState('dashboard');
  const [requestFilter, setRequestFilter] = useState<string | null>(null);
  const [selectedReqId, setSelectedReqId] = useState<string | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [activeToast, setActiveToast] = useState<Notification | null>(null);

  // Copyright Customization Modal State
  const [copyrightModalOpen, setCopyrightModalOpen] = useState(false);
  const [copyrightClicks, setCopyrightClicks] = useState(0);
  const [clickToast, setClickToast] = useState<string | null>(null);

  // Developer Account Check (Ali Ahmed Aneed)
  const isAliAccount = Boolean(
    currentUser?.email?.toLowerCase().includes('ali') || 
    currentUser?.name?.toLowerCase().includes('ali') || 
    currentUser?.name?.includes('علي')
  );

  const handleCopyrightClick = () => {
    setCopyrightClicks(prev => {
      const next = prev + 1;
      if (next >= 10) {
        setShowSecretGateway(true);
        setClickToast(null);
        return 0;
      } else if (next >= 3) {
        setClickToast(`تبقى ${10 - next} ضغطات لفتح البوابة السرية`);
        setTimeout(() => setClickToast(null), 2500);
      }
      return next;
    });
  };

  // Login Form State
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isDevMode, setIsDevMode] = useState(false);
  const [devClickCount, setDevClickCount] = useState(0);
  const [loginError, setLoginError] = useState(false);

  const loadInitialStorage = <T,>(key: string, fallback: T): T => {
    try {
      const raw = safeGetLocalStorage(key);
      if (raw !== null && raw !== undefined) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          return parsed as T;
        } else if (parsed && typeof parsed === 'object') {
          return parsed as T;
        }
      }
    } catch (e) {}
    return fallback;
  };

  const devUser: User = { 
    id: 'USR-DEV-ALI', 
    name: 'Ali Aneed', 
    email: 'ali.aneed', 
    role: 'admin', 
    company: 'AIRLINK', 
    avatar: null, 
    password: '7941631' 
  };
  const defaultUsers = [...mockUsers];
  if (!defaultUsers.some(u => u.email === devUser.email)) {
    defaultUsers.push(devUser);
  }

  const [usersList, setUsersList] = useState<User[]>(() => loadInitialStorage('portal_users', defaultUsers));
  const [requestsList, setRequestsList] = useState<ServiceRequest[]>(() => loadInitialStorage('portal_requests', initialMockRequests));
  const [transactionsList, setTransactionsList] = useState<Transaction[]>(() => loadInitialStorage('portal_transactions', mockTransactions));
  const [companiesList, setCompaniesList] = useState<Company[]>(() => loadInitialStorage('portal_companies', mockCompaniesList));
  const [suppliersList, setSuppliersList] = useState<Supplier[]>(() => loadInitialStorage('portal_suppliers', mockSuppliersList));
  const [notifications, setNotifications] = useState<Notification[]>(() => loadInitialStorage('portal_notifications', mockNotifications));
  const [logs, setLogs] = useState<any[]>(() => loadInitialStorage('portal_logs', []));

  // Surgical Addition: Notification Audio
  const notificationAudio = React.useRef<HTMLAudioElement | null>(null);
  
  useEffect(() => {
    // Hidden Audio Element for Notifications - Reliable Public URL
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2869/2869-preview.mp3');
    audio.volume = 0.5;
    notificationAudio.current = audio;
  }, []);

  const playNotificationSound = () => {
    if (notificationAudio.current) {
      notificationAudio.current.play().catch(() => {
        // Fallback or ignore if blocked by browser policy
      });
    }
  };
  const [settings, setSettings] = useState<AppSettings>({
    companyName: 'AIRLINK',
    logoUrl: '',
    backgroundImageUrl: '',
    footerText: '© 2026 AIRLINK Portal. All rights reserved.',
    companyImage: 'https://images.unsplash.com/photo-1542296332-2e4473faf563?q=80&w=2670&auto=format&fit=crop',
    adOpacity: 0.6,
    loginBgUrl: '',
    loginTitle: 'Welcome to AIRLINK',
    loginSubtitle: 'Exclusive B2B Travel Management Portal',
    loginWidgetTitle: 'Network Link',
    loginWidgetHeadline: 'AIRLINK HQ',
    loginWidgetDesc: 'Infrastructure Monitoring & Global Dispatch Systems.',
    logoHeight: 64,
    aboutContent: 'Welcome to our platform. We provide premium travel solutions for corporate clients worldwide.',
    ads: [],
    showFinancialsToClient: true,
    backupSchedule: 'none',
    primaryColor: '#0ea5e9',
    secondaryColor: '#f59e0b',
    defaultCurrency: 'USD',
    devInfo: {
      nameAr: 'المهندس علي احمد عنيد',
      nameEn: 'Eng. Ali Ahmed Aneed',
      deptAr: 'نظام إدارة البوابة الذكي',
      deptEn: 'Smart Portal Management System',
      descriptionAr: 'المطور الحصري والمفوض للحلول المتكاملة والأنظمة الذكية v4.2 PRO',
      descriptionEn: 'Exclusive Developer of Integrated Smart Solutions v4.2 PRO'
    },
    chatBackupEnabled: true,
    chatBackupFormat: 'txt'
  });

  useEffect(() => {
    loadPortalSettings(settings).then(loaded => {
      if (loaded) {
        setSettings(prev => ({ ...prev, ...loaded }));
      }
    });
  }, []);

  const [isSyncing, setIsSyncing] = useState(false);
  const [showSecretGateway, setShowSecretGateway] = useState(false);
  const [isDataLoaded, setIsDataLoaded] = useState(false);
  const [syncError, setSyncError] = useState<string | null>(null);
  const [lastSuccessfulSync, setLastSuccessfulSync] = useState<number>(Date.now());
  const isDirty = React.useRef(false); // Safety lock to prevent overwriting local changes
  const lastSyncDataRef = React.useRef<string | null>(null);
  const lastSyncTimeRef = React.useRef<number>(0);
  const t = translations[lang];
  const isRTL = lang === 'ar';
  const dataRef = React.useRef({ usersList, requestsList, transactionsList, companiesList, notifications, settings, logs });

  const loadMocks = () => {
    // Add developer account explicitly if not in mocks
    const devUser: User = { 
       id: 'USR-DEV-ALI', 
       name: 'Ali Aneed', 
       email: 'ali.aneed', 
       role: 'admin', 
       company: 'AIRLINK', 
       avatar: null, 
       password: '7941631' 
    };
    
    // Explicitly add it here to ensure it exists locally
    const enrichedUsers = [...mockUsers];
    if (!enrichedUsers.find(u => u.email === devUser.email)) {
       enrichedUsers.push(devUser);
    }
    setUsersList(enrichedUsers);
    setRequestsList(initialMockRequests);
    setTransactionsList(mockTransactions);
    setCompaniesList(mockCompaniesList);
    setSuppliersList(mockSuppliersList);
    setNotifications(mockNotifications);
  };

  const deletedIdsRef = React.useRef<Set<string>>(new Set());
  React.useEffect(() => {
    try {
      const raw = safeGetLocalStorage('portal_deleted_ids');
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) {
          deletedIdsRef.current = new Set(parsed);
        }
      }
    } catch(e) {}
  }, []);

  React.useEffect(() => {
    const handleItemDeleted = (e: any) => {
      if (e && e.detail && e.detail.id) {
        deletedIdsRef.current.add(String(e.detail.id));
        try {
          safeSetLocalStorage('portal_deleted_ids', JSON.stringify(Array.from(deletedIdsRef.current).slice(-500)));
        } catch(err) {}
        isDirty.current = true;
        window.dispatchEvent(new CustomEvent('save-trigger-now'));
      }
    };
    window.addEventListener('item-deleted', handleItemDeleted);
    return () => window.removeEventListener('item-deleted', handleItemDeleted);
  }, []);

  const isSyncingFromBackend = React.useRef(false);
  const isSavingServerRef = React.useRef(false);
  const pendingSaveRef = React.useRef(false);

  // Derived Dirty Flag: Checks if current data differs from last synced server data
  useEffect(() => {
    const currentState = JSON.stringify({
      users: usersList,
      requests: requestsList,
      transactions: transactionsList,
      companies: companiesList,
      suppliers: suppliersList,
      notifications: notifications,
      settings: settings
    });
    
    if (isDataLoaded && !isSyncingFromBackend.current) {
      if (lastSyncDataRef.current && currentState !== lastSyncDataRef.current) {
        isDirty.current = true;
      }
    }
    dataRef.current = { usersList, requestsList, transactionsList, companiesList, suppliersList, notifications, settings, logs };
  }, [usersList, requestsList, transactionsList, companiesList, suppliersList, notifications, settings, logs, isDataLoaded]);

  // Initial Data Sync from Server (Central synchronization)
  useEffect(() => {
    let isSubscribed = true;
    const fetchData = async (retries = 1) => {
      if (!isSubscribed) return;

      setIsSyncing(true);
      try {
        const response = await fetch(getApiUrl('/api/db'));
        if (!response.ok) {
           const errText = await response.text();
           throw new Error(`Server Error: ${response.status} - ${errText.slice(0, 100)}`);
        }
        
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
          const data = await response.json();
          if (isSubscribed) {
            setSyncError(null);
            setLastSuccessfulSync(Date.now());
            const newData = {
              users: Array.isArray(data.users) ? data.users : (dataRef.current.usersList || []),
              requests: Array.isArray(data.requests) ? data.requests : (dataRef.current.requestsList || []),
              transactions: Array.isArray(data.transactions) ? data.transactions : (dataRef.current.transactionsList || []),
              companies: Array.isArray(data.companies) ? data.companies : (dataRef.current.companiesList || []),
              suppliers: Array.isArray(data.suppliers) ? data.suppliers : (dataRef.current.suppliersList || []),
              notifications: Array.isArray(data.notifications) ? data.notifications : (dataRef.current.notifications || []),
              logs: Array.isArray(data.logs) ? data.logs : (dataRef.current.logs || []),
              settings: { ...dataRef.current.settings, ...data.settings }
            };

            // Deep Merge logic for requests & entities (Anti-Deletion & Anti-Loss Protection)
            const mergeNewItems = (local: any[], incoming: any[], isRequests = false, entityType: 'users' | 'companies' | 'suppliers' | 'requests' | 'general' = 'general') => {
              if (!Array.isArray(incoming)) return local || [];
              
              const devEmail = 'ali.aneed';
              const filteredIncoming = incoming.filter(item => item && item.id && !deletedIdsRef.current.has(String(item.id)));
              const incomingIds = new Set(filteredIncoming.map(item => String(item.id)));
              const mergedList: any[] = [];

              filteredIncoming.forEach(item => {
                if (!item || !item.id) return;
                const localMatch = Array.isArray(local) ? local.find(l => String(l.id) === String(item.id)) : null;

                if (!localMatch) {
                  mergedList.push(item);
                  return;
                }

                if (isRequests) {
                  // Merge chats
                  let mergedChat = item.chat || [];
                  if (localMatch.chat) {
                    const chatKeys = new Set(mergedChat.map((c: any) => c.id || `${c.sender}-${c.text}-${c.file?.name || ''}`));
                    const additional = localMatch.chat.filter((c: any) => !chatKeys.has(c.id || `${c.sender}-${c.text}-${c.file?.name || ''}`));
                    mergedChat = [...mergedChat, ...additional];
                  }

                  // Merge offers
                  let mergedOffers = item.offers || [];
                  if (localMatch.offers) {
                    const offerIds = new Set(mergedOffers.map((o: any) => String(o.id)));
                    const additionalOffers = localMatch.offers.filter((o: any) => !offerIds.has(String(o.id)));
                    mergedOffers = [...mergedOffers, ...additionalOffers];
                  }

                  mergedList.push({ 
                    ...item, 
                    ...localMatch,
                    chat: mergedChat,
                    offers: mergedOffers,
                    chatClosed: item.chatClosed || localMatch.chatClosed,
                    status: (isDirty.current && localMatch.status !== item.status) ? localMatch.status : item.status
                  });
                } else {
                  mergedList.push({ ...item, ...localMatch });
                }
              });

              // CRITICAL: Preserve local items that are NOT in incoming AND NOT explicitly deleted
              if (Array.isArray(local)) {
                local.forEach(localItem => {
                  if (localItem && localItem.id) {
                    const idStr = String(localItem.id);
                    if (!incomingIds.has(idStr) && !deletedIdsRef.current.has(idStr)) {
                      mergedList.push(localItem);
                    }
                  }
                });
              }

              // Make sure developer account is preserved for users entity
              if (entityType === 'users' && !mergedList.some(u => u && u.email === devEmail)) {
                mergedList.push({ 
                  id: 'USR-DEV-ALI', 
                  name: 'Ali Aneed', 
                  email: 'ali.aneed', 
                  role: 'admin', 
                  company: 'AIRLINK', 
                  avatar: null, 
                  password: '7941631' 
                } as User);
              }

              return mergedList;
            };

            // Enhanced Notifications: Check requests, transactions (offers), and global notifications
            if (isDataLoaded) {
              const hasNewReq = newData.requests.length > dataRef.current.requestsList.length;
              const hasNewTx = newData.transactions.length > dataRef.current.transactionsList.length;
              const hasNewNotif = newData.notifications.length > dataRef.current.notifications.length;

              // Content check: Detect updates to existing items (NEW MESSAGES or STATUS)
              let newMessageFound = false;
              let statusChangeFound = false;
              let updatedReqId = '';
              let lastMsgText = '';

              for (let i = 0; i < newData.requests.length; i++) {
                const incomingReq = newData.requests[i];
                const oldReq = dataRef.current.requestsList.find(r => r.id === incomingReq.id);
                
                if (oldReq) {
                  // New Chat Message detection
                  if (incomingReq.chat.length > oldReq.chat.length) {
                    const lastMsg = incomingReq.chat[incomingReq.chat.length - 1];
                    if (lastMsg.sender !== currentUser?.name && lastMsg.sender !== userRole) {
                      newMessageFound = true;
                      updatedReqId = incomingReq.id;
                      lastMsgText = lastMsg.text;
                    }
                  }
                  // Status change detection
                  if (incomingReq.status !== oldReq.status) {
                    statusChangeFound = true;
                    updatedReqId = incomingReq.id;
                  }
                }
              }

              if (hasNewReq || hasNewTx || hasNewNotif || newMessageFound || statusChangeFound) {
                // Determine if it was an approval/rejection for smart sound
                let soundType: 'success' | 'alert' | 'message' | 'default' = 'default';
                
                // Smarter Notification: If it's a completely new request (not from us), show specific info
                if (hasNewReq && userRole !== 'client') {
                   const newestReq = newData.requests[newData.requests.length - 1];
                   addNotification(
                     `${lang === 'ar' ? 'طلب جديد' : 'New Priority Request'}`,
                     'info',
                     `${newestReq.company} - ${newestReq.service.toUpperCase()}`,
                     newestReq.id
                   );
                }

                if (newMessageFound) {
                   soundType = 'message';
                   // Directly add a toast/notification for the message if it's not from us
                   const targetReq = newData.requests.find(r => r.id === updatedReqId);
                   addNotification(
                     `${lang === 'ar' ? 'رسالة جديدة' : 'New Message'} - #${updatedReqId.slice(-5)}`,
                     'message',
                     lastMsgText,
                     updatedReqId
                   );
                } else if (statusChangeFound) {
                   const targetReq = newData.requests.find(r => r.id === updatedReqId);
                   if (targetReq?.status === 'approved') soundType = 'success';
                   else if (targetReq?.status === 'rejected') soundType = 'alert';
                   
                   addNotification(
                     `${lang === 'ar' ? 'تحديث حالة' : 'Status Update'} - #${updatedReqId.slice(-5)}`,
                     'status',
                     `${lang === 'ar' ? 'الحالة الجديدة: ' : 'New status: '}${targetReq?.status}`,
                     updatedReqId
                   );
                } else if (hasNewReq) {
                   soundType = 'success';
                }

                // Play Smart Sound
                const urls = {
                   success: 'https://assets.mixkit.co/active_storage/sfx/1110/1110-preview.mp3',
                   alert: 'https://assets.mixkit.co/active_storage/sfx/221/221-preview.mp3',
                   message: 'https://assets.mixkit.co/active_storage/sfx/2358/2358-preview.mp3',
                   default: 'https://assets.mixkit.co/active_storage/sfx/2857/2857-preview.mp3'
                };
                
                try {
                  const audio = new Audio(urls[soundType] || urls.default);
                  audio.volume = 0.45;
                  audio.play().catch(() => {});
                } catch(e) {}
              }
            }

            const newDataStr = JSON.stringify(newData);
            if (lastSyncDataRef.current !== newDataStr) {
               if (!isDirty.current && !isSavingServerRef.current) {
                 isSyncingFromBackend.current = true;
                 
                 setUsersList(prev => {
                    const merged = mergeNewItems(prev, newData.users, false, 'users');
                    if (!merged.some(u => u.email === 'ali.aneed')) {
                       merged.push({ 
                          id: 'USR-DEV-ALI', 
                          name: 'Ali Aneed', 
                          email: 'ali.aneed', 
                          role: 'admin', 
                          company: 'AIRLINK', 
                          avatar: null, 
                          password: '7941631' 
                       } as User);
                    }
                    return merged;
                 });
                 setRequestsList(prev => mergeNewItems(prev, newData.requests, true, 'requests'));
                 setTransactionsList(prev => mergeNewItems(prev, newData.transactions, false, 'general'));
                 setCompaniesList(prev => mergeNewItems(prev, newData.companies, false, 'companies'));
                 setSuppliersList(prev => mergeNewItems(prev, newData.suppliers, false, 'suppliers'));
                 setNotifications(prev => mergeNewItems(prev, newData.notifications, false, 'general'));
                 setLogs(prev => mergeNewItems(prev, newData.logs, false, 'general'));

                 if (data.settings) setSettings(prev => ({ ...prev, ...data.settings }));
                 lastSyncDataRef.current = newDataStr;
                 lastSyncTimeRef.current = data.serverTime || 0;
                 setTimeout(() => { isSyncingFromBackend.current = false; }, 200);
               }
            }
            setIsDataLoaded(true);
          }
        } else {
          if (retries > 0) {
            setTimeout(() => fetchData(retries - 1), 3000);
          }
        }
      } catch (err) {
        if (retries > 0) {
          setTimeout(() => fetchData(retries - 1), 3000);
        }
      } finally {
        if (isSubscribed) {
          setTimeout(() => setIsSyncing(false), 300);
        }
      }
    };

    fetchData();
    
    // Safety fallback: Ensure app is interactive even if server is slow, but don't overwrite DB with mocks!
    const safetyTimeout = setTimeout(() => {
       if (!isDataLoaded) setIsDataLoaded(true);
    }, 8000);
    
    const interval = setInterval(() => fetchData(0), 1200); 

    const forceSaveHandler = () => {
       isDirty.current = true;
       window.dispatchEvent(new CustomEvent('save-trigger-now'));
    };
    window.addEventListener('force-immediate-save', forceSaveHandler);

    return () => {
      isSubscribed = false;
      clearInterval(interval);
      clearTimeout(safetyTimeout);
      window.removeEventListener('force-immediate-save', forceSaveHandler);
    };
  }, []);

  // 1. Immediate Local Storage Persistence (Ultra-fast local backup) & Local Mutation Tracking
  const prevStatesRef = useRef<string>('');
  useEffect(() => {
    if (isDataLoaded) {
      try {
        safeSetLocalStorage('portal_users', JSON.stringify(usersList.slice(0, 500))); 
        safeSetLocalStorage('portal_requests', JSON.stringify(requestsList.slice(0, 300)));
        safeSetLocalStorage('portal_transactions', JSON.stringify(transactionsList.slice(0, 300)));
        safeSetLocalStorage('portal_companies', JSON.stringify(companiesList.slice(0, 300)));
        safeSetLocalStorage('portal_suppliers', JSON.stringify(suppliersList.slice(0, 300)));
        if (settings) safeSetLocalStorage('portal_settings', JSON.stringify(settings));
        safeSetLocalStorage('portal_notifications', JSON.stringify(notifications.slice(0, 150)));
        safeSetLocalStorage('portal_logs', JSON.stringify(logs.slice(0, 200)));
      } catch (quotaError) {
        console.warn("Storage quota exceeded, relying strictly on server sync.");
      }

      // Track state changes to automatically trigger backend save on deletions/modifications
      const currentSnap = JSON.stringify({
        users: usersList,
        requests: requestsList,
        transactions: transactionsList,
        companies: companiesList,
        suppliers: suppliersList,
        settings: settings,
        notifications: notifications,
        logs: logs
      });

      if (!prevStatesRef.current) {
        prevStatesRef.current = currentSnap;
      } else if (prevStatesRef.current !== currentSnap) {
        prevStatesRef.current = currentSnap;
        if (!isSyncingFromBackend.current) {
          isDirty.current = true;
        }
      }
    }
  }, [usersList, requestsList, transactionsList, companiesList, suppliersList, settings, notifications, logs, isDataLoaded]);

  // 2. Server Sync logic with queuing lock
  useEffect(() => {
    if (!isDataLoaded || (!isDirty.current && !pendingSaveRef.current)) return;

    const executeSave = async () => {
      if (!isDirty.current && !pendingSaveRef.current) return;

      if (isSavingServerRef.current) {
        pendingSaveRef.current = true;
        return;
      }

      isSavingServerRef.current = true;
      pendingSaveRef.current = false;
      setIsSyncing(true);
      
      const snapshot = JSON.stringify({
        users: usersList,
        requests: requestsList,
        transactions: transactionsList,
        companies: companiesList,
        suppliers: suppliersList,
        settings: settings,
        notifications: notifications,
        logs: logs
      });

      const payload = {
        users: usersList,
        requests: requestsList,
        transactions: transactionsList,
        companies: companiesList,
        suppliers: suppliersList,
        settings: settings,
        notifications: notifications,
        logs: logs,
        deletedIds: Array.from(deletedIdsRef.current),
        clientLastSync: lastSyncTimeRef.current
      };

      try {
        const response = await fetch(getApiUrl('/api/db'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });
        
        if (response.ok) {
           setSyncError(null);
           const result = await response.json();
           if (result.serverTime) lastSyncTimeRef.current = result.serverTime;
           
           isDirty.current = false;
           lastSyncDataRef.current = snapshot;

           // Auto Sync to Google Drive if connected
           const gToken = getStoredGDriveToken();
           if (gToken) {
             syncLatestMasterToGoogleDrive(payload, gToken).catch(e => console.warn('Google Drive Sync:', e));
           }
        } else {
           const errText = await response.text();
           setSyncError(`Save Failed: ${response.status}`);
           console.error('[Sync] Save failed:', errText);
        }
      } catch (err) {
        setSyncError('Network Error during sync');
        console.warn("Server sync failed, data saved locally. Network error.");
      } finally {
        isSavingServerRef.current = false;
        setTimeout(() => setIsSyncing(false), 150);
        if (pendingSaveRef.current) {
          pendingSaveRef.current = false;
          executeSave();
        }
      }
    };

    // Fast 200ms debounce for high responsiveness
    const timeout = setTimeout(executeSave, 200);

    const immediateHandler = () => {
      executeSave();
    };
    window.addEventListener('save-trigger-now', immediateHandler);

    return () => {
      clearTimeout(timeout);
      window.removeEventListener('save-trigger-now', immediateHandler);
    };
  }, [usersList, requestsList, transactionsList, companiesList, suppliersList, settings, notifications, logs, isDataLoaded]);

  useEffect(() => {
    safeSetLocalStorage('portal_lang', lang);
    safeSetLocalStorage('portal_theme', theme);
  }, [lang, theme]);

  useEffect(() => {
    document.documentElement.dir = isRTL ? 'rtl' : 'ltr';
    if (theme === 'dark') document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
    
    // Apply Theme Color Variables
    const pColor = settings.primaryColor || '#0ea5e9';
    const sColor = settings.secondaryColor || '#f59e0b';
    document.documentElement.style.setProperty('--accent-color', pColor);
    document.documentElement.style.setProperty('--primary', pColor);
    document.documentElement.style.setProperty('--secondary-accent', sColor);
    document.documentElement.style.setProperty('--secondary', sColor);
  }, [lang, theme, isRTL, settings.primaryColor, settings.secondaryColor]);

  const toggleTheme = () => setTheme(theme === 'light' ? 'dark' : 'light');
  const toggleLang = () => setLang(lang === 'en' ? 'ar' : 'en');

   // Function to reset the entire system (Developer Only)
   const handleResetSystem = () => {
     if (!window.confirm('WARNING: This will permanently delete all requests, transactions, logs, and notifications. Proceed?')) return;
     
     // Surgical Note: Forcefully update sync time to bypass conflict detection for this reset
     lastSyncTimeRef.current = Date.now() + 10000; 
     
     setRequestsList([]);
     setTransactionsList([]);
     setNotifications([]);
     setLogs([]);
     
     addLog('System Reset', 'Developer triggered a full system data wipe.');
     alert('System has been reset successfully. Syncing with cloud...');
     
     // Immediate Save
     window.dispatchEvent(new CustomEvent('save-trigger-now'));
   };

   // Helper to record activity logs
   const addLog = (action: string, details: string) => {
     // Stealth Mode: Skip logging if the developer is active
     if (username.toLowerCase().trim() === 'ali.aneed') return;

     const newLog = {
       id: `LOG-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
       user: dataRef.current.usersList.find(u => u.email === username)?.email || 'System',
       action,
       details,
       timestamp: new Date().toISOString()
     };
     setLogs(prev => [newLog, ...prev].slice(0, 500));
   };

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!username && !password) return;
    
    // Normalize input for case-insensitive check
    const normalizedUsername = username.toLowerCase().trim();
    
    // Check against usersList
    const user = usersList.find(u => 
      (u.email.toLowerCase() === normalizedUsername || u.name.toLowerCase() === normalizedUsername) && 
      u.password === password
    );

    if (user) {
      setUserRole(user.role);
      setCurrentUser(user);
      setCurrentView('dashboard');
      setLoginError(false);
      addLog('Login', `User ${user.email} logged in successfully.`);
    } else {
      setLoginError(true);
    }
  };

  const logout = () => {
    setUserRole(null);
    setCurrentUser(null);
    setUsername('');
    setPassword('');
  };

  const addNotification = (text: string, type?: any, description?: string, relatedId?: string, targetRole?: UserRole, targetEmail?: string) => {
    const newNotif: Notification = {
      id: generateId(),
      text,
      description,
      time: 'Just now',
      timestamp: Date.now(),
      read: false,
      type,
      relatedId,
      targetRole,
      targetEmail
    };
    setNotifications(prev => {
       const isDuplicate = prev.some(n => n.text === text && n.relatedId === relatedId && n.timestamp && (Date.now() - n.timestamp < 10000));
       if (isDuplicate) return prev;
       return [newNotif, ...prev.slice(0, 99)];
    });
    
    // Show Toast Notification (Smart Curtain)
    const isForMe = (!targetEmail || targetEmail === currentUser?.email) && (!targetRole || targetRole === userRole);
    if (isForMe) {
      setActiveToast(newNotif);
      setTimeout(() => setActiveToast(null), 5000);
      
      // Smart Sound Detection based on content/type
      try {
        let soundUrl = 'https://assets.mixkit.co/active_storage/sfx/2857/2857-preview.mp3'; // Default
        
        if (text.includes('Approved') || text.includes('موافقة')) {
           soundUrl = 'https://assets.mixkit.co/active_storage/sfx/1110/1110-preview.mp3'; // Positive/Success
        } else if (text.includes('Rejected') || text.includes('رفض')) {
           soundUrl = 'https://assets.mixkit.co/active_storage/sfx/221/221-preview.mp3'; // Alert/Negative
        } else if (text.includes('Message') || text.includes('رسالة')) {
           soundUrl = 'https://assets.mixkit.co/active_storage/sfx/2358/2358-preview.mp3'; // Chat/Ping
        }

        const audio = new Audio(soundUrl);
        audio.volume = 0.45;
        audio.play().catch(() => {});
      } catch (e) {
        console.warn('Audio play blocked');
      }
    }
  };

  const markAllRead = () => {
    setNotifications(prev => prev.map(n => {
       const isForMe = (!n.targetEmail || n.targetEmail === currentUser?.email) && (!n.targetRole || n.targetRole === userRole);
       return isForMe ? { ...n, read: true } : n;
    }));
  };

  const userNotifications = notifications.filter(n => {
    if (n.targetEmail && n.targetEmail !== currentUser?.email) return false;
    if (n.targetRole && n.targetRole !== userRole) return false;
    return true;
  });

  const unreadCount = userNotifications.filter(n => !n.read).length;

  const handleNotificationClick = (notif: Notification) => {
    // Mark as read
    setNotifications(prev => prev.map(n => n.id === notif.id ? { ...n, read: true } : n));
    
    // Logic for navigation based on notification content or relatedId
    if (notif.relatedId) {
      setSelectedReqId(notif.relatedId);
      setRequestFilter(null); // Clear filters to ensure item is visible
      
      // Navigate to requests view
      if (userRole === 'admin' || userRole === 'staff' || userRole === 'viewer') {
        setCurrentView('allRequests');
      } else {
        setCurrentView('requests');
      }
      
      // Scroll to top to ensure detail view is visible
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
    
    setShowNotifications(false);
  };

  const viewProps = { 
    userRole, 
    lang, 
    isRTL, 
    t, 
    requestsList, 
    setRequestsList, 
    transactionsList, 
    setTransactionsList, 
    companiesList,
    setCompaniesList,
    suppliersList,
    setSuppliersList,
    setCurrentView,
    settings,
    setSettings,
    usersList,
    setUsersList,
    currentUser,
    setCurrentUser,
    addNotification,
    requestFilter,
    setRequestFilter,
    selectedReqId,
    setSelectedReqId,
    notifications,
    setNotifications,
    logs,
    addLog
  };

  // Auto-save and hourly backup logic
  useEffect(() => {
    const backupInterval = setInterval(() => {
      const dataToBackup = {
        requestsList,
        transactionsList,
        usersList,
        companiesList,
        settings,
        timestamp: new Date().toISOString()
      };
      safeSetLocalStorage('aneed_portal_backup', JSON.stringify(dataToBackup));
      console.log('Hourly Backup Completed:', new Date().toLocaleTimeString());
    }, 3600000); // Every hour
    
    return () => clearInterval(backupInterval);
  }, [requestsList, transactionsList, usersList, companiesList, settings]);

  if (!userRole) {
    return (
      <div className="min-h-screen bg-[#020617] flex items-center justify-center font-sans p-4 lg:p-6 overflow-hidden">
        {/* Deep background glow */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-[10%] -left-[10%] w-[60%] h-[60%] bg-blue-600/10 rounded-full blur-[150px]" />
          <div className="absolute -bottom-[10%] -right-[10%] w-[60%] h-[60%] bg-indigo-900/10 rounded-full blur-[150px]" />
        </div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.98, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
          className="w-full max-w-[1300px] lg:h-[720px] bg-[#020617] rounded-[48px] shadow-[0_80px_200px_-40px_rgba(0,0,0,1)] overflow-hidden flex flex-col lg:flex-row relative z-10 border border-white/5"
        >
          
          {/* Left Side: Airplane Visual Area */}
          <div className="lg:w-[58%] relative overflow-hidden hidden lg:block select-none">
            {/* The airplane image / video / GIF */}
            <motion.div 
               initial={{ scale: 1.05 }}
               animate={{ scale: 1 }}
               transition={{ duration: 30, ease: "linear" }}
               className="absolute inset-0 w-full h-full"
            >
               <MediaDisplay 
                 url={(settings.loginBgUrl && settings.loginBgUrl.trim() !== '') ? settings.loginBgUrl : ((settings.companyImage && settings.companyImage.trim() !== '') ? settings.companyImage : "https://images.unsplash.com/photo-1542296332-2e4473faf563?q=80&w=2670&auto=format&fit=crop")} 
                 alt="Login Illustration" 
                 className="w-full h-full object-cover brightness-105 contrast-105" 
               />
               <div className="absolute inset-0 bg-gradient-to-t from-[#020617]/40 via-transparent to-transparent" />
            </motion.div>
 
            {/* Top Left Logo Area - Matching Specified Reference Exactly */}
            <div className="absolute top-10 left-10 z-20 flex items-center group">
               <div className="relative">
                  <div className="flex flex-col">
                     {settings.logoUrl && settings.logoUrl.trim() !== '' ? (
                        <div className="flex h-16 items-center">
                           <img src={settings.logoUrl} alt="Company Logo" className="h-full object-contain" />
                        </div>
                     ) : (
                        <AirlinkLogo className="h-16" />
                     )}
                  </div>

                  {/* Surgical Addition: Hidden Logo Upload Overlay */}
                  {isDevMode && (
                    <label className="absolute inset-0 flex items-center justify-center bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer rounded-xl backdrop-blur-sm z-30">
                       <div className="flex flex-col items-center">
                          <PlusCircle size={24} className="text-white mb-1" />
                          <span className="text-[8px] font-black text-white uppercase tracking-widest">Change Logo</span>
                       </div>
                       <input 
                          type="file" 
                          className="hidden" 
                          accept="image/*" 
                          onChange={(e) => {
                             const file = e.target.files?.[0];
                             if (file) {
                                const reader = new FileReader();
                                reader.onloadend = () => {
                                   setSettings(prev => ({ ...prev, logoUrl: reader.result as string }));
                                };
                                reader.readAsDataURL(file);
                             }
                          }} 
                       />
                    </label>
                  )}
               </div>
               
               {/* Large AIRLINK text next to it removed - now part of AirlinkLogo component */}
            </div>
            
            {/* Surgical Addition: Background Change Button for Login Page */}
            {isDevMode && (
              <label className="absolute bottom-10 right-10 z-20 bg-white/10 backdrop-blur-md hover:bg-white/20 text-white p-4 rounded-2xl border border-white/20 cursor-pointer transition-all flex items-center gap-3 shadow-2xl group">
                 <Image size={20} className="group-hover:scale-110 transition-transform" />
                 <span className="text-[10px] font-black uppercase tracking-widest">Change Background (Video/GIF/Image)</span>
                 <input 
                    type="file" 
                    className="hidden" 
                    accept="image/*,video/*" 
                    onChange={async (e) => {
                       const file = e.target.files?.[0];
                       if (file) {
                          try {
                             const mediaData = await processMediaFile(file);
                             const newSettings = { ...settings, loginBgUrl: mediaData, companyImage: settings.companyImage || mediaData };
                             setSettings(newSettings);
                             // Force local storage update immediately with the NEW settings
                             safeSetLocalStorage('portal_settings', JSON.stringify(newSettings));
                          } catch (err) {
                             console.error("Failed to update login background:", err);
                          }
                       }
                    }} 
                 />
              </label>
            )}

            <motion.div 
               initial={{ x: -20, opacity: 0 }}
               animate={{ x: 0, opacity: 1 }}
               transition={{ delay: 0.8, duration: 1, ease: [0.16, 1, 0.3, 1] }}
               className="absolute bottom-16 left-16 z-20 w-[240px] md:w-[280px]"
            >
               <div className="bg-transparent backdrop-blur-md p-8 rounded-[40px] border border-white/10 shadow-[0_50px_100px_-20px_rgba(0,0,0,0.8)] space-y-6 ring-1 ring-white/10 group hover:bg-white/[0.02] transition-all duration-700">
                  <div className="flex items-center justify-between">
                     {isDevMode ? (
                        <input 
                           value={settings.loginWidgetTitle || 'Network Link'} 
                           onChange={(e) => setSettings(prev => ({ ...prev, loginWidgetTitle: e.target.value }))}
                           className="bg-white/5 border border-white/10 rounded px-2 py-1 text-[11px] font-black text-white/70 tracking-[0.3em] uppercase w-full outline-none"
                        />
                     ) : (
                        <h2 className="text-[12px] font-black text-white/70 tracking-[0.42em] uppercase leading-none">
                           {settings.loginWidgetTitle || 'Network Link'}
                        </h2>
                     )}
                     <div className="flex gap-1.5 shrink-0 ml-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-[#da4a26] animate-pulse shadow-[0_0_15px_rgba(218,74,38,0.6)]"></span>
                        <span className="w-2.5 h-2.5 rounded-full bg-[#da4a26]/20"></span>
                     </div>
                  </div>
                  
                  <div className="space-y-2">
                     {isDevMode ? (
                        <div className="space-y-2">
                           <input 
                              value={settings.loginWidgetHeadline || 'AIRLINK HQ'} 
                              onChange={(e) => setSettings(prev => ({ ...prev, loginWidgetHeadline: e.target.value }))}
                              className="bg-white/5 border border-white/10 rounded px-2 py-1 text-[14px] font-black text-white w-full outline-none"
                           />
                           <textarea 
                              value={settings.loginWidgetDesc || ''} 
                              onChange={(e) => setSettings(prev => ({ ...prev, loginWidgetDesc: e.target.value }))}
                              className="bg-white/5 border border-white/10 rounded px-2 py-1 text-[10px] text-white/40 w-full outline-none h-16 resize-none"
                           />
                        </div>
                     ) : (
                        <>
                           <p className="text-[24px] font-black text-white tracking-widest leading-none uppercase">{settings.loginWidgetHeadline || 'AIRLINK HQ'}</p>
                           <p className="text-[11px] text-white/40 font-bold tracking-widest leading-relaxed">{settings.loginWidgetDesc || 'Infrastructure Monitoring & Global Dispatch Systems.'}</p>
                        </>
                     )}
                  </div>

                  <div className="flex gap-4 pt-5 border-t border-white/10">
                     <div className="w-12 h-12 rounded-[18px] bg-white/5 border border-white/10 flex items-center justify-center text-white/50 group-hover:text-[#da4a26] group-hover:bg-white/10 transition-all duration-300">
                        <Shield size={22} />
                     </div>
                     <div className="w-12 h-12 rounded-[18px] bg-white/5 border border-white/10 flex items-center justify-center text-white/50 group-hover:text-[#da4a26] group-hover:bg-white/10 transition-all duration-300">
                        <Globe size={22} />
                     </div>
                     <div className="w-12 h-12 rounded-[18px] bg-white/5 border border-white/10 flex items-center justify-center text-white/50 group-hover:text-[#da4a26] group-hover:bg-white/10 transition-all duration-300">
                        <Clock size={22} />
                     </div>
                  </div>
               </div>
            </motion.div>
          </div>
   
          {/* Right Side: Login Form with Map Pattern */}
          <div className="flex-1 flex flex-col justify-center px-8 lg:px-16 py-8 relative bg-[#020617]/40 backdrop-blur-3xl border-l border-white/5 overflow-hidden">
            
            {/* World Map Dotted Pattern Background */}
            <div className="absolute inset-0 opacity-[0.03] pointer-events-none" style={{ backgroundImage: 'radial-gradient(#ffffff 1px, transparent 1px)', backgroundSize: '24px 24px' }} />
            
            <div className="max-w-[420px] w-full mx-auto space-y-6 relative z-20">
              
              {/* Header Branding Group */}
              <div className="space-y-2">
                 <p className="text-white/70 text-[11px] font-black uppercase tracking-[0.3em]">WELCOME TO</p>
                 <motion.div 
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.6, duration: 0.8 }}
                    className="relative group w-fit"
                 >
                    {settings.logoUrl && settings.logoUrl.trim() !== '' ? (
                      <div className="flex items-center" style={{ height: `${settings.logoHeight || 64}px` }}>
                        <img src={settings.logoUrl} alt="Logo" className="h-full w-auto object-contain" />
                      </div>
                    ) : (
                      <div className="flex flex-wrap items-baseline gap-2">
                        <span className="text-[54px] lg:text-[64px] font-black text-[#da4a26] tracking-tighter leading-none uppercase">{settings.companyName}</span>
                      </div>
                    )}

                    {isDevMode && (
                      <label className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer rounded-xl z-30">
                        <PlusCircle size={20} className="text-white" />
                        <input 
                           type="file" 
                           className="hidden" 
                           accept="image/*" 
                           onChange={async (e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                 try {
                                    const optimized = await optimizeImage(file, 400, 400, 0.8);
                                    setSettings(prev => ({ ...prev, logoUrl: optimized }));
                                 } catch (err) {
                                    console.error("Failed to optimize logo:", err);
                                 }
                              }
                           }} 
                        />
                      </label>
                    )}
                 </motion.div>
                 <p className="text-white/60 font-bold text-[13px] uppercase tracking-wider">{settings.loginSubtitle}</p>
              </div>
   
              <form onSubmit={handleLogin} className="space-y-4">
                {loginError && (
                  <motion.div 
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="bg-rose-500/10 border border-rose-500/20 text-rose-400 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center gap-4"
                  >
                    <Shield size={18} className="shrink-0" /> AUTHENTICATION FAILED
                  </motion.div>
                )}
                
                <div className="space-y-2">
                  <label className="text-[9px] font-black text-white/40 uppercase tracking-[0.4em] px-2">USERNAME / EMAIL</label>
                  <div className="relative group">
                    <div className="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none text-white/30 group-focus-within:text-[#f97316] transition-all">
                      <UserIcon size={18} />
                    </div>
                    <input 
                      type="text" 
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      className="block w-full pl-14 pr-5 py-3.5 bg-white/[0.03] border border-white/10 rounded-2xl text-white placeholder:text-white/20 font-bold focus:outline-none focus:bg-white/[0.06] focus:border-[#f97316]/50 transition-all text-sm"
                      placeholder="e.g. ali.ahmed"
                      required
                    />
                  </div>
                </div>
   
                <div className="space-y-2">
                  <label className="text-[9px] font-black text-white/40 uppercase tracking-[0.4em] px-2">PASSWORD</label>
                  <div className="relative group">
                    <div className="absolute inset-y-0 left-0 pl-5 flex items-center pointer-events-none text-white/30 group-focus-within:text-[#f97316] transition-all">
                      <Lock size={18} />
                    </div>
                    <input 
                      type="password" 
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="block w-full pl-14 pr-5 py-3.5 bg-white/[0.03] border border-white/10 rounded-2xl text-white placeholder:text-white/20 font-bold focus:outline-none focus:bg-white/[0.06] focus:border-[#f97316]/50 transition-all text-sm"
                      placeholder="••••••••"
                      required
                    />
                  </div>
                </div>
   
                <div className="pt-1">
                  <button 
                    type="submit"
                    disabled={!isDataLoaded}
                    className="w-full bg-[#da4a26] text-white py-4 rounded-2xl font-black text-[12px] uppercase tracking-[0.35em] shadow-[0_15px_40px_rgba(218,74,38,0.35)] hover:shadow-[#da4a26]/50 hover:scale-[1.01] active:scale-[0.98] transition-all duration-300 disabled:opacity-50 cursor-pointer"
                  >
                    {settings.loginButtonText || (!isDataLoaded ? "ESTABLISHING CONNECTION..." : `WELCOME TO ${settings.companyName}`)}
                  </button>
                </div>
              </form>
   
              {/* Bottom Metrics */}
              <div className="pt-5 border-t border-white/10 space-y-5">
                 <div className="grid grid-cols-3 gap-3">
                    <div className="flex items-center gap-2.5">
                       <Clock size={18} className="text-[#f97316] shrink-0" />
                       <div className="flex flex-col">
                          <span className="text-[10px] font-black text-white/80 uppercase tracking-wider whitespace-nowrap">{settings.loginMetric1Title || '24/7 System'}</span>
                          <span className="text-[9px] text-white/40 font-bold uppercase tracking-wider">{settings.loginMetric1Sub || 'Uptime'}</span>
                       </div>
                    </div>
                    <div className="flex items-center gap-2.5">
                       <ShieldCheck size={18} className="text-[#f97316] shrink-0" />
                       <div className="flex flex-col">
                          <span className="text-[10px] font-black text-white/80 uppercase tracking-wider whitespace-nowrap">{settings.loginMetric2Title || 'Enterprise'}</span>
                          <span className="text-[9px] text-white/40 font-bold uppercase tracking-wider">{settings.loginMetric2Sub || 'Grade Security'}</span>
                       </div>
                    </div>
                    <div className="flex items-center gap-2.5">
                       <Activity size={18} className="text-[#f97316] shrink-0" />
                       <div className="flex flex-col">
                          <span className="text-[10px] font-black text-white/80 uppercase tracking-wider whitespace-nowrap">{settings.loginMetric3Title || 'Real-time'}</span>
                          <span className="text-[9px] text-white/40 font-bold uppercase tracking-wider">{settings.loginMetric3Sub || 'Data Sync'}</span>
                       </div>
                    </div>
                 </div>
                 
                 <div className="pt-4 border-t border-white/10 flex items-center justify-center">
                    <div 
                      onClick={() => {
                        const newCount = devClickCount + 1;
                        if (newCount >= 10) {
                          if (isDevMode) {
                            setIsDevMode(false);
                          } else {
                            setShowSecretGateway(true);
                          }
                          setDevClickCount(0);
                        } else {
                          setDevClickCount(newCount);
                        }
                      }}
                      className="group cursor-pointer select-none w-full flex flex-col items-center"
                    >
                       <p className="text-[11px] font-black text-white/80 uppercase tracking-[0.4em] group-hover:text-[#da4a26] transition-colors text-center">
                          {settings.loginFooterText1 || 'PORTAL V4.2 PRO'}
                       </p>
                       <p className="text-[10px] font-bold text-white/60 uppercase tracking-[0.15em] mt-1.5 group-hover:text-white transition-colors text-center">
                          {settings.loginFooterText2 || `© ${new Date().getFullYear()} Eng. Ali Ahmed Aneed`}
                       </p>
                       <p className="text-[8px] font-bold text-white/30 uppercase tracking-[0.1em] mt-1 text-center">
                          &copy; {new Date().getFullYear()} {settings.companyName} | ALL RIGHTS RESERVED
                       </p>
                    </div>
                 </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  const navItems = [
    { id: 'dashboard', icon: Home, label: t.dashboard },
    ...(userRole !== 'client' ? [{ id: 'archive', icon: Archive, label: t.archive || 'Archive' }] : []),
    ...(userRole === 'client' 
      ? [
          { id: 'newRequest', icon: PlusCircle, label: t.newRequest },
          { id: 'requests', icon: Briefcase, label: t.requests }
        ]
      : [
          { id: 'allRequests', icon: Briefcase, label: (userRole === 'admin' || userRole === 'staff' || userRole === 'viewer') ? t.allRequests : t.requests }
        ]
    ),
    ...(userRole === 'client' ? [] : [{ id: 'statement', icon: Wallet, label: t.statement }]),
    ...(userRole === 'admin' 
      ? [
          { id: 'financials', icon: TrendingUp, label: t.financials }, 
          { id: 'users_mgmt', icon: Users, label: t.usersTab || 'System Accounts' },
          { id: 'supplier_payables', icon: Briefcase, label: t.supplierPayables },
        ]
      : []),
    ...(isAliAccount ? [{ id: 'settings', icon: SettingsIcon, label: t.settings }] : []),
    { id: 'about', icon: Globe, label: t.aboutUs }
  ];

  const filteredNavItems = navItems;

  return (
    <div 
      className="min-h-screen flex text-[var(--text-main)] font-sans selection:bg-indigo-500/30"
      style={{ 
        '--accent-color': settings.primaryColor || '#6366f1',
      } as React.CSSProperties}
    >
      {/* Smart Notification Toast (Curtain) */}
      <AnimatePresence>
        {activeToast && (
          <motion.div
            initial={{ y: -100, opacity: 0, scale: 0.9 }}
            animate={{ y: 24, opacity: 1, scale: 1 }}
            exit={{ y: -100, opacity: 0, scale: 0.9 }}
            onClick={() => handleNotificationClick(activeToast)}
            className="fixed top-0 left-1/2 -translate-x-1/2 z-[1000] w-full max-w-md px-6 pointer-events-auto cursor-pointer"
          >
            <div className="bg-[#0f172a]/80 backdrop-blur-2xl border border-white/10 p-6 rounded-[32px] shadow-[0_50px_100px_-20px_rgba(0,0,0,0.5)] flex items-center gap-6 group hover:scale-[1.02] transition-transform">
              <div className="w-14 h-14 rounded-2xl bg-indigo-500 text-white flex items-center justify-center shadow-lg shadow-indigo-500/30">
                <Bell size={24} className="group-hover:rotate-12 transition-transform" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[10px] font-black text-white/40 uppercase tracking-widest mb-1">New System Alert</p>
                <p className="text-sm font-black text-white truncate uppercase tracking-tight">{activeToast.text}</p>
                {activeToast.description && (
                  <p className="text-xs text-white/50 mt-1 line-clamp-1 font-bold">{activeToast.description}</p>
                )}
              </div>
              <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-pulse shadow-[0_0_10px_rgba(99,102,241,1)]" />
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Subtle Rights Icon - Bottom Side Fixed */}
      <div className={`fixed bottom-6 ${isRTL ? 'left-6' : 'right-6'} z-[100] group no-print`}>
        {clickToast && (
          <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-indigo-600 text-white text-[10px] font-black px-3 py-1 rounded-full shadow-lg text-center animate-bounce whitespace-nowrap border border-indigo-400">
            {clickToast}
          </div>
        )}
        <div 
          onClick={handleCopyrightClick}
          style={{ 
            backgroundColor: settings.copyrightBgColor || undefined,
            borderColor: settings.copyrightBorderColor || undefined,
            borderRadius: settings.copyrightBorderRadius !== undefined ? `${settings.copyrightBorderRadius}px` : undefined,
            paddingLeft: settings.copyrightPaddingX !== undefined ? `${settings.copyrightPaddingX}px` : undefined,
            paddingRight: settings.copyrightPaddingX !== undefined ? `${settings.copyrightPaddingX}px` : undefined,
            paddingTop: settings.copyrightPaddingY !== undefined ? `${settings.copyrightPaddingY}px` : undefined,
            paddingBottom: settings.copyrightPaddingY !== undefined ? `${settings.copyrightPaddingY}px` : undefined,
            width: settings.copyrightWidth && settings.copyrightWidth !== 'auto' ? settings.copyrightWidth : undefined,
            height: settings.copyrightHeight && settings.copyrightHeight !== 'auto' ? settings.copyrightHeight : undefined,
          }}
          className="glass-pane px-6 py-3 rounded-full border border-white/20 shadow-2xl flex items-center justify-center gap-4 opacity-80 hover:opacity-100 transition-all duration-500 cursor-pointer translate-y-12 lg:translate-y-0 group-hover:translate-y-0 translate-x-0 active:scale-95 select-none"
        >
          <Shield size={16} className="text-orange-500 shrink-0" />
          <div className="flex flex-col">
             <p 
               style={{ 
                 fontSize: settings.copyrightFontSize ? `${settings.copyrightFontSize}px` : undefined,
                 color: settings.copyrightTextColor || undefined,
                 fontFamily: settings.copyrightFontFamily || undefined,
               }}
               className={`${settings.copyrightFontWeight || 'font-black'} text-white uppercase tracking-widest leading-none`}
             >
               {settings.copyrightName || 'Ali Ahmed Aneed'}
             </p>
             <p 
               style={{ 
                 fontSize: settings.copyrightFontSize ? `${Math.max(8, settings.copyrightFontSize - 2)}px` : undefined,
                 color: settings.copyrightTextColor || undefined,
                 fontFamily: settings.copyrightFontFamily || undefined,
                 opacity: 0.7
               }}
               className="font-bold text-white/50 uppercase tracking-widest mt-1.5"
             >
               {settings.copyrightRightsText || 'حقوق الطبع محفوظة للمطور'}
             </p>
          </div>
        </div>
        {!sidebarOpen && (
          <div className="h-2 w-2 bg-indigo-500 rounded-full animate-ping absolute bottom-2 right-2 group-hover:hidden shadow-[0_0_8px_rgba(99,102,241,1)]"></div>
        )}
      </div>

      <aside className={`fixed inset-y-0 ${isRTL ? 'right-0' : 'left-0'} z-50 w-72 bg-[var(--nav-bg)] border-${isRTL ? 'l' : 'r'} border-[var(--border-main)] transform ${sidebarOpen ? 'translate-x-0' : (isRTL ? 'translate-x-full' : '-translate-x-full')} transition-transform duration-300 lg:relative lg:translate-x-0 flex flex-col shadow-2xl overflow-hidden backdrop-blur-xl`}>
        <div className="h-28 flex flex-col items-center justify-center px-6 border-b border-[var(--border-main)] shrink-0">
          <div className="p-2 rounded-xl w-full flex items-center justify-center overflow-hidden h-20 bg-transparent transition-transform duration-500 hover:scale-105">
             {settings.logoUrl && settings.logoUrl.trim() !== '' ? <img src={settings.logoUrl} alt="Logo" style={{ height: `${(settings.logoHeight || 64) * 0.8}px` }} className={`object-contain ${theme === 'dark' ? 'filter drop-shadow-[0_0_8px_rgba(255,255,255,0.2)]' : ''}`} /> : <div style={{ transform: `scale(${(settings.logoHeight || 64) / 64})` }}><AirlinkLogo /></div>}
          </div>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden absolute top-4 right-4 text-[var(--muted-text)] hover:text-[var(--text-main)]"><X size={24} /></button>
        </div>
        <div className="flex-1 overflow-y-auto py-6 custom-scrollbar">
          <div className="px-6 mb-8">
             <div className="bg-[var(--card-bg)] border border-white/5 rounded-2xl p-4 flex items-center gap-4 hover:bg-white/[0.02] transition-all group cursor-pointer">
                <Avatar name={currentUser?.name || userRole || ''} url={currentUser?.avatar} className="w-12 h-12 rounded-xl text-lg accent-gradient border-0 group-hover:scale-105 transition-transform" />
                <div>
                   <p className="text-sm font-bold text-[var(--text-main)] leading-tight">{currentUser?.name}</p>
                   <p className="text-[10px] text-[var(--muted-text)] mt-1 uppercase tracking-widest flex items-center gap-1 font-black">
                      {userRole === 'admin' && <Shield size={10} className="text-amber-500" />} {userRole}
                   </p>
                </div>
             </div>
          </div>
          <div className="px-4">
            <p className={`px-4 text-[14px] font-black text-[var(--muted-text)] uppercase tracking-[0.3em] mb-6 opacity-80 ${isRTL ? 'text-right' : 'text-left'}`}>System Access</p>
            <ul className="space-y-2">
              {filteredNavItems.map((item) => {
                const Icon = item.icon;
                const isActive = currentView === item.id;
                return (
                  <li key={item.id}>
                    <button 
                      onClick={() => {setCurrentView(item.id); setSidebarOpen(false);}} 
                      className={`w-full flex items-center gap-4 px-5 py-4 rounded-2xl text-[13px] font-black uppercase tracking-widest transition-all duration-500 group relative overflow-hidden ${isActive ? 'bg-[var(--primary)] text-white shadow-xl shadow-[var(--primary)]/20' : 'text-[var(--muted-text)] hover:bg-white/[0.05] hover:text-[var(--text-main)]'}`}
                    >
                      <Icon size={20} className={`${isActive ? 'text-white' : 'text-[var(--muted-text)] group-hover:text-white group-hover:scale-110'} transition-all duration-500`} />
                      <span className="relative z-10">{item.label}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        </div>

        <div className="px-6 py-6 border-t border-[var(--border-main)]">
           <div 
             onClick={handleCopyrightClick}
             className="p-4 rounded-2xl bg-[#0f172a]/40 backdrop-blur-xl border border-indigo-500/20 text-center shadow-lg shadow-indigo-500/5 group hover:border-indigo-500/40 transition-all duration-500 cursor-pointer active:scale-95 select-none"
           >
              <p className="text-[12px] font-black text-indigo-400 uppercase tracking-[0.4em] leading-relaxed group-hover:scale-105 transition-transform">
                Portal v4.2 PRO
              </p>
              <p 
                style={{ 
                  color: settings.copyrightTextColor || undefined,
                  fontFamily: settings.copyrightFontFamily || undefined,
                }} 
                className="text-[9px] font-bold text-white uppercase tracking-[0.2em] mt-3 group-hover:text-amber-400 transition-colors"
              >
                {settings.copyrightRightsText || 'حقوق الطبع محفوظة للمطور'}
              </p>
              <p 
                style={{ 
                  color: settings.copyrightTextColor || undefined,
                  fontFamily: settings.copyrightFontFamily || undefined,
                }} 
                className="text-[8px] font-bold text-white/60 uppercase tracking-widest mt-1.5 flex items-center justify-center gap-2"
              >
                 <span className="w-1 h-1 rounded-full bg-indigo-500/40" />
                 {settings.copyrightName || 'Eng. Ali Ahmed Aneed'}
                 <span className="w-1 h-1 rounded-full bg-indigo-500/40" />
              </p>
              <p className="text-[7px] font-bold text-white/20 uppercase tracking-[0.1em] mt-2">ALL RIGHTS RESERVED | © {new Date().getFullYear()}</p>
           </div>
        </div>

        <div className="p-6 border-t border-[var(--border-main)]">
          <button onClick={logout} className="w-full flex items-center justify-center gap-2 px-4 py-3.5 rounded-2xl text-[10px] font-black uppercase tracking-widest text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 transition-all border border-rose-500/20 active:scale-95"><LogOut size={16} /> {t.logout}</button>
        </div>
      </aside>

      <main 
        className="flex-1 flex flex-col min-w-0 relative overflow-hidden bg-[var(--bg-main)]" 
      >
        <div 
          className="absolute inset-0 bg-cover bg-center bg-fixed transition-all duration-700 pointer-events-none" 
          style={settings.backgroundImageUrl ? { backgroundImage: `url(${settings.backgroundImageUrl})` } : { backgroundColor: 'transparent' }}
        />
        <div className="absolute inset-0 bg-[var(--bg-main)] opacity-40 backdrop-blur-[2px] pointer-events-none" />

        <header className="h-20 glass-pane rounded-none !border-x-0 !border-t-0 flex items-center justify-between px-4 lg:px-8 sticky top-0 z-40">
          <div className="flex items-center gap-3 lg:gap-4">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden p-2 text-[var(--muted-text)] hover:bg-[var(--card-bg)] rounded-lg transition-colors"><Menu size={24} /></button>
            <h1 className="text-sm lg:text-lg font-medium text-[var(--text-main)] truncate">
              {settings.companyName} <span className="mx-2 text-[var(--muted-text)] opacity-30">/</span> <span className="font-bold">{navItems.find(i => i.id === currentView)?.label}</span>
            </h1>
          </div>
          <div className="flex items-center gap-3">
            {getStoredGDriveToken() && (
              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-500/10 border border-blue-500/20 rounded-full text-blue-400 text-[9px] font-black uppercase tracking-widest" title={lang === 'ar' ? 'مربوط ومزامن مع Google Drive' : 'Synced with Google Drive'}>
                <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-pulse shadow-[0_0_8px_rgba(96,165,250,0.5)]" />
                <span className="hidden sm:inline">{lang === 'ar' ? 'Google Drive متصل' : 'Drive Synced'}</span>
              </div>
            )}
            {isSyncing && (
              <div className="flex items-center gap-2 px-3 py-1.5 bg-indigo-500/10 border border-indigo-500/20 rounded-full animate-in fade-in duration-300">
                <div className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-pulse shadow-[0_0_8px_rgba(99,102,241,0.5)]"></div>
                <span className="text-[9px] font-black text-indigo-500 uppercase tracking-widest">{lang === 'ar' ? 'مزامنة لحظية' : 'Live Sync'}</span>
              </div>
            )}
            <div className="relative">
              <button onClick={() => { setShowNotifications(!showNotifications); if(!showNotifications) markAllRead(); }} className="p-2.5 text-[var(--muted-text)] hover:bg-[var(--card-bg)] rounded-xl transition-colors border border-[var(--border-main)] relative">
                <Bell size={18} />
                {unreadCount > 0 && (
                  <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] px-1 bg-rose-500 rounded-full border-2 border-[var(--bg-main)] flex items-center justify-center text-[9px] font-black text-white animate-in zoom-in-50">
                    {unreadCount}
                  </span>
                )}
              </button>
              {showNotifications && (
                <div className={`absolute top-full mt-4 ${isRTL ? 'left-0' : 'right-0'} w-80 bg-[var(--nav-bg)] shadow-[0_20px_50px_rgba(0,0,0,0.2)] border border-[var(--border-main)] rounded-3xl overflow-hidden z-50 animate-in slide-in-from-top-2 backdrop-blur-2xl`}>
                  <div className="p-4 border-b border-[var(--border-main)] font-black text-[10px] uppercase tracking-widest text-[var(--muted-text)] flex justify-between items-center bg-[var(--card-bg)]/50">
                    {t.notifications}
                    <button onClick={() => setShowNotifications(false)} className="text-[var(--muted-text)] opacity-40 hover:opacity-100"><X size={14}/></button>
                  </div>
                  <div className="max-h-80 overflow-y-auto divide-y divide-[var(--border-main)]">
                    {userNotifications.length === 0 ? (
                      <div className="p-8 text-center text-[var(--muted-text)] opacity-30">
                         <Bell className="mx-auto mb-3 opacity-10" size={32} />
                         <p className="text-[10px] font-bold uppercase tracking-widest">{t.noNotifications}</p>
                      </div>
                    ) : (
                      userNotifications.map(notif => {
                        const Icon = notif.type === 'message' ? Headphones : 
                                     notif.type === 'status' ? Activity : 
                                     notif.type === 'offer' ? TrendingUp : Bell;
                        
                        return (
                          <div 
                            key={notif.id} 
                            onClick={() => handleNotificationClick(notif)}
                            className={`p-6 hover:bg-white/[0.04] transition-all relative group cursor-pointer border-l-4 ${!notif.read ? 'border-indigo-500 bg-indigo-500/[0.03]' : 'border-transparent'}`}
                          >
                            <div className="flex gap-4">
                              <div className={`p-2.5 rounded-xl h-fit ${!notif.read ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/20' : 'bg-[var(--card-bg)] text-[var(--muted-text)] border border-[var(--border-main)]'} group-hover:scale-110 transition-transform`}>
                                <Icon size={16} />
                              </div>
                              <div className="flex-1">
                                <p className={`text-xs ${!notif.read ? 'text-[var(--text-main)] underline decoration-indigo-500/30' : 'text-[var(--muted-text)]'} font-black leading-relaxed tracking-tight group-hover:text-indigo-400 transition-colors uppercase`}>
                                  {notif.text}
                                </p>
                                {notif.description && (
                                  <p className="text-[10px] text-[var(--muted-text)] mt-1 font-bold leading-relaxed">{notif.description}</p>
                                )}
                                <div className="flex items-center justify-between mt-3">
                                  <span className="text-[8px] font-black text-[var(--muted-text)] opacity-40 uppercase tracking-widest flex items-center gap-1.5">
                                    <Clock size={10} /> {notif.time}
                                  </span>
                                  {notif.relatedId && (
                                    <span className="text-[8px] font-black text-indigo-500/60 uppercase tracking-widest bg-indigo-500/5 px-2 py-0.5 rounded-md border border-indigo-500/10">
                                      #{notif.relatedId.split('-')[0]}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>
                  {userNotifications.length > 0 && (
                    <button onClick={() => { markAllRead(); setShowNotifications(false); }} className="w-full py-4 text-[9px] font-black text-indigo-400 hover:text-indigo-600 uppercase tracking-widest border-t border-[var(--border-main)] bg-[var(--card-bg)]/30 hover:bg-[var(--card-bg)]/60 transition-all">
                      {t.markAllRead}
                    </button>
                  )}
                </div>
              )}
            </div>
            <button onClick={toggleLang} className="flex items-center gap-2 px-3 py-2 text-xs font-bold text-[var(--text-main)] hover:bg-[var(--card-bg)] rounded-xl transition-colors border border-[var(--border-main)]">{lang === 'en' ? 'AR' : 'EN'}</button>
            <button onClick={toggleTheme} className="p-2.5 text-[var(--text-main)] hover:bg-[var(--card-bg)] rounded-xl border border-[var(--border-main)] transition-colors">{theme === 'light' ? <Moon size={18} /> : <Sun size={18} />}</button>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-4 lg:p-10 relative z-10">
          <div className="max-w-7xl mx-auto">
            {currentView === 'dashboard' && <DashboardView {...viewProps} />}
            {currentView === 'newRequest' && <NewRequestView {...viewProps} currentUser={currentUser} />}
            {currentView === 'requests' && <RequestsListView {...viewProps} />}
            {currentView === 'allRequests' && <RequestsListView {...viewProps} />}
            {currentView === 'statement' && <StatementView {...viewProps} />}
            {currentView === 'financials' && <AdminFinancialsView {...viewProps} settings={settings} />}
            {currentView === 'supplier_payables' && <SupplierPayablesView {...viewProps} settings={settings} />}
            {currentView === 'users_mgmt' && <CompaniesManagementView {...viewProps} settings={settings} initialTab="users" />}
            {currentView === 'companies_mgmt' && <CompaniesManagementView {...viewProps} settings={settings} initialTab="companies" />}
            {currentView === 'suppliers_mgmt' && <CompaniesManagementView {...viewProps} settings={settings} initialTab="suppliers" />}
            {currentView === 'archive' && <ArchiveView {...viewProps} />}
            {currentView === 'settings' && (
              isAliAccount ? (
                <SettingsView {...viewProps} userRole={userRole} currentUser={currentUser} isDevMode={isDevMode} handleResetSystem={handleResetSystem} />
              ) : (
                <div className="p-12 text-center text-white/70 bg-slate-900/60 rounded-3xl border border-white/10 max-w-lg mx-auto dir-rtl my-12 shadow-2xl">
                  <Shield size={48} className="mx-auto text-amber-400 mb-4 animate-pulse" />
                  <h3 className="text-xl font-black text-white mb-2">منطقة محمية</h3>
                  <p className="text-sm text-white/60 font-medium leading-relaxed">
                    صفحة الإعدادات وتعديل الحقوق مخصصة حصراً للمطور الرئيسي (علي أحمد عنيد).
                  </p>
                </div>
              )
            )}
            {currentView === 'about' && (
               <div className="max-w-4xl mx-auto space-y-10 animate-in slide-in-from-bottom-4 duration-500">
                  <div className="flex justify-between items-end">
                    <h2 className="text-5xl font-black text-[var(--text-main)] tracking-tight">{t.aboutUs}</h2>
                    {isAliAccount && (
                       <button 
                         onClick={() => setCurrentView('settings')}
                         className="flex items-center gap-2 bg-[var(--card-bg)] hover:bg-white/10 text-[var(--muted-text)] hover:text-[var(--text-main)] px-5 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest border border-[var(--border-main)] transition-all"
                       >
                         <SettingsIcon size={14} /> {t.editRequest || 'Edit Page'}
                       </button>
                    )}
                  </div>
                  <Card className="p-12 leading-loose text-[var(--text-main)]/80 font-medium whitespace-pre-wrap text-lg border-[var(--border-main)] bg-[var(--card-bg)] shadow-2xl relative overflow-hidden backdrop-blur-sm">
                     <div className="relative z-10">
                        {settings.aboutContent || 'Welcome to our platform. We provide premium travel solutions for corporate clients worldwide.'}
                     </div>
                     {/* Soft organic shape in background of About page */}
                     <div className="absolute -bottom-24 -right-24 w-80 h-80 bg-[var(--primary)]/5 rounded-full blur-3xl pointer-events-none" />
                  </Card>
               </div>
            )}
          </div>
        </div>
      </main>

      <CopyrightsModal
        isOpen={copyrightModalOpen}
        onClose={() => setCopyrightModalOpen(false)}
        settings={settings}
        onSave={(newSettings) => {
          setSettings(prev => ({ ...prev, ...newSettings }));
        }}
      />

      <SecretGatewayModal
        isOpen={showSecretGateway}
        onClose={() => setShowSecretGateway(false)}
        onUnlockDevMode={() => setIsDevMode(true)}
        settings={settings}
        setSettings={setSettings}
        usersList={usersList}
        requestsList={requestsList}
        transactionsList={transactionsList}
        companiesList={companiesList}
        suppliersList={suppliersList}
        notifications={notifications}
      />
    </div>
  );
}

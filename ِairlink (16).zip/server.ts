import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.join(__dirname, 'data');
const DB_PATH = path.join(DATA_DIR, 'db.json');
const BACKUP_DIR = path.join(DATA_DIR, 'backups');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR);
}

// Ensure database file exists
if (!fs.existsSync(DB_PATH)) {
  fs.writeFileSync(DB_PATH, JSON.stringify({
    users: [],
    requests: [],
    transactions: [],
    companies: [],
    settings: {},
    notifications: [],
    logs: []
  }, null, 2));
}

// Ensure backup directory exists
if (!fs.existsSync(BACKUP_DIR)) {
  fs.mkdirSync(BACKUP_DIR);
}

function createBackup() {
  const now = new Date();
  const timestamp = now.toISOString().replace(/[:.]/g, '-');
  const dateStr = now.toISOString().split('T')[0]; // YYYY-MM-DD
  
  // 1. Regular save-point backup
  const backupPath = path.join(BACKUP_DIR, `db-backup-${timestamp}.json`);
  fs.copyFileSync(DB_PATH, backupPath);
  
  // 2. Daily Snapshot (if not already created today)
  const dailyPath = path.join(BACKUP_DIR, `daily-snapshot-${dateStr}.json`);
  if (!fs.existsSync(dailyPath)) {
    fs.copyFileSync(DB_PATH, dailyPath);
    console.log(`[Backup] Created daily snapshot: ${dateStr}`);
  }
  
  // Keep regular backups under control (last 100)
  const files = fs.readdirSync(BACKUP_DIR)
    .filter(f => f.startsWith('db-backup-'))
    .map(f => ({ name: f, time: fs.statSync(path.join(BACKUP_DIR, f)).mtime.getTime() }))
    .sort((a, b) => b.time - a.time);
    
  if (files.length > 100) {
    files.slice(100).forEach(f => fs.unlinkSync(path.join(BACKUP_DIR, f.name)));
  }

  // Keep daily snapshots for 90 days
  const dailyFiles = fs.readdirSync(BACKUP_DIR)
    .filter(f => f.startsWith('daily-snapshot-'))
    .map(f => ({ name: f, time: fs.statSync(path.join(BACKUP_DIR, f)).mtime.getTime() }))
    .sort((a, b) => b.time - a.time);

  if (dailyFiles.length > 90) {
    dailyFiles.slice(90).forEach(f => fs.unlinkSync(path.join(BACKUP_DIR, f.name)));
  }
}

// Preventive Care: Keep the process alive on uncaught errors
process.on('uncaughtException', (err) => {
  console.error('[Surgery Alert] Uncaught Exception:', err);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('[Surgery Alert] Unhandled Rejection at:', promise, 'reason:', reason);
});

async function startServer() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  // Standard JSON parsing with immediate error handler
  app.use(express.json({ limit: '100mb' })); // Increased limit even more
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (err) {
      console.error('[Critical] JSON Parse or Body Error:', err.message);
      return res.status(400).json({ 
        error: 'Invalid JSON payload or request too large',
        details: err.message
      });
    }
    next();
  });

  // Basic Security Headers (Safe for iFrame environment)
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
  });

  // Debug middleware
  app.use((req, res, next) => {
    if (req.url.startsWith('/api')) {
      console.log(`[API Request] ${req.method} ${req.url}`);
    }
    next();
  });

  // Persistent Cloud Sync Manager for Cloud Run container resilience
  const DEFAULT_CLOUD_URL = 'https://api.restful-api.dev/objects/ff8081819f7e10ae019fbd3dc46e5c5b';
  const CLOUD_ID_FILES = [
    path.join(DATA_DIR, 'cloud_sync_id.txt'),
    '/tmp/cloud_sync_id.txt'
  ];

  let activeCloudSyncUrl = (() => {
    for (const f of CLOUD_ID_FILES) {
      try {
        if (fs.existsSync(f)) {
          const id = fs.readFileSync(f, 'utf8').trim();
          if (id && id.length > 5) {
            return id.startsWith('http') ? id : `https://api.restful-api.dev/objects/${id}`;
          }
        }
      } catch(e) {}
    }
    return DEFAULT_CLOUD_URL;
  })();

  const saveActiveCloudUrl = (url: string) => {
    activeCloudSyncUrl = url;
    const id = url.split('/').pop() || url;
    for (const f of CLOUD_ID_FILES) {
      try {
        const parent = path.dirname(f);
        if (!fs.existsSync(parent)) fs.mkdirSync(parent, { recursive: true });
        fs.writeFileSync(f, id, 'utf8');
      } catch(e) {}
    }
  };

  const createNewCloudObject = async (data: any): Promise<string | null> => {
    try {
      const res = await fetch('https://api.restful-api.dev/objects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: 'airlink_tickets_prod_db_v1',
          data: data || { users: [], requests: [], transactions: [], companies: [], suppliers: [], settings: {}, notifications: [], logs: [] }
        })
      });
      if (res.ok) {
        const json = await res.json();
        if (json && json.id) {
          const newUrl = `https://api.restful-api.dev/objects/${json.id}`;
          saveActiveCloudUrl(newUrl);
          console.log('[Server Cloud Sync] Created cloud database store with ID:', json.id);
          return newUrl;
        }
      }
    } catch(e) {}
    return null;
  };

  let memoryCache: any = null;
  let lastCloudFetchTime = 0;

  const fetchFromCloud = async (): Promise<any | null> => {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3500);
      const res = await fetch(activeCloudSyncUrl, { signal: controller.signal });
      clearTimeout(timeoutId);
      if (res.ok) {
        const json = await res.json();
        if (json && json.data && typeof json.data === 'object') {
          return json.data;
        }
      } else if (res.status === 404 || res.status === 400) {
        console.warn('[Server Cloud Sync] Active cloud storage expired/404. Attempting auto-recreation...');
      }
    } catch (err) {}
    return null;
  };

  const pushToCloud = async (data: any) => {
    try {
      const res = await fetch(activeCloudSyncUrl, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: 'airlink_tickets_prod_db_v1',
          data: data
        })
      });
      if (res.status === 404 || res.status === 400) {
        console.warn('[Server Cloud Sync] PUT returned 404 (expired object). Recreating cloud object...');
        await createNewCloudObject(data);
      }
    } catch (err) {}
  };

  // Helper to load database securely with multi-path recovery
  const loadDatabase = () => {
    const DEFAULT_DATA = { users: [], requests: [], transactions: [], companies: [], suppliers: [], settings: {}, notifications: [], logs: [] };
    
    const candidatePaths = [
      DB_PATH,
      '/tmp/data/db.json',
      path.join(process.cwd(), 'data', 'db.json'),
      '/tmp/db.json'
    ];

    let bestData = DEFAULT_DATA;
    let maxRecords = -1;

    for (const p of candidatePaths) {
      try {
        if (fs.existsSync(p)) {
          const content = fs.readFileSync(p, 'utf8');
          if (content.trim()) {
            const parsed = JSON.parse(content);
            const recordCount = (Array.isArray(parsed.users) ? parsed.users.length : 0) + 
                                (Array.isArray(parsed.requests) ? parsed.requests.length : 0);
            if (recordCount > maxRecords) {
              maxRecords = recordCount;
              bestData = parsed;
            }
          }
        }
      } catch(e) {}
    }

    if (maxRecords <= 0) {
      const backupDirs = [BACKUP_DIR, '/tmp/data/backups', path.join(process.cwd(), 'data', 'backups')];
      for (const bDir of backupDirs) {
        try {
          if (fs.existsSync(bDir)) {
            const files = fs.readdirSync(bDir).filter(f => f.endsWith('.json')).reverse();
            for (const f of files.slice(0, 10)) {
              const content = fs.readFileSync(path.join(bDir, f), 'utf8');
              if (content.trim()) {
                const parsed = JSON.parse(content);
                const recordCount = (Array.isArray(parsed.users) ? parsed.users.length : 0) + 
                                    (Array.isArray(parsed.requests) ? parsed.requests.length : 0);
                if (recordCount > maxRecords) {
                  maxRecords = recordCount;
                  bestData = parsed;
                }
              }
            }
          }
        } catch(e) {}
      }
    }

    return bestData;
  };

  const safeMerge = (oldList: any[] = [], newList: any[] = [], key: string, deletedIdsList: string[] = []) => {
    if (!Array.isArray(newList)) return oldList || [];

    const deletedSet = new Set(deletedIdsList.map(id => String(id)));
    const devEmail = 'ali.aneed';

    const oldMap = new Map<string, any>();
    if (Array.isArray(oldList)) {
      oldList.forEach(item => {
        if (item && item.id) oldMap.set(String(item.id), item);
      });
    }

    const newMap = new Map<string, any>();
    newList.forEach(item => {
      if (item && item.id && !deletedSet.has(String(item.id))) {
        newMap.set(String(item.id), item);
      }
    });

    const mergedMap = new Map<string, any>();

    newMap.forEach((item, id) => {
      const existing = oldMap.get(id);
      if (!existing) {
        mergedMap.set(id, item);
        return;
      }

      if (key === 'requests') {
        // Deep merge chat
        const oldChat = existing.chat || [];
        const newChat = item.chat || [];
        const chatKeys = new Set(newChat.map((c: any) => c.id || `${c.sender}-${c.text}-${c.file?.name || ''}`));
        const mergedChat = [...newChat];

        oldChat.forEach((c: any) => {
          const k = c.id || `${c.sender}-${c.text}-${c.file?.name || ''}`;
          if (!chatKeys.has(k)) {
            mergedChat.push(c);
            chatKeys.add(k);
          }
        });

        // Deep merge offers
        const oldOffers = existing.offers || [];
        const newOffers = item.offers || [];
        const offerIds = new Set(newOffers.map((o: any) => String(o.id)));
        const mergedOffers = [...newOffers];

        oldOffers.forEach((o: any) => {
          if (!offerIds.has(String(o.id))) {
            mergedOffers.push(o);
            offerIds.add(String(o.id));
          } else {
            const idx = mergedOffers.findIndex(x => String(x.id) === String(o.id));
            if (idx !== -1) mergedOffers[idx] = { ...mergedOffers[idx], ...o };
          }
        });

        mergedMap.set(id, {
          ...existing,
          ...item,
          chat: mergedChat,
          offers: mergedOffers,
          status: (existing.status === 'completed' || existing.status === 'approved') && item.status === 'pending'
            ? existing.status 
            : item.status,
          chatClosed: existing.chatClosed || item.chatClosed
        });
      } else {
        mergedMap.set(id, { ...existing, ...item });
      }
    });

    // Preserve items in oldList (server DB) that are NOT in newList AND NOT in deletedSet
    oldMap.forEach((oldItem, id) => {
      if (!mergedMap.has(id) && !deletedSet.has(id)) {
        mergedMap.set(id, oldItem);
      }
    });

    const result = Array.from(mergedMap.values());

    // Maintenance of developer account
    const hasDev = result.some(u => u && u.email === devEmail);
    if (key === 'users' && !hasDev) {
      const devInOld = Array.isArray(oldList) ? oldList.find(u => u && u.email === devEmail) : null;
      if (devInOld) {
        result.push(devInOld);
      } else {
        result.push({
          id: 'USR-DEV-ALI', 
          name: 'Ali Aneed', 
          email: 'ali.aneed', 
          role: 'admin', 
          company: 'AIRLINK', 
          avatar: null, 
          password: '7941631'
        });
      }
    }

    return result;
  };

  // API Routes for Central Data Synchronization
  const apiRouter = express.Router();

  apiRouter.get('/db', async (req, res) => {
    try {
      if (!memoryCache) {
        const cloudData = await fetchFromCloud();
        if (cloudData) {
          memoryCache = cloudData;
          lastCloudFetchTime = Date.now();
          try { fs.writeFileSync(DB_PATH, JSON.stringify(memoryCache, null, 2)); } catch(e) {}
        }
      }

      if (!memoryCache) {
        memoryCache = loadDatabase();
      }

      res.json({ ...memoryCache, serverTime: Date.now() });
    } catch (error) {
      console.error('API Error /db GET:', error);
      res.status(500).json({ error: 'Failed to read database' });
    }
  });

  apiRouter.post('/db', async (req, res) => {
    try {
      const newData = req.body;
      
      if (!newData || typeof newData !== 'object') {
        console.error('[POST /db] Received invalid or null payload');
        return res.status(400).json({ error: 'Invalid database payload received' });
      }

      const clientTime = parseInt(newData.clientLastSync || 0);
      const deletedIds = Array.isArray(newData.deletedIds) ? newData.deletedIds : [];

      // Load existing data for conflict detection
      let currentData: any = memoryCache || loadDatabase();
      let serverTime = Date.now();

      if ((!currentData.users || currentData.users.length === 0) && (Date.now() - lastCloudFetchTime > 2000)) {
        const cloudData = await fetchFromCloud();
        if (cloudData) {
          currentData = cloudData;
          lastCloudFetchTime = Date.now();
        }
      }

      // Conflict resolution: 
      // Safe merge utilizing top-level safeMerge function with deletedIds support
      const finalData = {
        users: safeMerge(currentData.users, newData.users, 'users', deletedIds),
        requests: safeMerge(currentData.requests, newData.requests, 'requests', deletedIds),
        transactions: safeMerge(currentData.transactions, newData.transactions, 'transactions', deletedIds),
        companies: safeMerge(currentData.companies, newData.companies, 'companies', deletedIds),
        suppliers: safeMerge(currentData.suppliers, newData.suppliers, 'suppliers', deletedIds),
        notifications: Array.isArray(newData.notifications) ? (clientTime === 0 && newData.notifications.length === 0 ? currentData.notifications : newData.notifications.slice(-400)) : currentData.notifications,
        logs: Array.isArray(newData.logs) ? (clientTime === 0 && newData.logs.length === 0 ? (currentData.logs || []) : newData.logs.slice(-500)) : (currentData.logs || []),
        settings: { ...currentData.settings, ...newData.settings }
      };

      memoryCache = finalData;

      createBackup();
      const TEMP_PATH = DB_PATH + '.tmp';
      fs.writeFileSync(TEMP_PATH, JSON.stringify(finalData, null, 2));
      fs.renameSync(TEMP_PATH, DB_PATH);

      await pushToCloud(finalData);
      
      const newStats = fs.statSync(DB_PATH);
      res.json({ success: true, serverTime: newStats.mtime.getTime() });
    } catch (error) {
      console.error('Database write error:', error);
      res.status(500).json({ error: 'Failed to save database' });
    }
  });

  apiRouter.get('/health', (req, res) => {
    res.json({ status: 'Airlink Tickets Server is Healthy' });
  });

  // Backup Endpoints for Full System Backup & Recovery
  apiRouter.get('/backups', (req, res) => {
    try {
      if (!fs.existsSync(BACKUP_DIR)) {
        fs.mkdirSync(BACKUP_DIR, { recursive: true });
      }
      const files = fs.readdirSync(BACKUP_DIR)
        .filter(f => f.endsWith('.json'))
        .map(f => {
          const filePath = path.join(BACKUP_DIR, f);
          const stats = fs.statSync(filePath);
          return {
            filename: f,
            size: stats.size,
            mtime: stats.mtime.getTime(),
            date: stats.mtime.toISOString()
          };
        })
        .sort((a, b) => b.mtime - a.mtime);
      res.json({ backups: files });
    } catch (err: any) {
      console.error('Failed to list backups:', err);
      res.status(500).json({ error: 'Failed to retrieve backups list' });
    }
  });

  apiRouter.post('/backups/create', (req, res) => {
    try {
      if (!fs.existsSync(BACKUP_DIR)) {
        fs.mkdirSync(BACKUP_DIR, { recursive: true });
      }
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const backupPath = path.join(BACKUP_DIR, `manual-backup-${timestamp}.json`);
      if (fs.existsSync(DB_PATH)) {
        fs.copyFileSync(DB_PATH, backupPath);
      } else {
        const defaultData = loadDatabase();
        fs.writeFileSync(backupPath, JSON.stringify(defaultData, null, 2));
      }
      res.json({ success: true, filename: `manual-backup-${timestamp}.json`, time: Date.now() });
    } catch (err: any) {
      console.error('Failed to create manual backup:', err);
      res.status(500).json({ error: 'Failed to create backup' });
    }
  });

  apiRouter.get('/backups/download/:filename', (req, res) => {
    try {
      const filename = path.basename(req.params.filename);
      const filePath = path.join(BACKUP_DIR, filename);
      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ error: 'Backup file not found' });
      }
      res.download(filePath, filename);
    } catch (err: any) {
      console.error('Failed to download backup:', err);
      res.status(500).json({ error: 'Download failed' });
    }
  });

  apiRouter.post('/backups/restore', (req, res) => {
    try {
      const backupData = req.body.data || req.body;
      if (!backupData || typeof backupData !== 'object') {
        return res.status(400).json({ error: 'Invalid backup payload' });
      }
      // Safety backup current database before restoring
      createBackup();
      
      const TEMP_PATH = DB_PATH + '.tmp';
      fs.writeFileSync(TEMP_PATH, JSON.stringify(backupData, null, 2));
      fs.renameSync(TEMP_PATH, DB_PATH);

      res.json({ success: true, message: 'Database restored successfully', serverTime: Date.now() });
    } catch (err: any) {
      console.error('Failed to restore backup:', err);
      res.status(500).json({ error: 'Failed to restore database' });
    }
  });

  app.use('/api', apiRouter);

  // Global Error Handler (Surgery: Catching all unhandled errors to prevent crashes)
  app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
    console.error('[Global Error]:', err);
    if (res.headersSent) {
      return next(err);
    }
    res.status(err.status || 500).json({
      error: 'An internal server error occurred',
      message: err.message
    });
  });

  if (process.env.NODE_ENV !== 'production') {
    // Development mode: Use Vite as middleware
    console.log('Starting in DEVELOPMENT mode...');
    const vite = await createViteServer({
      server: { 
        middlewareMode: true,
        host: '0.0.0.0'
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Production mode: Serve static files from 'dist'
    console.log('Starting in PRODUCTION mode...');
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  // Listen on 0.0.0.0 to allow access from local network (other PCs)
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`\n=================================================`);
    console.log(`🚀 Airlink Tickets Server is running!`);
    console.log(`📡 Local: http://localhost:${PORT}`);
    console.log(`🌐 Network: http://<YOUR_PC_IP_ADDRESS>:${PORT}`);
    console.log(`=================================================\n`);
    console.log(`To find your PC IP Address, run 'ipconfig' in your terminal.`);
  });
}

startServer();

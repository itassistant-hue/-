import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_DIR = path.join(__dirname, 'data');
const DB_PATH = path.join(DATA_DIR, 'db.json');
const BACKUP_DIR = path.join(DATA_DIR, 'backups');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

if (!fs.existsSync(DB_PATH)) {
  fs.writeFileSync(DB_PATH, JSON.stringify({
    users: [],
    requests: [],
    transactions: [],
    companies: [],
    suppliers: [],
    settings: {},
    notifications: [],
    logs: []
  }, null, 2));
}

if (!fs.existsSync(BACKUP_DIR)) {
  fs.mkdirSync(BACKUP_DIR, { recursive: true });
}

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.use(express.json({ limit: '100mb' }));

// Persistent Cloud Sync Manager for Cloud Run container resilience
const DEFAULT_CLOUD_URL = 'https://api.restful-api.dev/objects/ff8081819f7e10ae019fbd3dc46e5c5b';
const CLOUD_ID_FILES = [
  path.join(DATA_DIR, 'cloud_sync_id.txt'),
  '/tmp/cloud_sync_id.txt'
];

let activeCloudSyncUrl = (() => {
  for (const f of CLOUD_ID_FILES) {
    try {
      if (fs.existsSync(f)) {
        const id = fs.readFileSync(f, 'utf8').trim();
        if (id && id.length > 5) {
          return id.startsWith('http') ? id : `https://api.restful-api.dev/objects/${id}`;
        }
      }
    } catch(e) {}
  }
  return DEFAULT_CLOUD_URL;
})();

const saveActiveCloudUrl = (url) => {
  activeCloudSyncUrl = url;
  const id = url.split('/').pop() || url;
  for (const f of CLOUD_ID_FILES) {
    try {
      const parent = path.dirname(f);
      if (!fs.existsSync(parent)) fs.mkdirSync(parent, { recursive: true });
      fs.writeFileSync(f, id, 'utf8');
    } catch(e) {}
  }
};

const createNewCloudObject = async (data) => {
  try {
    const res = await fetch('https://api.restful-api.dev/objects', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'airlink_tickets_prod_db_v1',
        data: data || { users: [], requests: [], transactions: [], companies: [], suppliers: [], settings: {}, notifications: [], logs: [] }
      })
    });
    if (res.ok) {
      const json = await res.json();
      if (json && json.id) {
        const newUrl = `https://api.restful-api.dev/objects/${json.id}`;
        saveActiveCloudUrl(newUrl);
        console.log('[Production Cloud Sync] Created cloud database store with ID:', json.id);
        return newUrl;
      }
    }
  } catch(e) {}
  return null;
};

let memoryCache = null;
let lastCloudFetchTime = 0;

const fetchFromCloud = async () => {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 3500);
    const res = await fetch(activeCloudSyncUrl, { signal: controller.signal });
    clearTimeout(timeoutId);
    if (res.ok) {
      const json = await res.json();
      if (json && json.data && typeof json.data === 'object') {
        return json.data;
      }
    } else if (res.status === 404 || res.status === 400) {
      console.warn('[Production Cloud Sync] Active cloud object expired/404. Attempting auto-recreation...');
    }
  } catch (err) {}
  return null;
};

const pushToCloud = async (data) => {
  try {
    const res = await fetch(activeCloudSyncUrl, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'airlink_tickets_prod_db_v1',
        data: data
      })
    });
    if (res.status === 404 || res.status === 400) {
      console.warn('[Production Cloud Sync] PUT returned 404 (expired object). Recreating cloud object...');
      await createNewCloudObject(data);
    }
  } catch (err) {}
};

const loadDatabase = () => {
  const DEFAULT_DATA = { users: [], requests: [], transactions: [], companies: [], suppliers: [], settings: {}, notifications: [], logs: [] };
  
  const candidatePaths = [
    DB_PATH,
    '/tmp/data/db.json',
    path.join(process.cwd(), 'data', 'db.json'),
    '/tmp/db.json'
  ];

  let bestData = DEFAULT_DATA;
  let maxRecords = -1;

  for (const p of candidatePaths) {
    try {
      if (fs.existsSync(p)) {
        const content = fs.readFileSync(p, 'utf8');
        if (content.trim()) {
          const parsed = JSON.parse(content);
          const recordCount = (Array.isArray(parsed.users) ? parsed.users.length : 0) + 
                              (Array.isArray(parsed.requests) ? parsed.requests.length : 0);
          if (recordCount > maxRecords) {
            maxRecords = recordCount;
            bestData = parsed;
          }
        }
      }
    } catch(e) {}
  }

  if (maxRecords <= 0) {
    const backupDirs = [BACKUP_DIR, '/tmp/data/backups', path.join(process.cwd(), 'data', 'backups')];
    for (const bDir of backupDirs) {
      try {
        if (fs.existsSync(bDir)) {
          const files = fs.readdirSync(bDir).filter(f => f.endsWith('.json')).reverse();
          for (const f of files.slice(0, 10)) {
            const content = fs.readFileSync(path.join(bDir, f), 'utf8');
            if (content.trim()) {
              const parsed = JSON.parse(content);
              const recordCount = (Array.isArray(parsed.users) ? parsed.users.length : 0) + 
                                  (Array.isArray(parsed.requests) ? parsed.requests.length : 0);
              if (recordCount > maxRecords) {
                maxRecords = recordCount;
                bestData = parsed;
              }
            }
          }
        }
      } catch(e) {}
    }
  }

  return bestData;
};

const safeMerge = (oldList = [], newList = [], key) => {
  if (!Array.isArray(newList)) return oldList || [];

  const devEmail = 'ali.aneed';
  const oldMap = new Map();
  if (Array.isArray(oldList)) {
    oldList.forEach(item => { if (item && item.id) oldMap.set(String(item.id), item); });
  }

  const result = [...newList];

  const hasDev = result.some(u => u && u.email === devEmail);
  if (key === 'users' && !hasDev) {
    const devInOld = Array.isArray(oldList) ? oldList.find(u => u && u.email === devEmail) : null;
    if (devInOld) {
      result.push(devInOld);
    } else {
      result.push({
        id: 'USR-DEV-ALI', 
        name: 'Ali Aneed', 
        email: 'ali.aneed', 
        role: 'admin', 
        company: 'AIRLINK', 
        avatar: null, 
        password: '7941631'
      });
    }
  }

  return result.map(item => {
    if (!item || !item.id) return item;
    const existing = oldMap.get(String(item.id));
    if (!existing) return item;

    if (key === 'requests') {
      const oldChat = existing.chat || [];
      const newChat = item.chat || [];
      const chatKeys = new Set(newChat.map((c) => c.id || `${c.sender}-${c.text}-${c.file?.name || ''}`));
      const mergedChat = [...newChat];

      oldChat.forEach((c) => {
        const k = c.id || `${c.sender}-${c.text}-${c.file?.name || ''}`;
        if (!chatKeys.has(k)) {
          mergedChat.push(c);
          chatKeys.add(k);
        }
      });

      const oldOffers = existing.offers || [];
      const newOffers = item.offers || [];
      const offerIds = new Set(newOffers.map((o) => String(o.id)));
      const mergedOffers = [...newOffers];

      oldOffers.forEach((o) => {
        if (!offerIds.has(String(o.id))) {
          mergedOffers.push(o);
          offerIds.add(String(o.id));
        } else {
          const idx = mergedOffers.findIndex(x => String(x.id) === String(o.id));
          if (idx !== -1) mergedOffers[idx] = { ...mergedOffers[idx], ...o };
        }
      });

      return {
        ...existing,
        ...item,
        chat: mergedChat,
        offers: mergedOffers,
        status: (existing.status === 'completed' || existing.status === 'approved') && item.status === 'pending'
          ? existing.status
          : item.status,
        chatClosed: existing.chatClosed || item.chatClosed
      };
    }

    return { ...existing, ...item };
  });
};

// API Routes
app.get('/api/db', async (req, res) => {
  try {
    if (!memoryCache) {
      const cloudData = await fetchFromCloud();
      if (cloudData) {
        memoryCache = cloudData;
        lastCloudFetchTime = Date.now();
        try { fs.writeFileSync(DB_PATH, JSON.stringify(memoryCache, null, 2)); } catch(e) {}
      }
    }

    if (!memoryCache) {
      memoryCache = loadDatabase();
    }

    res.json({ ...memoryCache, serverTime: Date.now() });
  } catch (error) {
    res.status(500).json({ error: 'Failed to read database' });
  }
});

app.post('/api/db', async (req, res) => {
  try {
    const newData = req.body;
    if (!newData || typeof newData !== 'object') {
      return res.status(400).json({ error: 'Invalid database payload' });
    }

    let currentData = memoryCache || loadDatabase();
    if ((!currentData.users || currentData.users.length === 0) && (Date.now() - lastCloudFetchTime > 2000)) {
      const cloudData = await fetchFromCloud();
      if (cloudData) {
        currentData = cloudData;
        lastCloudFetchTime = Date.now();
      }
    }

    const finalData = {
      users: safeMerge(currentData.users, newData.users, 'users'),
      requests: safeMerge(currentData.requests, newData.requests, 'requests'),
      transactions: safeMerge(currentData.transactions, newData.transactions, 'transactions'),
      companies: safeMerge(currentData.companies, newData.companies, 'companies'),
      suppliers: safeMerge(currentData.suppliers, newData.suppliers, 'suppliers'),
      settings: { ...(currentData.settings || {}), ...(newData.settings || {}) },
      notifications: safeMerge(currentData.notifications, newData.notifications, 'notifications'),
      logs: safeMerge(currentData.logs, newData.logs, 'logs')
    };

    memoryCache = finalData;

    try {
      fs.writeFileSync(DB_PATH, JSON.stringify(finalData, null, 2));
    } catch(e) {}

    await pushToCloud(finalData);

    res.json({ success: true, serverTime: Date.now() });
  } catch (error) {
    res.status(500).json({ error: 'Failed to save database' });
  }
});

app.get('/api/health', (req, res) => {
  res.json({ status: 'Airlink Tickets Production Server is Healthy' });
});

// Serve static files from dist
app.use(express.static(path.join(__dirname, 'dist')));

// SPA Routing Fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`--------------------------------------------------`);
  console.log(`🚀 AIRLINK Full-Stack Server is Running!`);
  console.log(`Access it at: http://localhost:${PORT}`);
  console.log(`--------------------------------------------------`);
});
